package com.thecomplex;

import com.thecomplex.block.ArchPieceBlock;
import com.thecomplex.block.DuctAnchorBlock;
import com.thecomplex.block.DuctTapeBlock;
import com.thecomplex.block.FlashlightGlowBlock;
import com.thecomplex.block.LpmdsBlock;
import com.thecomplex.block.ArchBlock;
import com.thecomplex.block.HalfPillarBlock;
import com.thecomplex.block.HalfWallBlock;
import com.thecomplex.block.LpmdsChuteBlock;
import com.thecomplex.block.PillarBlock;
import com.thecomplex.block.VerticalSlabBlock;
import com.thecomplex.block.WedgeBlock;
import com.thecomplex.block.NullZoneBlock;
import com.thecomplex.block.ThresholdBlock;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SlabBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.function.Supplier;

public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, TheComplex.MODID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, TheComplex.MODID);

    public static final RegistryObject<Block> WALLPAPER = reg("wallpaper",
            () -> new Block(props(MapColor.COLOR_YELLOW, SoundType.STONE).strength(1.5f, 6f)));
    public static final RegistryObject<Block> CARPET_FLOOR = reg("carpet_floor",
            () -> new Block(props(MapColor.COLOR_BROWN, SoundType.WOOL).strength(0.8f)));
    public static final RegistryObject<Block> CEILING_TILE = reg("ceiling_tile",
            () -> new Block(props(MapColor.SAND, SoundType.STONE).strength(0.8f)));
    public static final RegistryObject<Block> FLUORESCENT_PANEL = reg("fluorescent_panel",
            () -> new Block(props(MapColor.QUARTZ, SoundType.GLASS).strength(0.5f).lightLevel(s -> 15)));

    /** Tampak persis seperti wallpaper, tapi tanpa collision: pemain bisa jatuh tembus. */
    public static final RegistryObject<Block> NULL_ZONE = reg("null_zone",
            () -> new NullZoneBlock(props(MapColor.COLOR_YELLOW, SoundType.STONE).strength(1.5f)
                    .noCollission()
                    .isSuffocating((s, l, p) -> false)
                    .isViewBlocking((s, l, p) -> false)));

    /** Null Zone stabil, dibuka oleh LPMDS (dan satu permanen di Main Chamber sebagai jalan pulang). */
    public static final RegistryObject<Block> THRESHOLD = reg("threshold",
            () -> new ThresholdBlock(props(MapColor.COLOR_YELLOW, SoundType.GLASS).strength(-1f, 3600000f)
                    .noCollission().noOcclusion().noLootTable()
                    .lightLevel(s -> 9)
                    .isSuffocating((s, l, p) -> false)
                    .isViewBlocking((s, l, p) -> false)));

    public static final RegistryObject<Block> LPMDS = reg("lpmds",
            () -> new LpmdsBlock(props(MapColor.METAL, SoundType.METAL).strength(4f, 1200f)
                    .lightLevel(s -> s.getValue(LpmdsBlock.ACTIVE) ? 10 : 3)));

    /** Modul pengarah medan LPMDS: menempel di sisi mesin, dapat diputar 16 langkah. */
    public static final RegistryObject<Block> LPMDS_CHUTE = reg("lpmds_chute",
            () -> new LpmdsChuteBlock(props(MapColor.METAL, SoundType.METAL).strength(3f, 600f).noOcclusion()));

    /** Titik awal/akhir Duct Tape (placeholder model: Grindstone). */
    public static final RegistryObject<Block> DUCT_ANCHOR = reg("duct_anchor",
            () -> new DuctAnchorBlock(props(MapColor.METAL, SoundType.METAL).strength(1.5f, 6f).noOcclusion()));

    /** Satu petak Duct Tape di lantai (seperti Redstone). Tanpa item: dipasang oleh Duct Tape saat berjalan. */
    public static final RegistryObject<Block> DUCT_TAPE_STRIP = BLOCKS.register("duct_tape_strip",
            () -> new DuctTapeBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_LIGHT_GRAY).noCollission().noOcclusion()
                    .instabreak().sound(SoundType.WOOL).pushReaction(PushReaction.DESTROY).noLootTable()));

    /** Cahaya senter: tak terlihat, tanpa tabrakan, tanpa item. Dibuat/dihapus oleh FlashlightEvents. */
    public static final RegistryObject<Block> FLASHLIGHT_GLOW = BLOCKS.register("flashlight_glow",
            () -> new FlashlightGlowBlock(BlockBehaviour.Properties.of().replaceable().noCollission().noOcclusion()
                    .noLootTable().strength(-1f, 3600000f).pushReaction(PushReaction.DESTROY)
                    .lightLevel(s -> s.getValue(FlashlightGlowBlock.LEVEL))));

    // ------------------------------------------------------------------ blok bangunan
    // Setiap permukaan kuning punya tepat dua varian: "wallpaper" (klasik, ber-motif) dan "office_wall" (polos, kuning lebih terang).

    public static final RegistryObject<Block> OFFICE_WALL = reg("office_wall", () -> new Block(yellow()));
    public static final RegistryObject<Block> WHITE_WALL = reg("white_wall", () -> new Block(white()));

    public static final RegistryObject<Block> WALLPAPER_SLAB = reg("wallpaper_slab", () -> new SlabBlock(yellow()));
    public static final RegistryObject<Block> OFFICE_WALL_SLAB = reg("office_wall_slab", () -> new SlabBlock(yellow()));

    public static final RegistryObject<Block> WALLPAPER_VERTICAL_SLAB = reg("wallpaper_vertical_slab", () -> new VerticalSlabBlock(yellow()));
    public static final RegistryObject<Block> OFFICE_WALL_VERTICAL_SLAB = reg("office_wall_vertical_slab", () -> new VerticalSlabBlock(yellow()));

    public static final RegistryObject<Block> WALLPAPER_ARCH = reg("wallpaper_arch", () -> new ArchBlock(yellow()));
    public static final RegistryObject<Block> OFFICE_WALL_ARCH = reg("office_wall_arch", () -> new ArchBlock(yellow()));

    /** The two-block arch: Left and Right pieces go side by side over a doorway. */
    public static final RegistryObject<Block> WALLPAPER_ARCH_LEFT = reg("wallpaper_arch_left", () -> new ArchPieceBlock(yellow(), true));
    public static final RegistryObject<Block> WALLPAPER_ARCH_RIGHT = reg("wallpaper_arch_right", () -> new ArchPieceBlock(yellow(), false));
    public static final RegistryObject<Block> OFFICE_WALL_ARCH_LEFT = reg("office_wall_arch_left", () -> new ArchPieceBlock(yellow(), true));
    public static final RegistryObject<Block> OFFICE_WALL_ARCH_RIGHT = reg("office_wall_arch_right", () -> new ArchPieceBlock(yellow(), false));

    public static final RegistryObject<Block> WALLPAPER_WEDGE = reg("wallpaper_wedge", () -> new WedgeBlock(yellow()));
    public static final RegistryObject<Block> OFFICE_WALL_WEDGE = reg("office_wall_wedge", () -> new WedgeBlock(yellow()));
    public static final RegistryObject<Block> CARPET_WEDGE = reg("carpet_wedge",
            () -> new WedgeBlock(props(MapColor.COLOR_BROWN, SoundType.WOOL).strength(0.8f)));

    public static final RegistryObject<Block> WALLPAPER_PILLAR = reg("wallpaper_pillar", () -> new PillarBlock(yellow()));
    public static final RegistryObject<Block> OFFICE_WALL_PILLAR = reg("office_wall_pillar", () -> new PillarBlock(yellow()));

    public static final RegistryObject<Block> WALLPAPER_HALF_PILLAR = reg("wallpaper_half_pillar", () -> new HalfPillarBlock(yellow()));
    public static final RegistryObject<Block> OFFICE_WALL_HALF_PILLAR = reg("office_wall_half_pillar", () -> new HalfPillarBlock(yellow()));

    public static final RegistryObject<Block> WALLPAPER_HALF_WALL = reg("wallpaper_half_wall", () -> new HalfWallBlock(yellow().forceSolidOn()));
    public static final RegistryObject<Block> OFFICE_WALL_HALF_WALL = reg("office_wall_half_wall", () -> new HalfWallBlock(yellow().forceSolidOn()));

    private static BlockBehaviour.Properties yellow() {
        return props(MapColor.COLOR_YELLOW, SoundType.STONE).strength(1.5f, 6f);
    }

    private static BlockBehaviour.Properties white() {
        return props(MapColor.SNOW, SoundType.STONE).strength(1.5f, 6f);
    }

    private static BlockBehaviour.Properties props(MapColor color, SoundType sound) {
        return BlockBehaviour.Properties.of().mapColor(color).sound(sound);
    }

    private static RegistryObject<Block> reg(String name, Supplier<Block> sup) {
        RegistryObject<Block> o = BLOCKS.register(name, sup);
        if (name.equals("null_zone")) {
            ITEMS.register(name, () -> new com.thecomplex.block.NullZoneItem(o.get(), new Item.Properties()));   // special: converts the clicked block
        } else {
            ITEMS.register(name, () -> new BlockItem(o.get(), new Item.Properties()));
        }
        return o;
    }

    private ModBlocks() {}
}
