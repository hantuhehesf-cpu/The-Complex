package com.thecomplex.client;

import com.thecomplex.ModBlocks;
import com.thecomplex.TheComplex;
import com.thecomplex.net.Net;
import com.thecomplex.net.RemoteInteractPacket;
import com.thecomplex.portal.RemoteInteract;
import net.minecraft.client.Minecraft;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Clicks that go through a Threshold (v1.10): attack (hold to mine), and use / place. While the crosshair is inside the see-through
 * window and nothing real is closer, the click is sent to the server (see RemoteInteract) instead of hitting the frame blocks.
 */
@Mod.EventBusSubscriber(modid = TheComplex.MODID, value = Dist.CLIENT)
public final class RemoteInteractClient {
    private static boolean mining;

    private RemoteInteractClient() {}

    /** The window the crosshair looks through, or null. */
    private static PortalViewClient.Window through(Minecraft mc) {
        PortalViewClient.Window w = PortalViewClient.window();
        if (w == null || mc.player == null || mc.level == null) return null;
        Vec3 eye = mc.player.getEyePosition(), look = mc.player.getViewVector(1f);
        Vec3 n = w.axisX() ? new Vec3(1, 0, 0) : new Vec3(0, 0, 1);
        double denom = look.dot(n);
        if (Math.abs(denom) < 1.0E-4) return null;
        double t = w.center().subtract(eye).dot(n) / denom;
        if (t <= 0 || t > 5.0) return null;
        Vec3 rel = eye.add(look.scale(t)).subtract(w.center());
        double lat = w.axisX() ? rel.z : rel.x;
        if (Math.abs(lat) > w.halfW() + 0.1 || Math.abs(rel.y) > w.halfH() + 0.1) return null;
        HitResult hr = mc.hitResult;
        if (hr != null && hr.getType() != HitResult.Type.MISS) {
            boolean frame = hr instanceof BlockHitResult b && mc.level.getBlockState(b.getBlockPos()).is(ModBlocks.THRESHOLD.get());
            if (!frame && eye.distanceTo(hr.getLocation()) < t - 0.15) return null;      // something real is in front of the opening
        }
        return w;
    }

    @SubscribeEvent
    public static void onInteract(InputEvent.InteractionKeyMappingTriggered e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.screen != null) return;
        if (!e.isAttack() && !e.isUseItem()) return;
        PortalViewClient.Window w = through(mc);
        if (w == null) return;
        e.setCanceled(true);
        e.setSwingHand(false);
        mc.player.swing(e.getHand());
        int hand = e.getHand() == InteractionHand.MAIN_HAND ? 0 : 1;
        if (e.isAttack()) {
            Net.CHANNEL.sendToServer(new RemoteInteractPacket(RemoteInteract.ATTACK, hand, w.key()));
            mining = true;
        } else {
            Net.CHANNEL.sendToServer(new RemoteInteractPacket(RemoteInteract.USE, hand, w.key()));
        }
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) {
            mining = false;
            return;
        }
        if (!mining) return;
        PortalViewClient.Window w = mc.screen == null && mc.options.keyAttack.isDown() ? through(mc) : null;
        if (e.phase == TickEvent.Phase.START) {
            // vanilla would start mining the frame blocks under the crosshair while the button is held: hide them from it
            if (w != null) mc.hitResult = BlockHitResult.miss(mc.player.getEyePosition(), Direction.UP, mc.player.blockPosition());
        } else if (w != null) {
            Net.CHANNEL.sendToServer(new RemoteInteractPacket(RemoteInteract.MINE, 0, w.key()));
        } else {
            mining = false;
            Net.CHANNEL.sendToServer(new RemoteInteractPacket(RemoteInteract.MINE_STOP, 0, 0L));
        }
    }
}
