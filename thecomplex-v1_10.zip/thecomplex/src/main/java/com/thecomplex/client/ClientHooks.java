package com.thecomplex.client;

import com.thecomplex.briefcase.BriefcaseSessions;
import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompoundTag;

import java.util.List;

public final class ClientHooks {
    private ClientHooks() {}

    public static void openDev(String status, List<String> rooms, List<String> zones, String note) {
        Minecraft.getInstance().setScreen(new DevScreen(status, rooms, zones, note));
    }

    public static void briefcaseSync(int mode, int rows, CompoundTag data) {
        Minecraft mc = Minecraft.getInstance();
        if (mode == BriefcaseSessions.MODE_OPEN) {
            ThrowClient.cancel();
            mc.setScreen(new BriefcaseScreen(rows, data));
        } else if (mc.screen instanceof BriefcaseScreen s) {
            s.update(rows, data);
        }
    }
}
