package com.thecomplex.client;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.pipeline.TextureTarget;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.thecomplex.TheComplex;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.ProgressScreen;
import net.minecraft.client.gui.screens.ReceivingLevelScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.util.Mth;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import com.thecomplex.ModBlocks;
import com.thecomplex.block.NullZoneBlockEntity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix4f;

/**
 * Sisi klien perpindahan mulus lewat portal.
 *  - Layar loading ("Loading terrain") disembunyikan selama beberapa detik sesudah server memberi tahu ada perpindahan.
 *  - Bingkai terakhir sebelum pindah disimpan ke tekstur dan ditampilkan sebentar lalu memudar ke dunia baru
 *    (pada Threshold, bingkai itu hampir sama dengan pemandangan di seberang, jadi terasa menyambung).
 * Kalau penyimpanan bingkai gagal, dipakai pemudar warna polos.
 */
@Mod.EventBusSubscriber(modid = TheComplex.MODID, value = Dist.CLIENT)
public final class SeamlessClient {
    private static final long HOLD_MS = 240;
    private static final long FADE_MS = 520;
    private static final long ARM_MS = 6000;

    /** Same value as Seamless.STYLE_NULL_ZONE (not referenced directly: that class lives on the server side). */
    private static final int STYLE_NULL_ZONE = 1;
    /** Null Zone white flash: instant white, held until the new world is loaded (at least FLASH_MIN_HOLD_MS, at most FLASH_MAX_HOLD_MS), then a fast fade. */
    private static final long FLASH_RISE_MS = 40;
    private static final long FLASH_MIN_HOLD_MS = 120;
    private static final long FLASH_MAX_HOLD_MS = 1500;
    private static final long FLASH_FADE_MS = 520;

    private static TextureTarget freeze;
    private static boolean freezeValid;
    private static long armedUntil;
    private static long startMs;
    private static int style;
    private static boolean flash;
    private static Level flashFromLevel;
    private static long flashReadyMs;
    /** v1.10: the block an unstable Null Zone pretends to be, while the player's eyes are inside it (the "suffocated in a block" view). */
    private static BlockState insideState;
    private static long insideSeenMs;
    private static BlockState holdState;

    private SeamlessClient() {}

    /** Dipanggil saat paket dari server tiba (tepat sebelum paket pindah dimensi). */
    public static void begin(int s) {
        Minecraft mc = Minecraft.getInstance();
        style = s;
        long now = Util.getMillis();
        armedUntil = now + ARM_MS;
        startMs = now;
        flash = s == STYLE_NULL_ZONE;
        holdState = flash && insideState != null && now - insideSeenMs < 400 ? insideState : null;
        flashFromLevel = mc.level;
        flashReadyMs = 0;
        if (flash) {
            freezeValid = false;           // a Null Zone never shows a frozen old frame: it is a white flash instead
        } else {
            capture(mc);
        }
        PortalViewClient.onTeleport();
    }

    private static void capture(Minecraft mc) {
        freezeValid = false;
        try {
            RenderTarget main = mc.getMainRenderTarget();
            int w = main.width, h = main.height;
            if (w <= 0 || h <= 0) return;
            if (freeze == null || freeze.width != w || freeze.height != h) {
                if (freeze != null) freeze.destroyBuffers();
                freeze = new TextureTarget(w, h, false, Minecraft.ON_OSX);
            }
            freeze.bindWrite(false);
            main.blitToScreen(w, h);
            main.bindWrite(true);
            freezeValid = true;
        } catch (Throwable t) {
            freezeValid = false;
            TheComplex.LOGGER.warn("Seamless: could not store the last frame, using a plain fade instead", t);
        }
    }

    /** Sembunyikan layar loading yang dibuat game saat dimensi berganti. */
    @SubscribeEvent
    public static void onScreen(ScreenEvent.Opening e) {
        if (Util.getMillis() > armedUntil) return;
        Screen s = e.getNewScreen();
        if (s instanceof ReceivingLevelScreen || s instanceof ProgressScreen) e.setNewScreen(null);
    }

    /** Digambar di bawah HUD. */
    public static void drawOverlay(GuiGraphics g, int w, int h) {
        updateInside(Minecraft.getInstance());
        if (startMs == 0) {
            if (insideState != null && Util.getMillis() - insideSeenMs < 150) suffocate(g, w, h, insideState, 0.5f);
            return;
        }
        if (flash) {
            drawFlash(g, w, h);
            return;
        }
        long age = Util.getMillis() - startMs;
        if (age > HOLD_MS + FADE_MS) return;
        float a = age <= HOLD_MS ? 1f : 1f - (age - HOLD_MS) / (float) FADE_MS;
        a = Mth.clamp(a, 0f, 1f);
        a = a * a * (3f - 2f * a);
        if (!freezeValid || freeze == null) {
            int color = style == 0 ? 0xF0EBCB : 0x000000;
            g.fill(0, 0, w, h, ((int) (a * 255f) << 24) | color);
            return;
        }
        try {
            Matrix4f m = g.pose().last().pose();
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.disableDepthTest();
            RenderSystem.setShader(GameRenderer::getPositionTexColorShader);
            RenderSystem.setShaderTexture(0, freeze.getColorTextureId());
            BufferBuilder bb = Tesselator.getInstance().getBuilder();
            bb.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_TEX_COLOR);
            bb.vertex(m, 0, 0, 0).uv(0f, 1f).color(1f, 1f, 1f, a).endVertex();
            bb.vertex(m, 0, h, 0).uv(0f, 0f).color(1f, 1f, 1f, a).endVertex();
            bb.vertex(m, w, h, 0).uv(1f, 0f).color(1f, 1f, 1f, a).endVertex();
            bb.vertex(m, w, 0, 0).uv(1f, 1f).color(1f, 1f, 1f, a).endVertex();
            BufferUploader.drawWithShader(bb.end());
            RenderSystem.enableDepthTest();
            RenderSystem.disableBlend();
        } catch (Throwable t) {
            freezeValid = false;
            TheComplex.LOGGER.warn("Seamless: drawing the stored frame failed, using a plain fade from now on", t);
        }
    }

    /**
     * Null Zone entry: a quick white flash. White at once (rise 40 ms), held while the new world is still arriving,
     * then a fast fade. "Arrived" = the client level changed and the chunk under the player is loaded.
     */
    private static void drawFlash(GuiGraphics g, int w, int h) {
        long now = Util.getMillis();
        long age = now - startMs;
        if (flashReadyMs == 0) {
            Minecraft mc = Minecraft.getInstance();
            boolean arrived = mc.level != null && mc.level != flashFromLevel && mc.player != null
                    && mc.level.hasChunkAt(mc.player.blockPosition());
            if ((arrived && age >= FLASH_MIN_HOLD_MS) || age >= FLASH_MAX_HOLD_MS) flashReadyMs = now;
        }
        float a;
        if (flashReadyMs == 0) {
            if (holdState != null) {                       // eyes were inside the block: keep the dark block texture until the new world is there
                suffocate(g, w, h, holdState, 0.9f);
                return;
            }
            a = Mth.clamp(age / (float) FLASH_RISE_MS, 0f, 1f);
        } else {
            float t = (now - flashReadyMs) / (float) FLASH_FADE_MS;
            if (t >= 1f) {
                startMs = 0;               // finished
                flash = false;
                holdState = null;
                insideState = null;
                return;
            }
            a = (1f - t) * (1f - t);       // fast at first, soft at the end
        }
        g.fill(0, 0, w, h, ((int) (a * 255f) << 24) | 0xFFFFFF);
    }

    /** Tracks whether the player's eyes are inside an unstable Null Zone block (which block it pretends to be). */
    private static void updateInside(Minecraft mc) {
        if (mc.level == null || mc.player == null) {
            insideState = null;
            return;
        }
        BlockPos eye = BlockPos.containing(mc.player.getEyePosition());
        if (mc.level.getBlockState(eye).is(ModBlocks.NULL_ZONE.get())
                && mc.level.getBlockEntity(eye) instanceof NullZoneBlockEntity nz && !nz.isStable()) {
            BlockState orig = nz.getOriginal();
            insideState = orig != null ? orig : ModBlocks.WALLPAPER.get().defaultBlockState();
            insideSeenMs = Util.getMillis();
        }
    }

    /** The vanilla "inside a block" look: the block's texture stretched over the whole screen, dark. */
    private static void suffocate(GuiGraphics g, int w, int h, BlockState st, float alpha) {
        try {
            TextureAtlasSprite sprite = Minecraft.getInstance().getBlockRenderer().getBlockModelShaper().getParticleIcon(st);
            g.blit(0, 0, 0, w, h, sprite, 0.1f, 0.1f, 0.1f, alpha);
        } catch (Throwable t) {
            g.fill(0, 0, w, h, ((int) (alpha * 255f) << 24) | 0x0A0A0A);
        }
    }
}
