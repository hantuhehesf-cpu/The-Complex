package com.thecomplex.client;

import com.thecomplex.TheComplex;
import com.thecomplex.briefcase.RopeHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.Input;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.LogicalSide;

/**
 * Rope climbing on the client (the local player's movement is decided by the client).
 * You grab the rope ONLY by pressing jump (climb) or sneak (descend) while close to it (0.6 blocks or less from the rope line).
 * Once holding on: jump = climb, sneak = descend, no key = hang 0.25 blocks from the rope.
 * Pressing a movement key lets go. At the top, climbing or pressing a movement key vaults you onto the ledge next to the Briefcase.
 */
@Mod.EventBusSubscriber(modid = TheComplex.MODID, value = Dist.CLIENT)
public final class RopeClient {
    private static boolean attached;
    private static int cooldown;

    private RopeClient() {}

    @SubscribeEvent
    public static void onTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.side != LogicalSide.CLIENT) return;
        Minecraft mc = Minecraft.getInstance();
        if (!(e.player instanceof LocalPlayer p) || p != mc.player) return;
        if (cooldown > 0) cooldown--;
        if (p.getAbilities().flying || p.isPassenger() || p.isSpectator() || p.isDeadOrDying()) {
            attached = false;
            return;
        }

        RopeHelper.Hit h = RopeHelper.find(p);
        if (h == null) {
            attached = false;
            return;
        }

        Input in = p.input;
        boolean free = mc.screen == null;
        boolean up = free && in.jumping;
        boolean down = free && in.shiftKeyDown;
        boolean steering = free && (Math.abs(in.forwardImpulse) > 0.05f || Math.abs(in.leftImpulse) > 0.05f);
        double y = p.getY();
        boolean atTop = y >= h.top() - 0.05;

        if (!attached) {
            if (cooldown > 0) return;
            // Standing on the ledge and jumping must stay a normal jump: only grab when below the top, or when sneaking to descend.
            boolean grab = down || (up && y < h.top() - 0.25);
            if (!grab || steering) return;
            attached = true;
        } else if (atTop && (up || steering)) {
            // reached the top: vault onto the ledge (the Briefcase side is opposite to the hang direction)
            attached = false;
            cooldown = 15;
            net.minecraft.core.Direction ledge = h.entity().getRopeDir().getOpposite();
            p.setDeltaMovement(ledge.getStepX() * 0.22, 0.3, ledge.getStepZ() * 0.22);
            return;
        } else if (steering) {
            attached = false;               // let go
            return;
        }
        p.fallDistance = 0f;

        double vy = 0;
        if (up) vy = 0.2;
        else if (down) vy = -0.2;
        if (vy > 0) {
            // stop exactly at the ledge surface
            double room = h.top() + 0.02 - y;
            vy = room <= 0 ? 0 : Math.min(vy, room);
        }
        if (vy < 0 && y <= h.bottom() + 0.01) vy = 0;

        // ease toward the hanging point close to the rope
        double vx = clamp((h.tx() - p.getX()) * 0.5, 0.1);
        double vz = clamp((h.tz() - p.getZ()) * 0.5, 0.1);
        p.setDeltaMovement(vx, vy, vz);
    }

    private static double clamp(double v, double m) {
        return Math.max(-m, Math.min(m, v));
    }
}
