package com.thecomplex.client;

import com.thecomplex.ModBlocks;
import com.thecomplex.ModSounds;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundSource;

/**
 * The buzz of ONE fluorescent panel (v1.10). It plays from the panel's own position and gets louder as you walk toward it,
 * so the hum now comes from the lights themselves, not from the dimension. It stops by itself when the panel is gone or far away.
 */
public class HumSound extends AbstractTickableSoundInstance {
    /** Volume of one panel (0..1). Several panels near you add up, so this is low. */
    public static final float VOLUME = 0.30f;
    /** Panels farther than this many blocks do not play at all. */
    public static final double RANGE = 14.0;

    private final BlockPos pos;

    public HumSound(BlockPos pos) {
        super(ModSounds.FLUORESCENT_HUM.get(), SoundSource.AMBIENT, SoundInstance.createUnseededRandom());
        this.pos = pos;
        this.looping = true;
        this.delay = 0;
        this.volume = VOLUME;
        this.pitch = 0.97f + this.random.nextFloat() * 0.06f;      // a slight beat between neighboring panels
        this.relative = false;
        this.attenuation = SoundInstance.Attenuation.LINEAR;
        this.x = pos.getX() + 0.5;
        this.y = pos.getY() + 0.5;
        this.z = pos.getZ() + 0.5;
    }

    public BlockPos pos() {
        return pos;
    }

    @Override
    public void tick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null
                || !mc.level.getBlockState(pos).is(ModBlocks.FLUORESCENT_PANEL.get())
                || mc.player.distanceToSqr(x, y, z) > (RANGE + 3) * (RANGE + 3)) {
            stop();
        }
    }
}
