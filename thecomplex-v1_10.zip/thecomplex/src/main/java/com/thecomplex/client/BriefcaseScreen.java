package com.thecomplex.client;

import com.thecomplex.ModItems;
import com.thecomplex.briefcase.BriefcaseData;
import com.thecomplex.briefcase.BriefcaseSessions;
import com.thecomplex.briefcase.BriefcaseSizes;
import com.thecomplex.net.BriefcaseOpPacket;
import com.thecomplex.net.Net;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;

import java.util.List;

/**
 * Inventori Briefcase gaya Tetris (grid 8 x 3-4). Klik benda untuk memilih, klik petak tujuan untuk memindahkan.
 *  - Benda di inventorimu -> klik grid: masukkan. Shift + klik: masuk ke tempat kosong pertama.
 *  - Benda di grid -> klik grid lain: pindah posisi. Klik slot inventorimu: ambil keluar.
 *  - Slot "Rope" di kanan: khusus Rope (tiap Briefcase punya satu).
 * Animasi buka: kamera mendekat (FOV mengecil) dan Briefcase terbuka dari tengah.
 */
public class BriefcaseScreen extends Screen {
    private static final int CELL = 18;
    private static final int OPEN_TICKS = 12;
    private static final int SEL_NONE = 0, SEL_INV = 1, SEL_ENTRY = 2, SEL_ROPE = 3;

    private int rows;
    private List<BriefcaseData.Entry> entries;
    private ItemStack rope = ItemStack.EMPTY;
    private int age;
    private int selKind = SEL_NONE;
    private int selIdx;
    private final ItemStack icon = new ItemStack(ModItems.BRIEFCASE.get());

    // tata letak (dihitung di init)
    private int left, top, pw, ph, gridX, gridY, ropeX, invX, mainY, hotY;

    public BriefcaseScreen(int rows, CompoundTag data) {
        super(Component.literal("Exploration Briefcase"));
        read(rows, data);
    }

    private void read(int rows, CompoundTag data) {
        this.rows = rows;
        this.entries = BriefcaseData.read(data);
        this.rope = data.contains("Rope", Tag.TAG_COMPOUND) ? ItemStack.of(data.getCompound("Rope")) : ItemStack.EMPTY;
    }

    public void update(int rows, CompoundTag data) {
        read(rows, data);
        selKind = SEL_NONE;
        if (minecraft != null) rebuildWidgets();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    protected void init() {
        pw = 190;
        ph = 16 + rows * CELL + 12 + 3 * CELL + 4 + CELL + 8 + 10;
        left = (width - pw) / 2;
        top = Math.max(2, (height - ph) / 2);
        gridX = left + 7;
        gridY = top + 16;
        ropeX = gridX + BriefcaseData.COLS * CELL + 10;
        invX = left + (pw - 9 * CELL) / 2;
        mainY = gridY + rows * CELL + 12;
        hotY = mainY + 3 * CELL + 4;
        if (age == 0) {
            minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.CHEST_OPEN, 0.9f));
        }
    }

    @Override
    public void tick() {
        age++;
    }

    @Override
    public void removed() {
        Net.CHANNEL.sendToServer(new BriefcaseOpPacket(BriefcaseSessions.OP_CLOSE, 0, 0, 0));
        if (minecraft != null) minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.CHEST_CLOSE, 0.9f));
    }

    // ------------------------------------------------------------------ geometri

    private int invSlotAt(double mx, double my) {
        int cx = (int) Math.floor((mx - invX) / CELL);
        if (cx < 0 || cx > 8) return -1;
        int cy = (int) Math.floor((my - mainY) / CELL);
        if (cy >= 0 && cy < 3) return 9 + cy * 9 + cx;
        int hy = (int) Math.floor((my - hotY) / CELL);
        if (hy == 0) return cx;
        return -1;
    }

    private int[] gridCellAt(double mx, double my) {
        int gx = (int) Math.floor((mx - gridX) / CELL);
        int gy = (int) Math.floor((my - gridY) / CELL);
        if (gx < 0 || gx >= BriefcaseData.COLS || gy < 0 || gy >= rows) return null;
        return new int[]{gx, gy};
    }

    private int entryAt(int gx, int gy) {
        for (int i = 0; i < entries.size(); i++) {
            BriefcaseData.Entry e = entries.get(i);
            if (gx >= e.x && gx < e.x + e.w && gy >= e.y && gy < e.y + e.h) return i;
        }
        return -1;
    }

    private boolean overRope(double mx, double my) {
        return mx >= ropeX && mx < ropeX + CELL && my >= gridY && my < gridY + CELL;
    }

    private ItemStack invStack(int slot) {
        return minecraft.player.getInventory().getItem(slot);
    }

    // ------------------------------------------------------------------ input

    private void send(int op, int a, int b, int c) {
        Net.CHANNEL.sendToServer(new BriefcaseOpPacket(op, a, b, c));
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (age < OPEN_TICKS) return true;
        if (button != 0) {
            selKind = SEL_NONE;
            return true;
        }
        int slot = invSlotAt(mx, my);
        int[] cell = gridCellAt(mx, my);

        if (slot >= 0) {
            ItemStack st = invStack(slot);
            if (selKind == SEL_ENTRY) {
                send(BriefcaseSessions.OP_TAKE, selIdx, slot, 0);
                selKind = SEL_NONE;
            } else if (selKind == SEL_ROPE) {
                send(BriefcaseSessions.OP_TAKE_ROPE, 0, slot, 0);
                selKind = SEL_NONE;
            } else if (hasShiftDown() && !st.isEmpty()) {
                send(BriefcaseSessions.OP_QUICK_PUT, slot, 0, 0);
            } else if (selKind == SEL_INV && selIdx == slot) {
                selKind = SEL_NONE;
            } else if (!st.isEmpty()) {
                selKind = SEL_INV;
                selIdx = slot;
            } else {
                selKind = SEL_NONE;
            }
        } else if (cell != null) {
            int hit = entryAt(cell[0], cell[1]);
            if (selKind == SEL_INV) {
                send(BriefcaseSessions.OP_PUT, selIdx, cell[0], cell[1]);
                selKind = SEL_NONE;
            } else if (selKind == SEL_ENTRY) {
                if (hit == selIdx) {
                    selKind = SEL_NONE;
                } else {
                    BriefcaseData.Entry e = entries.get(selIdx);
                    send(BriefcaseSessions.OP_MOVE, selIdx, cell[0], cell[1]);
                    selKind = SEL_NONE;
                }
            } else if (hit >= 0) {
                selKind = SEL_ENTRY;
                selIdx = hit;
            } else {
                selKind = SEL_NONE;
            }
        } else if (overRope(mx, my)) {
            if (selKind == SEL_INV) {
                send(BriefcaseSessions.OP_PUT_ROPE, selIdx, 0, 0);
                selKind = SEL_NONE;
            } else if (!rope.isEmpty()) {
                selKind = selKind == SEL_ROPE ? SEL_NONE : SEL_ROPE;
            }
        } else {
            selKind = SEL_NONE;
        }
        return true;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (minecraft.options.keyInventory.matches(key, scan)) {
            onClose();
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    // ------------------------------------------------------------------ gambar

    private void drawItemFit(GuiGraphics g, ItemStack st, int x, int y, int w, int h, int cellsW, int cellsH) {
        float s = Math.max(1, Math.min(cellsW, cellsH));
        float cx = x + w * 0.5f, cy = y + h * 0.5f;
        g.pose().pushPose();
        g.pose().translate(cx - 8 * s, cy - 8 * s, 0);
        g.pose().scale(s, s, 1f);
        g.renderItem(st, 0, 0);
        g.pose().popPose();
        if (st.getCount() > 1) {
            g.pose().pushPose();
            g.pose().translate(0, 0, 200);
            String c = String.valueOf(st.getCount());
            g.drawString(font, c, x + w - 1 - font.width(c), y + h - 9, 0xFFFFFF, true);
            g.pose().popPose();
        }
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        float t = Mth.clamp((age + pt) / OPEN_TICKS, 0f, 1f);
        int cx = width / 2, cy = top + ph / 2;

        // fase 1: Briefcase tertutup membesar (kamera mendekat); fase 2: terbuka dari tengah
        if (t < 0.5f) {
            float s = 5f + 7f * (t / 0.5f);
            g.pose().pushPose();
            g.pose().translate(cx - 8 * s, cy - 8 * s, 0);
            g.pose().scale(s, s, 1f);
            g.renderItem(icon, 0, 0);
            g.pose().popPose();
        }
        float open = Mth.clamp((t - 0.35f) / 0.65f, 0f, 1f);
        if (open <= 0f) return;
        float eased = 1f - (1f - open) * (1f - open) * (1f - open);
        int halfH = Math.max(1, Math.round(ph * 0.5f * eased));
        boolean clip = eased < 1f;
        if (clip) g.enableScissor(left, cy - halfH, left + pw, cy + halfH);

        g.fill(left, top, left + pw, top + ph, 0xF01E1A14);
        g.renderOutline(left, top, pw, ph, 0xFF8A6A3A);
        g.drawString(font, "Exploration Briefcase", left + 7, top + 5, 0xE8D8A8, false);

        // grid
        for (int gy = 0; gy < rows; gy++) {
            for (int gx = 0; gx < BriefcaseData.COLS; gx++) {
                g.fill(gridX + gx * CELL, gridY + gy * CELL, gridX + gx * CELL + CELL - 1, gridY + gy * CELL + CELL - 1, 0xFF3B352C);
            }
        }
        for (int i = 0; i < entries.size(); i++) {
            BriefcaseData.Entry e = entries.get(i);
            int x = gridX + e.x * CELL, y = gridY + e.y * CELL, w = e.w * CELL - 1, h = e.h * CELL - 1;
            boolean sel = selKind == SEL_ENTRY && selIdx == i;
            g.fill(x, y, x + w, y + h, sel ? 0xFF8C7A3C : 0xFF574A33);
            g.renderOutline(x, y, w, h, sel ? 0xFFFFE070 : 0xFF2A241A);
            drawItemFit(g, e.stack, x, y, w, h, e.w, e.h);
        }

        // slot tali
        g.drawString(font, "Rope", ropeX, gridY - 10, 0xB8A888, false);
        boolean ropeSel = selKind == SEL_ROPE;
        g.fill(ropeX, gridY, ropeX + CELL - 1, gridY + CELL - 1, ropeSel ? 0xFF8C7A3C : 0xFF2B2B2B);
        g.renderOutline(ropeX, gridY, CELL - 1, CELL - 1, ropeSel ? 0xFFFFE070 : 0xFF6E5A3A);
        if (!rope.isEmpty()) g.renderItem(rope, ropeX + 1, gridY + 1);

        // inventori pemain
        g.drawString(font, "Inventory", invX, mainY - 10, 0xB8A888, false);
        for (int slot = 9; slot < 36; slot++) drawInvSlot(g, slot, invX + ((slot - 9) % 9) * CELL, mainY + ((slot - 9) / 9) * CELL);
        for (int slot = 0; slot < 9; slot++) drawInvSlot(g, slot, invX + slot * CELL, hotY);

        // bayangan penempatan
        int[] cell = gridCellAt(mx, my);
        if (cell != null && (selKind == SEL_INV || selKind == SEL_ENTRY)) {
            int w = 1, h = 1, ignore = -1;
            boolean allowed = true;
            if (selKind == SEL_INV) {
                BriefcaseSizes.Size sz = BriefcaseSizes.of(invStack(selIdx));
                if (sz == null) allowed = false;
                else {
                    w = sz.w();
                    h = sz.h();
                }
            } else if (selIdx < entries.size()) {
                BriefcaseData.Entry e = entries.get(selIdx);
                w = e.w;
                h = e.h;
                ignore = selIdx;
            }
            boolean ok = allowed && BriefcaseData.fits(entries, ignore, cell[0], cell[1], w, h, rows);
            int x0 = gridX + cell[0] * CELL, y0 = gridY + cell[1] * CELL;
            int x1 = Math.min(gridX + BriefcaseData.COLS * CELL, x0 + w * CELL), y1 = Math.min(gridY + rows * CELL, y0 + h * CELL);
            g.fill(x0, y0, x1 - 1, y1 - 1, ok ? 0x6040E060 : 0x60E04040);
        }

        if (clip) g.disableScissor();
        if (t < 1f) return;

        // keterangan benda di bawah kursor
        int slot = invSlotAt(mx, my);
        if (slot >= 0 && !invStack(slot).isEmpty()) {
            g.renderTooltip(font, invStack(slot), mx, my);
        } else if (cell != null) {
            int hit = entryAt(cell[0], cell[1]);
            if (hit >= 0) g.renderTooltip(font, entries.get(hit).stack, mx, my);
        } else if (overRope(mx, my) && !rope.isEmpty()) {
            g.renderTooltip(font, rope, mx, my);
        }
    }

    private void drawInvSlot(GuiGraphics g, int slot, int x, int y) {
        boolean sel = selKind == SEL_INV && selIdx == slot;
        g.fill(x, y, x + CELL - 1, y + CELL - 1, sel ? 0xFF8C7A3C : 0xFF2B2B2B);
        if (sel) g.renderOutline(x, y, CELL - 1, CELL - 1, 0xFFFFE070);
        ItemStack st = invStack(slot);
        if (!st.isEmpty()) {
            g.renderItem(st, x + 1, y + 1);
            g.renderItemDecorations(font, st, x + 1, y + 1);
            if (BriefcaseSizes.of(st) == null) g.fill(x, y, x + CELL - 1, y + CELL - 1, 0x80000000);
        }
    }
}
