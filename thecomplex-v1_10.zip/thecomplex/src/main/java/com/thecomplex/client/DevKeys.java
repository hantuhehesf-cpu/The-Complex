package com.thecomplex.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.thecomplex.TheComplex;
import com.thecomplex.net.DevOpenRequestPacket;
import com.thecomplex.net.Net;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

/**
 * The Developer UI key (default K, rebind it in Options > Controls > The Complex).
 * Pressing it asks the server to open the UI; the server only answers operators and players in creative mode.
 */
public final class DevKeys {
    public static final KeyMapping OPEN = new KeyMapping("key.thecomplex.dev_ui", InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_K, "key.categories.thecomplex");

    private DevKeys() {}

    @Mod.EventBusSubscriber(modid = TheComplex.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static final class Register {
        private Register() {}

        @SubscribeEvent
        public static void onKeys(RegisterKeyMappingsEvent e) {
            e.register(OPEN);
        }
    }

    @Mod.EventBusSubscriber(modid = TheComplex.MODID, value = Dist.CLIENT)
    public static final class Tick {
        private Tick() {}

        @SubscribeEvent
        public static void onTick(TickEvent.ClientTickEvent e) {
            if (e.phase != TickEvent.Phase.END) return;
            Minecraft mc = Minecraft.getInstance();
            while (OPEN.consumeClick()) {
                if (mc.player != null && mc.screen == null) Net.CHANNEL.sendToServer(new DevOpenRequestPacket());
            }
        }
    }
}
