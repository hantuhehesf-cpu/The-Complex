package com.thecomplex.client;

import com.mojang.blaze3d.pipeline.TextureTarget;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexBuffer;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.thecomplex.ModBlocks;
import com.thecomplex.TheComplex;
import com.thecomplex.net.PortalFarPacket;
import com.thecomplex.net.PortalViewPacket;
import com.thecomplex.portal.PortalMath;
import net.minecraft.Util;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.EmptyBlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterClientCommandsEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.client.model.data.ModelData;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.loading.FMLPaths;
import org.joml.Matrix4f;
import org.joml.Vector4f;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Efek see-through untuk Threshold, tanpa stencil dan tanpa dunia kedua (jadi aman untuk MobileGlues):
 *  1. Server mengirim cuplikan blok sisi seberang (PortalViewPacket) dan, di mode penuh, medan jauh (PortalFarPacket).
 *     Klien merakitnya SEKALI menjadi buffer GPU statis.
 *  2. Tiap frame, untuk Threshold terdekat yang terlihat, buffer itu digambar dari "kamera bayangan"
 *     (kamera pemain yang dipindah lewat transformasi portal) ke tekstur kecil (setengah resolusi layar).
 *  3. Tekstur itu ditempelkan pada bukaan Threshold dengan koordinat layar, dipecah jadi kisi kecil supaya perspektifnya benar.
 *     Bagian kisi yang berada di belakang kamera dipotong (clipping) sehingga jendela tidak menghilang saat pemain dekat.
 * Shader yang dipakai hanya shader bawaan Minecraft. Semua dibungkus pengaman:
 *  - kalau ada kesalahan, efek mati sendiri dan Threshold tampil seperti biasa,
 *  - kalau game sempat crash saat efek menyala, saat game dibuka lagi efek otomatis mati (berkas penanda),
 *  - perintah /complexview on|off|status.
 */
@Mod.EventBusSubscriber(modid = TheComplex.MODID, value = Dist.CLIENT)
public final class PortalViewClient {
    private static final double MAX_DIST = 24.0;
    private static final int MAX_QUADS_NEAR = 140000;
    private static final int MAX_QUADS_FAR = 24000;
    private static final int GRID_X = 6, GRID_Y = 9;
    private static final float NEAR_W = 0.05f;
    private static final long STALE_MS = 45_000;
    private static final int OK_FRAMES_TO_CLEAR_MARKER = 180;
    private static final int STRIDE = 9;                 // x y z u v r g b a

    private static final class View {
        long key;
        String dim;
        Vec3 src, dest;
        boolean axisX;
        float halfW, halfH;
        int ex, ez;
        float ambient;
        float skyR, skyG, skyB;
        VertexBuffer nearVb;
        VertexBuffer waterVb;
        VertexBuffer farVb;
        int nearHash, farHash;
        long lastMs;

        void close() {
            if (nearVb != null) nearVb.close();
            if (waterVb != null) waterVb.close();
            if (farVb != null) farVb.close();
            nearVb = null;
            waterVb = null;
            farVb = null;
        }
    }

    /** Daftar float yang tumbuh sendiri. */
    private static final class Floats {
        float[] a = new float[STRIDE * 4 * 256];
        int n;

        void vertex(float x, float y, float z, float u, float v, float r, float g, float b, float al) {
            if (n + STRIDE > a.length) a = Arrays.copyOf(a, a.length * 2);
            a[n++] = x;
            a[n++] = y;
            a[n++] = z;
            a[n++] = u;
            a[n++] = v;
            a[n++] = r;
            a[n++] = g;
            a[n++] = b;
            a[n++] = al;
        }
    }

    private static final Map<Long, View> VIEWS = new HashMap<>();

    /** The Threshold window drawn in the last frame (for clicks that go through it, see RemoteInteractClient). */
    public record Window(long key, Vec3 center, boolean axisX, float halfW, float halfH) {}

    private static Window lastWin;
    private static long lastWinMs;

    /** The window drawn a moment ago, or null. */
    public static Window window() {
        return lastWin != null && Util.getMillis() - lastWinMs < 250 ? lastWin : null;
    }
    private static TextureTarget target;

    private static boolean disabled;       // dimatikan otomatis karena kesalahan / crash sebelumnya
    private static boolean userOff;        // dimatikan pemain lewat /complexview off
    private static int okFrames;
    private static boolean markerWritten;
    private static String notice;

    private static final Path MARKER = FMLPaths.CONFIGDIR.get().resolve("thecomplex-portalview.attempt");
    private static final Path SETTING = FMLPaths.CONFIGDIR.get().resolve("thecomplex-portalview.txt");

    static {
        try {
            if (Files.exists(SETTING) && Files.readString(SETTING).trim().equalsIgnoreCase("off")) userOff = true;
            if (Files.exists(MARKER)) {
                // sesi sebelumnya berhenti saat efek menyala: matikan dulu
                userOff = true;
                disabled = true;
                Files.writeString(SETTING, "off");
                Files.deleteIfExists(MARKER);
                notice = "The Threshold see-through effect was switched off because the game stopped while it was on last time. "
                        + "Type /complexview on to try again.";
            }
        } catch (Throwable ignored) {
            // berkas tidak bisa dibaca: lanjut dengan nilai awal
        }
    }

    private PortalViewClient() {}

    // ---------------------------------------------------------------- data dari server

    // ---- v1.10: the blocks are baked on a worker thread, so a big snapshot does not freeze the game; the GPU upload happens in the client tick
    private static final java.util.concurrent.ExecutorService BAKER = java.util.concurrent.Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "thecomplex-portal-bake");
        t.setDaemon(true);
        return t;
    });
    private static final java.util.concurrent.ConcurrentLinkedQueue<Baked> DONE = new java.util.concurrent.ConcurrentLinkedQueue<>();
    private static final java.util.Set<Long> IN_FLIGHT = new java.util.HashSet<>();
    private static final Map<Long, PortalViewPacket> PENDING = new HashMap<>();

    private static final class Baked {
        long key;
        PortalViewPacket m;
        int hash;
        Floats near, water;
        Throwable error;
    }

    private record Sprites(TextureAtlasSprite water, TextureAtlasSprite lava) {}

    public static void receive(PortalViewPacket m) {
        if (userOff || disabled) return;
        try {
            if (m.idx().length == 0) {
                View gone = VIEWS.remove(m.key());
                if (gone != null) gone.close();
                return;
            }
            int hash = Arrays.hashCode(m.idx()) * 31 + Arrays.hashCode(m.ids()) + m.ambient() * 7 + Arrays.hashCode(m.masks())
                    + Arrays.hashCode(m.light()) * 13 + m.skyFactor() * 5;
            View v = VIEWS.get(m.key());
            if (v != null && v.nearHash == hash && v.dest.x == m.dx() && v.dest.z == m.dz()) {
                v.lastMs = Util.getMillis();                   // tidak berubah: tidak perlu dirakit ulang
                return;
            }
            if (IN_FLIGHT.contains(m.key())) {
                PENDING.put(m.key(), m);                       // newest one wins; baked when the current job is done
                return;
            }
            IN_FLIGHT.add(m.key());
            Minecraft mc = Minecraft.getInstance();
            Sprites sp = new Sprites(
                    mc.getTextureAtlas(TextureAtlas.LOCATION_BLOCKS).apply(new ResourceLocation("minecraft", "block/water_still")),
                    mc.getTextureAtlas(TextureAtlas.LOCATION_BLOCKS).apply(new ResourceLocation("minecraft", "block/lava_still")));
            BAKER.execute(() -> {
                Baked b = new Baked();
                b.key = m.key();
                b.m = m;
                b.hash = hash;
                try {
                    bake(b, sp);
                } catch (Throwable t) {
                    b.error = t;
                }
                DONE.add(b);
            });
        } catch (Throwable t) {
            fail("baking the portal view", t);
        }
    }

    /** Client tick: finished bake jobs get uploaded to the GPU. */
    private static void finishBakes() {
        Baked b;
        while ((b = DONE.poll()) != null) {
            IN_FLIGHT.remove(b.key);
            if (userOff || disabled) continue;
            if (b.error != null) {
                fail("baking the portal view", b.error);
                continue;
            }
            try {
                View v = VIEWS.get(b.key);
                if (v == null) {
                    v = new View();
                    VIEWS.put(b.key, v);
                }
                common(v, b.m);
                if (v.nearVb != null) v.nearVb.close();
                if (v.waterVb != null) v.waterVb.close();
                v.nearVb = upload(b.near);
                v.waterVb = upload(b.water);
                v.nearHash = b.hash;
            } catch (Throwable t) {
                fail("uploading the portal view", t);
                continue;
            }
            PortalViewPacket next = PENDING.remove(b.key);
            if (next != null) receive(next);
        }
    }

    public static void receiveFar(PortalFarPacket m) {
        if (userOff || disabled) return;
        try {
            View v = VIEWS.get(m.key());
            if (v == null) return;                              // cuplikan dekat selalu dikirim lebih dulu
            int hash = Arrays.hashCode(m.pal()) * 31 + Arrays.hashCode(m.heights()) + Arrays.hashCode(m.palette());
            if (v.farVb != null && v.farHash == hash) {
                v.lastMs = Util.getMillis();
                return;
            }
            bakeFar(v, m);
            v.farHash = hash;
        } catch (Throwable t) {
            fail("baking the far terrain", t);
        }
    }

    /** Dipanggil saat pemain dipindah (dimensi berganti): cuplikan lama tidak berlaku lagi. */
    public static void onTeleport() {
        closeAll();
    }

    private static void closeAll() {
        PENDING.clear();
        PortalGhosts.clear();
        try {
            for (View v : VIEWS.values()) v.close();
        } catch (Throwable ignored) {
            // buffer sudah tidak valid
        }
        VIEWS.clear();
    }

    private static float faceShade(Direction d) {
        return switch (d) {
            case UP -> 1.0f;
            case DOWN -> 0.5f;
            case NORTH, SOUTH -> 0.8f;
            default -> 0.6f;
        };
    }

    private static VertexBuffer upload(Floats f) {
        if (f.n == 0) return null;
        BufferBuilder bb = Tesselator.getInstance().getBuilder();
        bb.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_TEX_COLOR);
        float[] a = f.a;
        for (int i = 0; i < f.n; i += STRIDE) {
            bb.vertex(a[i], a[i + 1], a[i + 2]).uv(a[i + 3], a[i + 4]).color(a[i + 5], a[i + 6], a[i + 7], a[i + 8]).endVertex();
        }
        VertexBuffer vb = new VertexBuffer(VertexBuffer.Usage.STATIC);
        vb.bind();
        vb.upload(bb.end());
        VertexBuffer.unbind();
        return vb;
    }

    private static void common(View v, PortalViewPacket m) {
        v.key = m.key();
        v.dim = m.dim();
        v.src = new Vec3(m.sx(), m.sy(), m.sz());
        v.dest = new Vec3(m.dx(), m.dy(), m.dz());
        v.axisX = m.axis() == 0;
        v.halfW = m.halfW();
        v.halfH = m.halfH();
        v.ex = m.ex();
        v.ez = m.ez();
        v.ambient = m.ambient();
        v.skyR = ((m.sky() >> 16) & 255) / 255f;
        v.skyG = ((m.sky() >> 8) & 255) / 255f;
        v.skyB = (m.sky() & 255) / 255f;
        v.lastMs = Util.getMillis();
    }

    /** Brightness of a face from its light byte (block light high nibble, sky light low nibble): the vanilla light curve, gamma 0.5. */
    private static float brightness(int lightByte, int skyFactor) {
        float bl = ((lightByte >> 4) & 15) / 15f;
        float sl = (lightByte & 15) / 15f * (skyFactor / 15f);
        float l = Math.max(bl, sl);
        float f = l / (4f - 3f * l);
        float g = 1f - (float) Math.pow(1f - f, 4);
        return Mth.clamp(0.03f + 0.97f * Mth.lerp(0.5f, f, g), 0.03f, 1f);
    }

    /** Builds the vertex lists of one snapshot (runs on the worker thread: no GL calls here). */
    private static void bake(Baked out, Sprites sp) {
        PortalViewPacket m = out.m;
        Minecraft mc = Minecraft.getInstance();
        BlockRenderDispatcher disp = mc.getBlockRenderer();
        Floats near = new Floats(), water = new Floats();
        int quads = 0;
        RandomSource rs = RandomSource.create(42L);
        for (int i = 0; i < m.idx().length && quads < MAX_QUADS_NEAR; i++) {
            BlockState st = Block.BLOCK_STATE_REGISTRY.byId(m.ids()[i]);
            if (st == null || st.isAir()) continue;
            int idx = m.idx()[i];
            int lx = idx % m.w(), lz = (idx / m.w()) % m.d(), ly = idx / (m.w() * m.d());
            float wx = (float) (m.bx() + lx - m.dx()), wy = (float) (m.by() + ly - m.dy()), wz = (float) (m.bz() + lz - m.dz());
            int mask = m.masks()[i] & 0x3F;
            float br = st.getLightEmission() >= 8 ? 1f : brightness(m.light()[i], m.skyFactor());
            try {
                if (!st.getFluidState().isEmpty() && st.getRenderShape() != net.minecraft.world.level.block.RenderShape.MODEL) {
                    quads += bakeFluid(st, mask, wx, wy, wz, br, sp, near, water);
                    continue;
                }
                BakedModel model = disp.getBlockModel(st);
                boolean solid = st.isSolidRender(EmptyBlockGetter.INSTANCE, BlockPos.ZERO);
                List<BakedQuad> list = new ArrayList<>();
                for (Direction dir : Direction.values()) {
                    if (solid && (mask & (1 << dir.get3DDataValue())) == 0) continue;
                    list.addAll(model.getQuads(st, dir, rs, ModelData.EMPTY, null));
                }
                if (!solid) list.addAll(model.getQuads(st, null, rs, ModelData.EMPTY, null));

                for (BakedQuad q : list) {
                    if (quads >= MAX_QUADS_NEAR) break;
                    float sh = q.isShade() ? faceShade(q.getDirection()) : 1f;
                    float cr = 1f, cg = 1f, cb = 1f;
                    if (q.isTinted()) {
                        int tint = -1;
                        try {
                            tint = mc.getBlockColors().getColor(st, null, null, q.getTintIndex());
                        } catch (Throwable ignored) {
                            // pewarna yang butuh dunia: pakai putih
                        }
                        if (tint != -1) {
                            cr = ((tint >> 16) & 255) / 255f;
                            cg = ((tint >> 8) & 255) / 255f;
                            cb = (tint & 255) / 255f;
                        }
                    }
                    int[] vd = q.getVertices();
                    for (int k = 0; k < 4; k++) {
                        int o = k * 8;
                        near.vertex(Float.intBitsToFloat(vd[o]) + wx, Float.intBitsToFloat(vd[o + 1]) + wy, Float.intBitsToFloat(vd[o + 2]) + wz,
                                Float.intBitsToFloat(vd[o + 4]), Float.intBitsToFloat(vd[o + 5]), cr * sh * br, cg * sh * br, cb * sh * br, 1f);
                    }
                    quads++;
                }
            } catch (Throwable ignored) {
                // an odd modded block model: leave that block out
            }
        }
        out.near = near;
        out.water = water;
    }

    /** Water (translucent, into the water list) and lava (opaque, bright, into the near list). Returns the number of quads. */
    private static int bakeFluid(BlockState st, int mask, float wx, float wy, float wz, float br, Sprites sp, Floats near, Floats water) {
        boolean lava = st.getFluidState().is(net.minecraft.tags.FluidTags.LAVA);
        TextureAtlasSprite sprite = lava ? sp.lava() : sp.water();
        Floats f = lava ? near : water;
        float r = lava ? 1f : 0.25f, g = lava ? 1f : 0.46f, b = lava ? 1f : 0.89f, al = lava ? 1f : 0.72f;
        float h = 0.89f;
        float u0 = sprite.getU0(), u1 = sprite.getU1(), v0 = sprite.getV0(), v1 = sprite.getV1();
        float bright = lava ? 1f : br;
        int n = 0;
        for (Direction dir : Direction.values()) {
            if ((mask & (1 << dir.get3DDataValue())) == 0) continue;
            float[] c;
            switch (dir) {
                case UP -> c = new float[]{0, h, 0, 0, h, 1, 1, h, 1, 1, h, 0};
                case DOWN -> c = new float[]{0, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1};
                case NORTH -> c = new float[]{0, 0, 0, 0, h, 0, 1, h, 0, 1, 0, 0};
                case SOUTH -> c = new float[]{0, 0, 1, 1, 0, 1, 1, h, 1, 0, h, 1};
                case WEST -> c = new float[]{0, 0, 0, 0, 0, 1, 0, h, 1, 0, h, 0};
                default -> c = new float[]{1, 0, 0, 1, h, 0, 1, h, 1, 1, 0, 1};
            }
            float sh = faceShade(dir) * bright;
            float[] us = {u0, u1, u1, u0}, vs = {v0, v0, v1, v1};
            for (int k = 0; k < 4; k++) {
                f.vertex(c[k * 3] + wx, c[k * 3 + 1] + wy, c[k * 3 + 2] + wz, us[k], vs[k], r * sh, g * sh, b * sh, al);
            }
            n++;
        }
        return n;
    }

    /** (u, v) in the middle of a fully opaque white block texture: far terrain is drawn as flat opaque colors on top of it. */
    private static float[] whiteSpot() {
        try {
            TextureAtlasSprite sp = Minecraft.getInstance().getTextureAtlas(TextureAtlas.LOCATION_BLOCKS)
                    .apply(new ResourceLocation("minecraft", "block/white_concrete"));
            return new float[]{(sp.getU0() + sp.getU1()) / 2, (sp.getV0() + sp.getV1()) / 2};
        } catch (Throwable t) {
            return new float[]{0f, 0f};
        }
    }

    /**
     * v1.9: color of one far terrain tile {u, v, r, g, b}. It used to sample one texel of the block's texture, so leaves
     * (cherry leaves especially) with a see-through texel at that spot showed up as ghostly translucent columns.
     * Now the tile uses the block's map color on an opaque white texel: always solid, no texture holes.
     */
    private static float[] farSample(BlockState st, float[] white, Map<Block, float[]> cache) {
        float[] c = cache.get(st.getBlock());
        if (c != null) return c;
        float r = 0.45f, g = 0.5f, b = 0.4f;
        try {
            int col = st.getMapColor(EmptyBlockGetter.INSTANCE, BlockPos.ZERO).col;
            if (col != 0) {
                r = ((col >> 16) & 255) / 255f * 0.86f;
                g = ((col >> 8) & 255) / 255f * 0.86f;
                b = (col & 255) / 255f * 0.86f;
            }
        } catch (Throwable ignored) {
            // odd block: keep the neutral green-grey
        }
        c = new float[]{white[0], white[1], r, g, b};
        cache.put(st.getBlock(), c);
        return c;
    }

    /** Warna rata-rata permukaan atas sebuah blok: titik tengah tekstur sisi atasnya + pewarna biome. {u, v, r, g, b}. */
    private static float[] sample(BlockState st, Map<Block, float[]> cache) {
        float[] c = cache.get(st.getBlock());
        if (c != null) return c;
        Minecraft mc = Minecraft.getInstance();
        float u = 0, vv = 0, r = 1, g = 1, b = 1;
        try {
            if (!st.getFluidState().isEmpty()) {
                TextureAtlasSprite sp = mc.getTextureAtlas(TextureAtlas.LOCATION_BLOCKS).apply(new ResourceLocation("minecraft", "block/water_still"));
                u = (sp.getU0() + sp.getU1()) / 2;
                vv = (sp.getV0() + sp.getV1()) / 2;
                r = 0.25f;
                g = 0.45f;
                b = 0.85f;
            } else {
                BakedModel model = mc.getBlockRenderer().getBlockModel(st);
                List<BakedQuad> up = model.getQuads(st, Direction.UP, RandomSource.create(7L), ModelData.EMPTY, null);
                if (!up.isEmpty()) {
                    BakedQuad q = up.get(0);
                    int[] vd = q.getVertices();
                    for (int k = 0; k < 4; k++) {
                        u += Float.intBitsToFloat(vd[k * 8 + 4]) / 4f;
                        vv += Float.intBitsToFloat(vd[k * 8 + 5]) / 4f;
                    }
                    if (q.isTinted()) {
                        int tint = mc.getBlockColors().getColor(st, null, null, q.getTintIndex());
                        if (tint != -1) {
                            r = ((tint >> 16) & 255) / 255f;
                            g = ((tint >> 8) & 255) / 255f;
                            b = (tint & 255) / 255f;
                        }
                    }
                } else {
                    TextureAtlasSprite sp = model.getParticleIcon(ModelData.EMPTY);
                    u = (sp.getU0() + sp.getU1()) / 2;
                    vv = (sp.getV0() + sp.getV1()) / 2;
                }
            }
        } catch (Throwable ignored) {
            // blok aneh: pakai titik (0, 0) putih
        }
        c = new float[]{u, vv, r, g, b};
        cache.put(st.getBlock(), c);
        return c;
    }

    private static void bakeFar(View v, PortalFarPacket m) {
        int t = m.tile(), gw = m.gw(), gd = m.gd();
        float amb = 0.28f + 0.72f * Mth.clamp(m.ambient() / 15f, 0f, 1f);
        float maxDist = Math.max(1f, Math.max(gw, gd) * t / 2f);
        Map<Block, float[]> cache = new HashMap<>();
        float[] white = whiteSpot();
        float[][] samples = new float[m.palette().length][];
        for (int i = 0; i < samples.length; i++) {
            BlockState st = Block.BLOCK_STATE_REGISTRY.byId(m.palette()[i]);
            samples[i] = st == null ? new float[]{white[0], white[1], 0.5f, 0.5f, 0.5f} : farSample(st, white, cache);
        }
        Floats out = new Floats();
        int quads = 0;
        int[] dx = {1, -1, 0, 0}, dz = {0, 0, 1, -1};
        for (int iz = 0; iz < gd && quads < MAX_QUADS_FAR; iz++) {
            for (int ix = 0; ix < gw && quads < MAX_QUADS_FAR; ix++) {
                int i = iz * gw + ix;
                if (m.pal()[i] == (byte) 255) continue;
                float[] sp = samples[m.pal()[i] & 255];
                float x0 = (float) ((m.tx0() + ix) * t - m.dx()), x1 = x0 + t;
                float z0 = (float) ((m.tz0() + iz) * t - m.dz()), z1 = z0 + t;
                float y = (float) (m.heights()[i] - m.dy());
                float dist = (float) Math.hypot(x0 + t / 2f, z0 + t / 2f);
                float fade = 1f - Mth.clamp((dist / maxDist - 0.7f) / 0.3f, 0f, 1f);       // memudar ke warna langit di tepi
                float r = sp[2] * amb, g = sp[3] * amb, b = sp[4] * amb;
                out.vertex(x0, y, z0, sp[0], sp[1], r, g, b, fade);
                out.vertex(x0, y, z1, sp[0], sp[1], r, g, b, fade);
                out.vertex(x1, y, z1, sp[0], sp[1], r, g, b, fade);
                out.vertex(x1, y, z0, sp[0], sp[1], r, g, b, fade);
                quads++;
                for (int k = 0; k < 4; k++) {
                    int nx = ix + dx[k], nz = iz + dz[k];
                    if (nx < 0 || nz < 0 || nx >= gw || nz >= gd) continue;
                    int ni = nz * gw + nx;
                    if (m.pal()[ni] == (byte) 255 || m.heights()[ni] >= m.heights()[i]) continue;
                    float yl = (float) (m.heights()[ni] - m.dy());
                    float sr = r * 0.7f, sg = g * 0.7f, sb = b * 0.7f;
                    if (dx[k] != 0) {
                        float xs = dx[k] > 0 ? x1 : x0;
                        out.vertex(xs, y, z0, sp[0], sp[1], sr, sg, sb, fade);
                        out.vertex(xs, y, z1, sp[0], sp[1], sr, sg, sb, fade);
                        out.vertex(xs, yl, z1, sp[0], sp[1], sr, sg, sb, fade);
                        out.vertex(xs, yl, z0, sp[0], sp[1], sr, sg, sb, fade);
                    } else {
                        float zs = dz[k] > 0 ? z1 : z0;
                        out.vertex(x0, y, zs, sp[0], sp[1], sr, sg, sb, fade);
                        out.vertex(x1, y, zs, sp[0], sp[1], sr, sg, sb, fade);
                        out.vertex(x1, yl, zs, sp[0], sp[1], sr, sg, sb, fade);
                        out.vertex(x0, yl, zs, sp[0], sp[1], sr, sg, sb, fade);
                    }
                    quads++;
                }
            }
        }
        if (v.farVb != null) v.farVb.close();
        v.farVb = upload(out);
    }

    // ---------------------------------------------------------------- menggambar

    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) return;
        if (disabled || userOff || VIEWS.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        try {
            renderNearest(e, mc);
        } catch (Throwable t) {
            fail("drawing the portal view", t);
        }
    }

    /** Masih ada blok Threshold di tempat bingkai ini? (Gerbang yang sudah menutup tidak boleh meninggalkan "hantu".) */
    private static boolean framePresent(Minecraft mc, View v) {
        Vec3 lat = v.axisX ? new Vec3(0, 0, 1) : new Vec3(1, 0, 0);
        for (int a = -1; a <= 1; a += 2) {
            for (int b = -1; b <= 1; b += 2) {
                double fx = a * Math.max(0, v.halfW - 0.5), fy = b * Math.max(0, v.halfH - 0.5);
                Vec3 p = v.src.add(lat.scale(fx)).add(0, fy, 0);
                if (mc.level.getBlockState(BlockPos.containing(p)).is(ModBlocks.THRESHOLD.get())) return true;
            }
        }
        return false;
    }

    private static void renderNearest(RenderLevelStageEvent e, Minecraft mc) {
        Camera cam = e.getCamera();
        Vec3 cp = cam.getPosition();
        String dimNow = mc.level.dimension().location().toString();
        long now = Util.getMillis();

        View best = null;
        double bestD = MAX_DIST * MAX_DIST, bestS = 0;
        for (Iterator<View> it = VIEWS.values().iterator(); it.hasNext(); ) {
            View v = it.next();
            if (now - v.lastMs > STALE_MS) {
                v.close();
                it.remove();
                continue;
            }
            if (!v.dim.equals(dimNow)) continue;
            Vec3 rel = cp.subtract(v.src);
            double d2 = rel.lengthSqr();
            if (d2 > bestD) continue;
            double s = rel.dot(v.axisX ? new Vec3(1, 0, 0) : new Vec3(0, 0, 1));
            if (Math.abs(s) < 0.03) continue;
            if (v.nearVb == null && v.farVb == null && v.waterVb == null) continue;
            if (!framePresent(mc, v)) continue;                       // gerbang sudah menutup: jangan digambar
            best = v;
            bestD = d2;
            bestS = s;
        }
        if (best == null) return;
        View v = best;
        lastWin = new Window(v.key, v.src, v.axisX, v.halfW, v.halfH);
        lastWinMs = Util.getMillis();

        if (!markerWritten) {
            markerWritten = true;
            try {
                Files.writeString(MARKER, "portal view started");
            } catch (Throwable ignored) {
                // tidak apa-apa: hanya pengaman tambahan
            }
        }

        Vec3 n = v.axisX ? new Vec3(1, 0, 0) : new Vec3(0, 0, 1);
        Vec3 lat = v.axisX ? new Vec3(0, 0, 1) : new Vec3(1, 0, 0);
        double sgn = bestS > 0 ? 1 : -1;
        Vec3 travel = n.scale(-sgn);                                  // arah dari pemain menembus portal
        Vec3 exit = new Vec3(v.ex, 0, v.ez);
        double dyaw = PortalMath.yawOf(exit) - PortalMath.yawOf(travel);
        Vec3 vcam = v.dest.add(PortalMath.rotateYaw(cp.subtract(v.src), dyaw));

        int tw = Math.max(64, mc.getMainRenderTarget().width / 2);
        int th = Math.max(64, mc.getMainRenderTarget().height / 2);
        if (target == null || target.width != tw || target.height != th) {
            if (target != null) target.destroyBuffers();
            target = new TextureTarget(tw, th, true, Minecraft.ON_OSX);
            target.setFilterMode(9729);                                // GL_LINEAR
        }
        target.setClearColor(v.skyR, v.skyG, v.skyB, 1f);
        target.clear(Minecraft.ON_OSX);

        Matrix4f proj = e.getProjectionMatrix();
        Matrix4f mainView = e.getPoseStack().last().pose();

        // ---- 1. sisi seberang ke tekstur kecil
        // kamera bayangan = kamera pemain yang diputar sebesar dyaw (pitch, roll, dan goyangan kamera ikut terbawa)
        Matrix4f virtualView = new Matrix4f(mainView).rotateY((float) Math.toRadians(dyaw))
                .translate((float) (v.dest.x - vcam.x), (float) (v.dest.y - vcam.y), (float) (v.dest.z - vcam.z));
        target.bindWrite(true);
        RenderSystem.setShader(GameRenderer::getPositionTexColorShader);
        RenderSystem.setShaderTexture(0, TextureAtlas.LOCATION_BLOCKS);
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(true);
        RenderSystem.disableCull();
        if (v.farVb != null) {
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            v.farVb.bind();
            v.farVb.drawWithShader(virtualView, proj, RenderSystem.getShader());
            VertexBuffer.unbind();
        }
        RenderSystem.disableBlend();
        if (v.nearVb != null) {
            v.nearVb.bind();
            v.nearVb.drawWithShader(virtualView, proj, RenderSystem.getShader());
            VertexBuffer.unbind();
        }
        if (v.waterVb != null) {                                       // water: translucent, drawn after the opaque blocks
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.depthMask(false);
            v.waterVb.bind();
            v.waterVb.drawWithShader(virtualView, proj, RenderSystem.getShader());
            VertexBuffer.unbind();
            RenderSystem.depthMask(true);
            RenderSystem.disableBlend();
        }
        PortalGhosts.render(mc, v.key, v.dest, proj, virtualView, e.getPartialTick());   // entities on the other side
        mc.getMainRenderTarget().bindWrite(true);

        // ---- 2. tekstur itu ke bukaan Threshold
        double off = Math.abs(bestS) > 0.55 ? 0.52 : 0.0;             // di depan permukaan blok; di dalam blok: di bidang tengah
        Vec3 pc = v.src.add(n.scale(sgn * off));
        Matrix4f pm = new Matrix4f(proj).mul(mainView);
        int gx = GRID_X, gy = GRID_Y;
        float[][] gv = new float[(gx + 1) * (gy + 1)][];
        Vector4f tmp = new Vector4f();
        int outAnd = 0x1F;
        for (int iy = 0; iy <= gy; iy++) {
            for (int ix = 0; ix <= gx; ix++) {
                double fx = (ix / (double) gx * 2 - 1) * v.halfW, fy = (iy / (double) gy * 2 - 1) * v.halfH;
                Vec3 p = pc.add(lat.scale(fx)).add(0, fy, 0).subtract(cp);
                tmp.set((float) p.x, (float) p.y, (float) p.z, 1f);
                pm.transform(tmp);
                float[] g = {(float) p.x, (float) p.y, (float) p.z, tmp.x, tmp.y, tmp.z, tmp.w};
                gv[iy * (gx + 1) + ix] = g;
                int code = 0;
                if (g[3] < -g[6]) code |= 1;
                if (g[3] > g[6]) code |= 2;
                if (g[4] < -g[6]) code |= 4;
                if (g[4] > g[6]) code |= 8;
                if (g[6] < NEAR_W) code |= 16;
                outAnd &= code;
            }
        }
        if (outAnd != 0) {                                             // seluruh jendela di luar layar atau di belakang kamera
            afterDraw();
            return;
        }
        List<float[]> polys = new ArrayList<>();
        for (int iy = 0; iy < gy; iy++) {
            for (int ix = 0; ix < gx; ix++) {
                float[][] quad = {gv[iy * (gx + 1) + ix], gv[iy * (gx + 1) + ix + 1], gv[(iy + 1) * (gx + 1) + ix + 1], gv[(iy + 1) * (gx + 1) + ix]};
                clipNear(quad, polys);
            }
        }
        if (!polys.isEmpty()) {
            RenderSystem.setShader(GameRenderer::getPositionTexShader);
            RenderSystem.setShaderTexture(0, target.getColorTextureId());
            RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
            PoseStack mv = RenderSystem.getModelViewStack();
            mv.pushPose();
            mv.setIdentity();
            mv.mulPoseMatrix(mainView);
            RenderSystem.applyModelViewMatrix();
            BufferBuilder bb = Tesselator.getInstance().getBuilder();
            bb.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_TEX);
            for (float[] poly : polys) {
                int cnt = poly.length / 5;
                for (int i = 1; i + 1 < cnt; i++) {
                    int[] idx = {0, i, i + 1, i + 1};
                    for (int c : idx) bb.vertex(poly[c * 5], poly[c * 5 + 1], poly[c * 5 + 2]).uv(poly[c * 5 + 3], poly[c * 5 + 4]).endVertex();
                }
            }
            BufferUploader.drawWithShader(bb.end());
            mv.popPose();
            RenderSystem.applyModelViewMatrix();
        }
        afterDraw();
    }

    /**
     * Potong segi empat (titik: x y z cx cy cz cw) terhadap bidang dekat kamera (cw >= NEAR_W) dan tambahkan hasilnya ke out
     * sebagai poligon datar (x y z u v per titik, uv = koordinat layar). Tanpa ini, jendela yang sebagian ada di belakang kamera
     * (pemain berdiri dekat) tidak digambar sama sekali dan seolah hilang ketika arah pandang sedikit berubah.
     */
    private static void clipNear(float[][] quad, List<float[]> out) {
        List<float[]> poly = new ArrayList<>(5);
        for (int i = 0; i < 4; i++) {
            float[] a = quad[i], b = quad[(i + 1) % 4];
            boolean ina = a[6] >= NEAR_W, inb = b[6] >= NEAR_W;
            if (ina) poly.add(a);
            if (ina != inb) {
                float t = (NEAR_W - a[6]) / (b[6] - a[6]);
                float[] c = new float[7];
                for (int k = 0; k < 7; k++) c[k] = a[k] + (b[k] - a[k]) * t;
                c[6] = NEAR_W;
                poly.add(c);
            }
        }
        if (poly.size() < 3) return;
        float[] flat = new float[poly.size() * 5];
        for (int i = 0; i < poly.size(); i++) {
            float[] p = poly.get(i);
            flat[i * 5] = p[0];
            flat[i * 5 + 1] = p[1];
            flat[i * 5 + 2] = p[2];
            flat[i * 5 + 3] = (p[3] / p[6]) * 0.5f + 0.5f;
            flat[i * 5 + 4] = (p[4] / p[6]) * 0.5f + 0.5f;
        }
        out.add(flat);
    }

    private static void afterDraw() {
        RenderSystem.enableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(true);
        RenderSystem.disableBlend();
        if (++okFrames == OK_FRAMES_TO_CLEAR_MARKER) {
            try {
                Files.deleteIfExists(MARKER);
            } catch (Throwable ignored) {
                // tidak apa-apa
            }
        }
    }

    private static void fail(String what, Throwable t) {
        disabled = true;
        try {
            Minecraft.getInstance().getMainRenderTarget().bindWrite(true);
            VertexBuffer.unbind();
            RenderSystem.enableCull();
        } catch (Throwable ignored) {
            // sudah mati juga
        }
        closeAll();
        try {
            Files.deleteIfExists(MARKER);
        } catch (Throwable ignored) {
            // tidak apa-apa
        }
        TheComplex.LOGGER.error("Threshold see-through failed while " + what + ", switching it off for this session", t);
        notice = "The Threshold see-through effect hit an error and was switched off (the Threshold still works). See latest.log.";
    }

    // ---------------------------------------------------------------- pesan dan perintah

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        finishBakes();
        PortalGhosts.tick();
        if (notice == null) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        mc.player.sendSystemMessage(Component.literal("[Complex] " + notice));
        notice = null;
    }

    @SubscribeEvent
    public static void onCommands(RegisterClientCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("complexview")
                .then(Commands.literal("on").executes(c -> {
                    userOff = false;
                    disabled = false;
                    okFrames = 0;
                    markerWritten = false;
                    save("on");
                    c.getSource().sendSuccess(() -> Component.literal("Threshold see-through: ON"), false);
                    return 1;
                }))
                .then(Commands.literal("off").executes(c -> {
                    userOff = true;
                    closeAll();
                    save("off");
                    c.getSource().sendSuccess(() -> Component.literal("Threshold see-through: OFF"), false);
                    return 1;
                }))
                .then(Commands.literal("status").executes(c -> {
                    String s = disabled ? "switched off after an error" : userOff ? "OFF" : "ON";
                    c.getSource().sendSuccess(() -> Component.literal("Threshold see-through: " + s + " (views loaded: " + VIEWS.size() + ")"), false);
                    return 1;
                })));
    }

    private static void save(String value) {
        try {
            Files.writeString(SETTING, value);
        } catch (Throwable ignored) {
            // tidak apa-apa: pengaturan berlaku sampai game ditutup
        }
    }
}
