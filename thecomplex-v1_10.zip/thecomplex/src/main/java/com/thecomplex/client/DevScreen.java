package com.thecomplex.client;

import com.thecomplex.dev.DevActions;
import com.thecomplex.net.DevActionPacket;
import com.thecomplex.net.Net;
import net.minecraft.Util;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Developer UI (v1.9): a searchable command palette. Open it with the Developer UI key (default K) or the Complex Dev Tool item.
 *
 *  - type in the search bar: every tool in every category is filtered live (several words = all of them must match)
 *  - Up / Down moves the highlight, Enter runs it; or just tap / click a row
 *  - the left list picks a category; scroll with the mouse wheel or by dragging the list
 *  - the last result of an action is shown at the bottom
 * The search text, category and scroll position are kept while the UI refreshes after an action.
 */
public class DevScreen extends Screen {
    // ---- UI state that survives refreshes
    private static String query = "";
    private static int category = 0;
    private static double scroll = 0;
    private static int selected = 0;

    private static final String[] CATEGORIES = {"All", "Travel", "Null Zones", "Tracker", "Rooms", "LPMDS", "Briefcase", "Debug"};
    private static final int ALL = 0, TRAVEL = 1, NULLZONES = 2, TRACKER = 3, ROOMS = 4, LPMDS = 5, BRIEFCASE = 6, DEBUG = 7;

    // ---- colors (ARGB)
    private static final int BACKDROP = 0xB0050507, PANEL = 0xFF15171D, PANEL_EDGE = 0xFF2C303C, HEADER = 0xFF1B1E26;
    private static final int ACCENT = 0xFFE8C547, TEXT = 0xFFECEFF4, MUTED = 0xFF8B93A5, HOVER = 0xFF242836, SIDE_SELECTED = 0xFF2A2E3C;
    private static final int ROW_H = 28;

    private record Entry(int category, String label, String desc, String keywords, int action, String arg) {}

    private final String status;
    private final List<String> rooms;
    private final List<String> zones;     // "id|text"
    private final String note;
    private final long openedAt = Util.getMillis();

    private final List<Entry> all = new ArrayList<>();
    private List<Entry> shown = new ArrayList<>();
    private EditBox search;

    // layout
    private int px, py, pw, ph, sideX, sideY, sideW, listX, listY, listW, listH;

    // pointer state
    private int pressedRow = -1;
    private double pressX, pressY, moved;
    private boolean pressInList;

    public DevScreen(String status, List<String> rooms, List<String> zones, String note) {
        super(Component.literal("The Complex - Developer"));
        this.status = status;
        this.rooms = rooms;
        this.zones = zones;
        this.note = note == null ? "" : note;
        buildEntries();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    // ---------------------------------------------------------------- the tools

    private void add(int cat, String label, String desc, String keywords, int action) {
        all.add(new Entry(cat, label, desc, keywords, action, ""));
    }

    private void buildEntries() {
        add(TRAVEL, "Enter Main Chamber", "Go to the Main Chamber arrival point.", "enter main chamber arrival teleport go", DevActions.ENTER);
        add(TRAVEL, "Random Backrooms", "Drop into a random spot far from the Main Chamber.", "random backrooms complex teleport far", DevActions.BACKROOMS);
        add(TRAVEL, "Leave to Overworld", "Return to the Overworld.", "leave exit overworld return", DevActions.LEAVE);

        add(NULLZONES, "Null Zone (random)", "Create a Null Zone near you, wall or floor.", "null zone create random spawn", DevActions.NZ_ANY);
        add(NULLZONES, "Null Zone on floor", "Floor Null Zone: you fall in through the Backrooms ceiling.", "null zone floor fall ceiling", DevActions.NZ_FLOOR);
        add(NULLZONES, "Null Zone on wall", "Wall Null Zone: walk into the wall.", "null zone wall", DevActions.NZ_WALL);
        add(NULLZONES, "Null Zone on grass / dirt", "Floor Null Zone on grass or dirt (stand outside).", "null zone grass dirt ground outside", DevActions.NZ_GROUND);
        add(NULLZONES, "Stable Wild Null Zone", "Permanent two-way portal to a thick wall in the Backrooms.", "stable wild null zone portal two way permanent", DevActions.NZ_STABLE);
        add(NULLZONES, "Give Null Zone items", "4 placeable Null Zones: right-click a block to convert it.", "give null zone item place manual player", DevActions.NZ_GIVE);
        add(NULLZONES, "Restore all wild Null Zones", "Turn every recorded wild Null Zone back into its block.", "restore clear remove all wild null zones", DevActions.ZONES_CLEAR);
        add(NULLZONES, "Heat this chunk +240", "Raise the activity heat here: Null Zones appear more often.", "heat activity boost chance", DevActions.HEAT_BOOST);
        add(NULLZONES, "Clear heat log", "Forget your recorded activity.", "heat activity clear reset log", DevActions.HEAT_RESET);

        add(TRACKER, "Teleport to nearest Null Zone", "Go next to the closest recorded Null Zone.", "tracker nearest null zone teleport", DevActions.ZONE_NEAREST);
        for (String z : zones) {
            int bar = z.indexOf('|');
            String id = bar < 0 ? "" : z.substring(0, bar);
            String text = bar < 0 ? z : z.substring(bar + 1);
            all.add(new Entry(TRACKER, text, "Teleport next to this Null Zone.", "tracker null zone teleport", DevActions.ZONE_TP, id));
        }

        add(ROOMS, "Reload rooms", "Re-read the bundled .schem rooms.", "rooms reload schem refresh", DevActions.ROOM_RELOAD);
        for (String r : rooms) {
            all.add(new Entry(ROOMS, "Paste: " + r, "Paste this room under your feet.", "room paste schem " + r, DevActions.ROOM_PASTE, r));
        }

        add(LPMDS, "Give LPMDS set", "LPMDS, Emitter Chute and Magnetic Marker.", "lpmds give set machine marker chute", DevActions.LPMDS_GIVE);
        add(LPMDS, "Fill power", "Fill the nearest LPMDS power.", "lpmds power fill charge", DevActions.LPMDS_CHARGE);
        add(LPMDS, "Mark failed tests done", "The next test is the final one.", "lpmds tests skip final", DevActions.LPMDS_SKIP);
        add(LPMDS, "Force-open Threshold", "Open the Threshold of the nearest LPMDS now.", "lpmds threshold open force", DevActions.LPMDS_OPEN);
        add(LPMDS, "Close Threshold", "Close the Threshold of the nearest LPMDS.", "lpmds threshold close", DevActions.LPMDS_CLOSE);
        add(LPMDS, "Reset machine", "Test 0, power 0, marking cleared.", "lpmds reset machine", DevActions.LPMDS_RESET);
        add(LPMDS, "Nearest machine info", "Print the nearest LPMDS state.", "lpmds info status machine", DevActions.LPMDS_INFO);
        add(LPMDS, "Natural Null Zones ON / OFF", "Toggle the \"LPMDS was activated\" flag.", "natural null zones flag lpmds activated toggle", DevActions.LPMDS_FLAG);

        add(BRIEFCASE, "Give Briefcase set", "Briefcase, flashlight, batteries, duct tape, anchors, rope.", "briefcase give set flashlight rope tape", DevActions.BRIEFCASE_GIVE);
        add(BRIEFCASE, "Recall Briefcases on the ground", "Return thrown Briefcases within 48 blocks.", "briefcase recall pick up thrown", DevActions.BRIEFCASE_RECALL);

        add(DEBUG, "Chunk info", "Division, room template and axis of the chunk you stand in.", "debug chunk info division template generator pattern", DevActions.DEBUG_CHUNK);
        add(DEBUG, "Print status to chat", "Full status: dimension, rooms, position, heat.", "debug status chat info", DevActions.STATUS_CHAT);
        add(DEBUG, "Refresh", "Reload this screen's data.", "refresh reload update", DevActions.REFRESH);
        add(DEBUG, "Toggle creative / survival", "Switch your game mode.", "creative survival gamemode toggle", DevActions.TOGGLE_MODE);
        add(DEBUG, "Restore health and hunger", "Full health, full hunger.", "heal health hunger restore full", DevActions.HEAL);
    }

    // ---------------------------------------------------------------- search

    private static boolean blank(String s) {
        return s == null || s.trim().isEmpty();
    }

    private void refilter() {
        shown = new ArrayList<>();
        String[] tokens = blank(query) ? new String[0] : query.toLowerCase(Locale.ROOT).trim().split("\\s+");
        List<Entry> first = new ArrayList<>(), second = new ArrayList<>();
        for (Entry e : all) {
            if (tokens.length == 0) {
                if (category == ALL || e.category == category) shown.add(e);
                continue;
            }
            String label = e.label.toLowerCase(Locale.ROOT);
            String hay = label + " " + e.desc.toLowerCase(Locale.ROOT) + " " + e.keywords.toLowerCase(Locale.ROOT) + " " + CATEGORIES[e.category].toLowerCase(Locale.ROOT);
            boolean ok = true, inLabel = true;
            for (String t : tokens) {
                if (!hay.contains(t)) {
                    ok = false;
                    break;
                }
                if (!label.contains(t)) inLabel = false;
            }
            if (ok) (inLabel ? first : second).add(e);
        }
        if (tokens.length > 0) {
            shown.addAll(first);
            shown.addAll(second);
        }
        selected = Mth.clamp(selected, 0, Math.max(0, shown.size() - 1));
        clampScroll();
    }

    private void clampScroll() {
        double max = Math.max(0, shown.size() * ROW_H - listH);
        scroll = Mth.clamp(scroll, 0, max);
    }

    private int count(int cat) {
        if (cat == ALL) return all.size();
        int n = 0;
        for (Entry e : all) if (e.category == cat) n++;
        return n;
    }

    // ---------------------------------------------------------------- layout

    @Override
    protected void init() {
        pw = Math.min(width - 10, 470);
        ph = Math.min(height - 10, 280);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        sideW = pw < 320 ? 64 : 84;
        sideX = px + 8;
        sideY = py + 52;
        listX = sideX + sideW + 6;
        listY = sideY;
        listW = px + pw - 8 - 6 - listX;
        listH = py + ph - 30 - listY;

        search = new EditBox(font, px + 10, py + 25, pw - 20, 18, Component.literal("Search"));
        search.setMaxLength(60);
        search.setHint(Component.literal("Search tools...  e.g. null floor, room, lpmds"));
        search.setValue(query);
        search.setResponder(v -> {
            query = v;
            scroll = 0;
            selected = 0;
            refilter();
        });
        addRenderableWidget(search);
        setInitialFocus(search);

        addRenderableWidget(Button.builder(Component.literal("X"), b -> onClose()).bounds(px + pw - 26, py + 5, 18, 16).build());
        refilter();
    }

    // ---------------------------------------------------------------- drawing

    private int rowAt(double mx, double my) {
        if (mx < listX || mx >= listX + listW || my < listY || my >= listY + listH) return -1;
        int i = (int) ((my - listY + scroll) / ROW_H);
        return i >= 0 && i < shown.size() ? i : -1;
    }

    private int sideAt(double mx, double my) {
        if (mx < sideX || mx >= sideX + sideW || my < sideY) return -1;
        int i = (int) ((my - sideY) / 22);
        return i >= 0 && i < CATEGORIES.length ? i : -1;
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        g.fill(0, 0, width, height, BACKDROP);
        // panel with a 1 px edge and a header
        g.fill(px - 1, py - 1, px + pw + 1, py + ph + 1, PANEL_EDGE);
        g.fill(px, py, px + pw, py + ph, PANEL);
        g.fill(px, py, px + pw, py + 48, HEADER);
        g.fill(px, py + 48, px + pw, py + 49, ACCENT);
        g.drawString(font, "THE COMPLEX", px + 10, py + 8, ACCENT, false);
        g.drawString(font, "Developer", px + 10 + font.width("THE COMPLEX ") , py + 8, TEXT, false);
        String[] lines = status.split("\n");
        String right = lines.length > 3 ? lines[3] : (lines.length > 0 ? lines[0] : "");
        int rw = pw - 34 - font.width("THE COMPLEX Developer") - 28;
        if (rw > 40) {
            String r = font.plainSubstrByWidth(right, rw);
            g.drawString(font, r, px + pw - 34 - font.width(r), py + 9, MUTED, false);
        }

        // sidebar
        for (int i = 0; i < CATEGORIES.length; i++) {
            int y = sideY + i * 22;
            boolean sel = blank(query) && i == category;
            boolean hov = sideAt(mx, my) == i;
            if (sel) {
                g.fill(sideX, y, sideX + sideW, y + 20, SIDE_SELECTED);
                g.fill(sideX, y, sideX + 3, y + 20, ACCENT);
            } else if (hov) {
                g.fill(sideX, y, sideX + sideW, y + 20, HOVER);
            }
            g.drawString(font, font.plainSubstrByWidth(CATEGORIES[i], sideW - 26), sideX + 8, y + 6, sel ? ACCENT : 0xFFB8BECC, false);
            String n = String.valueOf(count(i));
            g.drawString(font, n, sideX + sideW - 4 - font.width(n), y + 6, MUTED, false);
        }

        // list
        g.enableScissor(listX, listY, listX + listW, listY + listH);
        boolean searching = !blank(query);
        int first = (int) (scroll / ROW_H);
        for (int i = first; i < shown.size(); i++) {
            int y = listY + i * ROW_H - (int) scroll;
            if (y >= listY + listH) break;
            Entry e = shown.get(i);
            boolean hov = rowAt(mx, my) == i;
            if (hov || i == selected) g.fill(listX, y, listX + listW, y + ROW_H - 2, hov ? HOVER : 0xFF1D202A);
            if (i == selected) g.fill(listX, y, listX + 2, y + ROW_H - 2, ACCENT);
            int chip = searching ? font.width(CATEGORIES[e.category]) + 8 : 0;
            g.drawString(font, font.plainSubstrByWidth(e.label, listW - 14 - chip), listX + 8, y + 4, TEXT, false);
            g.drawString(font, font.plainSubstrByWidth(e.desc, listW - 14 - chip), listX + 8, y + 15, MUTED, false);
            if (searching) {
                String c = CATEGORIES[e.category];
                g.drawString(font, c, listX + listW - 6 - font.width(c), y + 4, ACCENT, false);
            }
        }
        g.disableScissor();
        if (shown.isEmpty()) {
            g.drawCenteredString(font, "Nothing matches. Try fewer or other words.", listX + listW / 2, listY + 24, MUTED);
        }
        // scrollbar
        double max = Math.max(0, shown.size() * ROW_H - listH);
        if (max > 0) {
            int bx = listX + listW + 2;
            g.fill(bx, listY, bx + 3, listY + listH, 0xFF20232D);
            int bh = Math.max(16, (int) (listH * (listH / (listH + max))));
            int by = listY + (int) ((listH - bh) * (scroll / max));
            g.fill(bx, by, bx + 3, by + bh, ACCENT);
        }

        // footer
        int fy = py + ph - 22;
        g.fill(px, fy - 4, px + pw, fy - 3, PANEL_EDGE);
        String foot = blank(note) ? "Enter = run the highlighted tool   |   Esc or X = close" : note;
        g.drawString(font, font.plainSubstrByWidth(foot, pw - 20), px + 10, fy + 3, blank(note) ? MUTED : 0xFFF2E3A0, false);

        super.render(g, mx, my, pt);
    }

    // ---------------------------------------------------------------- input

    private void run(Entry e) {
        Net.CHANNEL.sendToServer(new DevActionPacket(e.action, e.arg));
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (super.mouseClicked(mx, my, button)) return true;
        int s = sideAt(mx, my);
        if (s >= 0) {
            category = s;
            query = "";
            search.setValue("");
            scroll = 0;
            selected = 0;
            refilter();
            return true;
        }
        pressedRow = rowAt(mx, my);
        pressInList = mx >= listX && mx < listX + listW && my >= listY && my < listY + listH;
        pressX = mx;
        pressY = my;
        moved = 0;
        return pressInList;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (pressInList) {
            scroll -= dy;
            moved += Math.abs(dx) + Math.abs(dy);
            clampScroll();
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        boolean wasList = pressInList;
        pressInList = false;
        if (wasList) {
            int row = pressedRow;
            pressedRow = -1;
            if (moved < 6 && row >= 0 && row < shown.size() && rowAt(mx, my) == row) {
                selected = row;
                run(shown.get(row));
            }
            return true;
        }
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double delta) {
        scroll -= delta * ROW_H;
        clampScroll();
        return true;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == 265 || key == 264) {                            // up / down
            if (!shown.isEmpty()) {
                selected = Mth.clamp(selected + (key == 264 ? 1 : -1), 0, shown.size() - 1);
                double top = selected * ROW_H;
                if (top < scroll) scroll = top;
                if (top + ROW_H > scroll + listH) scroll = top + ROW_H - listH;
                clampScroll();
            }
            return true;
        }
        if ((key == 257 || key == 335) && !shown.isEmpty()) {      // enter
            run(shown.get(Mth.clamp(selected, 0, shown.size() - 1)));
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public boolean charTyped(char c, int mods) {
        // the key that opened this screen must not end up in the search box
        if (Util.getMillis() - openedAt < 150) return true;
        return super.charTyped(c, mods);
    }
}
