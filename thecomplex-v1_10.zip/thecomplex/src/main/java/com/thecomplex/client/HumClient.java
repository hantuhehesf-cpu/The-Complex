package com.thecomplex.client;

import com.thecomplex.ModBlocks;
import com.thecomplex.TheComplex;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Starts the hum of the fluorescent panels around the player (v1.10). Every half second the nearest panels (at most MAX_SOURCES)
 * get their own looping, positioned sound; panels that are too far, or gone, stop on their own. This works in every dimension,
 * so a panel you place in the Overworld buzzes too.
 */
@Mod.EventBusSubscriber(modid = TheComplex.MODID, value = Dist.CLIENT)
public final class HumClient {
    private static final int MAX_SOURCES = 6;
    private static final int SCAN_EVERY = 10;
    private static final Map<Long, HumSound> ACTIVE = new HashMap<>();
    private static int timer;

    private HumClient() {}

    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) {
            ACTIVE.clear();
            return;
        }
        for (Iterator<HumSound> it = ACTIVE.values().iterator(); it.hasNext(); ) {
            if (it.next().isStopped()) it.remove();
        }
        if (++timer < SCAN_EVERY) return;
        timer = 0;

        int r = (int) HumSound.RANGE;
        BlockPos p = mc.player.blockPosition();
        List<BlockPos> found = new ArrayList<>();
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int dy = -3; dy <= 7; dy++) {
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    if (dx * dx + dz * dz > r * r) continue;
                    m.set(p.getX() + dx, p.getY() + dy, p.getZ() + dz);
                    if (mc.level.getBlockState(m).is(ModBlocks.FLUORESCENT_PANEL.get())) found.add(m.immutable());
                }
            }
        }
        found.sort((a, b) -> Double.compare(a.distSqr(p), b.distSqr(p)));
        for (int i = 0; i < found.size() && i < MAX_SOURCES; i++) {
            BlockPos q = found.get(i);
            if (ACTIVE.containsKey(q.asLong())) continue;
            if (ACTIVE.size() >= MAX_SOURCES) break;
            HumSound s = new HumSound(q);
            ACTIVE.put(q.asLong(), s);
            mc.getSoundManager().play(s);
        }
    }
}
