package com.thecomplex.client;

import com.mojang.authlib.GameProfile;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexSorting;
import com.thecomplex.net.PortalEntitiesPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.RemotePlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * The entities on the other side of a Threshold (v1.10). The server sends their positions; here each one becomes a "ghost":
 * a normal entity object of the same type that lives only in this class (it is never added to the world) and is drawn with the
 * vanilla entity renderers inside the see-through pass. Players are drawn with their own skin.
 * Any failure turns the ghosts off for the rest of the session; the portal view itself keeps working.
 */
public final class PortalGhosts {
    private static final class Ghost {
        Entity entity;
        Vec3 shown, target;
        float yRot, head, body;
        int light;
        long seenMs;
    }

    private static final Map<Long, Map<Integer, Ghost>> BY_VIEW = new HashMap<>();
    private static final Set<Integer> BAD_TYPES = new HashSet<>();
    private static boolean disabled;
    private static final long KEEP_MS = 1500;

    private PortalGhosts() {}

    public static void clear() {
        BY_VIEW.clear();
    }

    public static void receive(PortalEntitiesPacket m) {
        if (disabled) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        try {
            Map<Integer, Ghost> map = BY_VIEW.computeIfAbsent(m.key(), k -> new HashMap<>());
            long now = System.currentTimeMillis();
            for (PortalEntitiesPacket.Ent e : m.ents()) {
                Ghost g = map.get(e.id());
                if (g == null) {
                    if (BAD_TYPES.contains(e.type())) continue;
                    Entity ent = create(mc, e);
                    if (ent == null) {
                        BAD_TYPES.add(e.type());
                        continue;
                    }
                    g = new Ghost();
                    g.entity = ent;
                    g.shown = new Vec3(e.x(), e.y(), e.z());
                    map.put(e.id(), g);
                }
                g.target = new Vec3(e.x(), e.y(), e.z());
                g.yRot = e.yRot();
                g.head = e.head();
                g.body = e.body();
                g.light = e.light();
                g.seenMs = now;
                Entity ent = g.entity;
                ent.setXRot(e.xRot());
                ent.setShiftKeyDown((e.flags() & 1) != 0);
                if (ent instanceof Mob mob && (e.flags() & 2) != 0) mob.setBaby(true);
            }
            for (Iterator<Ghost> it = map.values().iterator(); it.hasNext(); ) {
                if (now - it.next().seenMs > KEEP_MS) it.remove();
            }
        } catch (Throwable t) {
            disabled = true;
            BY_VIEW.clear();
        }
    }

    private static Entity create(Minecraft mc, PortalEntitiesPacket.Ent e) {
        try {
            EntityType<?> type = BuiltInRegistries.ENTITY_TYPE.byId(e.type());
            if (type == null) return null;
            if (type == EntityType.PLAYER) return new RemotePlayer(mc.level, new GameProfile(e.uuid(), e.name()));
            return type.create(mc.level);
        } catch (Throwable t) {
            return null;
        }
    }

    /** One tick of animation time for every ghost (idle arms, tails, ears...). */
    public static void tick() {
        if (BY_VIEW.isEmpty()) return;
        for (Map<Integer, Ghost> map : BY_VIEW.values()) {
            for (Ghost g : map.values()) g.entity.tickCount++;
        }
    }

    /**
     * Draws the ghosts of one view. Called while the see-through texture is the render target: virtualView/proj are the matrices of the
     * virtual camera, origin = the destination frame center (the origin of the baked blocks).
     */
    public static void render(Minecraft mc, long key, Vec3 origin, Matrix4f proj, Matrix4f virtualView, float partial) {
        if (disabled) return;
        Map<Integer, Ghost> map = BY_VIEW.get(key);
        if (map == null || map.isEmpty()) return;
        PoseStack mv = RenderSystem.getModelViewStack();
        boolean pushed = false;
        EntityRenderDispatcher disp = mc.getEntityRenderDispatcher();
        try {
            mv.pushPose();
            pushed = true;
            mv.setIdentity();
            mv.mulPoseMatrix(virtualView);
            RenderSystem.applyModelViewMatrix();
            RenderSystem.setProjectionMatrix(proj, VertexSorting.DISTANCE_TO_ORIGIN);
            mc.gameRenderer.lightTexture().turnOnLightLayer();
            disp.setRenderShadow(false);                    // shadows would be cast on the blocks of the wrong dimension
            MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();
            PoseStack ps = new PoseStack();
            for (Ghost g : map.values()) {
                g.shown = g.shown.add(g.target.subtract(g.shown).scale(0.4));
                Entity ent = g.entity;
                ent.setYRot(g.yRot);
                ent.yRotO = g.yRot;
                ent.xRotO = ent.getXRot();
                if (ent instanceof LivingEntity le) {
                    le.yHeadRot = g.head;
                    le.yHeadRotO = g.head;
                    le.yBodyRot = g.body;
                    le.yBodyRotO = g.body;
                }
                ent.setPos(g.shown.x, g.shown.y, g.shown.z);
                ent.xo = g.shown.x;
                ent.yo = g.shown.y;
                ent.zo = g.shown.z;
                disp.render(ent, g.shown.x - origin.x, g.shown.y - origin.y, g.shown.z - origin.z, g.yRot, partial, ps, buf, g.light);
            }
            buf.endBatch();
        } catch (Throwable t) {
            disabled = true;
            BY_VIEW.clear();
        } finally {
            try {
                disp.setRenderShadow(true);
                mc.gameRenderer.lightTexture().turnOffLightLayer();
            } catch (Throwable ignored) {
                // nothing to restore
            }
            if (pushed) {
                mv.popPose();
                RenderSystem.applyModelViewMatrix();
            }
        }
    }
}
