package com.thecomplex.briefcase;

import net.minecraftforge.common.ForgeConfigSpec;

import java.util.List;

/** Pengaturan Briefcase, senter, tali. File: config/thecomplex-briefcase.toml */
public final class BriefcaseConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.IntValue ROWS;
    public static final ForgeConfigSpec.IntValue ROPE_MAX;
    public static final ForgeConfigSpec.IntValue FLASHLIGHT_SLOT_MINUTES;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> EXTRA_SIZES;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.comment("Exploration Briefcase").push("briefcase");
        ROWS = b.comment("Briefcase inventory grid height (width is always 8). 3 or 4.")
                .defineInRange("rows", 4, 3, 4);
        ROPE_MAX = b.comment("Maximum rope length (blocks).")
                .defineInRange("ropeMaxLength", 12, 2, 24);
        EXTRA_SIZES = b.comment("Sizes of other mods' items in the grid, format \"modid:item=WidthxHeight\". Example: \"exposure:camera=2x2\".",
                        "Items without size data count as 1x1. Blocks (BlockItem) are not allowed, except the Duct Anchor.")
                .defineList("extraSizes", List.of("exposure:camera=2x2"), o -> o instanceof String);
        b.pop();
        b.comment("Flashlight").push("flashlight");
        FLASHLIGHT_SLOT_MINUTES = b.comment("Duration of one battery slot (minutes). The flashlight has 2 slots.")
                .defineInRange("slotMinutes", 7, 1, 120);
        b.pop();
        SPEC = b.build();
    }

    private BriefcaseConfig() {}
}
