package com.thecomplex.briefcase;

import com.thecomplex.ModItems;
import com.thecomplex.net.BriefcaseSyncPacket;
import com.thecomplex.net.Net;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.PacketDistributor;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Sesi inventori Briefcase di server. Sumber kebenaran ada di NBT item (di tangan / di tanah);
 * klien hanya mengirim operasi, server memvalidasi lalu mengirim ulang isi terbaru.
 */
public final class BriefcaseSessions {
    public static final int OP_PUT = 0, OP_MOVE = 1, OP_TAKE = 2, OP_PUT_ROPE = 3, OP_TAKE_ROPE = 4, OP_QUICK_PUT = 5, OP_CLOSE = 6;
    public static final int MODE_OPEN = 0, MODE_UPDATE = 1;

    /** kind 0 = slot inventori pemain (id = indeks slot), kind 1 = entitas di tanah (id = id entitas). */
    private record Src(int kind, int id) {}

    private static final Map<UUID, Src> SESSIONS = new HashMap<>();

    private BriefcaseSessions() {}

    public static void openHand(ServerPlayer p, int slot) {
        Src s = new Src(0, slot);
        SESSIONS.put(p.getUUID(), s);
        sync(p, s, MODE_OPEN);
    }

    public static void openEntity(ServerPlayer p, BriefcaseEntity e) {
        Src s = new Src(1, e.getId());
        SESSIONS.put(p.getUUID(), s);
        sync(p, s, MODE_OPEN);
    }

    private static ItemStack resolve(ServerPlayer p, Src s) {
        if (s.kind() == 0) {
            if (s.id() < 0 || s.id() > 40) return ItemStack.EMPTY;
            ItemStack st = p.getInventory().getItem(s.id());
            return st.getItem() instanceof BriefcaseItem ? st : ItemStack.EMPTY;
        }
        Entity e = p.level().getEntity(s.id());
        if (e instanceof BriefcaseEntity be && be.isAlive() && be.distanceToSqr(p) < 49.0) return be.getStack();
        return ItemStack.EMPTY;
    }

    private static void sync(ServerPlayer p, Src s, int mode) {
        ItemStack b = resolve(p, s);
        if (b.isEmpty()) {
            SESSIONS.remove(p.getUUID());
            return;
        }
        Net.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p),
                new BriefcaseSyncPacket(mode, BriefcaseData.rows(), BriefcaseData.syncTag(b)));
    }

    private static void note(ServerPlayer p, String text) {
        p.displayClientMessage(Component.literal(text), true);
    }

    public static void handleOp(ServerPlayer p, int op, int a, int b, int c) {
        Src s = SESSIONS.get(p.getUUID());
        if (s == null) return;
        if (op == OP_CLOSE) {
            SESSIONS.remove(p.getUUID());
            return;
        }
        ItemStack briefcase = resolve(p, s);
        if (briefcase.isEmpty()) {
            SESSIONS.remove(p.getUUID());
            return;
        }
        Inventory inv = p.getInventory();
        int rows = BriefcaseData.rows();
        List<BriefcaseData.Entry> list = BriefcaseData.read(briefcase);

        switch (op) {
            case OP_PUT, OP_QUICK_PUT -> {
                if (a < 0 || a > 35) return;
                ItemStack src = inv.getItem(a);
                BriefcaseSizes.Size sz = BriefcaseSizes.of(src);
                if (sz == null) {
                    note(p, src.isEmpty() ? "Empty slot." : "This item doesn't fit in the Briefcase.");
                    break;
                }
                int x = b, y = c;
                if (op == OP_QUICK_PUT) {
                    int[] free = BriefcaseData.findFree(list, sz.w(), sz.h(), rows);
                    if (free == null) {
                        note(p, "The Briefcase is full.");
                        break;
                    }
                    x = free[0];
                    y = free[1];
                }
                if (!BriefcaseData.fits(list, -1, x, y, sz.w(), sz.h(), rows)) {
                    note(p, "It doesn't fit there.");
                    break;
                }
                list.add(new BriefcaseData.Entry(x, y, sz.w(), sz.h(), src.copy()));
                inv.setItem(a, ItemStack.EMPTY);
                BriefcaseData.write(briefcase, list);
            }
            case OP_MOVE -> {
                if (a < 0 || a >= list.size()) return;
                BriefcaseData.Entry e = list.get(a);
                if (!BriefcaseData.fits(list, a, b, c, e.w, e.h, rows)) {
                    note(p, "It doesn't fit there.");
                    break;
                }
                e.x = b;
                e.y = c;
                BriefcaseData.write(briefcase, list);
            }
            case OP_TAKE -> {
                if (a < 0 || a >= list.size()) return;
                BriefcaseData.Entry e = list.get(a);
                ItemStack st = e.stack;
                if (b >= 0 && b <= 35 && inv.getItem(b).isEmpty()) {
                    inv.setItem(b, st);
                    list.remove(a);
                } else {
                    inv.add(st);
                    if (st.isEmpty()) list.remove(a);
                    else note(p, "Your inventory is full.");
                }
                BriefcaseData.write(briefcase, list);
            }
            case OP_PUT_ROPE -> {
                if (a < 0 || a > 35) return;
                ItemStack src = inv.getItem(a);
                if (!src.is(ModItems.ROPE.get())) {
                    note(p, "This slot is for Rope only.");
                    break;
                }
                if (!BriefcaseData.getRope(briefcase).isEmpty()) {
                    note(p, "The rope slot is already occupied.");
                    break;
                }
                BriefcaseData.setRope(briefcase, src.split(1));
                if (src.isEmpty()) inv.setItem(a, ItemStack.EMPTY);
            }
            case OP_TAKE_ROPE -> {
                ItemStack rope = BriefcaseData.getRope(briefcase);
                if (rope.isEmpty()) return;
                if (b >= 0 && b <= 35 && inv.getItem(b).isEmpty()) {
                    inv.setItem(b, rope);
                    BriefcaseData.setRope(briefcase, ItemStack.EMPTY);
                } else if (inv.add(rope)) {
                    BriefcaseData.setRope(briefcase, ItemStack.EMPTY);
                } else {
                    note(p, "Your inventory is full.");
                }
            }
            default -> {
                return;
            }
        }

        if (s.kind() == 0) {
            inv.setChanged();
            p.containerMenu.broadcastChanges();
        }
        sync(p, s, MODE_UPDATE);
    }

    public static void forget(UUID id) {
        SESSIONS.remove(id);
    }
}
