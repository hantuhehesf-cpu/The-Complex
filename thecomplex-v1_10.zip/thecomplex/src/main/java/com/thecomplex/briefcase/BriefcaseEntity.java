package com.thecomplex.briefcase;

import com.thecomplex.ModItems;
import com.thecomplex.block.WedgeBlock;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Half;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;

import java.util.UUID;

/**
 * Briefcase yang dilempar. Fisika: jatuh, memantul, meluncur turun di tangga dan baji.
 * Kalau tahu-tahu diam dan ada Rope di slotnya, tali menggantung dari tepi terdekat (maks. ropeMaxLength blok)
 * dan bisa dipanjat / dituruni (lihat RopeHelper dan RopeClient).
 * Klik kanan: buka inventori. Sneak + klik kanan: ambil.
 */
public class BriefcaseEntity extends Entity {
    private static final EntityDataAccessor<Float> ROPE_LEN = SynchedEntityData.defineId(BriefcaseEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> ROPE_X = SynchedEntityData.defineId(BriefcaseEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> ROPE_Z = SynchedEntityData.defineId(BriefcaseEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> ROPE_TOP = SynchedEntityData.defineId(BriefcaseEntity.class, EntityDataSerializers.FLOAT);

    private static final EntityDataAccessor<Integer> ROPE_DIR = SynchedEntityData.defineId(BriefcaseEntity.class, EntityDataSerializers.INT);

    /** Jumlah kekuatan lempar (1..5) selama masih terbang; 0 = sudah mendarat / tidak dilempar. */
    private static final EntityDataAccessor<Integer> POWER = SynchedEntityData.defineId(BriefcaseEntity.class, EntityDataSerializers.INT);

    /** Seperti panah: drag udara 0,99 dan gravitasi terbang; setelah menempel, gravitasi biasa. */
    private static final double FLIGHT_DRAG = 0.99;
    private static final double FLIGHT_GRAVITY = 0.06;
    private static final double GRAVITY = 0.04;
    private static final double LAND_KEEP = 0.25;      // sisa kecepatan datar saat mendarat di lantai
    private static final double MAX_SLIDE = 0.30;
    /** Jarak terbang maksimum per tingkat kekuatan (kekuatan 5 = 7,25 blok, ditambah sedikit meluncur = sekitar 8). */
    public static final double RANGE_PER_POWER = 1.45;
    /** Kecepatan awal per tingkat kekuatan. */
    public static final double SPEED_PER_POWER = 0.227;

    private ItemStack stack = ItemStack.EMPTY;
    private UUID owner;
    private int rest;
    private boolean sleeping;
    private boolean inited;
    private boolean flying;
    private Vec3 origin = Vec3.ZERO;
    private double range;

    public BriefcaseEntity(EntityType<? extends BriefcaseEntity> type, Level level) {
        super(type, level);
    }

    public void setStack(ItemStack s) {
        this.stack = s;
    }

    public ItemStack getStack() {
        return stack;
    }

    public void setOwner(UUID id) {
        this.owner = id;
    }

    public float getRopeLen() {
        return entityData.get(ROPE_LEN);
    }

    public float getRopeX() {
        return entityData.get(ROPE_X);
    }

    public float getRopeZ() {
        return entityData.get(ROPE_Z);
    }

    public float getRopeTop() {
        return entityData.get(ROPE_TOP);
    }

    /** Arah tepi (dari Briefcase menuju kolom tali); pemain menggantung sedikit di sisi ini. */
    public Direction getRopeDir() {
        return Direction.from2DDataValue(entityData.get(ROPE_DIR));
    }

    private void setRope(float len, double x, double z, double top, Direction dir) {
        entityData.set(ROPE_LEN, len);
        entityData.set(ROPE_X, (float) x);
        entityData.set(ROPE_Z, (float) z);
        entityData.set(ROPE_TOP, (float) top);
        entityData.set(ROPE_DIR, dir.get2DDataValue());
    }

    /**
     * Kotak untuk culling kamera mencakup seluruh tali. Tanpa ini tali ikut hilang begitu
     * Briefcase (yang kecil) keluar dari layar, padahal talinya masih terlihat.
     */
    @Override
    public AABB getBoundingBoxForCulling() {
        AABB box = getBoundingBox().inflate(0.4);
        float len = getRopeLen();
        if (len > 0.4f) {
            double rx = getRopeX(), rz = getRopeZ(), top = getRopeTop();
            box = box.minmax(new AABB(rx - 0.4, top - len - 0.2, rz - 0.4, rx + 0.4, top + 0.4, rz + 0.4));
        }
        return box;
    }

    @Override
    public boolean shouldRenderAtSqrDistance(double distSqr) {
        return distSqr < 80.0 * 80.0;
    }

    @Override
    protected void defineSynchedData() {
        entityData.define(ROPE_LEN, 0f);
        entityData.define(ROPE_X, 0f);
        entityData.define(ROPE_Z, 0f);
        entityData.define(ROPE_TOP, 0f);
        entityData.define(ROPE_DIR, 0);
        entityData.define(POWER, 0);
    }

    /** Dipanggil server tepat sebelum entitas ditambahkan ke dunia. Kecepatan awal diatur pemanggil. */
    public void launch(int power) {
        entityData.set(POWER, power);
    }

    public boolean isFlying() {
        return flying;
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        stack = ItemStack.of(tag.getCompound("Stack"));
        if (tag.hasUUID("Owner")) owner = tag.getUUID("Owner");
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.put("Stack", stack.save(new CompoundTag()));
        if (owner != null) tag.putUUID("Owner", owner);
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }

    @Override
    public boolean isPickable() {
        return !isRemoved();
    }

    @Override
    public boolean isAttackable() {
        return false;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        return false;
    }

    @Override
    public ItemStack getPickResult() {
        return new ItemStack(ModItems.BRIEFCASE.get());
    }

    @Override
    public boolean isPushedByFluid() {
        return false;
    }

    private Direction slopeDown() {
        BlockPos p = BlockPos.containing(getX(), getY() - 0.05, getZ());
        BlockState s = level().getBlockState(p);
        if (s.getBlock() instanceof StairBlock && s.getValue(StairBlock.HALF) == Half.BOTTOM) return s.getValue(StairBlock.FACING);
        if (s.getBlock() instanceof WedgeBlock) return s.getValue(WedgeBlock.FACING).getOpposite();
        return null;
    }

    /**
     * Fisika meniru panah / pelampung pancing: lepas dengan kecepatan searah pandangan, drag udara 0,99,
     * gravitasi, lalu MENEMPEL begitu menabrak sesuatu (tanpa memantul). Jarak terbang dibatasi (kekuatan x 1,45 blok):
     * lewat dari itu tenaganya habis dan jatuh.
     * Kode yang sama berjalan di KLIEN dan SERVER (seperti proyektil vanilla), jadi mulus; server hanya mengoreksi posisi.
     * Benda yang sudah diam "tidur": hanya dicek lantainya tiap 10 tick.
     */
    @Override
    public void tick() {
        super.tick();
        boolean client = level().isClientSide;
        if (!client) {
            if (stack.isEmpty()) {
                discard();
                return;
            }
            if (getY() < level().getMinBuildHeight() - 32) {
                returnToOwner();
                return;
            }
        }
        if (!inited) {
            inited = true;
            origin = position();
            int power = entityData.get(POWER);
            flying = power > 0;
            range = RANGE_PER_POWER * power;
        }

        if (sleeping) {
            if ((tickCount + getId()) % 10 != 0) return;
            // cek lantai: masih ada?
            move(MoverType.SELF, new Vec3(0, -GRAVITY, 0));
            if (this.onGround()) {
                setDeltaMovement(Vec3.ZERO);
                return;
            }
            sleeping = false;
            rest = 0;
            if (!client && getRopeLen() > 0) setRope(0f, 0, 0, 0, Direction.NORTH);
        }

        Vec3 v = getDeltaMovement();
        if (flying) {
            v = new Vec3(v.x * FLIGHT_DRAG, v.y * FLIGHT_DRAG - FLIGHT_GRAVITY, v.z * FLIGHT_DRAG);
            if (position().distanceTo(origin) >= range) {
                // max range reached: kill the horizontal speed (and any upward speed) but let gravity keep acting normally
                v = new Vec3(v.x * 0.4, v.y > 0 ? v.y * 0.4 : v.y, v.z * 0.4);
            }
        } else {
            v = v.add(0, -GRAVITY, 0);
        }
        // penting: set dulu, karena move() membaca dan mengoreksi deltaMovement itu sendiri
        setDeltaMovement(v);
        move(MoverType.SELF, v);
        Vec3 a = getDeltaMovement();
        double nx = a.x, ny = a.y, nz = a.z;
        boolean ground = this.onGround();
        Direction down = null;

        if (flying) {
            if (ground || horizontalCollision || verticalCollision) {
                // menabrak: menempel seperti panah
                flying = false;
                if (!client) {
                    entityData.set(POWER, 0);
                    if (v.y < -0.1) level().playSound(null, blockPosition(), SoundEvents.WOOL_FALL, SoundSource.NEUTRAL, 0.8f, 0.7f);
                }
                if (horizontalCollision) {
                    nx = 0;
                    nz = 0;
                }
                if (ground) {
                    nx *= LAND_KEEP;
                    nz *= LAND_KEEP;
                }
                ny = 0;
            }
        } else if (ground) {
            ny = 0;
            down = slopeDown();
            if (down != null) {
                // tangga / baji: meluncur turun, kecepatan dibatasi
                nx = nx * 0.93 + down.getStepX() * 0.045;
                nz = nz * 0.93 + down.getStepZ() * 0.045;
                double h2 = nx * nx + nz * nz;
                if (h2 > MAX_SLIDE * MAX_SLIDE) {
                    double k = MAX_SLIDE / Math.sqrt(h2);
                    nx *= k;
                    nz *= k;
                }
            } else {
                BlockPos under = BlockPos.containing(getX(), getY() - 0.5, getZ());
                float f = level().getBlockState(under).getFriction(level(), under, this) * 0.8f;
                nx *= f;
                nz *= f;
            }
        } else {
            // jatuh bebas setelah menempel (lantai hilang)
            nx *= 0.98;
            nz *= 0.98;
            ny *= 0.98;
        }
        setDeltaMovement(nx, ny, nz);

        boolean still = !flying && ground && down == null && nx * nx + nz * nz < 4.0e-4 && Math.abs(ny) < 0.01;
        if (still) {
            setDeltaMovement(Vec3.ZERO);
            rest++;
            if (!client && rest == 6) computeRope();
            if (rest >= 8) sleeping = true;
        } else {
            if (rest != 0 && !client && getRopeLen() > 0) setRope(0f, 0, 0, 0, Direction.NORTH);
            rest = 0;
        }
    }

    private boolean free(BlockPos p) {
        BlockState st = level().getBlockState(p);
        return st.getCollisionShape(level(), p).isEmpty() && st.getFluidState().isEmpty();
    }

    private void computeRope() {
        if (BriefcaseData.getRope(stack).isEmpty()) {
            setRope(0f, 0, 0, 0, Direction.NORTH);
            return;
        }
        int max = BriefcaseConfig.ROPE_MAX.get();
        BlockPos base = BlockPos.containing(getX(), getY() + 0.05, getZ());
        int bestDepth = 0;
        BlockPos best = null;
        Direction bestDir = Direction.NORTH;
        for (Direction d : Direction.Plane.HORIZONTAL) {
            BlockPos n = base.relative(d);
            if (!free(n)) continue;
            int depth = 0;
            while (depth < max && free(n.below(depth + 1))) depth++;
            if (depth > bestDepth) {
                bestDepth = depth;
                best = n;
                bestDir = d;
            }
        }
        if (best == null) {
            setRope(0f, 0, 0, 0, Direction.NORTH);
            return;
        }
        // ujung atas tali = tinggi permukaan tempat Briefcase bertumpu
        setRope(bestDepth, best.getX() + 0.5, best.getZ() + 0.5, base.getY(), bestDir);
    }

    @Override
    public InteractionResult interact(Player player, InteractionHand hand) {
        if (level().isClientSide) return InteractionResult.SUCCESS;
        if (player instanceof ServerPlayer sp) {
            if (sp.isShiftKeyDown()) pickup(sp);
            else BriefcaseSessions.openEntity(sp, this);
        }
        return InteractionResult.CONSUME;
    }

    private void pickup(ServerPlayer sp) {
        ItemStack s = stack;
        stack = ItemStack.EMPTY;
        if (!sp.getInventory().add(s)) sp.drop(s, false);
        level().playSound(null, blockPosition(), SoundEvents.ARMOR_EQUIP_LEATHER, SoundSource.PLAYERS, 0.8f, 1.0f);
        discard();
    }

    /** Jatuh ke void: kembalikan ke pemilik kalau masih online. */
    private void returnToOwner() {
        if (!level().isClientSide && owner != null && level().getServer() != null) {
            ServerPlayer o = level().getServer().getPlayerList().getPlayer(owner);
            if (o != null && !stack.isEmpty()) {
                if (!o.getInventory().add(stack)) o.drop(stack, false);
                stack = ItemStack.EMPTY;
            }
        }
        discard();
    }
}
