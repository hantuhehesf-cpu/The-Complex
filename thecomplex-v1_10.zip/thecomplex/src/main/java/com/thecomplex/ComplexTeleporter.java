package com.thecomplex;

import com.thecomplex.activity.NullZoneSpawner;
import com.thecomplex.block.NullZoneLife;
import com.thecomplex.net.Net;
import com.thecomplex.portal.PortalFrame;
import com.thecomplex.portal.PortalPreloader;
import com.thecomplex.portal.Seamless;
import com.thecomplex.world.ComplexLayout;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * Semua perpindahan antara dunia luar dan The Complex. Semua lewat Seamless (tanpa layar loading).
 * Threshold: posisi, arah hadap, dan momentum dipetakan lewat bidang bingkai (masuk dari satu sisi, keluar searah).
 */
public final class ComplexTeleporter {
    private static final String CD = "complex_tp_cd";
    private static final String RET_SET = "complex_ret_set";
    private static final String RET_DIM = "complex_ret_dim";
    private static final String RET_GATE_SET = "complex_ret_gate_set";
    private static final String RET_GATE = "complex_ret_gate";
    private static final String RET_DIR = "complex_ret_dir";

    /** Jeda singkat sesudah pindah, supaya tidak langsung memicu portal tujuan. */
    private static final int COOLDOWN_TICKS = 12;

    private ComplexTeleporter() {}

    /** Tujuan lewat Threshold: dunia, bingkai di sana (bisa null), dan arah pemain keluar dari bingkai itu. */
    public record Dest(ServerLevel level, PortalFrame frame, Vec3 exit) {}

    public static boolean onCooldown(ServerPlayer p) {
        return p.tickCount < p.getPersistentData().getInt(CD);
    }

    public static void startCooldown(ServerPlayer p) {
        p.getPersistentData().putInt(CD, p.tickCount + COOLDOWN_TICKS);
    }

    /** Ingat dari mana pemain masuk, supaya Threshold di dalam The Complex bisa mengantar pulang. gate null = bukan lewat Threshold. */
    public static void rememberReturn(ServerPlayer p, BlockPos gate, Direction exitDir) {
        if (p.level().dimension() == TheComplex.COMPLEX) return;
        CompoundTag d = p.getPersistentData();
        d.putBoolean(RET_SET, true);
        d.putString(RET_DIM, p.level().dimension().location().toString());
        d.putInt("complex_ret_x", p.getBlockX());
        d.putInt("complex_ret_y", p.getBlockY());
        d.putInt("complex_ret_z", p.getBlockZ());
        d.putBoolean(RET_GATE_SET, gate != null);
        if (gate != null) {
            d.putLong(RET_GATE, gate.asLong());
            d.putInt(RET_DIR, exitDir.get2DDataValue());
        }
    }

    // ---------------------------------------------------------------- matematika arah

    /** Yaw Minecraft untuk arah horizontal v (0 = selatan/+Z, 90 = barat/-X). */
    public static double yawOf(Vec3 v) {
        return com.thecomplex.portal.PortalMath.yawOf(v);
    }

    /** Putar vektor mengelilingi sumbu Y sebesar deg derajat, dalam arti yang sama dengan yaw Minecraft. */
    public static Vec3 rotateYaw(Vec3 v, double deg) {
        return com.thecomplex.portal.PortalMath.rotateYaw(v, deg);
    }

    public static float yawToward(BlockPos from, double tx, double tz) {
        double dx = tx - (from.getX() + 0.5), dz = tz - (from.getZ() + 0.5);
        if (dx * dx + dz * dz < 0.25) return 0f;
        return (float) Math.toDegrees(Math.atan2(-dx, dz));
    }

    // ---------------------------------------------------------------- Threshold

    /** Tujuan untuk masuk ke The Complex: Threshold Main Chamber. Null kalau tidak ada / belum dimuat (kalau load = false). */
    public static Dest arrivalDest(MinecraftServer server, boolean load) {
        ServerLevel cx = server.getLevel(TheComplex.COMPLEX);
        BlockPos t = ComplexLayout.thresholdPos();
        if (cx == null || t == null) return null;
        if (!load && cx.getChunkSource().getChunkNow(t.getX() >> 4, t.getZ() >> 4) == null) return null;
        cx.getChunk(t.getX() >> 4, t.getZ() >> 4);
        PortalFrame f = PortalFrame.of(cx, t);
        if (f == null) return null;
        Vec3 n = f.normal();
        double dot = (ComplexLayout.chamberCenterX() - f.center.x) * n.x + (ComplexLayout.chamberCenterZ() - f.center.z) * n.z;
        double sign = dot < 0 ? -1 : 1;
        return new Dest(cx, f, n.scale(sign));
    }

    /** Tujuan untuk pulang dari The Complex: Threshold yang tadi dipakai masuk, keluar di sisi tempat pemain datang. */
    public static Dest returnDest(ServerPlayer p, boolean load) {
        CompoundTag d = p.getPersistentData();
        if (!d.getBoolean(RET_SET) || !d.getBoolean(RET_GATE_SET)) return null;
        ResourceLocation id = ResourceLocation.tryParse(d.getString(RET_DIM));
        if (id == null) return null;
        ServerLevel target = p.server.getLevel(ResourceKey.create(Registries.DIMENSION, id));
        if (target == null) return null;
        BlockPos gate = BlockPos.of(d.getLong(RET_GATE));
        if (!load && target.getChunkSource().getChunkNow(gate.getX() >> 4, gate.getZ() >> 4) == null) return null;
        target.getChunk(gate.getX() >> 4, gate.getZ() >> 4);
        PortalFrame f = PortalFrame.of(target, gate);
        if (f == null) return null;
        Direction dir = Direction.from2DDataValue(d.getInt(RET_DIR));
        return new Dest(target, f, new Vec3(dir.getStepX(), 0, dir.getStepZ()));
    }

    public static Dest destFor(ServerPlayer p, ServerLevel in, boolean load) {
        return in.dimension() == TheComplex.COMPLEX ? returnDest(p, load) : arrivalDest(p.server, load);
    }

    /**
     * Pemain baru saja menembus bingkai src. travel = arah gerak menembus bingkai, vel = kecepatan per tick.
     * Posisi relatif terhadap bingkai dibawa ke bingkai tujuan (diputar sesuai arah keluar), begitu pula arah hadap dan momentum.
     */
    public static void throughThreshold(ServerPlayer p, ServerLevel level, PortalFrame src, BlockPos gateBlock, Vec3 travel, Vec3 vel) {
        boolean inComplex = level.dimension() == TheComplex.COMPLEX;
        if (!inComplex) {
            Direction back = Direction.getNearest(-travel.x, 0, -travel.z);
            rememberReturn(p, gateBlock, back);
        }
        Dest d = destFor(p, level, true);
        if (d == null) {
            if (inComplex) fallbackReturn(p);
            else toArrival(p);
            return;
        }
        double dyaw = yawOf(d.exit()) - yawOf(travel);
        Vec3 rel = p.position().subtract(src.center);
        Vec3 np = settle(d.level(), p, d.frame().center.add(rotateYaw(rel, dyaw)), d.exit());
        float yaw = Mth.wrapDegrees((float) (p.getYRot() + dyaw));
        Seamless.send(p, d.level(), np, yaw, p.getXRot(), rotateYaw(vel, dyaw), Seamless.STYLE_THRESHOLD);
        if (!inComplex) Net.sendQuakeTo(p, 40, 1.4f);
    }

    /** Posisi bebas tabrakan di dekat pos; kalau tidak ada, tempat berdiri aman terdekat. */
    public static Vec3 settle(ServerLevel level, ServerPlayer p, Vec3 pos, Vec3 exit) {
        EntityDimensions dim = p.getDimensions(p.getPose());
        for (double k : new double[]{0, 0.3, 0.6, 1.0, 1.5}) {
            Vec3 c = pos.add(exit.scale(k));
            if (level.noCollision((Entity) null, dim.makeBoundingBox(c))) return c;
        }
        BlockPos s = safeSpotNear(level, BlockPos.containing(pos), 0);
        return new Vec3(s.getX() + 0.5, s.getY(), s.getZ() + 0.5);
    }

    // ---------------------------------------------------------------- tanpa bingkai (perintah, dev, fallback)

    /** Masuk ke Main Chamber di dekat Threshold-nya, menghadap isi ruangan. */
    public static void toArrival(ServerPlayer p) {
        ServerLevel lvl = p.server.getLevel(TheComplex.COMPLEX);
        if (lvl == null) return;
        rememberReturn(p, null, Direction.NORTH);
        BlockPos t = ComplexLayout.thresholdPos();
        BlockPos base = t != null ? t : new BlockPos(0, ComplexLayout.FLOOR_Y + 1, 0);
        lvl.getChunk(base.getX() >> 4, base.getZ() >> 4);
        BlockPos spot = safeSpotNear(lvl, base, t != null ? 2 : 0);
        Seamless.send(p, lvl, new Vec3(spot.getX() + 0.5, spot.getY(), spot.getZ() + 0.5),
                yawToward(spot, ComplexLayout.chamberCenterX(), ComplexLayout.chamberCenterZ()), 0f, Vec3.ZERO, Seamless.STYLE_THRESHOLD);
        Net.sendQuakeTo(p, 40, 1.4f);
    }

    /** Null Zone versi lama / manual (tanpa data bidang): langsung ke Backrooms. */
    public static void toBackrooms(ServerPlayer p) {
        throughNullZone(p, null, Vec3.ZERO);
    }

    /**
     * Wild Null Zone: to the procedural Backrooms, far from the Main Chamber.
     * normal DOWN (floor Null Zone) = the player falls in through the CEILING (a short-lived hole opens in it, no fall damage);
     * walls = the player arrives standing. Momentum is rotated along with the random arrival direction.
     */
    public static void throughNullZone(ServerPlayer p, Direction normal, Vec3 vel) {
        ServerLevel lvl = p.server.getLevel(TheComplex.COMPLEX);
        if (lvl == null) return;
        rememberReturn(p, null, Direction.NORTH);
        BlockPos spot = PortalPreloader.takeBackroomsSpot(p, lvl);
        if (spot == null) return;
        RandomSource r = p.getRandom();
        boolean floor = normal == Direction.DOWN;
        float yaw = r.nextFloat() * 360f;
        double dyaw = yaw - p.getYRot();
        Vec3 nv = rotateYaw(vel, dyaw);
        if (floor || CEILING_DROP_FOR_WALLS) {
            Drop drop = prepareCeilingDrop(lvl, spot, p.getBbHeight());
            if (drop != null) {
                Seamless.send(p, lvl, drop.pos(), yaw, p.getXRot(), dropVelocity(nv), Seamless.STYLE_NULL_ZONE, drop.fallDistance());
                return;
            }
        }
        if (floor) nv = new Vec3(nv.x, Math.max(nv.y, -0.5), nv.z);
        Seamless.send(p, lvl, new Vec3(spot.getX() + 0.5, spot.getY() + (floor ? 1.0 : 0.0), spot.getZ() + 0.5), yaw, p.getXRot(), nv, Seamless.STYLE_NULL_ZONE);
    }

    // ---------------------------------------------------------------- falling in through the ceiling

    /** How long (ticks) the ceiling hole stays open before the ceiling is solid again. */
    public static final int DROP_HOLE_TICKS = 160;
    /** Horizontal speed limit while falling out of the hole, so the hole walls do not catch the player. */
    private static final double DROP_MAX_HORIZONTAL = 0.10;
    /**
     * false (default): only floor Null Zones drop the player in through the ceiling; wall Null Zones put the player down standing.
     * true: wall Null Zones also drop the player in through the ceiling.
     */
    public static final boolean CEILING_DROP_FOR_WALLS = false;

    /** A ceiling hole: where to start (inside the hole), the fall distance to start with, and the cells that were opened. */
    public record Drop(Vec3 pos, float fallDistance, List<BlockPos> cells) {}

    /**
     * Opens a short-lived hole in the ceiling right above the standing spot and returns where to put the entity: inside the
     * hole, so it falls out of the ceiling into the room. The hole is a 3x3 column of Null Zone cells (no collision, they look
     * exactly like the ceiling and the wall mass above it) that close again by themselves after DROP_HOLE_TICKS.
     * Fluorescent panels are never opened, so the light does not change. Returns null if there is no suitable ceiling.
     */
    public static Drop prepareCeilingDrop(ServerLevel lvl, BlockPos stand, double height) {
        int x = stand.getX(), z = stand.getZ();
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        int top = lvl.getMaxBuildHeight() - 1;
        int cy = -1;                                          // y of the ceiling layer above this spot
        for (int y = stand.getY() + 3; y <= top; y++) {
            if (!lvl.getBlockState(m.set(x, y, z)).isAir()) {
                cy = y;
                break;
            }
        }
        if (cy < 0 || cy + 2 > top - 2) return null;          // stay clear of the bedrock cap
        for (int dy = 0; dy < 3; dy++) {
            if (!carvable(lvl, m.set(x, cy + dy, z))) return null;   // the middle column must be plain ceiling / wall mass
        }
        List<BlockPos> cells = new ArrayList<>();
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                for (int dy = 0; dy < 3; dy++) {
                    BlockPos q = new BlockPos(x + dx, cy + dy, z + dz);
                    if (lvl.hasChunkAt(q) && carvable(lvl, q)) cells.add(q);
                }
            }
        }
        long expires = lvl.getGameTime() + DROP_HOLE_TICKS;
        long anchor = new BlockPos(x, cy, z).asLong();
        for (BlockPos q : cells) {
            boolean isAnchor = q.getX() == x && q.getY() == cy && q.getZ() == z;
            NullZoneSpawner.placeCell(lvl, q, null, 0.0, anchor, expires, false, 0, 0, 0, isAnchor);
        }
        double h = Math.min(height, 2.8);
        double feetY = Math.max(cy + 0.05, cy + 3.0 - h - 0.1);            // whole body inside the opened column
        double drop = feetY - stand.getY();
        float fall = (float) -Math.max(0.0, drop - 2.5);                    // lands with 2.5 blocks of fall: no damage
        return new Drop(new Vec3(x + 0.5, feetY, z + 0.5), fall, cells);
    }

    /** Puts the ceiling back right away (used when the entity turned out not to fit). */
    public static void closeDrop(ServerLevel lvl, Drop drop) {
        for (BlockPos q : drop.cells()) NullZoneLife.restore(lvl, q);
    }

    /** Gentle start for the fall: limited sideways speed, slow downward speed. */
    public static Vec3 dropVelocity(Vec3 v) {
        double h = Math.sqrt(v.x * v.x + v.z * v.z);
        double k = h > DROP_MAX_HORIZONTAL ? DROP_MAX_HORIZONTAL / h : 1.0;
        return new Vec3(v.x * k, -0.1, v.z * k);
    }

    /** Plain ceiling tile or wall material only (never a light panel, bedrock, or anything with data). */
    private static boolean carvable(ServerLevel lvl, BlockPos pos) {
        BlockState s = lvl.getBlockState(pos);
        return (s.is(ModBlocks.CEILING_TILE.get()) || s.is(ModBlocks.WALLPAPER.get())
                || s.is(ModBlocks.OFFICE_WALL.get()) || s.is(ModBlocks.WHITE_WALL.get())) && !s.hasBlockEntity();
    }

    /** Titik berdiri acak di Backrooms jauh dari Main Chamber, di dalam satu chunk acak. Null kalau chunk itu tidak punya tempat. */
    public static BlockPos findBackroomsSpotInChunk(ServerLevel lvl, RandomSource r) {
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        int cx = (12 + r.nextInt(30)) * (r.nextBoolean() ? 1 : -1);
        int cz = (12 + r.nextInt(30)) * (r.nextBoolean() ? 1 : -1);
        lvl.getChunk(cx, cz);
        for (int i = 0; i < 64; i++) {
            int x = cx * 16 + r.nextInt(16);
            int z = cz * 16 + r.nextInt(16);
            m.set(x, ComplexLayout.FLOOR_Y + 1, z);
            if (lvl.getBlockState(m).isAir()
                    && lvl.getBlockState(m.above()).isAir()
                    && lvl.getBlockState(m.above(2)).isAir()
                    && lvl.getBlockState(m.below()).is(ModBlocks.CARPET_FLOOR.get())) {
                return m.immutable();
            }
        }
        return null;
    }

    public static BlockPos findBackroomsSpot(ServerLevel lvl, RandomSource r, int tries) {
        for (int i = 0; i < tries; i++) {
            BlockPos s = findBackroomsSpotInChunk(lvl, r);
            if (s != null) return s;
        }
        return null;
    }

    // ---------------------------------------------------------------- pulang tanpa bingkai

    /** Pulang ke tempat terakhir pemain masuk, atau spawn dunia. */
    private static void fallbackReturn(ServerPlayer p) {
        CompoundTag d = p.getPersistentData();
        ServerLevel target = null;
        BlockPos base = null;
        if (d.getBoolean(RET_SET)) {
            ResourceLocation id = ResourceLocation.tryParse(d.getString(RET_DIM));
            if (id != null) target = p.server.getLevel(ResourceKey.create(Registries.DIMENSION, id));
            base = new BlockPos(d.getInt("complex_ret_x"), d.getInt("complex_ret_y"), d.getInt("complex_ret_z"));
        }
        if (target == null) {
            target = p.server.overworld();
            base = target.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, target.getSharedSpawnPos());
        }
        target.getChunk(base.getX() >> 4, base.getZ() >> 4);
        BlockPos spot = safeSpotNear(target, base, 0);
        Seamless.send(p, target, new Vec3(spot.getX() + 0.5, spot.getY(), spot.getZ() + 0.5), p.getYRot(), p.getXRot(), Vec3.ZERO, Seamless.STYLE_THRESHOLD);
    }

    /** Threshold di dalam The Complex (tanpa bingkai tercatat) atau perintah: pulang ke tempat terakhir pemain masuk, atau spawn dunia. */
    public static void returnFromComplex(ServerPlayer p, BlockPos from) {
        fallbackReturn(p);
    }

    public static void leave(ServerPlayer p) {
        fallbackReturn(p);
    }

    /** Tempat berdiri bebas terdekat dari titik asal (minimal radius minR), bukan di dalam Threshold/Null Zone. */
    public static BlockPos safeSpotNear(ServerLevel level, BlockPos base, int minR) {
        BlockPos best = null;
        double bestD = Double.MAX_VALUE;
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int dx = -6; dx <= 6; dx++) {
            for (int dz = -6; dz <= 6; dz++) {
                if (Math.max(Math.abs(dx), Math.abs(dz)) < minR) continue;
                for (int dy = -2; dy <= 2; dy++) {
                    m.set(base.getX() + dx, base.getY() + dy, base.getZ() + dz);
                    BlockPos below = m.below();
                    if (isFree(level, m) && isFree(level, m.above())
                            && level.getBlockState(below).isCollisionShapeFullBlock(level, below)) {
                        double d = dx * dx + dz * dz + dy * dy * 4.0;
                        if (d < bestD) {
                            bestD = d;
                            best = m.immutable();
                        }
                    }
                }
            }
        }
        return best != null ? best : base;
    }

    private static boolean isFree(ServerLevel level, BlockPos pos) {
        BlockState s = level.getBlockState(pos);
        return s.getCollisionShape(level, pos).isEmpty()
                && s.getFluidState().isEmpty()
                && !s.is(ModBlocks.THRESHOLD.get())
                && !s.is(ModBlocks.NULL_ZONE.get());
    }
}
