package com.thecomplex.activity;

import com.thecomplex.ModBlocks;
import com.thecomplex.block.NullZoneBlock;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.level.Level;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Mencatat Null Zone liar yang baru muncul (hanya di memori, untuk pengujian lewat Developer UI). */
public final class NullZoneTracker {
    public record Entry(long id, ResourceKey<Level> dim, BlockPos pos, String kind) {}

    public static final int MAX = 12;
    private static final List<Entry> ENTRIES = new ArrayList<>();
    private static long nextId = 1;

    private NullZoneTracker() {}

    public static synchronized void add(ServerLevel level, BlockPos pos, String kind) {
        ENTRIES.add(new Entry(nextId++, level.dimension(), pos.immutable(), kind));
        while (ENTRIES.size() > MAX) ENTRIES.remove(0);
    }

    /** Buang entri yang blok Null Zone-nya sudah tidak ada (sudah pulih atau dihancurkan). */
    private static void prune(MinecraftServer server) {
        ENTRIES.removeIf(e -> {
            ServerLevel l = server.getLevel(e.dim());
            if (l == null || !l.hasChunkAt(e.pos())) return false;    // chunk tidak dimuat: tidak bisa dicek, biarkan
            return !l.getBlockState(e.pos()).is(ModBlocks.NULL_ZONE.get());
        });
    }

    /** Entri di dimensi pemain, diurutkan dari yang terdekat. */
    public static synchronized List<Entry> forPlayer(ServerPlayer p) {
        prune(p.server);
        List<Entry> out = new ArrayList<>();
        for (Entry e : ENTRIES) if (e.dim() == p.level().dimension()) out.add(e);
        out.sort(Comparator.comparingDouble(e -> distSq(p, e)));
        return out;
    }

    public static synchronized Entry find(long id) {
        for (Entry e : ENTRIES) if (e.id() == id) return e;
        return null;
    }

    public static Entry nearest(ServerPlayer p) {
        List<Entry> list = forPlayer(p);
        return list.isEmpty() ? null : list.get(0);
    }

    /** Pulihkan semua Null Zone liar yang tercatat. */
    public static synchronized int clearAll(MinecraftServer server) {
        int n = ENTRIES.size();
        for (Entry e : ENTRIES) {
            ServerLevel l = server.getLevel(e.dim());
            if (l == null || !l.hasChunkAt(e.pos())) continue;
            if (l.getBlockEntity(e.pos()) instanceof com.thecomplex.block.NullZoneBlockEntity be && be.hasAnchor()) {
                com.thecomplex.block.NullZoneLife.restoreCluster(l, be.getAnchor());
            }
            for (int dx = -1; dx <= 1; dx++)
                for (int dy = -1; dy <= 1; dy++)
                    for (int dz = -1; dz <= 1; dz++)
                        NullZoneBlock.restore(l, e.pos().offset(dx, dy, dz));
        }
        ENTRIES.clear();
        return n;
    }

    public static double distSq(ServerPlayer p, Entry e) {
        return p.distanceToSqr(e.pos().getX() + 0.5, e.pos().getY() + 0.5, e.pos().getZ() + 0.5);
    }

    /** Panah arah relatif terhadap hadap pemain: depan = atas. */
    public static String arrow(ServerPlayer p, BlockPos target) {
        double dx = target.getX() + 0.5 - p.getX();
        double dz = target.getZ() + 0.5 - p.getZ();
        double ang = Math.toDegrees(Math.atan2(-dx, dz));
        double rel = Mth.wrapDegrees(ang - p.getYRot());
        String[] arrows = {"↑", "↗", "→", "↘", "↓", "↙", "←", "↖"};
        return arrows[Math.floorMod((int) Math.round(rel / 45.0), 8)];
    }

    public static String describe(ServerPlayer p, Entry e) {
        int dist = (int) Math.round(Math.sqrt(distSq(p, e)));
        int dy = e.pos().getY() - p.blockPosition().getY();
        String vert = dy >= 3 ? " up " + dy : dy <= -3 ? " down " + (-dy) : "";
        return arrow(p, e.pos()) + " " + dist + " m" + vert + " " + e.kind()
                + " (" + e.pos().getX() + ", " + e.pos().getY() + ", " + e.pos().getZ() + ")";
    }
}
