package com.thecomplex.block;

import com.thecomplex.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.Tag;
import net.minecraft.network.Connection;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.client.model.data.ModelData;
import net.minecraftforge.client.model.data.ModelProperty;

/**
 * Data satu sel Null Zone: blok asli yang ditiru (untuk tampilan dan pemulihan), arah dan bidang portal di belakang
 * "dinding" (untuk perpindahan mulus), serta umur, pertumbuhan, dan pasangan (untuk Stable Wild Null Zone).
 * normal == null berarti Null Zone lama / manual: dipicu dengan cara lama (berdiri beberapa tick di dalamnya).
 */
public class NullZoneBlockEntity extends BlockEntity {
    /** Data yang dibaca model di sisi klien untuk meniru blok asli. */
    public static final ModelProperty<BlockState> MIMIC = new ModelProperty<>();

    private BlockState original;
    private Direction normal;
    private double plane;
    private boolean stable;
    private int pairId;
    private int end;
    private long expiresAt;
    private boolean hasAnchor;
    private long anchor;
    private boolean isAnchor;
    private int growsLeft;
    private int radius;

    public NullZoneBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.NULL_ZONE.get(), pos, state);
    }

    public BlockState getOriginal() {
        return original;
    }

    public void setOriginal(BlockState state) {
        this.original = state;
        setChanged();
        if (level != null) level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
    }

    /** Diisi oleh penyebar saat sel dibuat. */
    public void setup(BlockState original, Direction normal, double plane, boolean stable, int pairId, int end,
                      long expiresAt, long anchor, boolean isAnchor, int growsLeft) {
        this.normal = normal;
        this.plane = plane;
        this.stable = stable;
        this.pairId = pairId;
        this.end = end;
        this.expiresAt = expiresAt;
        this.hasAnchor = true;
        this.anchor = anchor;
        this.isAnchor = isAnchor;
        this.growsLeft = growsLeft;
        this.radius = 0;
        setOriginal(original);
    }

    /** Arah "masuk ke dinding" (dari ruangan ke dalam dinding; ke bawah untuk lantai). Null = Null Zone lama / manual. */
    public Direction getNormal() { return normal; }
    /** Posisi bidang portal sebagai (titik pada bidang) dot normal. */
    public double getPlane() { return plane; }
    public boolean isStable() { return stable; }
    public int getPairId() { return pairId; }
    /** 0 = ujung di Overworld, 1 = ujung di The Complex. */
    public int getEnd() { return end; }
    public long getExpiresAt() { return expiresAt; }
    public boolean hasAnchor() { return hasAnchor; }
    public long getAnchorLong() { return anchor; }
    public BlockPos getAnchor() { return hasAnchor ? BlockPos.of(anchor) : worldPosition; }
    public boolean isAnchor() { return isAnchor; }
    public int getGrowsLeft() { return growsLeft; }
    public void setGrowsLeft(int v) { growsLeft = v; setChanged(); }
    public int getRadius() { return radius; }
    public void setRadius(int v) { radius = v; setChanged(); }

    @Override
    public ModelData getModelData() {
        return original == null ? ModelData.EMPTY : ModelData.builder().with(MIMIC, original).build();
    }

    private void refreshModel() {
        if (level != null && level.isClientSide) {
            requestModelDataUpdate();
            level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
        }
    }

    @Override
    public void onLoad() {
        super.onLoad();
        refreshModel();
    }

    @Override
    public void handleUpdateTag(CompoundTag tag) {
        super.handleUpdateTag(tag);
        refreshModel();
    }

    @Override
    public void onDataPacket(Connection net, ClientboundBlockEntityDataPacket pkt) {
        super.onDataPacket(net, pkt);
        refreshModel();
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        if (original != null) tag.put("original", NbtUtils.writeBlockState(original));
        if (normal != null) {
            tag.putByte("normal", (byte) normal.get3DDataValue());
            tag.putDouble("plane", plane);
        }
        if (stable) tag.putBoolean("stable", true);
        if (pairId != 0) tag.putInt("pair", pairId);
        if (end != 0) tag.putInt("end", end);
        if (expiresAt != 0) tag.putLong("expires", expiresAt);
        if (hasAnchor) {
            tag.putLong("anchor", anchor);
            tag.putBoolean("isAnchor", isAnchor);
        }
        if (growsLeft != 0) tag.putInt("grows", growsLeft);
        if (radius != 0) tag.putInt("radius", radius);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        original = tag.contains("original", Tag.TAG_COMPOUND)
                ? NbtUtils.readBlockState(BuiltInRegistries.BLOCK.asLookup(), tag.getCompound("original"))
                : null;
        normal = tag.contains("normal") ? Direction.from3DDataValue(tag.getByte("normal")) : null;
        plane = tag.getDouble("plane");
        stable = tag.getBoolean("stable");
        pairId = tag.getInt("pair");
        end = tag.getInt("end");
        expiresAt = tag.getLong("expires");
        hasAnchor = tag.contains("anchor");
        anchor = tag.getLong("anchor");
        isAnchor = tag.getBoolean("isAnchor");
        growsLeft = tag.getInt("grows");
        radius = tag.getInt("radius");
    }

    @Override
    public CompoundTag getUpdateTag() {
        return saveWithoutMetadata();
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
}
