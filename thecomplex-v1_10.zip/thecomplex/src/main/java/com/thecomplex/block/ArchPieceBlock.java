package com.thecomplex.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * One half of a two-block arch: the Left Arch and the Right Arch are placed side by side over a doorway
 * (the pair spans 2 blocks). Each piece is the solid corner above the curve; together they leave a stepped arched opening.
 *
 * FACING is the direction you look THROUGH the doorway. The Left piece is on your left, the Right piece on your right.
 * Place both in the top layer of a 2-block-high door; the arch peak touches the top of the block.
 */
public class ArchPieceBlock extends Block {
    public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;

    /** Top solid height of each 2-pixel strip counted from the outer edge toward the center (the opening starts at this height). */
    private static final int[] H = {6, 10, 12, 14, 14, 16, 16, 16};

    private final boolean left;
    private final VoxelShape[] shapes = new VoxelShape[4];

    public ArchPieceBlock(Properties props, boolean left) {
        super(props);
        this.left = left;
        for (int turn = 0; turn < 4; turn++) {
            VoxelShape s = Shapes.empty();
            for (int i = 0; i < H.length; i++) {
                if (H[i] >= 16) continue;
                double x1 = left ? 2 * i : 16 - (2 * i + 2), x2 = x1 + 2;
                double z1 = 0, z2 = 16;
                // rotate clockwise (seen from above) by `turn` quarter turns: (x, z) -> (16 - z, x)
                double ax1 = x1, ax2 = x2, az1 = z1, az2 = z2;
                for (int t = 0; t < turn; t++) {
                    double nx1 = 16 - az2, nx2 = 16 - az1, nz1 = ax1, nz2 = ax2;
                    ax1 = nx1;
                    ax2 = nx2;
                    az1 = nz1;
                    az2 = nz2;
                }
                s = Shapes.or(s, Block.box(ax1, H[i], az1, ax2, 16, az2));
            }
            shapes[turn] = s;
        }
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.NORTH));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        return defaultBlockState().setValue(FACING, ctx.getHorizontalDirection());
    }

    private static int turns(Direction d) {
        return switch (d) {
            case EAST -> 1;
            case SOUTH -> 2;
            case WEST -> 3;
            default -> 0;
        };
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return shapes[turns(state.getValue(FACING))];
    }

    @Override
    public boolean useShapeForLightOcclusion(BlockState state) {
        return true;
    }

    @Override
    public BlockState rotate(BlockState state, Rotation rot) {
        return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
    }

    @Override
    public BlockState mirror(BlockState state, Mirror mirror) {
        return state.rotate(mirror.getRotation(state.getValue(FACING)));
    }
}
