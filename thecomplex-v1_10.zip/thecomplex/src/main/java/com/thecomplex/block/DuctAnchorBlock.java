package com.thecomplex.block;

import com.thecomplex.ModItems;
import com.thecomplex.tape.TapeEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;


/** Duct Tape Anchor (placeholder: model Grindstone). Titik awal dan akhir Duct Tape. */
public class DuctAnchorBlock extends Block {
    public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;
    private static final VoxelShape SHAPE = Block.box(2, 0, 2, 14, 14, 14);

    public DuctAnchorBlock(Properties props) {
        super(props);
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.NORTH));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        return defaultBlockState().setValue(FACING, ctx.getHorizontalDirection().getOpposite());
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return SHAPE;
    }

    @Override
    public boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
        return level.getBlockState(pos.below()).isFaceSturdy(level, pos.below(), Direction.UP);
    }

    @Override
    public BlockState updateShape(BlockState state, Direction dir, BlockState neighbor, LevelAccessor level, BlockPos pos, BlockPos neighborPos) {
        if (dir == Direction.DOWN && !state.canSurvive(level, pos)) return Blocks.AIR.defaultBlockState();
        return super.updateShape(state, dir, neighbor, level, pos, neighborPos);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide) return InteractionResult.SUCCESS;
        if (!(player instanceof ServerPlayer p) || !(level instanceof ServerLevel sl)) return InteractionResult.PASS;
        // satu tangan saja, supaya tidak diproses dua kali
        if (hand != InteractionHand.MAIN_HAND) return InteractionResult.CONSUME;

        TapeEvents.Session s = TapeEvents.sessionOf(p);
        ItemStack held = p.getMainHandItem();

        if (s == null) {
            if (p.isShiftKeyDown() && held.isEmpty()) {
                int n = TapeEvents.reel(sl, pos);
                TapeEvents.msg(p, n > 0 ? "Tape reeled in: " + n + " blocks." : "No tape is attached to this anchor.");
            } else if (held.is(ModItems.DUCT_TAPE.get())) {
                TapeEvents.begin(p, pos);
                TapeEvents.msg(p, "Tape started. Walk in a STRAIGHT line, then place a second anchor in line with it and right-click it.");
            } else {
                TapeEvents.msg(p, "Hold Duct Tape and right-click an anchor to start.");
            }
            return InteractionResult.CONSUME;
        }

        // sesi aktif: anchor ini akan jadi ujung tape
        if (pos.equals(s.a)) {
            TapeEvents.msg(p, "This is the starting anchor. Walk straight, then place a second anchor.");
            return InteractionResult.CONSUME;
        }
        if (s.axis < 0) {
            TapeEvents.msg(p, "Walk away from the starting anchor first so the tape direction locks in.");
            return InteractionResult.CONSUME;
        }
        int ddx = pos.getX() - s.a.getX(), ddz = pos.getZ() - s.a.getZ();
        int along = (s.axis == 0 ? ddx : ddz) * s.dir;
        int lat = s.axis == 0 ? ddz : ddx;
        if (lat != 0) {
            TapeEvents.msg(p, "The anchor is not in line with the starting anchor. Move it until it is straight.");
        } else if (along < 1) {
            TapeEvents.msg(p, "The anchor must be ahead, in the direction of the tape.");
        } else if (along - s.next > 3) {
            TapeEvents.msg(p, "Too far: the tape only reaches " + (s.next - 1) + " blocks so far. Keep walking.");
        } else if (!TapeEvents.fill(sl, p, s, along - 1, pos.getY())) {
            TapeEvents.msg(p, "Ran out of tape before reaching it. Bring another Duct Tape roll.");
        } else {
            TapeEvents.end(p);
            TapeEvents.msg(p, "Tape placed (" + (along - 1) + " blocks).");
        }
        return InteractionResult.CONSUME;
    }
}
