package com.thecomplex.block;

import com.thecomplex.portal.PortalRegistry;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Null Zone yang stabil. Tanpa collision, dua arah.
 * Perpindahannya ditangani PortalSystem (mendeteksi saat mata pemain melewati bidang bingkai, tanpa layar loading);
 * blok ini hanya mendaftarkan dirinya supaya bingkai bisa ditemukan dan chunk seberangnya dimuat lebih dulu.
 */
public class ThresholdBlock extends Block {
    public ThresholdBlock(Properties props) {
        super(props);
    }

    @Override
    public void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean isMoving) {
        super.onPlace(state, level, pos, oldState, isMoving);
        if (level instanceof ServerLevel sl) PortalRegistry.get(sl).add(pos);
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean isMoving) {
        if (!state.is(newState.getBlock()) && level instanceof ServerLevel sl) PortalRegistry.get(sl).remove(pos);
        super.onRemove(state, level, pos, newState, isMoving);
    }
}
