package com.thecomplex.block;

import com.thecomplex.TheComplex;
import com.thecomplex.activity.NullZoneSpawner;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * The Null Zone item (v1.9). Instead of placing a loose block, right-clicking a block turns THAT block into a Null Zone
 * that looks exactly like it. The portal behaves like a natural one, but it is permanent and is not used up.
 *
 *  - click a SIDE of a block: a wall Null Zone, 1 wide and 2 high (the clicked block and the one above, or below if above is
 *    not possible). Walk into the wall and you end up in the Backrooms.
 *  - click the TOP of a block: a floor Null Zone, 2x2 blocks and 2 deep, the 2x2 area nearest to where you clicked. Step on it and you
 *    fall through the ceiling of the Backrooms.
 *  - sneak + right-click a Null Zone: turns it back into the original block(s).
 * Works in every dimension except The Complex (unstable Null Zones are inert there).
 */
public class NullZoneItem extends BlockItem {
    public NullZoneItem(Block block, Properties props) {
        super(block, props);
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        if (level.isClientSide) return InteractionResult.SUCCESS;
        Player p = ctx.getPlayer();
        if (!(level instanceof ServerLevel sl) || p == null) return InteractionResult.PASS;
        BlockPos pos = ctx.getClickedPos();
        Direction face = ctx.getClickedFace();

        if (p.isShiftKeyDown()) {
            if (sl.getBlockEntity(pos) instanceof NullZoneBlockEntity be && !be.isStable() && be.getExpiresAt() < 0) {
                NullZoneLife.restoreCluster(sl, be.getAnchor());
                // a cluster only restores cells with the same anchor: restore the clicked one too, in case it is a single cell
                NullZoneLife.restore(sl, pos);
                tell(p, "Null Zone removed.");
            } else {
                tell(p, "Sneak + right-click a Null Zone you placed to remove it.");
            }
            return InteractionResult.CONSUME;
        }
        if (sl.dimension() == TheComplex.COMPLEX) {
            tell(p, "Null Zones only work outside The Complex.");
            return InteractionResult.CONSUME;
        }
        if (face == Direction.DOWN) {
            tell(p, "Click the side or the top of a block.");
            return InteractionResult.CONSUME;
        }
        boolean ok = face == Direction.UP ? placeFloor(sl, pos, ctx.getClickLocation()) : placeWall(sl, pos, face);
        tell(p, ok ? "Null Zone placed. Sneak + right-click it to remove it."
                : "That spot does not work: a Null Zone needs solid full blocks (no chests, doors, glass or plants) at least 1x2 for a wall, 2x2 and 2 deep for a floor.");
        if (ok && !p.getAbilities().instabuild) ctx.getItemInHand().shrink(1);
        return InteractionResult.CONSUME;
    }

    private static boolean placeWall(ServerLevel level, BlockPos pos, Direction face) {
        Direction d = face.getOpposite();                      // into the block, away from the player
        if (!NullZoneSpawner.canHost(level, pos)) return false;
        BlockPos other = NullZoneSpawner.canHost(level, pos.above()) ? pos.above()
                : NullZoneSpawner.canHost(level, pos.below()) ? pos.below() : null;
        if (other == null) return false;
        double plane = NullZoneSpawner.planeOf(d, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5);
        NullZoneSpawner.placeCell(level, pos, d, plane, pos.asLong(), -1, false, 0, 0, 0, true);
        NullZoneSpawner.placeCell(level, other, d, plane, pos.asLong(), -1, false, 0, 0, 0, false);
        return true;
    }

    private static boolean placeFloor(ServerLevel level, BlockPos pos, Vec3 hit) {
        int dx = hit.x - pos.getX() >= 0.5 ? 1 : -1;
        int dz = hit.z - pos.getZ() >= 0.5 ? 1 : -1;
        List<BlockPos> cells = new ArrayList<>(8);
        for (int ix : new int[]{0, dx}) {
            for (int iz : new int[]{0, dz}) {
                BlockPos top = pos.offset(ix, 0, iz);
                BlockPos deep = top.below();
                if (!level.hasChunkAt(top)) return false;
                BlockState above = level.getBlockState(top.above());
                if (!above.getCollisionShape(level, top.above()).isEmpty() || !above.getFluidState().isEmpty()) return false;
                if (!NullZoneSpawner.canHost(level, top) || !NullZoneSpawner.canHost(level, deep)) return false;
                cells.add(top);
                cells.add(deep);
            }
        }
        // the portal plane sits a little below the surface: the eyes of a player who sinks in cross it before the feet reach the bottom
        double plane = NullZoneSpawner.planeOf(Direction.DOWN, 0, pos.getY() + 1 - 0.25, 0);
        for (BlockPos c : cells) {
            NullZoneSpawner.placeCell(level, c, Direction.DOWN, plane, pos.asLong(), -1, false, 0, 0, 0, c.equals(pos));
        }
        return true;
    }

    private static void tell(Player p, String text) {
        p.displayClientMessage(Component.literal(text), true);
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("Right-click a block: it becomes a permanent Null Zone that looks the same."));
        tooltip.add(Component.literal("Side = wall (1x2). Top = floor (2x2, you fall through the ceiling)."));
        tooltip.add(Component.literal("Sneak + right-click a Null Zone to remove it."));
    }
}
