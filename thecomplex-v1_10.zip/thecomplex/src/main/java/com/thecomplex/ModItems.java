package com.thecomplex;

import com.thecomplex.briefcase.BriefcaseItem;
import com.thecomplex.dev.DevToolItem;
import com.thecomplex.item.ComplexItem;
import com.thecomplex.item.FlashlightItem;
import com.thecomplex.lpmds.LpmdsMarkerItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, TheComplex.MODID);

    /** Klik kanan untuk membuka panel uji (Developer UI). Hanya untuk OP atau mode kreatif. */
    public static final RegistryObject<Item> DEV_TOOL = ITEMS.register("dev_tool",
            () -> new DevToolItem(new Item.Properties().stacksTo(1)));

    /** Menandai mesin LPMDS dan bingkai target 2x3. */
    public static final RegistryObject<Item> LPMDS_MARKER = ITEMS.register("lpmds_marker",
            () -> new LpmdsMarkerItem(new Item.Properties().stacksTo(1)));

    /** Exploration Briefcase: tas yang dibawa ke The Complex (inventori Tetris, tali, bisa dilempar). */
    public static final RegistryObject<Item> BRIEFCASE = ITEMS.register("briefcase",
            () -> new BriefcaseItem(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> FLASHLIGHT = ITEMS.register("flashlight",
            () -> new FlashlightItem(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> FLASHLIGHT_BATTERY = ITEMS.register("flashlight_battery",
            () -> new ComplexItem(new Item.Properties().stacksTo(16), "One flashlight battery slot (7 minutes by default)."));

    /** 1 roll = 8 blok tape (daya tahan 8). */
    public static final RegistryObject<Item> DUCT_TAPE = ITEMS.register("duct_tape",
            () -> new ComplexItem(new Item.Properties().durability(8), "1 roll = 8 blocks. Right-click a Duct Anchor to start."));

    /** Maksimal 12 blok (config). Taruh di slot Tali Briefcase. */
    public static final RegistryObject<Item> ROPE = ITEMS.register("rope",
            () -> new ComplexItem(new Item.Properties().stacksTo(1), "Put it in the Briefcase's Rope slot. Throw the Briefcase, then climb."));

    private ModItems() {}
}
