package com.thecomplex.world;

import com.thecomplex.TheComplex;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.fml.loading.FMLPaths;
import net.minecraftforge.forgespi.language.IModFileInfo;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.TreeMap;
import java.util.stream.Stream;

/**
 * Sumber schematic, dari yang paling diutamakan:
 *   1. config/thecomplex/main_chamber.schem dan config/thecomplex/rooms/*.schem  (opsional, untuk uji cepat)
 *   2. di dalam mod sendiri: data/thecomplex/schem/main_chamber.schem dan data/thecomplex/schem/rooms/*.schem
 *   3. config/worldedit/schematics (hanya untuk Main Chamber)
 * Ruangan dengan nama sama di config menggantikan yang ada di dalam mod.
 */
public final class SchemStore {
    private record Found(Path path, String source) {}

    private static volatile boolean loaded;
    private static volatile Schem mainChamber;
    private static volatile String mainChamberSource = "";
    private static volatile List<Schem> rooms = List.of();

    private SchemStore() {}

    public static Path dir() {
        return FMLPaths.CONFIGDIR.get().resolve("thecomplex");
    }

    private static Path bundledDir() {
        try {
            IModFileInfo info = ModList.get().getModFileById(TheComplex.MODID);
            if (info == null) return null;
            Path p = info.getFile().findResource("data", "thecomplex", "schem");
            return (p != null && Files.isDirectory(p)) ? p : null;
        } catch (Exception e) {
            TheComplex.LOGGER.warn("[thecomplex] failed to open the mod's bundled schematic folder: {}", e.toString());
            return null;
        }
    }

    public static synchronized void load() {
        if (loaded) return;
        try {
            Files.createDirectories(dir().resolve("rooms"));
        } catch (IOException e) {
            TheComplex.LOGGER.warn("[thecomplex] could not create the config folder: {}", e.toString());
        }
        Found found = findMainChamber();
        mainChamber = found == null ? null : readOne(found.path());
        mainChamberSource = found == null ? "" : found.source();
        if (mainChamber == null) {
            TheComplex.LOGGER.info("[thecomplex] main_chamber.schem not found (config, bundled with the mod, WorldEdit folder); using the placeholder");
        }
        rooms = readRooms();
        loaded = true;
    }

    public static Schem mainChamber() {
        if (!loaded) load();
        return mainChamber;
    }

    public static List<Schem> rooms() {
        if (!loaded) load();
        return rooms;
    }

    /** Hanya ruangan; Main Chamber tidak dimuat ulang supaya dunia yang sudah jadi tetap konsisten. */
    public static synchronized int reloadRooms() {
        rooms = readRooms();
        return rooms.size();
    }

    public static String mainChamberStatus() {
        if (mainChamber() != null) return "main_chamber loaded (" + mainChamberSource + ")";
        return "main_chamber NOT found; put it in " + dir().resolve("main_chamber.schem") + " or inside the mod";
    }

    public static Schem find(String name) {
        for (Schem s : rooms()) if (s.name.equalsIgnoreCase(name)) return s;
        Schem m = mainChamber();
        return (m != null && name.equalsIgnoreCase("main_chamber")) ? m : null;
    }

    // ------------------------------------------------------------------ pencarian

    private static boolean isMainName(String fileName) {
        String n = fileName.toLowerCase();
        if (!n.endsWith(".schem")) return false;
        return n.substring(0, n.length() - 6).replaceAll("[ _\\-]", "").equals("mainchamber");
    }

    private static Found findMainChamber() {
        Found f = scanForMain(dir(), "config");
        if (f == null) f = scanForMain(bundledDir(), "bundled with the mod");
        if (f == null) f = scanForMain(FMLPaths.CONFIGDIR.get().resolve("worldedit").resolve("schematics"), "WorldEdit folder");
        return f;
    }

    private static Found scanForMain(Path d, String label) {
        if (d == null || !Files.isDirectory(d)) return null;
        try (Stream<Path> files = Files.list(d)) {
            Optional<Path> hit = files.filter(p -> isMainName(p.getFileName().toString())).sorted().findFirst();
            return hit.map(p -> new Found(p, label)).orElse(null);
        } catch (IOException e) {
            TheComplex.LOGGER.warn("[thecomplex] failed to read folder {}: {}", d, e.toString());
            return null;
        }
    }

    private static Schem readOne(Path file) {
        if (file == null || !Files.isRegularFile(file)) return null;
        try {
            Schem s = Schem.read(file);
            TheComplex.LOGGER.info("[thecomplex] loaded {} ({}x{}x{})", file.getFileName(), s.width, s.height, s.length);
            return s;
        } catch (Exception e) {
            TheComplex.LOGGER.error("[thecomplex] failed to read {}: {}", file.getFileName(), e.toString());
            return null;
        }
    }

    private static List<Schem> readRooms() {
        Map<String, Schem> byName = new TreeMap<>();
        Path bundled = bundledDir();
        readRoomsFrom(bundled == null ? null : bundled.resolve("rooms"), byName);
        readRoomsFrom(dir().resolve("rooms"), byName);
        return List.copyOf(byName.values());
    }

    private static void readRoomsFrom(Path dir, Map<String, Schem> out) {
        if (dir == null || !Files.isDirectory(dir)) return;
        try (Stream<Path> files = Files.list(dir)) {
            files.filter(p -> p.getFileName().toString().toLowerCase().endsWith(".schem")).sorted().forEach(p -> {
                Schem s = readOne(p);
                if (s == null) return;
                if ((s.width + 15) / 16 > ComplexLayout.SLOT || (s.length + 15) / 16 > ComplexLayout.SLOT) {
                    TheComplex.LOGGER.warn("[thecomplex] {} too big for a {}x{} chunk slot, skipped",
                            s.name, ComplexLayout.SLOT, ComplexLayout.SLOT);
                    return;
                }
                out.put(s.name.toLowerCase(), s);
            });
        } catch (IOException e) {
            TheComplex.LOGGER.warn("[thecomplex] failed to read the rooms folder: {}", e.toString());
        }
    }
}
