package com.thecomplex.world;

import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.levelgen.PositionalRandomFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * Architectural planner for one 16x16 chunk of the Backrooms.
 *
 * The planner is pure and deterministic: the same world seed always gives the same plan for a chunk, and a chunk never reads
 * another chunk's plan (only the shared EDGE functions, which both neighbors evaluate identically).
 *
 * Room logic comes first. Every chunk is ONE of a few clear archetypes, built in this order:
 *  1. edges (walls and door spans, matching the neighbors),
 *  2. the archetype (pillar hall, split hall, corridor with rooms, junction with four rooms, gallery, big room with ring corridor),
 *  3. cleared landings in front of doors, space around hand-built rooms,
 *  4. wall ribs aligned with the pillar lattice,
 *  5. density: any empty 5x5 window gets a pillar ON THE GRID (pillars sit on a 4-cell lattice that continues across chunk borders),
 *  6. connectivity guarantee (flood fill, carved passage, sealed pockets filled).
 * The ceiling is always flat. Doorways are a lintel row of wall blocks (arches are switched off, see ARCHES).
 *
 * v1.6 rules (from play-testing):
 *  - pillars are rare: only chunks that roll "pillars allowed" (Division.pillarPct) get any pillar or rib at all,
 *  - no straight sight line longer than about 4 chunks: every 4th chunk line is a "jog" where doors are pushed off-center
 *    and fully open edges become doors, and corridors only exist between two jog lines,
 *  - one wall material per division (Division.family). Where two divisions with different materials meet, the wall is two
 *    blocks thick so each side sees its own material,
 *  - fewer doors per room.
 *
 * Macro connectivity: the world is split into 8x8-chunk blocks. Inside a block, chunk links form a random spanning tree
 * plus extra random openings for loops. Between blocks every boundary has at least one guaranteed gateway.
 */
public final class BackroomsDesigner {
    // ---- column kinds
    public static final byte OPEN = 0, WALL = 1, PILLAR = 2, HALF_PILLAR = 3, VSLAB = 4, LINTEL = 5, ARCH_L = 6, ARCH_R = 7;
    // ---- material families (white only exists as a full wall block)
    public static final byte CLASSIC = 0, OFFICE = 1, WHITE = 2;
    /** Arch pieces are disabled for now (the doorway is a plain lintel row). Set to true to bring them back. */
    public static final boolean ARCHES = false;
    // ---- v1.9 template ids (the first ones, 0..14, are described in template())
    /** Solid wall chunk: the whole interior is wall, with 3-wide tunnels from every door to the middle. */
    static final int WALL_MASS = 15;
    /** Long plain hallway: two full-length walls, a few doors into the side bands. */
    static final int HALLWAY = 16;
    /** Hall with square pilasters (wall stubs) against the west and north walls. */
    static final int PILASTERS = 17;
    /** A bulkhead: a 3-thick partition across the chunk with one 3-wide tunnel through it. */
    static final int BULKHEAD = 18;
    /** A solid wall core in the middle of the hall. */
    static final int CORE = 19;
    /** What a generic chunk may be swapped for (wall mass twice as likely as the others). */
    private static final int[] VARIANTS = {11, 12, 13, 14, WALL_MASS, WALL_MASS, HALLWAY, PILASTERS, BULKHEAD, CORE};
    /** Distance (in chunks) between "jog" lines that break long straight halls. */
    private static final int JOG = 4;

    private static final int N = 16;
    /** No bare floor window larger than this (in cells) is allowed. */
    private static final int WINDOW = 5;
    // Direction.get2DDataValue(): 0 south, 1 west, 2 north, 3 east
    private static final int D_S = 0, D_W = 1, D_N = 2, D_E = 3;

    public static final class Plan {
        public final byte[] kind = new byte[N * N];
        public final byte[] fam = new byte[N * N];
        /** Direction.get2DDataValue() (facing for half pillars, slabs and arch pieces). */
        public final byte[] dir = new byte[N * N];
        final boolean[] keep = new boolean[N * N];

        Plan copy() {
            Plan c = new Plan();
            System.arraycopy(kind, 0, c.kind, 0, kind.length);
            System.arraycopy(fam, 0, c.fam, 0, fam.length);
            System.arraycopy(dir, 0, c.dir, 0, dir.length);
            System.arraycopy(keep, 0, c.keep, 0, keep.length);
            return c;
        }

        void restore(Plan o) {
            System.arraycopy(o.kind, 0, kind, 0, kind.length);
            System.arraycopy(o.fam, 0, fam, 0, fam.length);
            System.arraycopy(o.dir, 0, dir, 0, dir.length);
        }

        public byte kindAt(int x, int z) {
            return x < 0 || z < 0 || x >= N || z >= N ? WALL : kind[z * N + x];
        }

        void set(int x, int z, byte k, byte f, int d) {
            if (x < 0 || z < 0 || x >= N || z >= N) return;
            int i = z * N + x;
            kind[i] = k;
            fam[i] = f;
            dir[i] = (byte) d;
        }

        boolean isOpen(int x, int z) {
            return x >= 1 && z >= 1 && x < N && z < N && kind[z * N + x] == OPEN && !keep[z * N + x];
        }
    }

    /** One side of a chunk. state: 0 wall, 1 door (start, width), 2 fully open. */
    public record Edge(int state, int start, int width) {
        public boolean passable() {
            return state > 0;
        }

        public boolean isDoor(int i) {
            return state == 2 || (state == 1 && i >= start && i < start + width);
        }

        public int mid() {
            return state == 2 ? 8 : start + width / 2;
        }
    }

    private BackroomsDesigner() {}

    // =====================================================================================================
    // Edges and macro connectivity
    // =====================================================================================================

    /** Is the west edge of chunk (cx, cz) a jog line? Lines are JOG chunks apart, shifted per chunk row. */
    private static boolean jogWest(PositionalRandomFactory f, int cx, int cz) {
        int shift = f.at(cz, 51, 3).nextInt(JOG);
        return Math.floorMod(cx + shift, JOG) == 0;
    }

    /** Is the north edge of chunk (cx, cz) a jog line? */
    private static boolean jogNorth(PositionalRandomFactory f, int cx, int cz) {
        int shift = f.at(cx, 52, 3).nextInt(JOG);
        return Math.floorMod(cz + shift, JOG) == 0;
    }

    /** The west (or north) edge owned by chunk (cx, cz). Neighbors call this for their east / south side. */
    public static Edge edge(PositionalRandomFactory f, int cx, int cz, boolean west) {
        int ncx = west ? cx - 1 : cx, ncz = west ? cz : cz - 1;
        if (ComplexLayout.reserved(ncx, ncz)) {
            // custom Main Chamber: no extra wall, so openings in the chamber wall lead straight into the Backrooms
            return new Edge(ComplexLayout.hasCustomMainChamber() ? 2 : 0, 0, 0);
        }
        int state;
        if (ComplexLayout.roomAt(f, ncx, ncz) != null) state = 1;     // next to a hand-built room: always a door
        else state = treeState(f, cx, cz, west);

        Division a = Division.at(f, cx, cz), b = Division.at(f, ncx, ncz);
        boolean jog = west ? jogWest(f, cx, cz) : jogNorth(f, cx, cz);
        // a corridor that runs through this edge: the edge must carry a door lined up with the corridor
        int want = west ? 1 : 2;
        boolean corridor = archetype(f, cx, cz, a, f.at(cx, 2, cz)).axis == want
                || archetype(f, ncx, ncz, b, f.at(ncx, 2, ncz)).axis == want;
        // different ceiling heights or wall materials meet, or a jog line, or a corridor: door only, never a fully open hall
        if (state == 2 && (a.air != b.air || a.family != b.family || jog || corridor)) state = 1;

        RandomSource r = f.at(cx, west ? 45 : 46, cz);
        int roll = r.nextInt(100);
        // Ordinary doors always sit in the band 5..10; jog doors sit outside it (2..4 or 11..13). So a straight line of
        // sight can never pass a jog line, and no hall is longer than JOG chunks.
        int w, start;
        if (corridor && !jog) {
            w = 4;
            start = 6;                                                // cells 6..9, same as the corridor template
        } else if (jog) {
            w = 3;
            start = r.nextBoolean() ? 2 : 11;
        } else {
            w = roll < 35 ? 3 : roll < 80 ? 4 : 5;
            start = 5 + r.nextInt(6 - w + 1);
        }
        return new Edge(state, start, w);
    }

    private static boolean linksWest(PositionalRandomFactory f, int cx, int cz) {
        int lx = Math.floorMod(cx, Division.REGION), lz = Math.floorMod(cz, Division.REGION);
        if (lx == 0) return false;
        if (lz == 0) return true;
        return f.at(cx, 44, cz).nextBoolean();
    }

    private static int treeState(PositionalRandomFactory f, int cx, int cz, boolean west) {
        int R = Division.REGION;
        int lx = Math.floorMod(cx, R), lz = Math.floorMod(cz, R);
        RandomSource r = f.at(cx, west ? 40 : 41, cz);
        boolean boundary = west ? lx == 0 : lz == 0;
        if (boundary) {
            // gateway between two 8x8 blocks: one guaranteed per boundary line, a few extra
            int idx = west ? lz : lx;
            int base = f.at(Math.floorDiv(cx, R), west ? 42 : 43, Math.floorDiv(cz, R)).nextInt(R);
            boolean open = idx == base || r.nextInt(100) < 10;
            return open ? (r.nextInt(100) < 10 ? 2 : 1) : 0;
        }
        boolean tree = west == linksWest(f, cx, cz);
        if (tree) return r.nextInt(100) < 8 ? 2 : 1;
        int openness = Division.at(f, cx, cz).openness;
        return r.nextInt(100) < openness ? (r.nextInt(100) < 8 ? 2 : 1) : 0;
    }

    // =====================================================================================================
    // Archetype of a chunk (pure function of the seed, so neighbors can ask what a chunk will look like)
    // =====================================================================================================

    /** pattern: template id; axis: 1 = a corridor runs along X, 2 = along Z, 0 = no corridor. */
    static final class Arch {
        final int pattern;
        final int axis;
        final boolean pillars;

        Arch(int pattern, int axis, boolean pillars) {
            this.pattern = pattern;
            this.axis = axis;
            this.pillars = pillars;
        }
    }

    static boolean pillarsAllowed(PositionalRandomFactory f, int cx, int cz, Division div) {
        return div.family != WHITE && f.at(cx, 35, cz).nextInt(100) < div.pillarPct;
    }

    /**
     * Decides the template of chunk (cx, cz). Takes the chunk's own random source ({@code f.at(cx, 2, cz)}) and leaves it
     * positioned so the template can keep drawing from it.
     */
    static Arch archetype(PositionalRandomFactory f, int cx, int cz, Division div, RandomSource r) {
        int id = div.pickPattern(r.nextInt(100));
        boolean pillars = pillarsAllowed(f, cx, cz, div);
        // pillar patterns only in the few chunks that are allowed to have pillars
        if (!pillars && (id == 0 || id == 1 || id == 4)) {
            int q = r.nextInt(100);
            id = q < 25 ? 10 : q < 65 ? 2 + r.nextInt(2) : 9;
        }
        // more variety: the generic layouts are often swapped for a room-in-hall, L-walls, a zigzag of two partitions, alcoves,
        // or (v1.9) a solid wall chunk with tunnels, a long plain hallway, a pilaster hall, a thick bulkhead or a solid core
        if ((id == 2 || id == 3 || id == 9 || id == 10) && r.nextInt(100) < 45) id = VARIANTS[r.nextInt(VARIANTS.length)];
        int axis = 0;
        if (id == 5) axis = 1;
        else if (id == 6) axis = 2;
        else if (id == 8 || id == HALLWAY) axis = r.nextBoolean() ? 1 : 2;
        // a corridor may only run between two jog lines, so no hallway is longer than JOG - 1 chunks
        if (axis == 1 && (jogWest(f, cx, cz) || jogWest(f, cx + 1, cz))) { id = r.nextInt(100) < 50 ? 9 : 10; axis = 0; }
        if (axis == 2 && (jogNorth(f, cx, cz) || jogNorth(f, cx, cz + 1))) { id = r.nextInt(100) < 50 ? 9 : 10; axis = 0; }
        return new Arch(id, axis, pillars);
    }

    // =====================================================================================================
    // Plan
    // =====================================================================================================

    public static Plan design(PositionalRandomFactory f, int cx, int cz, Division div, List<int[]> roomBoxes, int x0, int z0) {
        Plan p = new Plan();
        Edge ew = edge(f, cx, cz, true), en = edge(f, cx, cz, false);
        Edge ee = edge(f, cx + 1, cz, true), es = edge(f, cx, cz + 1, false);
        // one material per division. The shared edge wall is seen from the neighbor's room, so it carries the neighbor's material.
        byte fam = div.family;
        byte famW = Division.at(f, cx - 1, cz).family, famN = Division.at(f, cx, cz - 1).family;

        // 1. edge walls with door spans
        for (int i = 0; i < N; i++) {
            p.set(0, i, WALL, famW, 0);
            p.set(i, 0, WALL, famN, 0);
        }
        if (ew.state() == 2) for (int i = 1; i < N; i++) p.set(0, i, OPEN, famW, 0);
        else if (ew.state() == 1) door(p, true, 0, ew.start(), ew.width(), famW);
        if (en.state() == 2) for (int i = 1; i < N; i++) p.set(i, 0, OPEN, famN, 0);
        else if (en.state() == 1) door(p, false, 0, en.start(), en.width(), famN);
        p.set(0, 0, WALL, famW, 0);

        // portals: one cell per passable side
        List<int[]> portals = new ArrayList<>();
        if (ew.passable()) portals.add(new int[]{0, ew.mid()});
        if (en.passable()) portals.add(new int[]{en.mid(), 0});
        if (ee.passable()) portals.add(new int[]{15, ee.mid()});
        if (es.passable()) portals.add(new int[]{es.mid(), 15});

        // landing strips (2 deep) in front of each door stay clear
        markLanding(p, ew, true, 0);
        markLanding(p, en, false, 0);
        markLanding(p, ee, true, 14);
        markLanding(p, es, false, 14);

        // 2. archetype
        RandomSource r = f.at(cx, 2, cz);
        Arch arch = archetype(f, cx, cz, div, r);
        template(p, arch, r, fam);

        // 3. clear landings, give hand-built rooms breathing room
        for (int i = 0; i < N * N; i++) {
            if (p.keep[i] && (i % N) != 0 && (i / N) != 0) p.kind[i] = OPEN;
        }
        for (int[] box : roomBoxes) {
            for (int lx = 1; lx < N; lx++) {
                for (int lz = 1; lz < N; lz++) {
                    int wx = x0 + lx, wz = z0 + lz;
                    if (wx >= box[0] - 2 && wx <= box[1] + 2 && wz >= box[2] - 2 && wz <= box[3] + 2) p.kind[lz * N + lx] = OPEN;
                }
            }
        }

        // 3a. solid wall chunk: cut a 3-wide tunnel from every door to the middle of the chunk
        if (arch.pattern == WALL_MASS) {
            for (int[] q : portals) tunnel(p, Mth.clamp(q[0], 1, 14), Mth.clamp(q[1], 1, 14));
            for (int x = 7; x <= 9; x++) for (int z = 7; z <= 9; z++) clearCell(p, x, z);
        }

        // 3b. where the neighbor uses another wall material the wall is two blocks thick: the outer layer shows the
        // neighbor's material, the inner layer (the first row of this chunk) shows ours
        if (famW != fam) thickWall(p, true, ew, fam);
        if (famN != fam) thickWall(p, false, en, fam);

        // 4 and 5. ribs and density, each step validated against connectivity (only in chunks that may have pillars)
        if (arch.pillars) decorate(p, portals, f.at(cx, 6, cz), fam);

        // 6. final guarantee
        enforce(p, portals, fam);
        // 7. doorways are always 3 blocks tall
        finishDoorways(p, div);
        return p;
    }

    /**
     * Doorways are 3 blocks tall. With 3 blocks of air that means no lintel at all (the door is a full-height gap);
     * with 4 blocks of air the lintel sits on top of the 3-block opening. A lintel that lost one of its posts
     * (a landing strip or a carved passage removed the wall next to it) is dropped instead of hanging in the air.
     */
    private static void finishDoorways(Plan p, Division div) {
        if (div.air < 4) {
            for (int i = 0; i < N * N; i++) if (p.kind[i] == LINTEL) p.kind[i] = OPEN;
            return;
        }
        boolean changed;
        do {
            changed = false;
            for (int z = 0; z < N; z++) {
                for (int x = 0; x < N; x++) {
                    if (p.kind[z * N + x] != LINTEL) continue;
                    boolean supportedX = post(p, x - 1, z) && post(p, x + 1, z);
                    boolean supportedZ = post(p, x, z - 1) && post(p, x, z + 1);
                    if (!supportedX && !supportedZ) {
                        p.kind[z * N + x] = OPEN;
                        changed = true;
                    }
                }
            }
        } while (changed);
    }

    /** Something a lintel can rest on. Cells outside the plan count as supported (the neighbor owns them). */
    private static boolean post(Plan p, int x, int z) {
        if (x < 0 || z < 0 || x >= N || z >= N) return true;
        byte k = p.kind[z * N + x];
        return k == WALL || k == PILLAR || k == HALF_PILLAR || k == VSLAB || k == LINTEL || k == ARCH_L || k == ARCH_R;
    }

    private static void thickWall(Plan p, boolean west, Edge e, byte fam) {
        for (int i = 1; i < N; i++) {
            if (e.isDoor(i)) continue;
            if (west) p.set(1, i, WALL, fam, 0);
            else p.set(i, 1, WALL, fam, 0);
        }
    }

    private static void markLanding(Plan p, Edge e, boolean vertical, int inner) {
        if (!e.passable()) return;
        for (int i = 0; i < N; i++) {
            if (!e.isDoor(i)) continue;
            for (int d = 0; d < 2; d++) {
                int a = vertical ? (inner == 0 ? 1 + d : 14 + d) : i;
                int b = vertical ? i : (inner == 0 ? 1 + d : 14 + d);
                if (a >= 1 && a < N && b >= 1 && b < N) p.keep[b * N + a] = true;
            }
        }
    }

    // =====================================================================================================
    // Doorways: a lintel row of wall blocks, with the Left + Right Arch pair over the center two cells
    // =====================================================================================================

    /**
     * @param wallRunsAlongZ true for a wall on a fixed x (running along Z): the passage then runs along X
     * @param line           the fixed x (or z) of the wall
     * @param start          first cell along the wall
     * @param w              door width in cells
     */
    private static void door(Plan p, boolean wallRunsAlongZ, int line, int start, int w, byte fam) {
        int archStart = Math.max(0, (w - 2) / 2);
        // Looking through the doorway: facing EAST for X passages (left = lower z), facing NORTH for Z passages (left = lower x).
        int facing = wallRunsAlongZ ? D_E : D_N;
        for (int i = start; i < start + w; i++) {
            int x = wallRunsAlongZ ? line : i, z = wallRunsAlongZ ? i : line;
            int rel = i - start;
            if (ARCHES && w >= 2 && rel == archStart) p.set(x, z, ARCH_L, fam, facing);
            else if (ARCHES && w >= 2 && rel == archStart + 1) p.set(x, z, ARCH_R, fam, facing);
            else p.set(x, z, LINTEL, fam, 0);
        }
    }

    // =====================================================================================================
    // Archetypes
    // =====================================================================================================

    private static byte accent(RandomSource r, byte fam) {
        return fam;
    }

    /** Pillars sit on a 4-cell lattice (2, 6, 10, 14) that continues seamlessly across chunk borders. */
    private static void lattice(Plan p, byte fam, int mode) {
        for (int ix = 0; ix < 4; ix++) {
            for (int iz = 0; iz < 4; iz++) {
                boolean on = switch (mode) {
                    case 0 -> true;                     // every lattice point
                    case 1 -> iz == 1 || iz == 2;       // two rows (a nave between them)
                    default -> (ix + iz) % 2 == 0;      // checkerboard
                };
                if (on) p.set(2 + 4 * ix, 2 + 4 * iz, PILLAR, fam, 0);
            }
        }
    }

    /** Wall along one axis from a to b at a fixed line, with door gaps. Used for partitions and room walls. */
    private static void wallLine(Plan p, boolean alongX, int line, int a, int b, byte fam) {
        for (int i = a; i <= b; i++) p.set(alongX ? i : line, alongX ? line : i, WALL, fam, 0);
    }

    private static void template(Plan p, Arch arch, RandomSource r, byte fam) {
        int id = arch.pattern;
        switch (id) {
            case 0 -> lattice(p, fam, 0);                       // pillar hall
            case 1 -> lattice(p, fam, 1);                       // colonnade with a nave
            case 4 -> lattice(p, fam, 2);                       // checkerboard hall
            case 10 -> { }                                      // plain empty hall (no pillars)
            case 11 -> {                                        // a room standing in an empty hall, one or two doors
                byte f2 = accent(r, fam);
                int rw = 5 + r.nextInt(5), rd = 5 + r.nextInt(5);
                int rx = 3 + r.nextInt(11 - rw), rz = 3 + r.nextInt(11 - rd);
                wallLine(p, true, rz, rx, rx + rw - 1, f2);
                wallLine(p, true, rz + rd - 1, rx, rx + rw - 1, f2);
                wallLine(p, false, rx, rz, rz + rd - 1, f2);
                wallLine(p, false, rx + rw - 1, rz, rz + rd - 1, f2);
                int first = r.nextInt(4);
                int doors = r.nextInt(100) < 50 ? 2 : 1;
                for (int k = 0; k < doors; k++) {
                    int side = (first + k * 2) % 4;                 // the second door faces the opposite side
                    int w = 2 + r.nextInt(2);
                    if (side < 2) door(p, false, side == 0 ? rz : rz + rd - 1, rx + 1 + r.nextInt(rw - 2 - w + 1), w, fam);
                    else door(p, true, side == 2 ? rx : rx + rw - 1, rz + 1 + r.nextInt(rd - 2 - w + 1), w, fam);
                }
            }
            case 12 -> {                                        // an L of wall: a nook without a door
                byte f2 = accent(r, fam);
                int len1 = 5 + r.nextInt(6), len2 = 4 + r.nextInt(5);
                int z1 = 4 + r.nextInt(8);
                boolean fromLeft = r.nextBoolean();
                int a = fromLeft ? 3 : 12 - len1 + 1, b = fromLeft ? 3 + len1 - 1 : 12;
                wallLine(p, true, z1, a, b, f2);
                int xe = fromLeft ? b : a;
                int z2 = Mth.clamp(z1 + (r.nextBoolean() ? 1 : -1) * (len2 - 1), 3, 12);
                wallLine(p, false, xe, Math.min(z1, z2), Math.max(z1, z2), f2);
            }
            case 13 -> {                                        // two partitions, doors on opposite ends: a zigzag path
                boolean alongX = r.nextBoolean();
                byte f2 = accent(r, fam);
                int l1 = 4 + r.nextInt(2), l2 = 10 + r.nextInt(2);
                boolean first = r.nextBoolean();
                wallLine(p, alongX, l1, 1, 15, f2);
                wallLine(p, alongX, l2, 1, 15, f2);
                door(p, !alongX, l1, first ? 2 + r.nextInt(4) : 9 + r.nextInt(4), 3, fam);
                door(p, !alongX, l2, first ? 9 + r.nextInt(4) : 2 + r.nextInt(4), 3, fam);
            }
            case 14 -> {                                        // a row of three alcoves along one wall
                byte f2 = accent(r, fam);
                int side = r.nextInt(4), len = 3 + r.nextInt(2);
                for (int k = 0; k < 3; k++) {
                    int c0 = 3 + k * 4, c1 = c0 + 3;
                    for (int c : new int[]{c0, c1}) {
                        switch (side) {
                            case 0 -> wallLine(p, false, c, 1, len, f2);
                            case 1 -> wallLine(p, false, c, 15 - len, 14, f2);
                            case 2 -> wallLine(p, true, c, 1, len, f2);
                            default -> wallLine(p, true, c, 15 - len, 14, f2);
                        }
                    }
                }
            }
            case WALL_MASS -> {                                 // solid wall: the tunnels are cut in design() once the doors are known
                for (int x = 1; x < N; x++) for (int z = 1; z < N; z++) p.set(x, z, WALL, fam, 0);
            }
            case HALLWAY -> {                                   // two full-length walls with side doors; ends line up with the corridor edges
                boolean alongX = arch.axis == 1;
                byte f2 = accent(r, fam);
                wallLine(p, alongX, 5, 1, 15, f2);
                wallLine(p, alongX, 10, 1, 15, f2);
                for (int line : new int[]{5, 10}) {
                    door(p, !alongX, line, 2 + r.nextInt(3), 3, fam);
                    if (r.nextInt(100) < 55) door(p, !alongX, line, 9 + r.nextInt(4), 3, fam);
                }
            }
            case PILASTERS -> {                                 // wall stubs 2 deep and 1 wide against the west and north walls
                byte f2 = accent(r, fam);
                for (int i : new int[]{3, 7, 11}) {
                    p.set(1, i, WALL, f2, 0);
                    p.set(2, i, WALL, f2, 0);
                    p.set(i, 1, WALL, f2, 0);
                    p.set(i, 2, WALL, f2, 0);
                }
            }
            case BULKHEAD -> {                                  // a 3-thick partition with one 3-wide tunnel
                boolean alongX = r.nextBoolean();
                byte f2 = accent(r, fam);
                int line = 6 + r.nextInt(3);
                int o = 3 + r.nextInt(8);
                for (int t = 0; t < 3; t++) wallLine(p, alongX, line + t, 1, 15, f2);
                for (int t = 0; t < 3; t++) {
                    for (int i = o; i < o + 3; i++) p.set(alongX ? i : line + t, alongX ? line + t : i, OPEN, fam, 0);
                }
            }
            case CORE -> {                                      // a solid block 4 to 6 cells wide in the middle
                byte f2 = accent(r, fam);
                int w = 4 + r.nextInt(3), d = 4 + r.nextInt(3);
                int x0 = 8 - w / 2 + r.nextInt(3) - 1, z0 = 8 - d / 2 + r.nextInt(3) - 1;
                for (int x = x0; x < x0 + w; x++) for (int z = z0; z < z0 + d; z++) p.set(x, z, WALL, f2, 0);
            }
            case 2, 3 -> {                                      // hall split by one partition with a door
                boolean alongX = id == 2;
                int line = r.nextBoolean() ? 4 : 12;
                byte f2 = accent(r, fam);
                int w = 3 + r.nextInt(3), o = 2 + r.nextInt(12 - w);
                wallLine(p, alongX, line, 1, 15, f2);
                door(p, !alongX, line, o, w, fam);
            }
            case 5, 6 -> corridor(p, id == 5, r, fam, true, arch.pillars);    // corridor with a row of rooms on each side
            case 8 -> corridor(p, arch.axis == 1, r, fam, false, arch.pillars);   // gallery: rooms on one side, open on the other
            case 7 -> {                                         // junction: two corridors cross, four rooms in the corners
                byte f2 = accent(r, fam);
                for (int i : new int[]{5, 10}) {
                    wallLine(p, true, i, 1, 4, f2);
                    wallLine(p, true, i, 11, 15, f2);
                    wallLine(p, false, i, 1, 4, f2);
                    wallLine(p, false, i, 11, 15, f2);
                }
                door(p, true, 5, 2, 2, fam);       // NW room: door on its east wall (x = 5)
                door(p, true, 10, 2, 2, fam);      // NE room: door on its west wall (x = 10)
                door(p, true, 5, 12, 2, fam);      // SW room
                door(p, true, 10, 12, 2, fam);     // SE room
            }
            default -> {                                        // big room with a ring corridor around it
                byte f2 = accent(r, fam);
                wallLine(p, false, 3, 3, 12, f2);
                wallLine(p, false, 12, 3, 12, f2);
                wallLine(p, true, 3, 3, 12, f2);
                wallLine(p, true, 12, 3, 12, f2);
                door(p, true, 3, 7, 2, fam);
                door(p, true, 12, 7, 2, fam);
                if (r.nextBoolean()) { door(p, false, 3, 7, 2, fam); door(p, false, 12, 7, 2, fam); }
                if (arch.pillars) for (int x : new int[]{6, 10}) for (int z : new int[]{6, 10}) p.set(x, z, PILLAR, fam, 0);
            }
        }
    }

    /**
     * Corridor 4 wide (cells 6..9) with walls at 5 and 10. The side bands are cut into rooms by partitions at 5 and 10,
     * each room opens onto the corridor through a 2-wide arched door.
     * @param rooms false = rooms only on the low side, the other side stays an open pillar hall
     */
    private static void corridor(Plan p, boolean alongX, RandomSource r, byte fam, boolean rooms, boolean pillars) {
        byte f2 = accent(r, fam);
        // corridor walls (axis: along X means the corridor runs along X, walls are lines of constant z)
        wallLine(p, alongX, 5, 1, 15, f2);
        if (rooms) wallLine(p, alongX, 10, 1, 15, f2);
        // room partitions across both bands
        for (int x : new int[]{5, 10}) {
            wallLine(p, !alongX, x, 1, 4, f2);
            if (rooms) wallLine(p, !alongX, x, 11, 15, f2);
        }
        // doors from each room onto the corridor (room centers 2.5, 7.5, 12.5 -> door cells 2-3, 7-8, 12-13)
        for (int c : new int[]{2, 7, 12}) {
            door(p, !alongX, 5, c, 2, fam);
            if (rooms) door(p, !alongX, 10, c, 2, fam);
        }
        if (!rooms && pillars) {
            // the far side is a pillar hall on the lattice
            for (int ix = 0; ix < 4; ix++) for (int iz = 2; iz < 4; iz++) p.set(alongX ? 2 + 4 * ix : 2 + 4 * iz, alongX ? 2 + 4 * iz : 2 + 4 * ix, PILLAR, fam, 0);
        }
    }

    // =====================================================================================================
    // Decoration (on the grid only)
    // =====================================================================================================

    private static void decorate(Plan p, List<int[]> portals, RandomSource r, byte fam) {
        // thin vertical-slab ribs against the owned walls, aligned with the pillar lattice rows and columns
        for (int i : new int[]{2, 6, 10, 14}) {
            if (p.kindAt(0, i) == WALL && p.isOpen(1, i) && r.nextInt(100) < 40) place(p, portals, 1, i, VSLAB, fam, D_W);
            if (p.kindAt(i, 0) == WALL && p.isOpen(i, 1) && r.nextInt(100) < 40) place(p, portals, i, 1, VSLAB, fam, D_N);
        }
        // density: no 5x5 window of bare floor. Break it with a pillar ON the lattice.
        boolean[] tried = new boolean[N * N];
        for (int pass = 0; pass < 40; pass++) {
            int[] w = findEmptyWindow(p, tried);
            if (w == null) break;
            tried[w[1] * N + w[0]] = true;
            boolean done = false;
            for (int x = w[0]; x < w[0] + WINDOW && !done; x++) {
                for (int z = w[1]; z < w[1] + WINDOW && !done; z++) {
                    if ((x - 2) % 4 != 0 || (z - 2) % 4 != 0) continue;
                    if (!p.isOpen(x, z)) continue;
                    done = place(p, portals, x, z, PILLAR, fam, 0);
                }
            }
            // The lattice points of this window are all taken by door landings: fall back to the open cell nearest to the
            // window center (one pillar slightly off the grid is better than a bare plate).
            for (int ring = 0; ring <= 2 && !done; ring++) {
                for (int dx = -ring; dx <= ring && !done; dx++) {
                    for (int dz = -ring; dz <= ring && !done; dz++) {
                        if (Math.max(Math.abs(dx), Math.abs(dz)) != ring) continue;
                        int x = w[0] + 2 + dx, z = w[1] + 2 + dz;
                        if (p.isOpen(x, z)) done = place(p, portals, x, z, PILLAR, fam, 0);
                    }
                }
            }
        }
    }

    private static boolean place(Plan p, List<int[]> portals, int x, int z, byte k, byte fam, int d) {
        Plan snap = p.copy();
        p.set(x, z, k, fam, d);
        if (connected(p, portals)) return true;
        p.restore(snap);
        return false;
    }

    private static int[] findEmptyWindow(Plan p, boolean[] tried) {
        for (int z0 = 1; z0 <= N - WINDOW; z0++) {
            for (int x0 = 1; x0 <= N - WINDOW; x0++) {
                if (tried[z0 * N + x0]) continue;
                boolean empty = true;
                for (int x = x0; x < x0 + WINDOW && empty; x++) for (int z = z0; z < z0 + WINDOW; z++) if (p.kindAt(x, z) != OPEN) { empty = false; break; }
                if (empty) return new int[]{x0, z0};
            }
        }
        return null;
    }

    // =====================================================================================================
    // Connectivity
    // =====================================================================================================

    private static boolean walkable(byte k) {
        return k == OPEN || k == LINTEL || k == ARCH_L || k == ARCH_R;
    }

    private static boolean[] reach(Plan p, int sx, int sz) {
        boolean[] seen = new boolean[N * N];
        if (sx < 0 || sz < 0 || sx >= N || sz >= N || !walkable(p.kind[sz * N + sx])) return seen;
        int[] stack = new int[N * N];
        int sp = 0;
        stack[sp++] = sz * N + sx;
        seen[sz * N + sx] = true;
        while (sp > 0) {
            int i = stack[--sp];
            int x = i % N, z = i / N;
            if (x > 0 && !seen[i - 1] && walkable(p.kind[i - 1])) { seen[i - 1] = true; stack[sp++] = i - 1; }
            if (x < N - 1 && !seen[i + 1] && walkable(p.kind[i + 1])) { seen[i + 1] = true; stack[sp++] = i + 1; }
            if (z > 0 && !seen[i - N] && walkable(p.kind[i - N])) { seen[i - N] = true; stack[sp++] = i - N; }
            if (z < N - 1 && !seen[i + N] && walkable(p.kind[i + N])) { seen[i + N] = true; stack[sp++] = i + N; }
        }
        return seen;
    }

    /** True when all portals reach each other and no walkable cell is sealed off. */
    private static boolean connected(Plan p, List<int[]> portals) {
        int sx, sz;
        if (!portals.isEmpty()) {
            sx = portals.get(0)[0];
            sz = portals.get(0)[1];
        } else {
            sx = -1;
            sz = -1;
            for (int i = 0; i < N * N; i++) if (walkable(p.kind[i])) { sx = i % N; sz = i / N; break; }
            if (sx < 0) return true;
        }
        boolean[] seen = reach(p, sx, sz);
        for (int[] q : portals) if (!seen[q[1] * N + q[0]]) return false;
        for (int i = 0; i < N * N; i++) if (walkable(p.kind[i]) && !seen[i]) return false;
        return true;
    }

    private static void carve(Plan p, int ax, int az, int bx, int bz) {
        int x = ax, z = az;
        while (x != bx) {
            clearCell(p, x, z);
            clearCell(p, x, z + 1);
            x += Integer.compare(bx, x);
        }
        while (z != bz) {
            clearCell(p, x, z);
            clearCell(p, x + 1, z);
            z += Integer.compare(bz, z);
        }
        clearCell(p, bx, bz);
    }

    /** 3-wide tunnel from (ax, az) to the middle of the chunk: first along X, then along Z. */
    private static void tunnel(Plan p, int ax, int az) {
        int x = ax, z = az;
        while (x != 8) {
            for (int k = -1; k <= 1; k++) clearCell(p, x, z + k);
            x += Integer.compare(8, x);
        }
        while (z != 8) {
            for (int k = -1; k <= 1; k++) clearCell(p, x + k, z);
            z += Integer.compare(8, z);
        }
    }

    private static void clearCell(Plan p, int x, int z) {
        if (x < 1 || z < 1 || x >= N || z >= N) return;     // never touch the edge walls
        p.kind[z * N + x] = OPEN;
    }

    /** Last line of defense: make connectivity true no matter what the templates did. */
    private static void enforce(Plan p, List<int[]> portals, byte fam) {
        if (!portals.isEmpty()) {
            int[] root = portals.get(0);
            if (!walkable(p.kind[root[1] * N + root[0]])) p.kind[root[1] * N + root[0]] = OPEN;
            for (int k = 1; k < portals.size(); k++) {
                int[] q = portals.get(k);
                boolean[] seen = reach(p, root[0], root[1]);
                if (!seen[q[1] * N + q[0]]) {
                    if (!walkable(p.kind[q[1] * N + q[0]])) p.kind[q[1] * N + q[0]] = OPEN;
                    carve(p, q[0], q[1], root[0], root[1]);
                }
            }
        }
        // fill every sealed pocket
        int sx = -1, sz = -1;
        if (!portals.isEmpty()) {
            sx = portals.get(0)[0];
            sz = portals.get(0)[1];
        } else {
            // no doors at all: keep the largest area
            int best = 0;
            for (int i = 0; i < N * N; i++) {
                if (!walkable(p.kind[i])) continue;
                boolean[] seen = reach(p, i % N, i / N);
                int c = 0;
                for (boolean b : seen) if (b) c++;
                if (c > best) { best = c; sx = i % N; sz = i / N; }
            }
        }
        if (sx < 0) return;
        boolean[] seen = reach(p, sx, sz);
        for (int i = 0; i < N * N; i++) {
            if (walkable(p.kind[i]) && !seen[i]) {
                p.kind[i] = WALL;
                p.fam[i] = fam;
            }
        }
    }
}
