package com.thecomplex.lpmds;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import com.thecomplex.block.LpmdsBlock;

import java.util.Locale;

/**
 * Magnetic Marker: menandai mesin LPMDS dan bingkai target 2x3.
 *  1. Klik kanan LPMDS: tandai mesin.
 *  2. Klik kanan dua sel sudut berlawanan dari bingkai (sel kosong di depan sisi blok yang diklik, seperti memasang blok).
 *  3. Bingkai 2 lebar x 3 tinggi x 1 tebal otomatis tertaut ke mesin yang ditandai.
 * Sneak + klik: hapus semua penandaan.
 */
public class LpmdsMarkerItem extends Item {
    public LpmdsMarkerItem(Properties props) {
        super(props);
    }

    private static void msg(ServerPlayer p, String text) {
        p.displayClientMessage(Component.literal("[Marker] " + text), true);
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        if (level.isClientSide) return InteractionResult.SUCCESS;
        if (!(ctx.getPlayer() instanceof ServerPlayer p)) return InteractionResult.PASS;
        ItemStack stack = ctx.getItemInHand();
        CompoundTag t = stack.getOrCreateTag();

        if (p.isShiftKeyDown()) {
            clear(t);
            msg(p, "Marking cleared.");
            return InteractionResult.CONSUME;
        }

        BlockPos clicked = ctx.getClickedPos();
        if (level.getBlockState(clicked).getBlock() instanceof LpmdsBlock) {
            t.putLong("lpmds", clicked.asLong());
            t.putString("lpmdsDim", level.dimension().location().toString());
            msg(p, "LPMDS marked at " + clicked.toShortString() + ".");
            tryLink(p, t);
            return InteractionResult.CONSUME;
        }

        BlockPos cell = clicked.relative(ctx.getClickedFace());
        if (!t.contains("p1") || t.contains("p2")) {
            t.putLong("p1", cell.asLong());
            t.remove("p2");
            t.remove("frameMin");
            t.remove("frameAxis");
            msg(p, "Frame corner 1: " + cell.toShortString() + ". Click the opposite corner (2 wide x 3 tall).");
        } else {
            BlockPos p1 = BlockPos.of(t.getLong("p1"));
            LpmdsFrame f = LpmdsFrame.fromCorners(p1, cell);
            if (f == null) {
                msg(p, "Wrong shape: must be 2 wide x 3 tall x 1 thick. Click the correct opposite corner.");
            } else {
                t.putLong("p2", cell.asLong());
                t.putLong("frameMin", f.min().asLong());
                t.putInt("frameAxis", f.axis());
                msg(p, "2x3 frame marked.");
                tryLink(p, t);
            }
        }
        return InteractionResult.CONSUME;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide && player.isShiftKeyDown() && player instanceof ServerPlayer p) {
            clear(stack.getOrCreateTag());
            msg(p, "Marking cleared.");
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    private static void clear(CompoundTag t) {
        for (String k : new String[]{"lpmds", "lpmdsDim", "p1", "p2", "frameMin", "frameAxis"}) t.remove(k);
    }

    private static void tryLink(ServerPlayer p, CompoundTag t) {
        if (!t.contains("lpmds") || !t.contains("frameMin")) return;
        ServerLevel level = p.serverLevel();
        if (!level.dimension().location().toString().equals(t.getString("lpmdsDim"))) {
            msg(p, "The marked LPMDS is in another dimension.");
            return;
        }
        BlockPos lp = BlockPos.of(t.getLong("lpmds"));
        if (level.getBlockEntity(lp) instanceof LpmdsBlockEntity be) {
            LpmdsFrame f = new LpmdsFrame(BlockPos.of(t.getLong("frameMin")), t.getInt("frameAxis"));
            be.setMarkedFrame(f);
            double dist = f.center().distanceTo(net.minecraft.world.phys.Vec3.atCenterOf(lp));
            msg(p, String.format(Locale.ROOT, "Frame linked to the LPMDS (distance %.0f blocks, max %d).", dist, LpmdsConfig.RANGE.get()));
        } else {
            msg(p, "No LPMDS found at " + lp.toShortString() + ".");
        }
    }
}
