package com.thecomplex.lpmds;

import com.thecomplex.ModBlockEntities;
import com.thecomplex.ModBlocks;
import com.thecomplex.TheComplex;
import com.thecomplex.activity.ActivityData;
import com.thecomplex.block.LpmdsBlock;
import com.thecomplex.block.LpmdsChuteBlock;
import com.thecomplex.net.Net;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.energy.IEnergyStorage;

import java.util.Locale;

/**
 * Mesin LPMDS. Daya masuk lewat Forge Energy (IEnergyStorage), antarmuka yang didukung Create: Power Grid
 * (konverter FE-nya) dan banyak mod lain. Urutan:
 *   IDLE -> klik kanan -> RUNNING (tes) -> FAILED (pendinginan) -> IDLE -> ... -> tes akhir berhasil -> OPEN.
 * Tes pertama sebanyak {@link LpmdsConfig#FAILED_TESTS} pasti gagal (bergaya tes Async); setelah itu tes akhir
 * berhasil kalau daya cukup, area target bebas, dan (untuk bingkai yang ditandai) arah chute tepat.
 */
public class LpmdsBlockEntity extends BlockEntity {
    public enum Phase { IDLE, RUNNING, FAILED, OPEN }

    private static final int CHARGE_PHASE = 40;     // tick awal tes: pengisian medan
    private static final int RUN_FAILED = 120;
    private static final int RUN_FINAL = 200;
    private static final int CHECK_TICK = 60;       // saat tes akhir memeriksa arah chute

    private static final String[][] SCRIPT = {
            {"FIELD COLLAPSE", "Low-frequency resonance disrupted the field. The machine is being calibrated, retry after cooldown."},
            {"PHASE SURGE", "Back-current detected in the coil. Calibration continues, retry after cooldown."},
            {"LOCK FAILED", "A rift opened briefly, then closed. The field is nearly stable, retry after cooldown."},
    };

    private int energy;
    private Phase phase = Phase.IDLE;
    private int timer;
    private int runTotal;
    private int failTick;
    private int testsDone;
    private boolean finalRun;
    private int flicker;
    private LpmdsFrame flickerFrame;
    private String lastFail = "";
    private LpmdsFrame marked;     // bingkai yang ditandai dengan Magnetic Marker
    private LpmdsFrame active;     // bingkai yang sedang terbuka

    private final IEnergyStorage storage = new IEnergyStorage() {
        @Override
        public int receiveEnergy(int max, boolean simulate) {
            int n = Math.min(Math.min(LpmdsConfig.CAPACITY.get() - energy, max), LpmdsConfig.MAX_RECEIVE.get());
            if (n <= 0) return 0;
            if (!simulate) {
                energy += n;
                setChanged();
            }
            return n;
        }

        @Override
        public int extractEnergy(int max, boolean simulate) {
            return 0;
        }

        @Override
        public int getEnergyStored() {
            return energy;
        }

        @Override
        public int getMaxEnergyStored() {
            return LpmdsConfig.CAPACITY.get();
        }

        @Override
        public boolean canExtract() {
            return false;
        }

        @Override
        public boolean canReceive() {
            return true;
        }
    };
    private LazyOptional<IEnergyStorage> energyCap = LazyOptional.of(() -> storage);

    public LpmdsBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.LPMDS.get(), pos, state);
    }

    // ------------------------------------------------------------------ capability

    @Override
    public <T> LazyOptional<T> getCapability(Capability<T> cap, Direction side) {
        if (cap == ForgeCapabilities.ENERGY) return energyCap.cast();
        return super.getCapability(cap, side);
    }

    @Override
    public void invalidateCaps() {
        super.invalidateCaps();
        energyCap.invalidate();
    }

    @Override
    public void reviveCaps() {
        super.reviveCaps();
        energyCap = LazyOptional.of(() -> storage);
    }

    // ------------------------------------------------------------------ penandaan

    public void setMarkedFrame(LpmdsFrame f) {
        this.marked = f;
        setChanged();
    }

    public LpmdsFrame getMarkedFrame() {
        return marked;
    }

    // ------------------------------------------------------------------ interaksi pemain

    public void interact(ServerPlayer p) {
        ServerLevel level = p.serverLevel();
        BlockState state = getBlockState();
        if (level.dimension() == TheComplex.COMPLEX) {
            p.displayClientMessage(Component.literal("[LPMDS] no signal"), true);
            return;
        }
        switch (phase) {
            case OPEN -> {
                if (p.isShiftKeyDown()) {
                    closeFrame(level, true);
                    say(level, worldPosition, "Threshold closed. The machine is back on standby.");
                } else {
                    tell(p, "The Threshold is open and stable. Sneak + click (empty hand) to close it.");
                }
            }
            case IDLE -> startTest(p, level, worldPosition, state);
            case FAILED -> tell(p, "Cooling down " + (timer / 20 + 1) + " s. Last test: " + lastFail);
            default -> tell(p, "A test is running...");
        }
    }

    private void startTest(ServerPlayer p, ServerLevel level, BlockPos pos, BlockState state) {
        boolean fin = testsDone >= LpmdsConfig.FAILED_TESTS.get();
        String problem = diagnose(level, pos, state, fin);
        if (problem != null) {
            tell(p, problem);
            return;
        }
        finalRun = fin;
        runTotal = fin ? RUN_FINAL : RUN_FAILED;
        timer = runTotal;
        failTick = 50 + level.random.nextInt(runTotal - 70);
        phase = Phase.RUNNING;
        level.setBlock(pos, state.setValue(LpmdsBlock.ACTIVE, true), 3);
        say(level, pos, (fin ? "FINAL TEST" : String.format(Locale.ROOT, "TEST %02d", testsDone + 1)) + " started. Charging the field...");
        level.playSound(null, pos, SoundEvents.WARDEN_SONIC_CHARGE, SoundSource.BLOCKS, 3.0f, 0.7f);
        Net.sendQuake(level, pos, 40, 0.4f);
        setChanged();
    }

    /** Pemeriksaan sebelum tes dimulai. Kalau ada masalah, tes tidak dijalankan dan tidak dihitung. */
    private String diagnose(ServerLevel level, BlockPos pos, BlockState state, boolean fin) {
        LpmdsFrame f = resolveFrame(level, pos, state);
        double dist = f.center().distanceTo(Vec3.atCenterOf(pos));
        if (dist > LpmdsConfig.RANGE.get()) {
            return String.format(Locale.ROOT, "Target too far: %.0f blocks (max %d).", dist, LpmdsConfig.RANGE.get());
        }
        for (BlockPos c : f.cells()) {
            if (!level.hasChunkAt(c)) return "The target area isn't loaded.";
            BlockState s = level.getBlockState(c);
            if (!(s.isAir() || s.canBeReplaced() || s.is(ModBlocks.THRESHOLD.get()))) {
                return "The target area is blocked by " + s.getBlock().getName().getString() + " at " + c.toShortString() + ".";
            }
        }
        int need = cost(fin);
        if (LpmdsConfig.REQUIRE_POWER.get() && energy < need * 9 / 10) {
            return "Not enough power: " + energy + " / " + need + " FE. Connect a power source (Forge Energy, e.g. a Create: Power Grid FE converter).";
        }
        return null;
    }

    private static int cost(boolean fin) {
        return fin ? LpmdsConfig.FINAL_COST.get() : LpmdsConfig.TEST_COST.get();
    }

    // ------------------------------------------------------------------ chute dan bingkai

    private record Chute(BlockPos pos, int step) {}

    private Chute findChute(Level level, BlockPos pos) {
        for (Direction d : Direction.values()) {
            BlockPos n = pos.relative(d);
            BlockState s = level.getBlockState(n);
            if (s.getBlock() instanceof LpmdsChuteBlock) return new Chute(n, s.getValue(BlockStateProperties.ROTATION_16));
        }
        return null;
    }

    /** Bingkai yang dipakai: yang ditandai, atau (kalau belum ada) 3 blok di depan arah chute / depan mesin. */
    private LpmdsFrame resolveFrame(Level level, BlockPos pos, BlockState state) {
        if (marked != null) return marked;
        Chute c = findChute(level, pos);
        float yaw = c != null ? c.step() * 22.5f : state.getValue(LpmdsBlock.FACING).toYRot();
        double rad = Math.toRadians(yaw);
        double dx = -Math.sin(rad), dz = Math.cos(rad);
        int bx = (int) Math.floor(pos.getX() + 0.5 + dx * 3.0);
        int bz = (int) Math.floor(pos.getZ() + 0.5 + dz * 3.0);
        return new LpmdsFrame(new BlockPos(bx, pos.getY(), bz), Math.abs(dz) >= Math.abs(dx) ? 0 : 1);
    }

    private static double bearingYaw(BlockPos from, Vec3 to) {
        double dx = to.x - (from.getX() + 0.5);
        double dz = to.z - (from.getZ() + 0.5);
        double yaw = Math.toDegrees(Math.atan2(-dx, dz));
        return yaw < 0 ? yaw + 360.0 : yaw;
    }

    private String alignmentProblem(ServerLevel level, BlockPos pos, BlockState state) {
        Chute c = findChute(level, pos);
        if (marked == null) return null;          // tanpa bingkai ditandai, medan mengikuti chute
        if (c == null) return "No chute module installed. Attach an LPMDS Emitter Chute to the side of the machine.";
        int best = ((int) Math.round(bearingYaw(pos, marked.center()) / 22.5)) & 15;
        int diff = Math.abs(c.step() - best);
        diff = Math.min(diff, 16 - diff);
        if (diff == 0) return null;
        return String.format(Locale.ROOT, "Chute is off by %d steps: now %s (%.1f°), needed %s (%.1f°). Rotate the chute with right-click.",
                diff, LpmdsChuteBlock.compass(c.step()), c.step() * 22.5, LpmdsChuteBlock.compass(best), best * 22.5);
    }

    // ------------------------------------------------------------------ tick

    public static void serverTick(Level level, BlockPos pos, BlockState state, LpmdsBlockEntity be) {
        if (level instanceof ServerLevel sl) be.tick(sl, pos, state);
    }

    private void tick(ServerLevel level, BlockPos pos, BlockState state) {
        if (flicker > 0 && --flicker == 0) clearFlicker(level);
        switch (phase) {
            case RUNNING -> runTick(level, pos, state);
            case FAILED -> {
                if (--timer <= 0) {
                    phase = Phase.IDLE;
                    setChanged();
                    say(level, pos, "Cooldown complete. The LPMDS is ready for the next test.");
                }
            }
            default -> {
                if (phase != Phase.OPEN && state.getValue(LpmdsBlock.ACTIVE)) {
                    level.setBlock(pos, state.setValue(LpmdsBlock.ACTIVE, false), 3);
                }
            }
        }
    }

    private void runTick(ServerLevel level, BlockPos pos, BlockState state) {
        int elapsed = runTotal - timer;
        int perTick = Math.max(1, cost(finalRun) / runTotal);
        if (LpmdsConfig.REQUIRE_POWER.get()) {
            if (energy < perTick) {
                fail(level, pos, state, "POWER DROP at " + pct(elapsed) + "%",
                        "Not enough power to hold the field. Check the power source, then retry.", 1, false);
                return;
            }
            energy -= perTick;
        }
        effects(level, pos, state, elapsed);
        if (finalRun && elapsed == CHECK_TICK) {
            String problem = alignmentProblem(level, pos, state);
            if (problem != null) {
                fail(level, pos, state, "FIELD MISALIGNED at " + pct(elapsed) + "%", problem, 0, false);
                return;
            }
        }
        if (!finalRun && elapsed == failTick) {
            scriptedFail(level, pos, state, elapsed);
            return;
        }
        if (--timer <= 0) {
            if (finalRun) succeed(level, pos, state);
            else scriptedFail(level, pos, state, elapsed);
        }
    }

    private static int pct(int elapsed) {
        return Math.min(99, elapsed * 100 / 120);
    }

    private void scriptedFail(ServerLevel level, BlockPos pos, BlockState state, int elapsed) {
        int k = testsDone % SCRIPT.length;
        String title = String.format(Locale.ROOT, "TEST %02d: %s at %d%%", testsDone + 1, SCRIPT[k][0], pct(elapsed));
        fail(level, pos, state, title, SCRIPT[k][1], k, true);
    }

    // ------------------------------------------------------------------ efek

    private void effects(ServerLevel level, BlockPos pos, BlockState state, int elapsed) {
        Vec3 c = Vec3.atCenterOf(pos).add(0, 0.6, 0);
        double progress = elapsed / (double) runTotal;
        if (elapsed < CHARGE_PHASE) {
            if (elapsed % 4 == 0) {
                double r = 1.7 - 1.5 * elapsed / CHARGE_PHASE;
                for (int i = 0; i < 8; i++) {
                    double a = i * Math.PI / 4 + elapsed * 0.2;
                    level.sendParticles(ParticleTypes.END_ROD, c.x + Math.cos(a) * r, c.y, c.z + Math.sin(a) * r, 1, 0, 0, 0, 0.0);
                }
            }
        } else if (elapsed % 4 == 0) {
            beam(level, pos, state);
        }
        if (elapsed % 20 == 0) {
            level.playSound(null, pos, SoundEvents.BEACON_AMBIENT, SoundSource.BLOCKS, 2.5f, 0.5f + (float) progress * 1.3f);
            float amp = (finalRun ? 0.5f : 0.3f) + (float) progress * (finalRun ? 1.1f : 0.7f);
            Net.sendQuake(level, pos, 30, amp);
        }
        if (elapsed % 10 == 0) {
            int n = (int) Math.round(progress * 10);
            String label = finalRun ? "FINAL TEST" : String.format(Locale.ROOT, "TEST %02d", testsDone + 1);
            bar(level, pos, label + "  [" + "#".repeat(n) + "-".repeat(10 - n) + "] " + (int) (progress * 100) + "%");
        }
    }

    /** Sinar medan: dari chute searah arahnya (kalau ada), atau langsung ke target. Meleset terlihat jelas. */
    private void beam(ServerLevel level, BlockPos pos, BlockState state) {
        LpmdsFrame f = resolveFrame(level, pos, state);
        Chute chute = findChute(level, pos);
        Vec3 origin = Vec3.atCenterOf(chute != null ? chute.pos() : pos).add(0, 0.2, 0);
        Vec3 target = f.center();
        Vec3 dir;
        if (chute != null) {
            double rad = Math.toRadians(chute.step() * 22.5);
            dir = new Vec3(-Math.sin(rad), 0, Math.cos(rad));
        } else {
            dir = target.subtract(origin).normalize();
        }
        double len = Math.min(LpmdsConfig.RANGE.get(), Math.max(2.0, target.distanceTo(origin)));
        for (double s = 0.6; s < len; s += 0.8) {
            level.sendParticles(ParticleTypes.ELECTRIC_SPARK, origin.x + dir.x * s, origin.y + dir.y * s, origin.z + dir.z * s, 1, 0.05, 0.05, 0.05, 0.0);
        }
        level.sendParticles(ParticleTypes.END_ROD, target.x, target.y, target.z, 3, 0.4, 0.8, 0.4, 0.01);
    }

    // ------------------------------------------------------------------ gagal

    private void fail(ServerLevel level, BlockPos pos, BlockState state, String title, String hint, int style, boolean count) {
        if (count) testsDone++;
        phase = Phase.FAILED;
        timer = LpmdsConfig.COOLDOWN.get();
        lastFail = title;
        level.setBlock(pos, state.setValue(LpmdsBlock.ACTIVE, false), 3);
        Vec3 c = Vec3.atCenterOf(pos).add(0, 0.6, 0);
        switch (style) {
            case 0 -> {
                level.sendParticles(ParticleTypes.LARGE_SMOKE, c.x, c.y, c.z, 30, 0.5, 0.4, 0.5, 0.03);
                level.sendParticles(ParticleTypes.ELECTRIC_SPARK, c.x, c.y, c.z, 40, 0.6, 0.5, 0.6, 0.4);
                level.playSound(null, pos, SoundEvents.GENERIC_EXPLODE, SoundSource.BLOCKS, 1.4f, 0.6f);
            }
            case 1 -> {
                level.sendParticles(ParticleTypes.ELECTRIC_SPARK, c.x, c.y, c.z, 90, 1.2, 0.8, 1.2, 0.6);
                level.sendParticles(ParticleTypes.FLASH, c.x, c.y, c.z, 1, 0, 0, 0, 0);
                level.playSound(null, pos, SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.BLOCKS, 2.0f, 0.7f);
                level.playSound(null, pos, SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.BLOCKS, 1.5f, 0.9f);
            }
            default -> {
                LpmdsFrame f = resolveFrame(level, pos, state);
                BlockState thr = ModBlocks.THRESHOLD.get().defaultBlockState();
                for (BlockPos cell : f.cells()) {
                    BlockState s = level.getBlockState(cell);
                    if (s.isAir() || s.canBeReplaced()) level.setBlock(cell, thr, 3);
                }
                flickerFrame = f;
                flicker = 14;
                Vec3 fc = f.center();
                level.sendParticles(ParticleTypes.SONIC_BOOM, fc.x, fc.y, fc.z, 1, 0, 0, 0, 0);
                level.sendParticles(ParticleTypes.REVERSE_PORTAL, fc.x, fc.y, fc.z, 40, 0.5, 1.0, 0.5, 0.2);
                level.playSound(null, pos, SoundEvents.BEACON_DEACTIVATE, SoundSource.BLOCKS, 2.5f, 0.5f);
            }
        }
        Net.sendQuake(level, pos, 60 + 10 * style, 0.9f + 0.2f * style);
        say(level, pos, title);
        say(level, pos, hint);
        if (count) {
            say(level, pos, "Tests completed: " + testsDone + " / " + LpmdsConfig.FAILED_TESTS.get() + " before the final test.");
        }
        setChanged();
    }

    private void clearFlicker(ServerLevel level) {
        LpmdsFrame f = flickerFrame;
        flickerFrame = null;
        if (f == null || phase == Phase.OPEN) return;
        for (BlockPos c : f.cells()) {
            if (level.getBlockState(c).is(ModBlocks.THRESHOLD.get())) level.setBlock(c, Blocks.AIR.defaultBlockState(), 3);
        }
    }

    // ------------------------------------------------------------------ berhasil

    private void succeed(ServerLevel level, BlockPos pos, BlockState state) {
        LpmdsFrame f = resolveFrame(level, pos, state);
        for (BlockPos c : f.cells()) {
            BlockState s = level.getBlockState(c);
            if (!(s.isAir() || s.canBeReplaced() || s.is(ModBlocks.THRESHOLD.get()))) {
                fail(level, pos, state, "LOCK-ON FAILED", "The target area was blocked when the field locked at " + c.toShortString() + ".", 0, false);
                return;
            }
        }
        BlockState thr = ModBlocks.THRESHOLD.get().defaultBlockState();
        for (BlockPos c : f.cells()) level.setBlock(c, thr, 3);
        active = f;
        phase = Phase.OPEN;
        timer = 0;
        testsDone = Math.max(testsDone, LpmdsConfig.FAILED_TESTS.get());
        level.setBlock(pos, state.setValue(LpmdsBlock.ACTIVE, true), 3);
        ActivityData.get(level.getServer().overworld()).setActivated(true);     // Null Zone alami boleh muncul mulai sekarang

        Vec3 c = f.center();
        level.sendParticles(ParticleTypes.FLASH, c.x, c.y, c.z, 1, 0, 0, 0, 0);
        level.sendParticles(ParticleTypes.END_ROD, c.x, c.y, c.z, 90, 0.8, 1.4, 0.8, 0.18);
        level.sendParticles(ParticleTypes.REVERSE_PORTAL, c.x, c.y, c.z, 70, 0.6, 1.2, 0.6, 0.25);
        level.playSound(null, BlockPos.containing(c), SoundEvents.END_PORTAL_SPAWN, SoundSource.BLOCKS, 3.0f, 1.0f);
        level.playSound(null, pos, SoundEvents.BEACON_POWER_SELECT, SoundSource.BLOCKS, 2.0f, 0.8f);
        Net.sendQuake(level, pos, 140, 1.6f);
        for (ServerPlayer p : level.players()) {
            if (p.distanceToSqr(c.x, c.y, c.z) > 32 * 32) continue;
            p.connection.send(new ClientboundSetTitlesAnimationPacket(10, 70, 25));
            p.connection.send(new ClientboundSetTitleTextPacket(Component.literal("THRESHOLD STABLE")));
            p.connection.send(new ClientboundSetSubtitleTextPacket(Component.literal("Two-way gateway to The Complex is open")));
        }
        say(level, pos, "FINAL TEST: SUCCESS. Field locked. Threshold stable and open.");
        setChanged();
    }

    // ------------------------------------------------------------------ menutup

    public void closeFrame(ServerLevel level, boolean touchSelf) {
        LpmdsFrame f = active;
        if (f != null) {
            for (BlockPos c : f.cells()) {
                if (level.getBlockState(c).is(ModBlocks.THRESHOLD.get())) level.setBlock(c, Blocks.AIR.defaultBlockState(), 3);
            }
        }
        active = null;
        phase = Phase.IDLE;
        timer = 0;
        level.playSound(null, worldPosition, SoundEvents.BEACON_DEACTIVATE, SoundSource.BLOCKS, 2.0f, 0.7f);
        Net.sendQuake(level, worldPosition, 40, 0.5f);
        if (touchSelf) {
            BlockState st = getBlockState();
            if (st.hasProperty(LpmdsBlock.ACTIVE)) level.setBlock(worldPosition, st.setValue(LpmdsBlock.ACTIVE, false), 3);
        }
        setChanged();
    }

    /** Dipanggil saat blok mesin dihancurkan. */
    public void onBroken() {
        if (level instanceof ServerLevel sl && phase == Phase.OPEN) closeFrame(sl, false);
    }

    // ------------------------------------------------------------------ bantuan pesan

    private void tell(ServerPlayer p, String msg) {
        p.displayClientMessage(Component.literal("[LPMDS] " + msg), false);
    }

    private void say(ServerLevel level, BlockPos pos, String msg) {
        for (ServerPlayer p : level.players()) {
            if (p.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) <= 24 * 24) {
                p.sendSystemMessage(Component.literal("[LPMDS] " + msg));
            }
        }
    }

    private void bar(ServerLevel level, BlockPos pos, String msg) {
        for (ServerPlayer p : level.players()) {
            if (p.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) <= 24 * 24) {
                p.displayClientMessage(Component.literal(msg), true);
            }
        }
    }

    // ------------------------------------------------------------------ alat uji (Developer UI)

    public static LpmdsBlockEntity findNear(ServerLevel level, BlockPos origin, int r) {
        LpmdsBlockEntity best = null;
        double bestD = Double.MAX_VALUE;
        for (BlockPos p : BlockPos.betweenClosed(origin.offset(-r, -r / 2, -r), origin.offset(r, r / 2, r))) {
            if (level.getBlockEntity(p) instanceof LpmdsBlockEntity be) {
                double d = p.distSqr(origin);
                if (d < bestD) {
                    bestD = d;
                    best = be;
                }
            }
        }
        return best;
    }

    public void devCharge() {
        energy = LpmdsConfig.CAPACITY.get();
        setChanged();
    }

    public void devSkipTests() {
        testsDone = LpmdsConfig.FAILED_TESTS.get();
        setChanged();
    }

    public void devReset(ServerLevel level) {
        if (phase == Phase.OPEN) closeFrame(level, true);
        phase = Phase.IDLE;
        timer = 0;
        testsDone = 0;
        energy = 0;
        marked = null;
        setChanged();
    }

    public void devForceOpen(ServerLevel level) {
        if (phase == Phase.OPEN) return;
        devSkipTests();
        succeed(level, worldPosition, getBlockState());
    }

    public String statusLine(Level lvl) {
        Chute c = findChute(lvl, worldPosition);
        return "fase=" + phase.name().toLowerCase(Locale.ROOT) + ", test=" + testsDone + "/" + LpmdsConfig.FAILED_TESTS.get()
                + ", power=" + energy + "/" + LpmdsConfig.CAPACITY.get() + " FE"
                + ", frame=" + (marked != null ? "marked" : "automatic")
                + ", chute=" + (c == null ? "none yet" : LpmdsChuteBlock.compass(c.step()));
    }

    public LpmdsFrame getTargetPreview(Level lvl) {
        return resolveFrame(lvl, worldPosition, getBlockState());
    }

    // ------------------------------------------------------------------ simpan / muat

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putInt("energy", energy);
        tag.putInt("phase", phase.ordinal());
        tag.putInt("tests", testsDone);
        tag.putString("lastFail", lastFail);
        if (marked != null) tag.put("marked", marked.toTag());
        if (active != null) tag.put("active", active.toTag());
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        energy = Math.max(0, tag.getInt("energy"));
        phase = Phase.values()[Mth.clamp(tag.getInt("phase"), 0, Phase.values().length - 1)];
        if (phase == Phase.RUNNING || phase == Phase.FAILED) phase = Phase.IDLE;     // tes terputus saat dunia ditutup
        testsDone = tag.getInt("tests");
        lastFail = tag.getString("lastFail");
        marked = tag.contains("marked") ? LpmdsFrame.fromTag(tag.getCompound("marked")) : null;
        active = tag.contains("active") ? LpmdsFrame.fromTag(tag.getCompound("active")) : null;
        if (phase == Phase.OPEN && active == null) phase = Phase.IDLE;
    }
}
