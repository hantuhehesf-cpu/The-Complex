package com.thecomplex.lpmds;

import net.minecraftforge.common.ForgeConfigSpec;

/** Pengaturan LPMDS. File: config/thecomplex-common.toml (bisa diubah tanpa build ulang). */
public final class LpmdsConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue REQUIRE_POWER;
    public static final ForgeConfigSpec.IntValue CAPACITY;
    public static final ForgeConfigSpec.IntValue MAX_RECEIVE;
    public static final ForgeConfigSpec.IntValue TEST_COST;
    public static final ForgeConfigSpec.IntValue FINAL_COST;
    public static final ForgeConfigSpec.IntValue FAILED_TESTS;
    public static final ForgeConfigSpec.IntValue COOLDOWN;
    public static final ForgeConfigSpec.IntValue RANGE;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.comment("LPMDS (Low-Proximity Magnetic Distortion System)").push("lpmds");
        REQUIRE_POWER = b.comment("Requires Forge Energy (FE) from Create: Power Grid or another mod. false = the machine runs without power (for testing).")
                .define("requirePower", true);
        CAPACITY = b.comment("Machine power storage capacity (FE).")
                .defineInRange("capacity", 200000, 1000, 100000000);
        MAX_RECEIVE = b.comment("Maximum power the machine accepts per tick (FE).")
                .defineInRange("maxReceivePerTick", 5000, 1, 1000000);
        TEST_COST = b.comment("Power used by one failed test (FE).")
                .defineInRange("failedTestCost", 30000, 0, 100000000);
        FINAL_COST = b.comment("Power used by the successful final test (FE).")
                .defineInRange("finalTestCost", 90000, 0, 100000000);
        FAILED_TESTS = b.comment("Number of tests that are guaranteed to fail before the next one may succeed.")
                .defineInRange("scriptedFailures", 3, 0, 12);
        COOLDOWN = b.comment("Cooldown after a failed test (ticks, 20 ticks = 1 second).")
                .defineInRange("cooldownTicks", 160, 20, 12000);
        RANGE = b.comment("Maximum distance from the machine to the target frame (blocks).")
                .defineInRange("range", 24, 4, 64);
        b.pop();
        SPEC = b.build();
    }

    private LpmdsConfig() {}
}
