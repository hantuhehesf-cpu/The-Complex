package com.thecomplex.portal;

import com.thecomplex.ModBlocks;
import com.thecomplex.TheComplex;
import com.thecomplex.world.ComplexLayout;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Daftar blok Threshold per dunia, supaya sistem portal bisa menemukan bingkai di dekat pemain tanpa memindai dunia. */
public class PortalRegistry extends SavedData {
    private final Set<Long> blocks = new HashSet<>();

    public static PortalRegistry get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(PortalRegistry::load, PortalRegistry::new, "thecomplex_portals");
    }

    public static PortalRegistry load(CompoundTag tag) {
        PortalRegistry r = new PortalRegistry();
        for (long l : tag.getLongArray("t")) r.blocks.add(l);
        return r;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        long[] arr = new long[blocks.size()];
        int i = 0;
        for (long l : blocks) arr[i++] = l;
        tag.putLongArray("t", arr);
        return tag;
    }

    public void add(BlockPos pos) {
        if (blocks.add(pos.asLong())) setDirty();
    }

    public void remove(BlockPos pos) {
        if (blocks.remove(pos.asLong())) setDirty();
    }

    /** Blok Threshold dalam radius dari titik, yang terdekat dulu. Termasuk Threshold Main Chamber di dimensi The Complex. */
    public static List<BlockPos> near(ServerLevel level, BlockPos center, double radius) {
        List<BlockPos> out = new ArrayList<>();
        double r2 = radius * radius;
        for (long l : get(level).blocks) {
            BlockPos p = BlockPos.of(l);
            if (p.distSqr(center) <= r2 && level.getBlockState(p).is(ModBlocks.THRESHOLD.get())) out.add(p);
        }
        if (level.dimension() == TheComplex.COMPLEX) {
            BlockPos t = ComplexLayout.thresholdPos();
            if (t != null && t.distSqr(center) <= r2 && !out.contains(t) && level.getBlockState(t).is(ModBlocks.THRESHOLD.get())) out.add(t);
        }
        out.sort(Comparator.comparingDouble(p -> p.distSqr(center)));
        return out;
    }
}
