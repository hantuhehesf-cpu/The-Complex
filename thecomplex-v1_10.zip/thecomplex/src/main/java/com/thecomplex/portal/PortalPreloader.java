package com.thecomplex.portal;

import com.thecomplex.ComplexTeleporter;
import com.thecomplex.TheComplex;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.TicketType;
import net.minecraft.world.level.ChunkPos;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Memuat chunk sisi seberang portal SEBELUM pemain menembusnya, satu chunk per tick supaya server tidak tersendat,
 * dan menahannya tetap dimuat selama pemain masih di dekat portal. Juga menyiapkan tujuan Backrooms untuk Null Zone liar.
 */
public final class PortalPreloader {
    private record Pending(ServerLevel level, int x, int z) {}

    private static final Map<UUID, ArrayDeque<Pending>> QUEUES = new HashMap<>();
    private static final Map<UUID, BlockPos> BACK_PLAN = new HashMap<>();
    private static final Map<UUID, Integer> BACK_TRIES = new HashMap<>();

    private PortalPreloader() {}

    public static void request(ServerPlayer p, ServerLevel level, int cx, int cz, int radius) {
        request(p, level, cx, cz, radius, 2);
    }

    /**
     * Minta chunk (cx, cz) dan sekelilingnya (radius chunk) dimuat di level (satu per tick), dan tahan agar tetap dimuat sebentar.
     * ticketRadius lebih besar (mode penuh) memuat chunk jauh secara bertahap oleh server sendiri, dan chunk dalam (ticketRadius - 2)
     * ikut di-tick (mob bergerak, tanaman tumbuh, dst).
     */
    public static void request(ServerPlayer p, ServerLevel level, int cx, int cz, int radius, int ticketRadius) {
        ArrayDeque<Pending> q = QUEUES.computeIfAbsent(p.getUUID(), k -> new ArrayDeque<>());
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                if (level.getChunkSource().getChunkNow(cx + dx, cz + dz) != null) continue;
                if (q.size() >= 48) return;
                boolean dup = false;
                for (Pending n : q) if (n.level == level && n.x == cx + dx && n.z == cz + dz) { dup = true; break; }
                if (!dup) q.add(new Pending(level, cx + dx, cz + dz));
            }
        }
        keepLoaded(level, cx, cz, ticketRadius);
    }

    /** Tiket wilayah: chunk tetap dimuat sekitar 15 detik sesudah permintaan terakhir. */
    private static void keepLoaded(ServerLevel level, int cx, int cz) {
        keepLoaded(level, cx, cz, 2);
    }

    private static void keepLoaded(ServerLevel level, int cx, int cz, int radius) {
        level.getChunkSource().addRegionTicket(TicketType.PORTAL, new ChunkPos(cx, cz), radius, new BlockPos(cx * 16, 0, cz * 16));
    }

    /** Dipanggil tiap tick untuk pemain: muat paling banyak satu chunk dari antrean. */
    public static void tick(ServerPlayer p) {
        ArrayDeque<Pending> q = QUEUES.get(p.getUUID());
        if (q == null || q.isEmpty()) return;
        Pending n = q.poll();
        n.level.getChunk(n.x, n.z);
    }

    // ---------------------------------------------------------------- tujuan Backrooms untuk Null Zone liar

    /** Pilih satu tujuan Backrooms lebih awal (satu chunk per panggilan). */
    public static void planBackrooms(ServerPlayer p) {
        UUID id = p.getUUID();
        ServerLevel lvl = p.server.getLevel(TheComplex.COMPLEX);
        if (lvl == null) return;
        BlockPos have = BACK_PLAN.get(id);
        if (have != null) {
            keepLoaded(lvl, have.getX() >> 4, have.getZ() >> 4);
            return;
        }
        int tries = BACK_TRIES.merge(id, 1, Integer::sum);
        if (tries > 20) return;
        BlockPos s = ComplexTeleporter.findBackroomsSpotInChunk(lvl, p.getRandom());
        if (s != null) {
            BACK_PLAN.put(id, s);
            keepLoaded(lvl, s.getX() >> 4, s.getZ() >> 4);
        }
    }

    /** Ambil tujuan yang sudah disiapkan; kalau belum ada, cari sekarang. */
    public static BlockPos takeBackroomsSpot(ServerPlayer p, ServerLevel lvl) {
        BlockPos s = BACK_PLAN.remove(p.getUUID());
        BACK_TRIES.remove(p.getUUID());
        if (s == null) s = ComplexTeleporter.findBackroomsSpot(lvl, p.getRandom(), 16);
        return s;
    }

    public static void forget(UUID id) {
        QUEUES.remove(id);
        BACK_PLAN.remove(id);
        BACK_TRIES.remove(id);
    }
}
