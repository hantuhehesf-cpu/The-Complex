package com.thecomplex.portal;

import com.thecomplex.ModBlocks;
import com.thecomplex.TheComplex;
import com.thecomplex.block.NullZoneBlockEntity;
import com.thecomplex.net.Net;
import com.thecomplex.net.PortalFarPacket;
import com.thecomplex.net.PortalEntitiesPacket;
import com.thecomplex.net.PortalViewPacket;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Cuplikan sisi seberang sebuah Threshold untuk efek see-through. Tidak ada rendering dunia kedua:
 * server mengirim blok-blok yang terlihat (kotak di depan bingkai tujuan), klien menggambarnya ke tekstur kecil
 * dan menempelkannya pada bukaan Threshold.
 *
 * Mode biasa: kotak kecil (sekitar 2 chunk). Mode penuh ({@link PortalSettings#isFull()}): kotak lebih besar dan, di dunia terbuka,
 * medan jauh sebagai kisi tile 4x4 blok sampai 8-12 chunk, diperbarui hampir real-time.
 */
public final class PortalView {
    private static final int FAR_TILE = 4;
    private static final long FAR_SALT = 0x5F5F5F5F5F5F5F5FL;

    /**
     * Size of the snapshot box (blocks). half = lateral reach, depth = how far behind the frame, below/above = the vertical range of the
     * full 3D scan, maxCells = cap on visible blocks. nearHalf/nearDepth > 0 (open worlds in full mode): only that inner part is scanned
     * in full 3D, the rest of the box is scanned column by column along the terrain surface (see build()).
     */
    private record Cfg(int half, int depth, int below, int above, int maxCells, int nearHalf, int nearDepth) {}

    private static final Map<UUID, Map<Long, Long>> NEXT = new HashMap<>();
    /** Hash dan waktu kirim terakhir per bingkai: cuplikan yang tidak berubah tidak dikirim ulang (kecuali tiap 30 detik, supaya klien tidak menganggapnya basi). */
    private static final Map<UUID, Map<Long, long[]>> LAST = new HashMap<>();

    /** The portal view a player is looking at right now (set every second by maybeSend); used for the fast entity updates. */
    private record Active(long key, long since, ServerLevel dest, PortalFrame dstFrame, Vec3 exit, Cfg cfg) {}

    private static final Map<UUID, Active> ACTIVE = new HashMap<>();

    private PortalView() {}

    private static Cfg cfg(boolean full, boolean complex) {
        if (complex) return full ? new Cfg(32, 96, 3, 8, 30000, 0, 0) : new Cfg(14, 28, 3, 8, 5000, 0, 0);
        return full ? new Cfg(48, 96, 14, 40, 70000, 14, 28) : new Cfg(14, 28, 3, 16, 5000, 0, 0);
    }

    /** Kirim cuplikan tujuan bingkai src ke pemain, kalau sudah waktunya. (v1.10: tidak ada lagi medan jauh "LOD": semuanya blok asli.) */
    public static void maybeSend(ServerPlayer p, ServerLevel srcLevel, PortalFrame src, ServerLevel dest, PortalFrame dstFrame, Vec3 exit,
                                 PortalSettings st) {
        long now = srcLevel.getGameTime();
        boolean full = st.isFull();
        boolean complex = dest.dimension() == TheComplex.COMPLEX;
        Cfg cfg = cfg(full, complex);
        ACTIVE.put(p.getUUID(), new Active(src.key(), now, dest, dstFrame, exit, cfg));
        Map<Long, Long> next = NEXT.computeIfAbsent(p.getUUID(), k -> new HashMap<>());

        Long due = next.get(src.key());
        if (due == null || now >= due) {
            PortalViewPacket pkt = build(dest, srcLevel.dimension().location().toString(), src, dstFrame, exit, cfg);
            if (pkt != null) {
                next.put(src.key(), now + (full ? 60 : 200));
                long h = (Arrays.hashCode(pkt.idx()) * 31L + Arrays.hashCode(pkt.ids())) * 31L + Arrays.hashCode(pkt.masks())
                        + Arrays.hashCode(pkt.light()) * 17L + pkt.ambient() + pkt.skyFactor() * 3L;
                Map<Long, long[]> last = LAST.computeIfAbsent(p.getUUID(), k -> new HashMap<>());
                long[] prev = last.get(src.key());
                if (prev == null || prev[0] != h || now - prev[1] >= 600) {
                    last.put(src.key(), new long[]{h, now});
                    Net.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), pkt);
                }
            }
        }
    }

    /** Every 3 ticks: positions of the entities on the other side, for the see-through view (called from PortalSystem each player tick). */
    public static void tickEntities(ServerPlayer p) {
        Active a = ACTIVE.get(p.getUUID());
        if (a == null) return;
        long now = p.serverLevel().getGameTime();
        if (now - a.since() > 60) {
            ACTIVE.remove(p.getUUID());
            return;
        }
        if (p.tickCount % 3 != 0) return;
        PortalEntitiesPacket pkt = PortalEntitiesPacket.collect(a.key(), a.dest(), a.dstFrame(), a.exit(), a.cfg().half(), a.cfg().depth(), p);
        if (pkt != null) Net.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), pkt);
    }

    public static void forget(UUID id) {
        NEXT.remove(id);
        LAST.remove(id);
        ACTIVE.remove(id);
    }

    /**
     * Bounds of the near snapshot box: {minX, maxX, minZ, maxZ}.
     * The box STARTS AT the frame's own cell. It used to start one cell further out, so the floor and the wall reveals
     * exactly at the frame plane were never baked; seen from up close, that strip showed the plain clear color
     * (a flat olive patch on the floor). The Threshold blocks themselves are still skipped in build().
     */
    private static int[] nearBox(Vec3 c, int ex, int ez, Cfg cfg) {
        int bx = Mth.floor(c.x), bz = Mth.floor(c.z);
        if (ex != 0) {
            return new int[]{ex > 0 ? bx : bx - cfg.depth(), ex > 0 ? bx + cfg.depth() : bx, bz - cfg.half(), bz + cfg.half()};
        }
        return new int[]{bx - cfg.half(), bx + cfg.half(), ez > 0 ? bz : bz - cfg.depth(), ez > 0 ? bz + cfg.depth() : bz};
    }

    private static int skyColor(ServerLevel dest, int ambient) {
        if (dest.dimension() == TheComplex.COMPLEX) return 0x6B6538;
        float f = 0.10f + 0.90f * Mth.clamp(ambient / 15f, 0f, 1f);
        return ((int) (0.47f * f * 255) << 16) | ((int) (0.65f * f * 255) << 8) | (int) (1.0f * f * 255);
    }

    private static final int NO_DATA = Integer.MIN_VALUE;
    private static final int[] DX = {1, -1, 0, 0}, DZ = {0, 0, 1, -1};

    /** Collects the visible blocks of one snapshot. */
    private static final class Scan {
        final ServerLevel dest;
        final int minX, maxX, minY, maxY, minZ, maxZ, w, h, d;
        final long[] packed;
        final byte[] maskOf, lightOf;
        int n;
        final BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        final BlockPos.MutableBlockPos q = new BlockPos.MutableBlockPos();

        Scan(ServerLevel dest, int minX, int maxX, int minY, int maxY, int minZ, int maxZ, int cap) {
            this.dest = dest;
            this.minX = minX;
            this.maxX = maxX;
            this.minY = minY;
            this.maxY = maxY;
            this.minZ = minZ;
            this.maxZ = maxZ;
            this.w = maxX - minX + 1;
            this.h = maxY - minY + 1;
            this.d = maxZ - minZ + 1;
            this.packed = new long[cap];
            this.maskOf = new byte[w * h * d];
            this.lightOf = new byte[w * h * d];
        }

        boolean full() {
            return n >= packed.length;
        }

        /** Looks at one cell and records it when it is visible. Returns true when the cell is a solid, opaque, non-fluid block. */
        boolean cell(int x, int y, int z) {
            if (full()) return false;
            m.set(x, y, z);
            if (!dest.hasChunkAt(m)) return false;
            BlockState s = dest.getBlockState(m);
            if (s.isAir()) return false;
            FluidState fl = s.getFluidState();
            boolean fluid = !fl.isEmpty() && s.getRenderShape() != RenderShape.MODEL;
            if (!fluid && s.getRenderShape() != RenderShape.MODEL) return false;
            if (s.is(ModBlocks.THRESHOLD.get())) return false;
            if (s.is(ModBlocks.NULL_ZONE.get())) {
                BlockEntity be = dest.getBlockEntity(m);
                if (be instanceof NullZoneBlockEntity nz && nz.getOriginal() != null) s = nz.getOriginal();
                fl = s.getFluidState();
                fluid = false;
            }
            boolean solid = !fluid && s.isSolidRender(dest, m);
            int mask = 0x3F;
            if (solid) {
                mask = exposedMask(m);
                if (mask == 0) return true;                    // hidden inside the ground, but still "solid" for the caller
            } else if (fluid) {
                mask = fluidMask(m, fl);
                if (mask == 0) return false;
            }
            int idx = ((y - minY) * d + (z - minZ)) * w + (x - minX);
            maskOf[idx] = (byte) mask;
            lightOf[idx] = (byte) lightAt(m, mask, solid || fluid);
            packed[n++] = ((long) idx << 32) | (Block.BLOCK_STATE_REGISTRY.getId(s) & 0xFFFFFFFFL);
            return solid;
        }

        /** Sides of a solid block that face empty space inside the box (bit = Direction.get3DDataValue). 0 = fully hidden. */
        int exposedMask(BlockPos p) {
            int mask = 0;
            for (Direction dir : Direction.values()) {
                int nx = p.getX() + dir.getStepX(), ny = p.getY() + dir.getStepY(), nz = p.getZ() + dir.getStepZ();
                if (nx < minX || nx > maxX || ny < minY || ny > maxY || nz < minZ || nz > maxZ) continue;
                q.set(nx, ny, nz);
                if (!dest.hasChunkAt(q)) continue;                  // never load a chunk just to look at a neighbor
                if (!dest.getBlockState(q).isSolidRender(dest, q)) mask |= 1 << dir.get3DDataValue();
            }
            return mask;
        }

        /** Sides of a fluid block that touch air or a different block (not the same fluid, not an opaque block). */
        int fluidMask(BlockPos p, FluidState fl) {
            int mask = 0;
            for (Direction dir : Direction.values()) {
                int nx = p.getX() + dir.getStepX(), ny = p.getY() + dir.getStepY(), nz = p.getZ() + dir.getStepZ();
                if (nx < minX || nx > maxX || ny < minY || ny > maxY || nz < minZ || nz > maxZ) continue;
                q.set(nx, ny, nz);
                if (!dest.hasChunkAt(q)) continue;
                BlockState ns = dest.getBlockState(q);
                if (ns.isSolidRender(dest, q)) continue;
                FluidState nf = ns.getFluidState();
                if (!nf.isEmpty() && nf.getType().isSame(fl.getType())) continue;
                mask |= 1 << dir.get3DDataValue();
            }
            return mask;
        }

        /** Block light (high nibble) and sky light (low nibble) the visible sides of this cell get. */
        int lightAt(BlockPos p, int mask, boolean useNeighbors) {
            int bl = 0, sl = 0;
            if (useNeighbors) {
                for (Direction dir : Direction.values()) {
                    if ((mask & (1 << dir.get3DDataValue())) == 0) continue;
                    q.set(p).move(dir);
                    bl = Math.max(bl, dest.getBrightness(LightLayer.BLOCK, q));
                    sl = Math.max(sl, dest.getBrightness(LightLayer.SKY, q));
                }
            } else {
                bl = dest.getBrightness(LightLayer.BLOCK, p);
                sl = dest.getBrightness(LightLayer.SKY, p);
            }
            return (bl << 4) | sl;
        }
    }

    /** Null kalau chunk tujuan belum dimuat. */
    private static PortalViewPacket build(ServerLevel dest, String srcDim, PortalFrame src, PortalFrame dst, Vec3 exit, Cfg cfg) {
        Vec3 c = dst.center;
        int ex = (int) Math.signum(exit.x), ez = (int) Math.signum(exit.z);
        int by = Mth.floor(c.y);
        int[] box = nearBox(c, ex, ez, cfg);
        int minX = box[0], maxX = box[1], minZ = box[2], maxZ = box[3];
        if (dest.getChunkSource().getChunkNow(Mth.floor(c.x) >> 4, Mth.floor(c.z) >> 4) == null) return null;
        int w = maxX - minX + 1, d = maxZ - minZ + 1;

        // vertical range: fixed around the frame, or (open worlds, full mode) following the terrain so seabeds, valleys and hills are in
        boolean columns = cfg.nearHalf() > 0;
        int[] top = null;
        int minY = by - cfg.below(), maxY = by + cfg.above();
        if (columns) {
            top = new int[w * d];
            int lo = Integer.MAX_VALUE, hi = Integer.MIN_VALUE;
            for (int z = minZ; z <= maxZ; z++) {
                for (int x = minX; x <= maxX; x++) {
                    LevelChunk ch = dest.getChunkSource().getChunkNow(x >> 4, z >> 4);
                    int i = (z - minZ) * w + (x - minX);
                    if (ch == null) {
                        top[i] = NO_DATA;
                        continue;
                    }
                    int t = ch.getHeight(Heightmap.Types.WORLD_SURFACE, x & 15, z & 15) - 1;
                    top[i] = t;
                    lo = Math.min(lo, t);
                    hi = Math.max(hi, t);
                }
            }
            if (lo > hi) return null;
            minY = Mth.clamp(Math.min(lo - 2, by - cfg.below()), Math.max(dest.getMinBuildHeight(), by - 128), by);
            maxY = Mth.clamp(Math.max(hi + 1, by + cfg.above()), by, Math.min(dest.getMaxBuildHeight() - 1, by + 128));
        }
        Scan sc = new Scan(dest, minX, maxX, minY, maxY, minZ, maxZ, cfg.maxCells());

        int depthLen = ex != 0 ? w : d;
        int latMin = ex != 0 ? minZ : minX, latMax = ex != 0 ? maxZ : maxX;
        int latCenter = ex != 0 ? Mth.floor(c.z) : Mth.floor(c.x);
        int nearMin = Math.max(minY, by - cfg.below()), nearMax = Math.min(maxY, by + cfg.above());
        // from near to far: when there are too many blocks, the farthest ones are the ones that get cut off
        for (int step = 0; step < depthLen && !sc.full(); step++) {
            for (int lat = latMin; lat <= latMax && !sc.full(); lat++) {
                int x, z;
                if (ex != 0) {
                    x = ex > 0 ? minX + step : maxX - step;
                    z = lat;
                } else {
                    z = ez > 0 ? minZ + step : maxZ - step;
                    x = lat;
                }
                boolean near = !columns || (step <= cfg.nearDepth() && Math.abs(lat - latCenter) <= cfg.nearHalf());
                if (near) {
                    for (int y = nearMin; y <= nearMax && !sc.full(); y++) sc.cell(x, y, z);
                } else {
                    int t = top[(z - minZ) * w + (x - minX)];
                    if (t == NO_DATA) continue;
                    int lowN = t;                                           // the lowest neighbor decides how deep the side faces go
                    for (int k = 0; k < 4; k++) {
                        int nx = x + DX[k], nz = z + DZ[k];
                        if (nx < minX || nx > maxX || nz < minZ || nz > maxZ) continue;
                        int tn = top[(nz - minZ) * w + (nx - minX)];
                        if (tn != NO_DATA) lowN = Math.min(lowN, tn);
                    }
                    for (int y = Math.min(t, maxY); y >= minY; y--) {
                        boolean solid = sc.cell(x, y, z);
                        if (solid && y <= lowN - 1) break;                  // closed in on all sides below here
                    }
                }
            }
        }

        int n = sc.n;
        long[] cut = Arrays.copyOf(sc.packed, n);
        Arrays.sort(cut);
        int[] idx = new int[n], ids = new int[n];
        byte[] masks = new byte[n], light = new byte[n];
        for (int i = 0; i < n; i++) {
            idx[i] = (int) (cut[i] >>> 32);
            ids[i] = (int) (cut[i] & 0xFFFFFFFFL);
            masks[i] = sc.maskOf[idx[i]];
            light[i] = sc.lightOf[idx[i]];
        }
        BlockPos at = BlockPos.containing(c.x + exit.x * 3, c.y, c.z + exit.z * 3);
        int ambient = dest.getMaxLocalRawBrightness(at);
        int skyFactor = dest.dimensionType().hasSkyLight() ? Math.max(0, 15 - dest.getSkyDarken()) : 0;
        int axis = src.normalAxis == Direction.Axis.X ? 0 : 1;
        return new PortalViewPacket(src.key(), srcDim, src.center.x, src.center.y, src.center.z, axis,
                (float) src.halfWidth, (float) src.halfHeight, c.x, c.y, c.z, ex, ez,
                minX, minY, minZ, w, sc.h, d, ambient, skyColor(dest, ambient), skyFactor, idx, ids, masks, light);
    }

    // ---------------------------------------------------------------- medan jauh (mode penuh, dunia terbuka)

    /**
     * v1.9: tiles whose chunk is not loaded used to stay empty, and the sky showed through them as holes in the skyline.
     * Each such tile now copies its lowest known neighbor (lowest, so a hole never becomes a false tall pillar). Repeated
     * for a few rounds so a hole several tiles wide closes from the edges inward.
     */
    private static void fillHoles(byte[] pal, short[] heights, boolean[] unloaded, int gw, int gd) {
        int[] dx = {1, -1, 0, 0}, dz = {0, 0, 1, -1};
        for (int round = 0; round < 6; round++) {
            byte[] np = pal.clone();
            short[] nh = heights.clone();
            boolean any = false;
            for (int iz = 0; iz < gd; iz++) {
                for (int ix = 0; ix < gw; ix++) {
                    int i = iz * gw + ix;
                    if (!unloaded[i] || pal[i] != (byte) 255) continue;
                    int best = -1;
                    for (int k = 0; k < 4; k++) {
                        int nx = ix + dx[k], nz = iz + dz[k];
                        if (nx < 0 || nz < 0 || nx >= gw || nz >= gd) continue;
                        int ni = nz * gw + nx;
                        if (pal[ni] == (byte) 255) continue;
                        if (best < 0 || heights[ni] < heights[best]) best = ni;
                    }
                    if (best >= 0) {
                        np[i] = pal[best];
                        nh[i] = heights[best];
                        any = true;
                    }
                }
            }
            System.arraycopy(np, 0, pal, 0, pal.length);
            System.arraycopy(nh, 0, heights, 0, heights.length);
            if (!any) break;
        }
    }

    /** Tinggi dan jenis blok permukaan per tile 4x4 blok di luar kotak dekat, sampai distChunks chunk dari bingkai tujuan. */
    private static PortalFarPacket buildFar(ServerLevel dest, PortalFrame src, PortalFrame dst, Vec3 exit, int distChunks, Cfg near, int[] complete) {
        Vec3 c = dst.center;
        int ex = (int) Math.signum(exit.x), ez = (int) Math.signum(exit.z);
        int r = distChunks * 16;
        int bx = Mth.floor(c.x), bz = Mth.floor(c.z);
        int minX, maxX, minZ, maxZ;
        if (ex != 0) {
            minX = ex > 0 ? bx + 1 : bx - r;
            maxX = ex > 0 ? bx + r : bx - 1;
            minZ = bz - r;
            maxZ = bz + r;
        } else {
            minZ = ez > 0 ? bz + 1 : bz - r;
            maxZ = ez > 0 ? bz + r : bz - 1;
            minX = bx - r;
            maxX = bx + r;
        }
        int t = FAR_TILE;
        int tx0 = Math.floorDiv(minX, t), tx1 = Math.floorDiv(maxX, t);
        int tz0 = Math.floorDiv(minZ, t), tz1 = Math.floorDiv(maxZ, t);
        int gw = tx1 - tx0 + 1, gd = tz1 - tz0 + 1;
        int[] nb = nearBox(c, ex, ez, near);

        byte[] pal = new byte[gw * gd];
        short[] heights = new short[gw * gd];
        boolean[] unloaded = new boolean[gw * gd];
        Map<Block, Integer> palette = new HashMap<>();
        int[] palIds = new int[250];
        int present = 0, expected = 0;
        BlockPos.MutableBlockPos q = new BlockPos.MutableBlockPos();
        for (int iz = 0; iz < gd; iz++) {
            for (int ix = 0; ix < gw; ix++) {
                int i = iz * gw + ix;
                pal[i] = (byte) 255;
                int x = (tx0 + ix) * t + t / 2, z = (tz0 + iz) * t + t / 2;
                if (x >= nb[0] && x <= nb[1] && z >= nb[2] && z <= nb[3]) continue;            // sudah tercakup kotak dekat
                if (x < minX || x > maxX || z < minZ || z > maxZ) continue;
                expected++;
                LevelChunk ch = dest.getChunkSource().getChunkNow(x >> 4, z >> 4);
                if (ch == null) {
                    unloaded[i] = true;                  // a hole for now: filled from its neighbors below
                    continue;
                }
                int top = ch.getHeight(Heightmap.Types.WORLD_SURFACE, x & 15, z & 15) - 1;
                BlockState s = null;
                int y = top;
                for (int k = 0; k < 6 && y > dest.getMinBuildHeight(); k++, y--) {
                    q.set(x, y, z);
                    BlockState cand = ch.getBlockState(q);
                    if (cand.isAir()) continue;
                    if (cand.is(Blocks.SNOW) || cand.is(BlockTags.LEAVES) || !cand.getFluidState().isEmpty() || cand.isSolidRender(dest, q)) {
                        s = cand;
                        break;
                    }
                }
                if (s == null) continue;
                Block b = s.getBlock();
                Integer pi = palette.get(b);
                if (pi == null) {
                    if (palette.size() >= palIds.length) pi = 0;
                    else {
                        pi = palette.size();
                        palette.put(b, pi);
                        palIds[pi] = Block.BLOCK_STATE_REGISTRY.getId(b.defaultBlockState());
                    }
                }
                pal[i] = (byte) (int) pi;
                heights[i] = (short) (y + 1);
                present++;
            }
        }
        complete[0] = expected > 0 && present * 10L >= expected * 9L ? 1 : 0;
        if (present == 0) return null;
        fillHoles(pal, heights, unloaded, gw, gd);
        int ambient = dest.getMaxLocalRawBrightness(BlockPos.containing(c.x + exit.x * 3, c.y, c.z + exit.z * 3));
        return new PortalFarPacket(src.key(), c.x, c.y, c.z, t, tx0, tz0, gw, gd, ambient, Arrays.copyOf(palIds, palette.size()), pal, heights);
    }
}
