package com.thecomplex.portal;

import com.thecomplex.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Set;

/**
 * Satu bingkai Threshold: kumpulan blok Threshold yang saling menempel (biasanya 2 lebar x 3 tinggi x 1 tebal).
 * Sumbu tipis bingkai adalah sumbu "normal": itulah arah orang berjalan menembusnya.
 */
public final class PortalFrame {
    public final BlockPos min;
    public final BlockPos max;
    /** X atau Z: sumbu tempat orang menembus bingkai. */
    public final Direction.Axis normalAxis;
    /** Titik tengah bingkai (di tengah ketebalan bingkai). */
    public final Vec3 center;
    public final double halfWidth;
    public final double halfHeight;

    private PortalFrame(BlockPos min, BlockPos max, Direction.Axis axis) {
        this.min = min;
        this.max = max;
        this.normalAxis = axis;
        this.center = new Vec3((min.getX() + max.getX() + 1) / 2.0, (min.getY() + max.getY() + 1) / 2.0, (min.getZ() + max.getZ() + 1) / 2.0);
        int sx = max.getX() - min.getX() + 1, sz = max.getZ() - min.getZ() + 1;
        this.halfWidth = (axis == Direction.Axis.X ? sz : sx) / 2.0;
        this.halfHeight = (max.getY() - min.getY() + 1) / 2.0;
    }

    /** Bingkai yang memuat blok di start, atau null kalau di sana bukan Threshold. */
    public static PortalFrame of(BlockGetter level, BlockPos start) {
        Block thr = ModBlocks.THRESHOLD.get();
        if (!level.getBlockState(start).is(thr)) return null;
        Set<Long> seen = new HashSet<>();
        ArrayDeque<BlockPos> queue = new ArrayDeque<>();
        queue.add(start);
        seen.add(start.asLong());
        int minX = start.getX(), minY = start.getY(), minZ = start.getZ();
        int maxX = minX, maxY = minY, maxZ = minZ;
        while (!queue.isEmpty() && seen.size() < 48) {
            BlockPos p = queue.poll();
            minX = Math.min(minX, p.getX());
            minY = Math.min(minY, p.getY());
            minZ = Math.min(minZ, p.getZ());
            maxX = Math.max(maxX, p.getX());
            maxY = Math.max(maxY, p.getY());
            maxZ = Math.max(maxZ, p.getZ());
            for (Direction d : Direction.values()) {
                BlockPos n = p.relative(d);
                if (seen.contains(n.asLong())) continue;
                if (!level.getBlockState(n).is(thr)) continue;
                seen.add(n.asLong());
                queue.add(n);
            }
        }
        int sx = maxX - minX + 1, sz = maxZ - minZ + 1;
        Direction.Axis axis;
        if (sx == 1 && sz > 1) axis = Direction.Axis.X;
        else if (sz == 1 && sx > 1) axis = Direction.Axis.Z;
        else if (sx == 1) axis = guess(level, start);
        else axis = sx <= sz ? Direction.Axis.X : Direction.Axis.Z;
        return new PortalFrame(new BlockPos(minX, minY, minZ), new BlockPos(maxX, maxY, maxZ), axis);
    }

    /** Bingkai satu blok: sumbu bingkai adalah sumbu yang kedua sisinya berisi blok padat, sumbu normal yang lain. */
    private static Direction.Axis guess(BlockGetter level, BlockPos p) {
        int alongX = (solid(level, p.east()) ? 1 : 0) + (solid(level, p.west()) ? 1 : 0);
        int alongZ = (solid(level, p.north()) ? 1 : 0) + (solid(level, p.south()) ? 1 : 0);
        if (alongX > alongZ) return Direction.Axis.Z;
        if (alongZ > alongX) return Direction.Axis.X;
        return Direction.Axis.Z;
    }

    private static boolean solid(BlockGetter level, BlockPos p) {
        BlockState s = level.getBlockState(p);
        return !s.isAir() && !s.is(ModBlocks.THRESHOLD.get()) && !s.getCollisionShape(level, p).isEmpty();
    }

    public long key() {
        return min.asLong();
    }

    /** Vektor satuan sepanjang sumbu normal. */
    public Vec3 normal() {
        return normalAxis == Direction.Axis.X ? new Vec3(1, 0, 0) : new Vec3(0, 0, 1);
    }

    /** Vektor satuan sepanjang lebar bingkai. */
    public Vec3 lateral() {
        return normalAxis == Direction.Axis.X ? new Vec3(0, 0, 1) : new Vec3(1, 0, 0);
    }

    /** Apakah titik p (di bidang bingkai) jatuh di dalam bukaan, dengan sedikit toleransi. */
    public boolean containsOnPlane(Vec3 p, double marginW, double marginH) {
        Vec3 rel = p.subtract(center);
        return Math.abs(rel.dot(lateral())) <= halfWidth + marginW && Math.abs(rel.y) <= halfHeight + marginH;
    }
}
