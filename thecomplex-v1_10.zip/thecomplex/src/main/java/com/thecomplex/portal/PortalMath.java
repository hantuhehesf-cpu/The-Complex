package com.thecomplex.portal;

import net.minecraft.world.phys.Vec3;

/** Matematika arah yang dipakai server dan klien (tanpa kelas server apa pun). */
public final class PortalMath {
    private PortalMath() {}

    /** Yaw Minecraft untuk arah horizontal v (0 = selatan/+Z, 90 = barat/-X). */
    public static double yawOf(Vec3 v) {
        return Math.toDegrees(Math.atan2(-v.x, v.z));
    }

    /** Putar vektor mengelilingi sumbu Y sebesar deg derajat, dalam arti yang sama dengan yaw Minecraft. */
    public static Vec3 rotateYaw(Vec3 v, double deg) {
        double r = Math.toRadians(deg), c = Math.cos(r), s = Math.sin(r);
        return new Vec3(v.x * c - v.z * s, v.y, v.z * c + v.x * s);
    }
}
