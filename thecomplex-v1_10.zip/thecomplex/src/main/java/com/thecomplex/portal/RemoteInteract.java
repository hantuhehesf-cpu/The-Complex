package com.thecomplex.portal;

import com.thecomplex.ComplexTeleporter;
import com.thecomplex.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/**
 * Interacting with the other dimension through a Threshold (v1.10). When the player clicks while looking through the opening, the
 * client sends the click here. The server takes the player's line of sight, carries it through the portal into the other
 * dimension (the same transform the player's position gets), and acts on what it hits there:
 *  - attack: hurts the entity that was hit (damage from the player's attack attribute, with the cooldown),
 *  - hold attack on a block: mines it (progress by the tool, drops go to the other side; creative breaks it at once),
 *  - use: right-click on an entity, or on a block (levers, doors, buttons...; or place the block/use the item in hand).
 * Limits: reach counts from the player, so the part before the opening is used up; menus (chests, furnaces) close at once
 * because the player is in another dimension.
 */
public final class RemoteInteract {
    public static final int ATTACK = 0, USE = 1, MINE = 2, MINE_STOP = 3;
    private static final double START = 0.6;           // skip the frame blocks themselves

    private record Mine(ResourceKey<Level> dim, BlockPos pos, float progress) {}

    private record Target(ServerLevel dest, Vec3 origin, Vec3 dir, double remaining) {}

    private static final Map<UUID, Mine> MINES = new HashMap<>();

    private RemoteInteract() {}

    public static void handle(ServerPlayer p, int action, int hand, long key) {
        if (p.isSpectator() || !p.isAlive()) return;
        if (action == MINE_STOP) {
            stopMining(p);
            return;
        }
        Target t = target(p, key);
        if (t == null) {
            if (action == MINE) stopMining(p);
            return;
        }
        Vec3 start = t.origin().add(t.dir().scale(START));
        Vec3 end = t.origin().add(t.dir().scale(t.remaining()));
        BlockHitResult bh = t.dest().clip(new ClipContext(start, end, ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, p));
        double bd = bh.getType() == HitResult.Type.MISS ? Double.MAX_VALUE : start.distanceToSqr(bh.getLocation());
        Entity hit = null;
        double ed = bd;
        List<Entity> near = t.dest().getEntities((Entity) null, new AABB(start, end).inflate(1.0), e -> !e.isSpectator() && e.isPickable());
        for (Entity e : near) {
            Optional<Vec3> r = e.getBoundingBox().inflate(e.getPickRadius()).clip(start, end);
            if (r.isPresent()) {
                double dd = start.distanceToSqr(r.get());
                if (dd < ed) {
                    ed = dd;
                    hit = e;
                }
            }
        }
        InteractionHand h = hand == 0 ? InteractionHand.MAIN_HAND : InteractionHand.OFF_HAND;
        switch (action) {
            case ATTACK -> {
                if (hit != null) attack(p, t, hit);
                else mine(p, t, bh, true);
            }
            case MINE -> {
                if (hit != null) stopMining(p);
                else mine(p, t, bh, false);
            }
            case USE -> {
                if (hit != null) {
                    p.interactOn(hit, h);
                    p.swing(h, true);
                } else if (bh.getType() == HitResult.Type.BLOCK) {
                    useBlock(p, t, bh, h);
                }
            }
            default -> {
            }
        }
    }

    /** The player's line of sight carried into the other dimension, or null when the player is not looking through a Threshold opening. */
    private static Target target(ServerPlayer p, long key) {
        ServerLevel level = p.serverLevel();
        PortalFrame f = null;
        for (BlockPos pos : PortalRegistry.near(level, p.blockPosition(), 8)) {
            PortalFrame fr = PortalFrame.of(level, pos);
            if (fr != null && fr.key() == key) {
                f = fr;
                break;
            }
        }
        if (f == null) return null;
        ComplexTeleporter.Dest d = ComplexTeleporter.destFor(p, level, false);
        if (d == null) return null;
        Vec3 eye = p.getEyePosition(), look = p.getLookAngle(), n = f.normal();
        double denom = look.dot(n);
        if (Math.abs(denom) < 1.0E-4) return null;
        double t = f.center.subtract(eye).dot(n) / denom;
        if (t <= 0.0 || t > 5.0) return null;
        Vec3 hit = eye.add(look.scale(t));
        if (!f.containsOnPlane(hit, 0.1, 0.1)) return null;
        Vec3 travel = n.scale(denom > 0 ? 1 : -1);
        double dyaw = ComplexTeleporter.yawOf(d.exit()) - ComplexTeleporter.yawOf(travel);
        Vec3 origin = d.frame().center.add(ComplexTeleporter.rotateYaw(hit.subtract(f.center), dyaw));
        Vec3 dir = ComplexTeleporter.rotateYaw(look, dyaw).normalize();
        double rem = (p.isCreative() ? 5.0 : 4.5) - t;
        if (rem < START + 0.4) return null;
        return new Target(d.level(), origin, dir, rem);
    }

    private static void attack(ServerPlayer p, Target t, Entity e) {
        stopMining(p);
        if (!e.isAttackable() || e.skipAttackInteraction(p)) return;
        float scale = p.getAttackStrengthScale(0.5f);
        float dmg = (float) p.getAttributeValue(Attributes.ATTACK_DAMAGE) * (0.2f + scale * scale * 0.8f);
        p.swing(InteractionHand.MAIN_HAND, true);
        p.resetAttackStrengthTicker();
        if (dmg <= 0) return;
        if (e.hurt(t.dest().damageSources().playerAttack(p), dmg) && e instanceof LivingEntity le) {
            le.knockback(0.4, -t.dir().x, -t.dir().z);
        }
    }

    private static void useBlock(ServerPlayer p, Target t, BlockHitResult bh, InteractionHand h) {
        BlockPos pos = bh.getBlockPos();
        if (!p.getAbilities().mayBuild || !t.dest().mayInteract(p, pos)) return;
        ItemStack stack = p.getItemInHand(h);
        BlockState st = t.dest().getBlockState(pos);
        p.swing(h, true);
        if (!p.isSecondaryUseActive() || stack.isEmpty()) {
            if (st.use(t.dest(), p, h, bh).consumesAction()) return;
        }
        if (!stack.isEmpty()) stack.useOn(new UseOnContext(t.dest(), p, h, stack, bh));
    }

    private static void mine(ServerPlayer p, Target t, BlockHitResult bh, boolean start) {
        if (bh.getType() != HitResult.Type.BLOCK) {
            stopMining(p);
            return;
        }
        BlockPos pos = bh.getBlockPos();
        ServerLevel dest = t.dest();
        BlockState st = dest.getBlockState(pos);
        if (!p.getAbilities().mayBuild || !dest.mayInteract(p, pos)) return;
        if (st.isAir() || st.getDestroySpeed(dest, pos) < 0 || st.is(ModBlocks.THRESHOLD.get())) return;
        if (start) p.swing(InteractionHand.MAIN_HAND, true);
        if (p.isCreative()) {
            if (start) dest.destroyBlock(pos, false, p);
            return;
        }
        Mine cur = MINES.get(p.getUUID());
        float progress = cur != null && cur.dim().equals(dest.dimension()) && cur.pos().equals(pos) ? cur.progress() : 0f;
        progress += st.getDestroyProgress(p, dest, pos);
        if (progress >= 1f) {
            ItemStack tool = p.getMainHandItem();
            BlockEntity be = dest.getBlockEntity(pos);
            if (dest.destroyBlock(pos, false, p)) {
                if (p.hasCorrectToolForDrops(st)) Block.dropResources(st, dest, pos, be, p, tool);
                tool.mineBlock(dest, st, pos, p);
            }
            dest.destroyBlockProgress(p.getId(), pos, -1);
            MINES.remove(p.getUUID());
        } else {
            MINES.put(p.getUUID(), new Mine(dest.dimension(), pos, progress));
            dest.destroyBlockProgress(p.getId(), pos, (int) (progress * 10f));
        }
    }

    private static void stopMining(ServerPlayer p) {
        Mine cur = MINES.remove(p.getUUID());
        if (cur == null) return;
        ServerLevel dest = p.server.getLevel(cur.dim());
        if (dest != null) dest.destroyBlockProgress(p.getId(), cur.pos(), -1);
    }

    public static void forget(UUID id) {
        MINES.remove(id);
    }
}
