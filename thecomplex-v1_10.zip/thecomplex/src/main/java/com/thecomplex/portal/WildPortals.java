package com.thecomplex.portal;

import com.thecomplex.ComplexTeleporter;
import com.thecomplex.ModBlocks;
import com.thecomplex.TheComplex;
import com.thecomplex.activity.NullZoneSpawner;
import com.thecomplex.block.NullZoneBlockEntity;
import com.thecomplex.world.ComplexLayout;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/**
 * Stable Wild Null Zone: pintu dinding yang sangat langka, permanen, dua arah (seperti Threshold yang menyamar).
 * Ujung satunya ada jauh di dalam The Complex, jauh dari Main Chamber. Lewat dari mana pun, keluar di ujung yang lain.
 */
public final class WildPortals {
    public static final int MAX_PAIRS = 6;

    private WildPortals() {}

    private record FarEnd(BlockPos cell, Direction normal) {}

    /**
     * Buat ujung seberang di The Complex untuk Stable Wild Null Zone di (originCell, normal) dan catat pasangannya.
     * Ujung Overworld ditaruh oleh pemanggil. Mengembalikan id pasangan, atau -1 kalau gagal (tidak ada tempat / sudah penuh).
     */
    public static int createPair(ServerLevel origin, BlockPos originCell, Direction normal, RandomSource r) {
        MinecraftServer server = origin.getServer();
        if (server == null) return -1;
        ServerLevel complex = server.getLevel(TheComplex.COMPLEX);
        WildPortalData data = WildPortalData.get(server);
        if (complex == null || data.count() >= MAX_PAIRS) return -1;
        FarEnd far = findFarEnd(complex, r);
        if (far == null) return -1;
        int id = data.reserve();
        BlockPos a = far.cell();
        Direction d = far.normal();
        double plane = NullZoneSpawner.planeOf(d, a.getX() + 0.5, a.getY() + 0.5, a.getZ() + 0.5);
        NullZoneSpawner.placeCell(complex, a, d, plane, a.asLong(), 0, true, id, 1, 0, true);
        NullZoneSpawner.placeCell(complex, a.above(), d, plane, a.asLong(), 0, true, id, 1, 0, false);
        data.put(new WildPortalData.Pair(id,
                new WildPortalData.End(origin.dimension().location().toString(), originCell.asLong(), normal.get3DDataValue()),
                new WildPortalData.End(TheComplex.COMPLEX.location().toString(), a.asLong(), d.get3DDataValue())));
        return id;
    }

    /**
     * Finds a Backrooms wall for the far end of a Stable Wild Null Zone: open floor in front, far from the Main Chamber.
     * v1.9: the portal must sit in the middle of a solid wall block that is at least 3 blocks thick AND 3 blocks long
     * (see isThickWall). A thin wall would open into the next room right behind the portal.
     */
    private static FarEnd findFarEnd(ServerLevel complex, RandomSource r) {
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        int baseCx = (int) Math.floor(ComplexLayout.chamberCenterX() / 16.0);
        int baseCz = (int) Math.floor(ComplexLayout.chamberCenterZ() / 16.0);
        for (int tries = 0; tries < 24; tries++) {
            int cx = baseCx + (14 + r.nextInt(30)) * (r.nextBoolean() ? 1 : -1);
            int cz = baseCz + (14 + r.nextInt(30)) * (r.nextBoolean() ? 1 : -1);
            complex.getChunk(cx, cz);
            // thick walls are rarer than thin ones, so look at many cells per chunk (cheap: no chunk loading)
            for (int i = 0; i < 240; i++) {
                int x = cx * 16 + 2 + r.nextInt(12);
                int z = cz * 16 + 2 + r.nextInt(12);
                m.set(x, ComplexLayout.FLOOR_Y + 1, z);
                if (!complex.getBlockState(m).isAir() || !complex.getBlockState(m.above()).isAir()
                        || !complex.getBlockState(m.below()).is(ModBlocks.CARPET_FLOOR.get())) continue;
                BlockPos floor = m.immutable();
                for (Direction d : new Direction[]{Direction.NORTH, Direction.EAST, Direction.SOUTH, Direction.WEST}) {
                    BlockPos a = floor.relative(d);
                    if (isThickWall(complex, a, d)) return new FarEnd(a, d);
                }
            }
        }
        return null;
    }

    /**
     * A solid block of wall material around the portal cells: 3 thick (the cell a, and the two cells behind it, going in
     * direction d), 3 long (the cell and one cell to each side), and 2 high (a and the cell above it, the portal itself).
     * That is 18 cells, all Backrooms wall. The area is never loaded here: an unloaded chunk counts as "not thick enough".
     */
    private static boolean isThickWall(ServerLevel level, BlockPos a, Direction d) {
        Direction side = d.getClockWise();
        for (int depth = 0; depth < 3; depth++) {
            for (int lat = -1; lat <= 1; lat++) {
                BlockPos c = a.relative(d, depth).relative(side, lat);
                if (!level.hasChunkAt(c)) return false;
                if (!isBackroomsWall(level.getBlockState(c)) || !isBackroomsWall(level.getBlockState(c.above()))) return false;
            }
        }
        return true;
    }

    private static boolean isBackroomsWall(BlockState s) {
        return s.is(ModBlocks.WALLPAPER.get()) || s.is(ModBlocks.OFFICE_WALL.get()) || s.is(ModBlocks.WHITE_WALL.get());
    }

    /** Ujung lain dari pasangan nz: dunia, sel, dan normal-nya. Null kalau pasangan tidak ditemukan. */
    public static WildPortalData.End otherEnd(MinecraftServer server, NullZoneBlockEntity nz) {
        WildPortalData.Pair pair = WildPortalData.get(server).get(nz.getPairId());
        if (pair == null) return null;
        return nz.getEnd() == 0 ? pair.complex() : pair.overworld();
    }

    public static ServerLevel levelOf(MinecraftServer server, WildPortalData.End end) {
        ResourceLocation id = ResourceLocation.tryParse(end.dim());
        return id == null ? null : server.getLevel(ResourceKey.create(Registries.DIMENSION, id));
    }

    /** Pemain menembus bidang sebuah Stable Wild Null Zone. travel = arah gerak (horizontal), vel = kecepatan per tick. */
    public static void cross(ServerPlayer p, NullZoneBlockEntity nz, Vec3 travel, Vec3 vel) {
        MinecraftServer server = p.server;
        WildPortalData.End other = otherEnd(server, nz);
        if (other == null) return;
        ServerLevel dest = levelOf(server, other);
        if (dest == null) return;
        BlockPos oc = BlockPos.of(other.cell());
        Direction on = Direction.from3DDataValue(other.normal());
        dest.getChunk(oc.getX() >> 4, oc.getZ() >> 4);
        // keluar di sisi ruangan dinding tujuan, sedikit di dalam sel (belum melewati bidangnya)
        Vec3 exit = new Vec3(-on.getStepX(), 0, -on.getStepZ());
        double relY = Mth.clamp(p.getY() - nz.getAnchor().getY(), 0.0, 1.0);
        Vec3 np = new Vec3(oc.getX() + 0.5 + exit.x * 0.45, oc.getY() + relY, oc.getZ() + 0.5 + exit.z * 0.45);
        np = ComplexTeleporter.settle(dest, p, np, exit);
        double dyaw = ComplexTeleporter.yawOf(exit) - ComplexTeleporter.yawOf(travel);
        float yaw = Mth.wrapDegrees((float) (p.getYRot() + dyaw));
        if (nz.getEnd() == 0) ComplexTeleporter.rememberReturn(p, null, Direction.NORTH);
        Seamless.send(p, dest, np, yaw, p.getXRot(), ComplexTeleporter.rotateYaw(vel, dyaw), Seamless.STYLE_WILD);
    }
}
