package com.thecomplex.portal;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.HashMap;
import java.util.Map;

/** Pasangan Stable Wild Null Zone: satu ujung di Overworld, satu ujung jauh di The Complex. Disimpan di data Overworld. */
public class WildPortalData extends SavedData {
    /** Satu ujung: dimensi, sel bawah dinding, dan arah normal (Direction.get3DDataValue). */
    public record End(String dim, long cell, int normal) {
        CompoundTag toTag() {
            CompoundTag t = new CompoundTag();
            t.putString("dim", dim);
            t.putLong("cell", cell);
            t.putInt("n", normal);
            return t;
        }

        static End fromTag(CompoundTag t) {
            return new End(t.getString("dim"), t.getLong("cell"), t.getInt("n"));
        }
    }

    public record Pair(int id, End overworld, End complex) {}

    private final Map<Integer, Pair> pairs = new HashMap<>();
    private int nextId = 1;

    public static WildPortalData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(WildPortalData::load, WildPortalData::new, "thecomplex_wild");
    }

    public static WildPortalData load(CompoundTag tag) {
        WildPortalData d = new WildPortalData();
        d.nextId = Math.max(1, tag.getInt("next"));
        ListTag list = tag.getList("pairs", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag t = list.getCompound(i);
            Pair p = new Pair(t.getInt("id"), End.fromTag(t.getCompound("a")), End.fromTag(t.getCompound("b")));
            d.pairs.put(p.id(), p);
        }
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putInt("next", nextId);
        ListTag list = new ListTag();
        for (Pair p : pairs.values()) {
            CompoundTag t = new CompoundTag();
            t.putInt("id", p.id());
            t.put("a", p.overworld().toTag());
            t.put("b", p.complex().toTag());
            list.add(t);
        }
        tag.put("pairs", list);
        return tag;
    }

    public int reserve() {
        setDirty();
        return nextId++;
    }

    public void put(Pair p) {
        pairs.put(p.id(), p);
        setDirty();
    }

    public Pair get(int id) {
        return pairs.get(id);
    }

    public int count() {
        return pairs.size();
    }
}
