package com.thecomplex;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.thecomplex.activity.ActivityData;
import com.thecomplex.activity.ActivityTracker;
import com.thecomplex.activity.NullZoneSpawner;
import com.thecomplex.portal.PortalSettings;
import com.thecomplex.world.Schem;
import com.thecomplex.world.SchemStore;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.ChunkPos;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Map;

@Mod.EventBusSubscriber(modid = TheComplex.MODID)
public final class ServerEvents {
    private ServerEvents() {}

    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("complex").requires(s -> s.hasPermission(2))
                .then(Commands.literal("enter").executes(c -> {
                    ComplexTeleporter.toArrival(c.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("backrooms").executes(c -> {
                    ComplexTeleporter.toBackrooms(c.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("leave").executes(c -> {
                    ComplexTeleporter.leave(c.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("rooms").executes(c -> {
                    StringBuilder sb = new StringBuilder("Rooms: ");
                    for (Schem r : SchemStore.rooms()) sb.append(r.name).append(" (").append(r.width).append('x')
                            .append(r.height).append('x').append(r.length).append(") ");
                    sb.append("| ").append(SchemStore.mainChamberStatus());
                    c.getSource().sendSuccess(() -> Component.literal(sb.toString()), false);
                    return 1;
                }))
                .then(Commands.literal("reload").executes(c -> {
                    int n = SchemStore.reloadRooms();
                    c.getSource().sendSuccess(() -> Component.literal("Reloaded: " + n + " rooms"), true);
                    return n;
                }))
                .then(Commands.literal("room").then(Commands.argument("name", StringArgumentType.word()).executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    String name = StringArgumentType.getString(c, "name");
                    Schem s = SchemStore.find(name);
                    if (s == null) {
                        c.getSource().sendFailure(Component.literal("Room not found: " + name));
                        return 0;
                    }
                    s.placeInLevel(p.serverLevel(), p.blockPosition().below());
                    c.getSource().sendSuccess(() -> Component.literal("Pasted: " + s.name), true);
                    return 1;
                })))
                .then(Commands.literal("heat").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    ActivityData d = ActivityData.get(p.server.overworld());
                    float here = d.heatAt(p.getUUID(), p.chunkPosition());
                    long oneIn = Math.round(1.0 / ActivityTracker.chance(here));
                    StringBuilder sb = new StringBuilder();
                    sb.append(String.format("Heat at this chunk: %.1f (Null Zone chance every 10 seconds: 1/%d)", here, oneIn));
                    sb.append(" | Top:");
                    for (Map.Entry<Long, Float> en : d.top(p.getUUID(), 5)) {
                        ChunkPos cp = new ChunkPos(en.getKey());
                        sb.append(String.format(" [%d,%d]=%.0f", cp.getMiddleBlockX(), cp.getMiddleBlockZ(), en.getValue()));
                    }
                    c.getSource().sendSuccess(() -> Component.literal(sb.toString()), false);
                    return 1;
                }))
                .then(Commands.literal("portal")
                        .then(Commands.literal("full")
                                .then(Commands.literal("on").executes(c -> {
                                    PortalSettings st = PortalSettings.get(c.getSource().getServer());
                                    st.setFull(true);
                                    c.getSource().sendSuccess(() -> Component.literal("Portal full mode: ON (default). The other side is drawn with real blocks, light, water and entities up to about 6 chunks"
                                            + " (up to " + st.getDistance() + " chunks are kept loaded and ticking near portals), and you can attack, mine and use things through the portal."
                                            + " Heavy on a phone: /complex portal full off turns it off."), true);
                                    return 1;
                                }))
                                .then(Commands.literal("off").executes(c -> {
                                    PortalSettings.get(c.getSource().getServer()).setFull(false);
                                    c.getSource().sendSuccess(() -> Component.literal("Portal full mode: OFF (small box only, no entities)"), true);
                                    return 1;
                                })))
                        .then(Commands.literal("distance").then(Commands.argument("chunks",
                                IntegerArgumentType.integer(PortalSettings.MIN_DISTANCE, PortalSettings.MAX_DISTANCE)).executes(c -> {
                            PortalSettings st = PortalSettings.get(c.getSource().getServer());
                            st.setDistance(IntegerArgumentType.getInteger(c, "chunks"));
                            c.getSource().sendSuccess(() -> Component.literal("Portal full mode view distance: " + st.getDistance() + " chunks"), true);
                            return 1;
                        })))
                        .then(Commands.literal("status").executes(c -> {
                            PortalSettings st = PortalSettings.get(c.getSource().getServer());
                            c.getSource().sendSuccess(() -> Component.literal("Portal full mode: " + (st.isFull() ? "ON" : "OFF")
                                    + ", view distance " + st.getDistance() + " chunks (used only when ON)"), false);
                            return 1;
                        })))
                .then(Commands.literal("spawnwild").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    boolean ok = NullZoneSpawner.spawnFor(p, ActivityData.get(p.server.overworld()), NullZoneSpawner.MODE_STABLE);
                    if (ok) c.getSource().sendSuccess(() -> Component.literal("Stable Wild Null Zone created near you (its other end is far inside The Complex)"), true);
                    else c.getSource().sendFailure(Component.literal("No suitable indoor wall found, or the limit of Stable Wild Null Zones is reached"));
                    return ok ? 1 : 0;
                }))
                .then(Commands.literal("spawnground").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    boolean ok = NullZoneSpawner.spawnFor(p, ActivityData.get(p.server.overworld()), NullZoneSpawner.MODE_GROUND);
                    if (ok) c.getSource().sendSuccess(() -> Component.literal("Null Zone created on grass/dirt near you"), true);
                    else c.getSource().sendFailure(Component.literal("No suitable grass or dirt found, try standing outside"));
                    return ok ? 1 : 0;
                }))
                .then(Commands.literal("spawnnz").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    boolean ok = NullZoneSpawner.spawnFor(p, ActivityData.get(p.server.overworld()));
                    if (ok) c.getSource().sendSuccess(() -> Component.literal("Null Zone created near you"), true);
                    else c.getSource().sendFailure(Component.literal("No suitable indoor wall found, try again inside a building"));
                    return ok ? 1 : 0;
                })));
    }
}
