package com.thecomplex.net;

import com.thecomplex.portal.RemoteInteract;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Client -> server: the player clicked while looking through a Threshold (action: see RemoteInteract; hand 0 = main, 1 = off; key = the frame). */
public record RemoteInteractPacket(int action, int hand, long key) {
    public static void encode(RemoteInteractPacket m, FriendlyByteBuf buf) {
        buf.writeByte(m.action);
        buf.writeByte(m.hand);
        buf.writeLong(m.key);
    }

    public static RemoteInteractPacket decode(FriendlyByteBuf buf) {
        return new RemoteInteractPacket(buf.readByte(), buf.readByte(), buf.readLong());
    }

    public static void handle(RemoteInteractPacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> {
            ServerPlayer p = c.getSender();
            if (p != null) RemoteInteract.handle(p, m.action, m.hand, m.key);
        });
        c.setPacketHandled(true);
    }
}
