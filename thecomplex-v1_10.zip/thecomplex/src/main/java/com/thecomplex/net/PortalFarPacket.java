package com.thecomplex.net;

import com.thecomplex.client.PortalViewClient;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Server -> klien (hanya mode penuh): medan jauh di seberang Threshold sebagai kisi tile 4x4 blok (satu tinggi + satu jenis blok per tile),
 * dipakai klien sebagai "Level of Detail" sampai 8-12 chunk. pal 255 = tile tidak ada (chunk belum dimuat).
 * Kisi mulai di tile (tx0, tz0), lebar gw tile ke arah X dan gd tile ke arah Z, urutan x dulu baru z.
 */
public record PortalFarPacket(long key, double dx, double dy, double dz, int tile, int tx0, int tz0, int gw, int gd,
                              int ambient, int[] palette, byte[] pal, short[] heights) {
    public static void encode(PortalFarPacket m, FriendlyByteBuf buf) {
        buf.writeLong(m.key);
        buf.writeDouble(m.dx);
        buf.writeDouble(m.dy);
        buf.writeDouble(m.dz);
        buf.writeByte(m.tile);
        buf.writeInt(m.tx0);
        buf.writeInt(m.tz0);
        buf.writeVarInt(m.gw);
        buf.writeVarInt(m.gd);
        buf.writeByte(m.ambient);
        buf.writeVarInt(m.palette.length);
        for (int id : m.palette) buf.writeVarInt(id);
        for (int i = 0; i < m.pal.length; i++) {
            buf.writeByte(m.pal[i]);
            if (m.pal[i] != (byte) 255) buf.writeShort(m.heights[i]);
        }
    }

    public static PortalFarPacket decode(FriendlyByteBuf buf) {
        long key = buf.readLong();
        double dx = buf.readDouble(), dy = buf.readDouble(), dz = buf.readDouble();
        int tile = buf.readByte();
        int tx0 = buf.readInt(), tz0 = buf.readInt();
        int gw = buf.readVarInt(), gd = buf.readVarInt();
        int ambient = buf.readByte();
        int pn = buf.readVarInt();
        int[] palette = new int[pn];
        for (int i = 0; i < pn; i++) palette[i] = buf.readVarInt();
        int n = gw * gd;
        byte[] pal = new byte[n];
        short[] heights = new short[n];
        for (int i = 0; i < n; i++) {
            pal[i] = buf.readByte();
            if (pal[i] != (byte) 255) heights[i] = buf.readShort();
        }
        return new PortalFarPacket(key, dx, dy, dz, tile, tx0, tz0, gw, gd, ambient, palette, pal, heights);
    }

    public static void handle(PortalFarPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> PortalViewClient.receiveFar(m)));
        ctx.get().setPacketHandled(true);
    }
}
