package com.thecomplex.net;

import com.thecomplex.client.PortalGhosts;
import com.thecomplex.portal.PortalFrame;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;
import java.util.function.Supplier;

/**
 * Server -> client (every 3 ticks while a Threshold is in view): the living entities on the other side of the portal, so they can be
 * drawn in the see-through view. key = the portal frame this belongs to.
 */
public record PortalEntitiesPacket(long key, List<Ent> ents) {
    /** flags: 1 = crouching, 2 = baby. light = packed block/sky light (block << 4 | sky << 20). name/uuid only for players. */
    public record Ent(int id, int type, double x, double y, double z, float yRot, float xRot, float head, float body, int flags, int light,
                      UUID uuid, String name) {}

    private static final int MAX_ENTITIES = 40;

    /** The entities inside the view box on the destination side; null when there is nothing to show and nothing was shown before. */
    public static PortalEntitiesPacket collect(long key, ServerLevel dest, PortalFrame dst, Vec3 exit, int half, int depth, ServerPlayer viewer) {
        Vec3 c = dst.center;
        int ex = (int) Math.signum(exit.x), ez = (int) Math.signum(exit.z);
        AABB box;
        if (ex != 0) {
            box = new AABB(ex > 0 ? c.x : c.x - depth, c.y - 96, c.z - half, ex > 0 ? c.x + depth : c.x, c.y + 96, c.z + half);
        } else {
            box = new AABB(c.x - half, c.y - 96, ez > 0 ? c.z : c.z - depth, c.x + half, c.y + 96, ez > 0 ? c.z + depth : c.z);
        }
        List<Entity> found = new ArrayList<>(dest.getEntities((Entity) null, box,
                e -> e instanceof LivingEntity && e != viewer && !e.isSpectator() && !e.isInvisible() && e.isAlive()));
        found.sort(Comparator.comparingDouble(e -> e.distanceToSqr(c)));
        List<Ent> out = new ArrayList<>();
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (Entity e : found) {
            if (out.size() >= MAX_ENTITIES) break;
            m.set(e.getX(), e.getEyeY(), e.getZ());
            int bl = dest.getBrightness(LightLayer.BLOCK, m), sl = dest.getBrightness(LightLayer.SKY, m);
            int flags = (e.isCrouching() ? 1 : 0) | (e instanceof LivingEntity le && le.isBaby() ? 2 : 0);
            float body = e instanceof LivingEntity le ? le.yBodyRot : e.getYRot();
            float head = e instanceof LivingEntity le ? le.yHeadRot : e.getYRot();
            boolean player = e instanceof Player;
            out.add(new Ent(e.getId(), BuiltInRegistries.ENTITY_TYPE.getId(e.getType()), e.getX(), e.getY(), e.getZ(), e.getYRot(), e.getXRot(),
                    head, body, flags, (bl << 4) | (sl << 20), player ? e.getUUID() : new UUID(0, 0), player ? e.getName().getString() : ""));
        }
        return new PortalEntitiesPacket(key, out);
    }

    public static void encode(PortalEntitiesPacket m, FriendlyByteBuf buf) {
        buf.writeLong(m.key);
        buf.writeVarInt(m.ents.size());
        for (Ent e : m.ents) {
            buf.writeVarInt(e.id);
            buf.writeVarInt(e.type);
            buf.writeDouble(e.x);
            buf.writeDouble(e.y);
            buf.writeDouble(e.z);
            buf.writeFloat(e.yRot);
            buf.writeFloat(e.xRot);
            buf.writeFloat(e.head);
            buf.writeFloat(e.body);
            buf.writeByte(e.flags);
            buf.writeInt(e.light);
            buf.writeUUID(e.uuid);
            buf.writeUtf(e.name, 64);
        }
    }

    public static PortalEntitiesPacket decode(FriendlyByteBuf buf) {
        long key = buf.readLong();
        int n = buf.readVarInt();
        List<Ent> list = new ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            int id = buf.readVarInt(), type = buf.readVarInt();
            double x = buf.readDouble(), y = buf.readDouble(), z = buf.readDouble();
            float yRot = buf.readFloat(), xRot = buf.readFloat(), head = buf.readFloat(), body = buf.readFloat();
            int flags = buf.readByte(), light = buf.readInt();
            UUID uuid = buf.readUUID();
            String name = buf.readUtf(64);
            list.add(new Ent(id, type, x, y, z, yRot, xRot, head, body, flags, light, uuid, name));
        }
        return new PortalEntitiesPacket(key, list);
    }

    public static void handle(PortalEntitiesPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> PortalGhosts.receive(m)));
        ctx.get().setPacketHandled(true);
    }
}
