package com.thecomplex.net;

import com.thecomplex.dev.DevActions;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Client -> server: the Developer UI key was pressed. The server answers with OpenDevPacket if the player is allowed to use it. */
public record DevOpenRequestPacket() {
    public static void encode(DevOpenRequestPacket m, FriendlyByteBuf buf) {
    }

    public static DevOpenRequestPacket decode(FriendlyByteBuf buf) {
        return new DevOpenRequestPacket();
    }

    public static void handle(DevOpenRequestPacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> {
            ServerPlayer p = c.getSender();
            if (p != null && DevActions.allowed(p)) DevActions.sendOpen(p);
        });
        c.setPacketHandled(true);
    }
}
