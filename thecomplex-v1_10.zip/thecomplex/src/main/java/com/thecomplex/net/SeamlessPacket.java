package com.thecomplex.net;

import com.thecomplex.client.SeamlessClient;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Server -> klien: sebentar lagi pemain dipindah lewat portal. Klien menyimpan bingkai terakhir dan menyembunyikan layar loading. */
public record SeamlessPacket(int style) {
    public static void encode(SeamlessPacket m, FriendlyByteBuf buf) {
        buf.writeVarInt(m.style);
    }

    public static SeamlessPacket decode(FriendlyByteBuf buf) {
        return new SeamlessPacket(buf.readVarInt());
    }

    public static void handle(SeamlessPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> SeamlessClient.begin(m.style)));
        ctx.get().setPacketHandled(true);
    }
}
