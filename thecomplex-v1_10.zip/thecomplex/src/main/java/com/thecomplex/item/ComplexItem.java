package com.thecomplex.item;

import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/** Item sederhana dengan satu baris keterangan (Flashlight Battery, Duct Tape, Rope). */
public class ComplexItem extends Item {
    private final String tip;

    public ComplexItem(Properties props, String tip) {
        super(props);
        this.tip = tip;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tips, TooltipFlag flag) {
        if (!tip.isEmpty()) tips.add(Component.literal(tip));
        if (stack.isDamageableItem()) {
            tips.add(Component.literal("Remaining: " + (stack.getMaxDamage() - stack.getDamageValue()) + " blocks"));
        }
    }
}
