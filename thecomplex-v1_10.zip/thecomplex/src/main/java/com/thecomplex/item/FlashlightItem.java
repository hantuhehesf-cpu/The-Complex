package com.thecomplex.item;

import com.thecomplex.ModItems;
import com.thecomplex.briefcase.BriefcaseConfig;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * Senter. Punya 2 slot baterai, 1 slot = (default) 7 menit.
 * Klik kanan: nyalakan/matikan. Klik kanan dengan Flashlight Battery di tangan lain: isi slot kosong.
 * Cahaya dibuat oleh FlashlightEvents (blok cahaya sementara di titik yang disorot).
 */
public class FlashlightItem extends Item {
    public static final int SLOTS = 2;

    public FlashlightItem(Properties props) {
        super(props);
    }

    public static int slotTicks() {
        return BriefcaseConfig.FLASHLIGHT_SLOT_MINUTES.get() * 60 * 20;
    }

    public static int maxCharge() {
        return slotTicks() * SLOTS;
    }

    public static int charge(ItemStack s) {
        return s.hasTag() ? s.getTag().getInt("Charge") : 0;
    }

    public static boolean isOn(ItemStack s) {
        return s.hasTag() && s.getTag().getBoolean("On");
    }

    public static ItemStack charged() {
        ItemStack s = new ItemStack(ModItems.FLASHLIGHT.get());
        s.getOrCreateTag().putInt("Charge", maxCharge());
        return s;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) return InteractionResultHolder.sidedSuccess(stack, true);

        ItemStack other = player.getItemInHand(hand == InteractionHand.MAIN_HAND ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND);
        CompoundTag t = stack.getOrCreateTag();
        if (other.is(ModItems.FLASHLIGHT_BATTERY.get())) {
            if (t.getInt("Charge") + slotTicks() <= maxCharge()) {
                t.putInt("Charge", t.getInt("Charge") + slotTicks());
                if (!player.getAbilities().instabuild) other.shrink(1);
                level.playSound(null, player.blockPosition(), SoundEvents.ARMOR_EQUIP_IRON, SoundSource.PLAYERS, 0.8f, 1.4f);
                player.displayClientMessage(Component.literal("Battery installed."), true);
            } else {
                player.displayClientMessage(Component.literal("Both battery slots are full."), true);
            }
            return InteractionResultHolder.consume(stack);
        }

        if (t.getInt("Charge") <= 0) {
            t.putBoolean("On", false);
            player.displayClientMessage(Component.literal("Out of battery. Hold a Flashlight Battery in your other hand and right-click."), true);
            level.playSound(null, player.blockPosition(), SoundEvents.LEVER_CLICK, SoundSource.PLAYERS, 0.4f, 0.6f);
            return InteractionResultHolder.consume(stack);
        }
        boolean on = !t.getBoolean("On");
        t.putBoolean("On", on);
        level.playSound(null, player.blockPosition(), SoundEvents.LEVER_CLICK, SoundSource.PLAYERS, 0.6f, on ? 1.4f : 1.0f);
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public boolean isBarVisible(ItemStack stack) {
        return true;
    }

    @Override
    public int getBarWidth(ItemStack stack) {
        return Math.round(13f * Math.min(charge(stack), maxCharge()) / maxCharge());
    }

    @Override
    public int getBarColor(ItemStack stack) {
        return charge(stack) > slotTicks() ? 0xFFD84A : 0xE8821E;
    }

    @Override
    public boolean shouldCauseReequipAnimation(ItemStack oldStack, ItemStack newStack, boolean slotChanged) {
        return slotChanged || oldStack.getItem() != newStack.getItem();
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tips, TooltipFlag flag) {
        int c = charge(stack);
        int filled = (c + slotTicks() - 1) / slotTicks();
        StringBuilder sb = new StringBuilder("Battery: ");
        for (int i = 0; i < SLOTS; i++) sb.append(i < filled ? "[#]" : "[ ]");
        int secs = c / 20;
        sb.append(String.format("  %d:%02d", secs / 60, secs % 60));
        tips.add(Component.literal(sb.toString()));
        tips.add(Component.literal("Right-click: on/off. Battery in your other hand: recharge."));
    }
}
