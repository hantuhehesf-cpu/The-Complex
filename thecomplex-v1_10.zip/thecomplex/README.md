# The Complex — Forge 1.20.1

Not compiled or tested in the authoring environment, so the first build may need small fixes (see "Most likely compile checks" at the end).
All player-facing text in the mod is American English.

## Build
GitHub Actions (`build.yml`). Java 17. The jar is the `thecomplex-jar` artifact.

## Schematics (WorldEdit `.schem`) live INSIDE the mod
- Bundled Main Chamber: `src/main/resources/data/thecomplex/schem/main_chamber.schem`
- Bundled rooms: `src/main/resources/data/thecomplex/schem/rooms/*.schem`
- Through GitHub: upload `.schem` files to the repo root (next to the ZIP). The workflow copies them into the mod automatically.
  A file named `mainchamber` / `main_chamber` / `Main Chamber` replaces the Main Chamber, any other name becomes a room.
- Quick test without rebuilding (optional): `config/thecomplex/main_chamber.schem` and `config/thecomplex/rooms/` win over the bundled ones.
  Empty them to go back to the bundled versions.
- Room rules: schematic point (0,0,0) = north-west corner of the floor; the lowest layer is the floor (y=16); maximum size 64x64
  (4x4 chunks); air height is free (3 to 6 or more). Blocks only (no entities or chest contents).
- The Main Chamber is chunk-aligned around (0,0). Openings in its outer wall (any position, width or height) lead straight into the Backrooms.
  A `thecomplex:threshold` block inside it is the door to the outside world; the arrival point is computed from its position.
  After replacing the Main Chamber, delete the `dimensions/thecomplex/the_complex` folder in the world save.

## Procedural Backrooms (rewritten generator)

Goal: dense, intentional, liminal. Full of architecture, empty of purpose, slightly wrong proportions, one mono-yellow palette.
Everything is deterministic from the single world seed, and every chunk is generated statelessly (no dependency on other chunks), so it is thread-safe and cheap on Android.

### Placement logic (`world/BackroomsDesigner.java`)
Room logic comes first, details last. Each 16x16 chunk is planned as a grid of 256 columns (wall, pillar, half pillar, vertical slab, doorway lintel,
left or right arch piece) and rendered to blocks by `ComplexChunkGenerator`. The ceiling is always flat (tile + fluorescent panels); there are no stepped ceilings, platforms or wedges in the generated halls.
1. **Edges.** A chunk owns its west and north wall; the east and south walls are owned by the neighbors, and both sides evaluate the same function, so openings always match.
   Doors are slightly off-scale: 3 to 6 blocks wide and a little off-center.
2. **Archetype.** One clear room type per chunk, chosen from the division's weights:
   pillar hall, colonnade with a nave, checkerboard hall, hall split by one partition with an arched door, corridor with a row of rooms on each side,
   gallery (rooms on one side, pillar hall on the other), junction (two corridors cross, four corner rooms), big room with a ring corridor.
3. **Doorways (v1.7).** A doorway is always 3 blocks tall. With 3 blocks of air (A, D, B, C) a door is a plain full-height gap, no lintel.
   With 4 blocks of air (F) a lintel row sits on top of the 3-block opening. A lintel that lost a post (landing strip or carved passage) is dropped
   (`finishDoorways`), so no beam floats in the air. Arch pieces are switched off (`BackroomsDesigner.ARCHES = false`).
4. **Landing strips.** The two cells in front of every door are always kept clear. Walls near hand-built rooms are cleared so every room door leads out.
5. **Pillars are rare (v1.6).** Only chunks that roll "pillars allowed" (`Division.pillarPct`: 10% in A/B, 8% in D, 22% in F, 0% in C) get any pillar or rib.
   There the pillars sit on the 4-cell lattice (cells 2, 6, 10, 14) and thin vertical-slab ribs line up with it. All other chunks use plain halls, partitions or a big room without pillars.
6. **Density pass.** Only in pillar chunks: a 5x5 window of bare floor gets a pillar on the lattice.
6b. **Variety (v1.7).** 40% of the generic layouts (partition halls, big room, empty hall) are swapped for one of four extra ones:
   a room standing in an empty hall (one or two doors), an L of wall (nook), a zigzag of two partitions with doors on opposite ends, a row of three alcoves.
7. **No long straight halls (v1.6).** Every 4th chunk line (shifted per row/column) is a "jog" line: its doors sit outside the usual door band (2-4 or 11-13 instead of 5-10)
   and a fully open edge becomes a door. Corridors only exist between two jog lines, so no hall is longer than about 4 chunks.
8. **Fewer openings (v1.6).** Fewer extra loops (10% / 8% instead of 22% / 25%) and `Division.openness` lowered, so rooms have about 2.3 doors on average.
9. **Connectivity guarantee.** See below.

### Density and connectivity
- Density is a hard rule of step 6 (offline test over 3 seeds: no chunk has an empty 5x5 window; about 77% of cells remain open floor, 14% walls).
- **Inside a chunk:** after every decoration step a flood fill checks that all doors reach each other and that no walkable cell is sealed off; a step that would break this is reverted.
  As a last resort, doors that still cannot reach each other get a carved 2-wide passage and every sealed pocket is filled in.
- **Between chunks:** the world is split into 8x8-chunk blocks. Inside a block, chunk links form a random spanning tree (each chunk links north OR west) plus extra random openings for loops.
  Every boundary between two blocks has at least one guaranteed gateway. So every chunk can reach every other chunk by construction
  (verified: 576 of 576 chunks reachable on each tested seed). Hand-built rooms are the one exception you control: a fully closed room with no doors can block its own chunks.

### Module library and rarity tags
The generator uses: Classic Wallpaper, Plain Office Wall (a lighter yellow) and White Office Wall, one per division (see below),
full wall blocks (rooms, corridors, lintels), pillars (lattice, rare), vertical slabs (thin wall ribs, rare), and the existing ceiling tile and fluorescent panel grid (3 blocks of air in Standard areas).
Half pillars, horizontal slabs, wedges, carpet wedges and half walls remain available as building blocks and for your hand-built rooms; the generator no longer scatters them.
Material consistency (v1.6): ONE wall material per division, no mixing inside it. Where two divisions with different materials meet, the wall is two blocks thick
(the outer layer shows the neighbor's material, the inner layer ours), so each room only ever sees its own material. White Office Wall exists only as a full block, so division C has no pillars or ribs.

Hand-built `.schem` rooms are the rare set-pieces (gallery, village street, living rooms, ...). The file name can end with two codes:
- `@` + division letters: `pitfalls@A.schem` (division A only), `office@AD.schem` (A and D). No `@` = every division.
- `#` + rarity: `#1` common (default), `#2` half as common as #1, `#3` a quarter, `#4` very rare, **`#5` = exactly one in the whole dimension**.
  A #5 room is placed in one slot chosen by the world seed, within 8 slots (about 512 blocks) of the origin, in a division its name allows.
- Examples: `village_street@A#2.schem`, `strange_door@F#5.schem`.
Each 4x4-chunk slot has a 30% chance to hold one room (`ComplexLayout.ROOM_CHANCE`). New rooms are simply dropped into the rooms folder; the generator core does not change.
The remaining chunk area around a room is filled with procedural Backrooms, so there is no void.

### Divisions
The world is split into 8x8-chunk regions called **divisions**. Each has a fixed wall material:

| Division | Name | Wall | Air | Region chance | Character |
|---|---|---|---|---|---|
| A | Standard | Classic Wallpaper | 3 | 36% | mix of patterns, normal lights, rare pillars |
| D | No Lighting Tile | Classic Wallpaper | 3 | 12% | no fluorescent panels at all |
| F | Wide Halls | Classic Wallpaper | 4 | 14% | wide halls (25% extra openings), 4 blocks of air, more pillars (v1.8: renamed from "Fragments"; the letter F is unchanged) |
| B | Plain Office Wall | Plain Office Wall | 3 | 24% | plain lighter-yellow walls |
| C | White Office Wall | White Office Wall | 3 | 14% | plain white walls, no pillars |

**B and C never appear near the Main Chamber**: within `Division.HOME_RADIUS` (24 chunks) of the chamber centre only A, D and F can appear
(their chances are rescaled to 100%). The ceiling height is constant within a division. Where heights or materials differ, the edge is a door or a wall, never fully open.
Settings live in `Division.java`.

### Null Zones and the LPMDS
Null Zones are not placed by the generator. Natural Null Zones appear only after an LPMDS has been opened in the world (`ActivityData`);
the Dev UI LPMDS tab has a "Natural Null Zones ON/OFF" toggle for testing. The generator only provides the architecture they hide in.

### Ambience
The fluorescent panel hum (`fluorescent_hum.ogg`) loops across The Complex. The current file is a 20.6-second seamless loop made from the
"Factory Fluorescent Light Buzz" recording (mono, 44.1 kHz, normalized, crackle bursts tamed). Base volume: `HumSound.VOLUME`.

## Activity and Null Zones
- Every 5 seconds in the Overworld, the chunk you are in is recorded (max 256 chunks per player, slowly decaying).
- Natural Null Zones **only appear after an LPMDS has been opened** in this world (stored in world data; toggle with Dev UI LPMDS tab, "Natural Null Zones ON/OFF").
  The Dev UI test buttons can still create one at any time.
- Null Zones are checked every 10 seconds; the chance rises from 1/360 (unfamiliar place) to 1/60 (a place you visit very often).
  They appear on indoor walls (1x2) or floors (2x2, two blocks deep), biased toward the chunks with the highest heat.
- A Null Zone disguises itself as the block it replaces (biome-tinted blocks such as grass are not used) and restores it after use or after 10 to 30 minutes.
  Ones placed by hand or from a `.schem` are permanent and look like wallpaper.
- **Entering (v1.8).** Touching a Null Zone gives a quick **white flash** (instant white, held until the new world has loaded, then a fast fade).
  Stepping into a **floor** Null Zone drops you into the Backrooms **through the ceiling**: a 3x3 hole opens in the ceiling above the arrival spot (plain ceiling tile
  and wall material only, never a light panel, so the lighting does not change), you start inside it and fall into the room without fall damage, and the hole closes
  again after 8 seconds. Wall Null Zones put you down standing (`ComplexTeleporter.CEILING_DROP_FOR_WALLS = true` makes them drop you through the ceiling too).
- **Mobs and items (v1.8).** Living entities (mobs, animals, villagers) and dropped items can walk or fall into an unstable Null Zone and arrive in the Backrooms
  (a floor Null Zone drops them through the ceiling too), and they use Stable Wild Null Zones in both directions. A Null Zone is used up by the first entity, like for a player.
  Passengers and vehicles, leashed mobs, bosses, and anything too big for the arrival spot are never moved.
- **Stable Wild Null Zones (v1.8).** The Overworld end can sit in any hostable block, cobblestone included (`NullZoneSpawner.canHostStable`).
  The Backrooms end is only placed in a solid wall block that is **3 blocks thick and 3 blocks long** (v1.9; it was 2 thick in v1.8): the portal cells sit in the middle,
  with wall on both sides and two more wall layers behind. Ones created before v1.9 are unchanged.
- **Placeable Null Zones (v1.9).** The Null Zone item (creative tabs "Building Blocks" and "Tools & Utilities", or Dev UI > Null Zones > Give Null Zone items):
  right-click the side of a block = wall Null Zone (1x2), top of a block = floor Null Zone (2x2, 2 deep, you fall through the Backrooms ceiling).
  The clicked block turns into a Null Zone that looks identical. It is permanent and never used up. Sneak + right-click it to turn it back. It does nothing inside The Complex.
- The Fragment system (captured Overworld buildings and trees pasted into the Backrooms) was **removed in v1.8**. Old `thecomplex_fragments` data in a world save is simply ignored.

## Developer UI (no commands)
Open it with the **Developer UI key (default K**, change it in Options > Controls > The Complex) or by right-clicking the **Complex Dev Tool** item
(creative tab "Tools & Utilities"). Operators or creative mode only. On Android, map the key to an on-screen button in your launcher's control editor.
- **Search bar** (already focused when the UI opens): type to filter every tool in every category live. Several words must all match (for example `null floor`).
  Up / Down moves the highlight, Enter runs it. Or tap / click a row.
- **Categories** on the left: All, Travel, Null Zones, Tracker (recent Null Zones: tap one to teleport), Rooms (one row per `.schem` room: tap to paste),
  LPMDS, Briefcase, Debug (chunk info = division and room template of the chunk you stand in, print status, refresh, creative/survival, heal).
- The last result is shown at the bottom. The search text, category and scroll position are kept after every action. Esc or the X button closes it.
While the Dev Tool is held, the action bar shows an arrow and distance to the nearest Null Zone,
and air cells touching a Null Zone within 40 blocks get light sparks. The old `/complex ...` commands still exist.

## LPMDS + Threshold (needs power)
1. Place the **LPMDS**. Connect a **Forge Energy (FE)** source to any side: an FE converter from Create: Power Grid, or another mod that outputs FE
   (e.g. a Create Crafts & Additions alternator). Power is stored in the machine (default 200,000 FE).
2. Attach an **LPMDS Emitter Chute** to the side of the machine. Right-click rotates clockwise (16 steps of 22.5 degrees), sneak + click (empty hand) counterclockwise.
   Step 0 = south, 4 = west, 8 = north, 12 = east.
3. Use the **Magnetic Marker**: right-click the LPMDS, then click two opposite corner cells of a frame 2 wide x 3 tall x 1 thick
   (the empty cell in front of the clicked face, like placing a block). Yellow lines = the frame, blue line = the link to the machine. Sneak + click clears the marking.
4. Right-click the LPMDS (empty hand) to start a test. If something is wrong (power, distance, blocked area), the machine explains it and the test does not count.
5. **Tests 1, 2 and 3 always fail** (a different effect each time: field collapse, phase surge, lock failed; camera shake, sound, particles and a log in chat).
   After an 8-second cooldown, try again. The number of failed tests and the cooldown are configurable.
6. The **final test** succeeds if power is sufficient (90,000 FE), the target area is clear, and the chute faces the frame (the nearest step toward the frame).
   The field beam shows the chute's real direction, so a miss is obvious. On success: a "THRESHOLD STABLE" screen, a flash, a long shake, and 6 Threshold blocks form.
   The Threshold stays open until closed (sneak + click, empty hand) or the machine is destroyed.
- Without a marked frame, the field follows the chute direction (or the machine's front if there is no chute) and opens a 3-block Threshold in front of it.
- Configuration: `config/thecomplex-common.toml` (requirePower, capacity, maxReceivePerTick, failedTestCost, finalTestCost, scriptedFailures, cooldownTicks, range).
  `requirePower=false` runs the machine without power.
- Power integration uses the Forge Energy interface (no compile-time dependency on Create or Power Grid). `create` and `powergrid` are optional dependencies in mods.toml.

## Building blocks (yellow palette)
Every yellow surface has two variants: **Classic Wallpaper** (`wallpaper`, striped pattern) and **Plain Office Wall** (`office_wall`, lighter plain yellow).
There is also **White Office Wall** (`white_wall`). All are in the Building Blocks creative tab.

| Part | Classic Wallpaper | Plain Office Wall |
|---|---|---|
| Full block | `wallpaper` | `office_wall` (+ `white_wall`) |
| Horizontal slab | `wallpaper_slab` | `office_wall_slab` |
| Vertical slab | `wallpaper_vertical_slab` | `office_wall_vertical_slab` |
| Arch (single block with a hole) | `wallpaper_arch` | `office_wall_arch` |
| Arch, left piece | `wallpaper_arch_left` | `office_wall_arch_left` |
| Arch, right piece | `wallpaper_arch_right` | `office_wall_arch_right` |
| Wedge / slope | `wallpaper_wedge` | `office_wall_wedge` |
| 12x12 pillar | `wallpaper_pillar` | `office_wall_pillar` |
| Half pillar (against a wall) | `wallpaper_half_pillar` | `office_wall_half_pillar` |
| Half wall (connecting) | `wallpaper_half_wall` | `office_wall_half_wall` |

Also: `carpet_wedge` (a wedge with carpet texture).
- Vertical slab: click the side of a block to attach to it; click the inner side with the same slab to merge into a full block.
- Arch: placed facing your view; a single block with an arched hole.
- Left Arch + Right Arch: place them side by side in the top layer of a 2-block-high doorway (facing = the direction you look through the door); the pair spans 2 blocks.
- Wedge: rises in the direction you face when placing; its collision is 8 steps of 2 pixels, so it is a smooth ramp.
- Half wall: a thin 12-pixel-high divider that connects automatically (tag `minecraft:walls`); can be jumped over.

## v1.8 notes
- **Lighting is vanilla.** `dimension_type/the_complex.json` now uses `ambient_light` 0.0 (the Overworld value; it was 0.1, the Nether value, which lifts every dark spot).
  Light levels of all blocks are unchanged. Nothing in v1.8 adds or removes light.
- **Threshold see-through void fixed.** The preview box on the far side of a Threshold now starts at the frame's own cell. Before, the floor and wall edges right at the frame
  were never drawn, and from up close that strip showed as a flat olive patch (the preview's clear color).

## v1.9 notes
- **New textures.** Ceiling tile: one tile per block, cut from the provided 5x5 tile sheet (4 slightly different tiles, picked at random per block).
  Fluorescent panel: a white diffuser in a thin metal frame on the same tile. Classic Wallpaper: staggered double chevrons with beaded stripes, recreated from
  the reference picture (the original file 39920.png did not arrive; send it again and it can be used pixel for pixel: it replaces `textures/block/wallpaper.png`).
- **New room templates** (they replace part of the generic halls): solid wall chunk with 3-wide tunnels from every door (about 1 chunk in 20), long plain hallway
  (two full-length walls with side doors), pilaster hall (wall stubs against two walls), bulkhead (a 3-thick partition with a tunnel) and a solid core in the middle of a hall.
  Dev UI > Debug > Chunk info tells you which template the chunk you stand in uses.
- **Far view fixes (Full portal mode).** Far terrain is now drawn as flat opaque map colors (leaves such as cherry leaves no longer show as ghostly translucent columns),
  and tiles whose chunk is not loaded yet are filled from their neighbors instead of leaving see-through holes in the skyline.
- Network protocol is now 5 (new packet for the Developer UI key): server and clients must both run v1.9.

## v1.10 notes
- **Portal full mode is ON by default** (`/complex portal full off` turns it off). The far "LOD" tiles are gone: the other side is drawn with real,
  textured blocks. The snapshot box is now 97 wide and 96 deep in the Overworld and follows the terrain (valleys, seabeds and hills are included), with a
  full 3D scan close to the frame and a surface scan farther out. Beyond the box you see the sky color, not blobs.
- **Light and water.** Every visible face gets the light of the other dimension (block light and sky light with the time of day), so dark rooms in the Complex look
  dark through the portal. Water and lava are drawn.
- **Entities.** Living entities (mobs, animals, other players with their skins) in the other dimension are drawn through the portal, updated every 3 ticks.
  They are "ghost" copies that only exist in the renderer, so they are static (no walking legs yet).
- **Interaction through the portal.** Looking through a Threshold window: attack hits entities on the other side, holding attack mines blocks there
  (creative breaks at once), right-click uses blocks (doors, levers, buttons), places blocks, or uses things on entities. Reach counts from you, so the distance to the window
  is used up. Menus (chests, furnaces) close at once. The portal view runs on a background thread for baking, and any render error switches only the part that failed off.
- **Null Zones.** Entities must be fully inside Null Zone blocks before they are moved (it looks like they vanish into a block without collision; entities too big to fit are moved after 3 seconds).
  Mob pathfinding treats a Null Zone like the solid block it pretends to be, so villagers and others path around and over it normally.
  Players see the dark "inside a block" texture of the disguised block when their eyes are inside an unstable Null Zone, then a white flash when the new world is there.
- **Fluorescent panels make the sound now.** The global hum of the dimension is gone. Each of the nearest 6 panels within 14 blocks plays its own positioned buzz
  (louder as you get close, works in any dimension).
- Network protocol is now 6.

## V1.5 Part I: Exploration Briefcase

New items (creative tab "Tools & Utilities", or Dev UI tab **Case** > "Give Briefcase set"): `briefcase`, `flashlight`, `flashlight_battery`,
`duct_tape`, `duct_anchor` (block, placeholder Grindstone model), `rope`. Settings: `config/thecomplex-briefcase.toml`.

**Using the Briefcase**
- Right-click (Briefcase in hand): open the inventory. The camera moves closer (FOV narrows) and the Briefcase opens from the center.
- Left-click: enter the **throw stance**. A **5-segment** bar appears below the crosshair. Set the value with the mouse wheel (the hotbar does not change during the stance)
  or by left-clicking repeatedly (5 wraps to 1; the easiest way on a touch screen). **Right-click = throw**, only while the bar is shown.
  Changing hotbar slot, ESC, or opening any screen cancels it.
- The physics imitate an **arrow / fishing bobber**: it flies along your full view direction (up or down), gravity pulls it, and it **sticks as soon as it hits something**
  (no bouncing, no tumbling; it only tilts along its flight direction). Flight distance is limited to 1.45 blocks per power level: power 5 is about 8 blocks (including a short slide), in any direction.
  On stairs and wedges it slides downhill. The simulation runs on both client and server (smooth), and resting Briefcases sleep.
- Right-click a Briefcase on the ground: open its inventory. Sneak + right-click: pick it up.
- Dev UI tab Case > "Recall Briefcases on the ground" returns every Briefcase within 48 blocks (if one gets stuck).

**Tetris-style inventory**: an 8-wide x 4-high grid (`rows` in the config, may be 3). Click an item in your inventory (gold highlight), then click a grid cell.
A green shadow means it fits, red means it does not. Click an item in the grid and then another cell to move it; click a slot in your inventory to take it out.
Shift + click puts it in the first free spot. The **Rope** slot on the right is for Rope only (every Briefcase has one).
Item sizes (width x height): Flashlight 1x2, Battery 1x1, Duct Tape 1x1, Duct Anchor 2x1, Rope 2x1, other items 1x1.
Items from other mods (camera, flares, radio) are sized in the config `extraSizes`, format `"modid:item=2x2"` (default example: `exposure:camera=2x2`).
Blocks cannot be stored (except the Duct Anchor). Rotating items is not implemented.

**Rope**: put a Rope in the Rope slot and throw the Briefcase. If it stops at an edge (the neighboring cell is open downward), the rope hangs from that edge,
at most 12 blocks (`ropeMaxLength`); water counts as the bottom. To grab it: stand close to the rope (0.6 blocks or less) and press **jump (climb) or sneak (descend)**.
Then: jump = climb, sneak = descend, no key = hang (0.25 blocks from the rope, so the rope does not clip through your body). **Pressing a movement key lets go.**
At the top, press jump or a movement key to vault onto the ledge next to the Briefcase. To go down from a ledge: step into the rope's column, then press sneak.
Walking past a rope no longer holds you in the air.

**Flashlight**: right-click = on/off. 2 battery slots, 1 slot = 7 minutes (`slotMinutes`). Recharge: hold a Flashlight Battery in your other hand and right-click.
The light is made by invisible light blocks at the point you aim at, only while the flashlight is held. Those blocks remove themselves if the game stops unexpectedly.

**Duct Tape** (a **block** on the floor, like Redstone: no clipping into the floor, breakable one by one, drops nothing):
1. Place a Duct Anchor, hold Duct Tape, right-click the anchor.
2. Walk in a STRAIGHT line away (the direction locks to the X or Z axis). Tape blocks are laid on the floor where you walk, 1 roll = 8 blocks (spare rolls in your inventory are used automatically). Straying more than 1 block off the line pauses the tape until you return.
3. Place the second anchor exactly in line with the first and right-click it: the last gap is filled and the tape is done.
Sneak + empty hand on an anchor reels in all tape attached to it. Cells without a solid floor (for example on top of a wedge) are skipped.

**Not implemented / good to know**
- No crafting recipes or loot yet: everything comes from creative or the Dev UI.
- Moving items inside the grid exists but is untested: if something goes wrong, take the item out and put it back.
- Rope: a dedicated server with `allow-flight=false` may kick a player hanging for more than 4 seconds. Singleplayer is fine.
- The Briefcase and flashlight models and textures are code-made placeholders (16x16).
- Entity Culling: if the rope still disappears, make sure `thecomplex:briefcase` is in that mod's skip/whitelist.

## V1.6: Seamless portals

Immersive Portals crashes on MobileGlues, so this is a workaround that needs no stencil buffer and no second world.

**How a crossing works (`portal/PortalSystem.java`).** Every tick the server follows each player's EYE. When the eye passes through the PLANE of a portal
(Threshold, Null Zone, Stable Wild Null Zone) the player is moved at once, from either side. The old "stand 8 ticks inside the block" rule remains only for Null Zone blocks
that carry no portal data (creative-placed, `.schem`, or from older saves).
`portal/Seamless.java` does the move: it makes sure the destination chunks are loaded, tells the client (`SeamlessPacket`), teleports, resets fall distance and re-sends the velocity.

**Threshold position, rotation, momentum (`ComplexTeleporter.throughThreshold`).** The player's position relative to the entered frame is carried to the exit frame,
rotated by the angle between "direction of travel" and "exit direction". View yaw and momentum rotate by the same angle, pitch is kept. Both directions work:
Overworld gate -> Main Chamber Threshold (exit towards the chamber centre); Main Chamber Threshold -> the gate the player came through, on the side they came from
(if that gate is gone: the remembered position / world spawn).

**No loading screen (`client/SeamlessClient.java`).** The "Loading terrain" screen is hidden for a few seconds after the server's notice. The last rendered frame is stored in a texture,
shown for about a quarter of a second and dissolved into the new world. Because the Threshold see-through already shows the other side, that frame is nearly the new view.

**Preloading (`portal/PortalPreloader.java`).** Within 20 blocks of a Threshold the destination chunks are loaded one per tick (no server hitch) and kept loaded with chunk tickets.
Within 14 blocks of a wild Null Zone the Backrooms destination is chosen in advance; Stable Wild Null Zones preload their far end.

**See-through (`portal/PortalView.java`, `client/PortalViewClient.java`).** The server sends a small snapshot of the other side (blocks in a 29 wide x 28 deep x 12 high box in front of the exit frame, only the visible faces).
The client turns it into quads, draws it from a "shadow camera" (the player camera moved through the portal) into a half-resolution texture, and pastes that texture onto the Threshold opening
using screen-space coordinates on a small grid. Only vanilla shaders are used. Safety: any error switches the effect off for the session; if the game stops while it is on, it is
off the next time (marker file `config/thecomplex-portalview.attempt`); `/complexview on|off|status` (client command, saved in `config/thecomplex-portalview.txt`).
Thresholds placed before this version are not in the registry (`PortalRegistry`), so they get preload and see-through only after the gate is opened again.

**Full mode (v1.7, off by default).** `/complex portal full on|off`, `/complex portal distance 8-12`, `/complex portal status` (op, saved per world, `portal/PortalSettings`).
When ON: the see-through box grows (Overworld 49x48 blocks and 31 tall, The Complex 65x96), in the Overworld the far terrain is sent as a grid of 4x4-block tiles
(`PortalFarPacket`, height + top block per tile) and drawn up to the chosen distance with a fade into the sky colour, the destination is refreshed about every 3 seconds
(far terrain every 30 seconds, or every 5 seconds while chunks are still loading), and a chunk ticket of the same radius keeps the other side loaded and ticking
(chunks within distance-2 get entity ticking: mobs move, crops grow) while a player is within 20 blocks of a portal. Mobs are not drawn (that needs a second client world).
Heavy for an integrated server on a phone. The default (OFF) keeps the small box (29 wide, 28 deep).
Fixes in v1.7: the window is clipped against the camera near plane (it no longer vanishes when you stand close and turn a little), a view is only drawn while the
Threshold blocks still exist (no ghost after the gate closes), and the static geometry is baked once into GPU buffers instead of re-sent every frame.

**Null Zones.** A portal sits invisibly behind the no-collision mimic wall (or below the mimic floor). Walls: the plane is the middle of the wall block. Floors: the plane is 0.25 block under the surface.
Floor entries arrive just under the Backrooms ceiling and drop one block. Null Zones may now appear on any full solid block (all woods, cobblestone family, stone, bricks, house floors),
on Dirt and Grass Block outdoors (never on natural tree trunks, huge mushrooms, or under a tree canopy: `NullZoneSpawner.isTreeLike`; house logs are fine) (client tint handler `ClientSetup.onBlockColors` copies the grass colour), and on some occasions grow (up to 3 rings, either on a timer or after being used).

**Stable Wild Null Zone (`portal/WildPortals.java`).** About 3% of wall placements (or Dev UI "Stable Wild Null Zone" / `/complex spawnwild`). Permanent, cannot be mined in survival,
two-way. Its other end is a similar wall far inside The Complex (14+ chunks from the Main Chamber). At most 6 pairs per world (`WildPortals.MAX_PAIRS`); data is in `WildPortalData`.

New client command: `/complexview`. New server commands: `/complex spawnwild`, `/complex spawnground`.

## Most likely compile checks
- v1.8: `Entity.changeDimension(ServerLevel, ITeleporter)` with an overridden `ITeleporter.getPortalInfo`, `PortalInfo(Vec3, Vec3, float, float)`, `Entity.canChangeDimensions()`,
  `Entity.xo/yo/zo`, `Entity.fallDistance`, `Mob.isLeashed()`, `Level.hasChunkAt(BlockPos)` on the client, `GuiGraphics.fill`
- v1.7: `VertexBuffer` (constructor with `Usage.STATIC`, `upload(BufferBuilder.RenderedBuffer)`, `drawWithShader(Matrix4f, Matrix4f, ShaderInstance)`, `close`), `RenderSystem.getShader`,
  `IntegerArgumentType`, `LeavesBlock.PERSISTENT`, `BlockTags.DIRT`, `ChunkAccess.getHeight(Heightmap.Types, int, int)`
- v1.6 portals: `ScreenEvent.Opening.setNewScreen`, `RenderTarget.blitToScreen`, `TextureTarget` (constructor, `setFilterMode`), `RenderSystem.getModelViewStack` + `PoseStack.setIdentity/mulPoseMatrix`,
  `BufferUploader.drawWithShader`, `RenderLevelStageEvent.getProjectionMatrix`, `Camera.getLookVector`, `TicketType.PORTAL` + `ServerChunkCache.addRegionTicket`,
  `Level.noCollision(Entity, AABB)`, `Direction.getNearest(double,double,double)`, `Block.BLOCK_STATE_REGISTRY`, `BakedQuad.getVertices/isTinted/getTintIndex`,
  `RegisterColorHandlersEvent.Block`, `RegisterClientCommandsEvent`
- `RandomState.getOrCreateRandomFactory`, `Heightmap.primeHeightmaps`, `ViewportEvent.RenderFog`
- `BlockStateParser.parseForBlock`, `NbtIo.readCompressed`, `NbtUtils.readBlockState`, `SavedData`
- `IModFile.findResource` (SchemStore), `ModelEvent.ModifyBakingResult` and `BakedModelWrapper` (MimicModel)
- `Screen.rebuildWidgets` (DevScreen), `AbstractTickableSoundInstance` (HumSound)
- Briefcase: `ItemRenderer.renderStatic` + `ItemDisplayContext`, `RenderLevelStageEvent`, `InputEvent.InteractionKeyMappingTriggered`/`MouseScrollingEvent`,
  `RegisterGuiOverlaysEvent`, `NetworkHooks.getEntitySpawningPacket`, `BlockBehaviour.Properties.replaceable()`, `ItemProperties.register`,
  `Entity.getBoundingBoxForCulling`, `ArchPieceBlock` shapes
- Generator: `WallBlock.UP/NORTH_WALL...` and `WallSide` (half-wall states), `SlabBlock.TYPE`, `VerticalSlabBlock.FACING`
- LPMDS: `ForgeCapabilities.ENERGY` + `LazyOptional`, `ForgeConfigSpec`, screen title packet (`ClientboundSetTitleTextPacket`), `SoundEvents.WARDEN_SONIC_CHARGE`

## Next phase
V1.5 Part II, then entities (Lifeform, then Still Lifes).
