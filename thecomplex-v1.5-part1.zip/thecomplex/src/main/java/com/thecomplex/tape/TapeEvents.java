package com.thecomplex.tape;

import com.thecomplex.ModItems;
import com.thecomplex.TheComplex;
import com.thecomplex.net.Net;
import com.thecomplex.net.TapeSyncPacket;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Alur Duct Tape:
 *  1. Pegang Duct Tape, klik kanan anchor awal: sesi dimulai.
 *  2. Jalan LURUS (satu sumbu). Tape muncul bertahap di lantai di belakangmu, 1 roll = 8 blok.
 *  3. Pasang anchor kedua tepat sejajar, klik kanan: tape terpasang.
 */
@Mod.EventBusSubscriber(modid = TheComplex.MODID)
public final class TapeEvents {
    private static final Map<UUID, UUID> SESSIONS = new HashMap<>();   // pemain -> id tape
    private static final Map<UUID, Long> WARNED = new HashMap<>();

    private TapeEvents() {}

    public static void msg(ServerPlayer p, String text) {
        p.displayClientMessage(Component.literal("[Tape] " + text), true);
    }

    public static UUID sessionOf(ServerPlayer p) {
        return SESSIONS.get(p.getUUID());
    }

    public static void begin(ServerPlayer p, TapeData.Tape t) {
        SESSIONS.put(p.getUUID(), t.id);
    }

    public static void end(ServerPlayer p) {
        SESSIONS.remove(p.getUUID());
    }

    public static void syncAll(ServerLevel level) {
        Net.CHANNEL.send(PacketDistributor.DIMENSION.with(level::dimension), new TapeSyncPacket(TapeData.get(level).views()));
    }

    public static void syncTo(ServerPlayer p) {
        Net.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), new TapeSyncPacket(TapeData.get(p.serverLevel()).views()));
    }

    /** Pakai 1 blok dari roll mana pun yang dibawa (tangan dulu). false = tidak ada roll. */
    public static boolean consumeUnit(ServerPlayer p) {
        ItemStack main = p.getMainHandItem(), off = p.getOffhandItem();
        if (main.is(ModItems.DUCT_TAPE.get())) return use(p, main);
        if (off.is(ModItems.DUCT_TAPE.get())) return use(p, off);
        for (int i = 0; i < p.getInventory().items.size(); i++) {
            ItemStack s = p.getInventory().items.get(i);
            if (s.is(ModItems.DUCT_TAPE.get())) return use(p, s);
        }
        return false;
    }

    private static boolean use(ServerPlayer p, ItemStack roll) {
        roll.hurtAndBreak(1, p, x -> {});
        return true;
    }

    /** Dipanggil saat blok anchor dihancurkan: tape yang menempel padanya ikut hilang. */
    public static void anchorRemoved(ServerLevel level, BlockPos pos) {
        TapeData d = TapeData.get(level);
        TapeData.Tape t;
        boolean changed = false;
        while ((t = d.touching(pos)) != null) {
            final UUID id = t.id;
            SESSIONS.values().removeIf(v -> v.equals(id));
            d.remove(t);
            changed = true;
        }
        if (changed) syncAll(level);
    }

    @SubscribeEvent
    public static void onTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p)) return;
        UUID tid = SESSIONS.get(p.getUUID());
        if (tid == null) return;
        ServerLevel level = p.serverLevel();
        TapeData d = TapeData.get(level);
        TapeData.Tape t = d.find(tid);
        if (t == null || t.b != null) {
            SESSIONS.remove(p.getUUID());
            return;
        }

        double dx = p.getX() - (t.a.getX() + 0.5), dz = p.getZ() - (t.a.getZ() + 0.5);
        if (t.axis < 0) {
            if (Math.max(Math.abs(dx), Math.abs(dz)) < 1.3) return;
            if (Math.abs(dx) >= Math.abs(dz)) {
                t.axis = 0;
                t.dir = dx > 0 ? 1 : -1;
            } else {
                t.axis = 1;
                t.dir = dz > 0 ? 1 : -1;
            }
            d.setDirty();
        }
        double along = (t.axis == 0 ? dx : dz) * t.dir;
        double lat = t.axis == 0 ? dz : dx;
        if (Math.abs(lat) > 1.0) {
            long now = p.level().getGameTime();
            if (now - WARNED.getOrDefault(p.getUUID(), -100L) > 60) {
                WARNED.put(p.getUUID(), now);
                msg(p, "Keluar jalur: tape berhenti. Kembali ke garis lurus dari anchor awal.");
            }
            return;
        }
        int want = Math.min(TapeData.MAX_LEN, (int) Math.floor(along - 0.3));
        boolean changed = false;
        while (t.ys.size() < want) {
            if (!consumeUnit(p)) {
                long now = p.level().getGameTime();
                if (now - WARNED.getOrDefault(p.getUUID(), -100L) > 60) {
                    WARNED.put(p.getUUID(), now);
                    msg(p, "Roll habis. Pegang atau bawa Duct Tape lain, atau pasang anchor kedua.");
                }
                break;
            }
            t.ys.add((float) p.getY());
            changed = true;
        }
        if (changed) {
            d.setDirty();
            syncAll(level);
        }
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) syncTo(p);
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) syncTo(p);
    }

    @SubscribeEvent
    public static void onDimension(PlayerEvent.PlayerChangedDimensionEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) {
            SESSIONS.remove(p.getUUID());
            syncTo(p);
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        SESSIONS.remove(e.getEntity().getUUID());
        WARNED.remove(e.getEntity().getUUID());
    }
}
