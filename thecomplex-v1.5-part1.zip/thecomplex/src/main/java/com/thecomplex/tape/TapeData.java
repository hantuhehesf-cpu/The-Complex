package com.thecomplex.tape;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Semua Duct Tape di satu dimensi. Disimpan di data dunia. */
public class TapeData extends SavedData {
    public static final int MAX_LEN = 64;

    public static class Tape {
        public UUID id = UUID.randomUUID();
        public BlockPos a;
        public int axis = -1;   // 0 = sumbu X, 1 = sumbu Z, -1 = belum terkunci
        public int dir;         // +1 / -1
        public List<Float> ys = new ArrayList<>();
        public BlockPos b;      // anchor kedua (null = belum selesai)

        public TapeView view() {
            float[] arr = new float[ys.size()];
            for (int i = 0; i < arr.length; i++) arr[i] = ys.get(i);
            return new TapeView(a, axis, dir, arr, b);
        }
    }

    public final List<Tape> tapes = new ArrayList<>();

    public static TapeData get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(TapeData::load, TapeData::new, "thecomplex_tape");
    }

    public Tape find(UUID id) {
        for (Tape t : tapes) if (t.id.equals(id)) return t;
        return null;
    }

    public Tape startingAt(BlockPos pos) {
        for (Tape t : tapes) if (t.a.equals(pos)) return t;
        return null;
    }

    public Tape touching(BlockPos pos) {
        for (Tape t : tapes) if (t.a.equals(pos) || pos.equals(t.b)) return t;
        return null;
    }

    public Tape start(BlockPos a) {
        Tape t = new Tape();
        t.a = a;
        tapes.add(t);
        setDirty();
        return t;
    }

    public void remove(Tape t) {
        tapes.remove(t);
        setDirty();
    }

    public List<TapeView> views() {
        List<TapeView> out = new ArrayList<>();
        for (Tape t : tapes) out.add(t.view());
        return out;
    }

    @Override
    public CompoundTag save(CompoundTag root) {
        ListTag list = new ListTag();
        for (Tape t : tapes) {
            CompoundTag c = new CompoundTag();
            c.putUUID("id", t.id);
            c.putLong("a", t.a.asLong());
            c.putInt("axis", t.axis);
            c.putInt("dir", t.dir);
            int[] bits = new int[t.ys.size()];
            for (int i = 0; i < bits.length; i++) bits[i] = Float.floatToIntBits(t.ys.get(i));
            c.putIntArray("ys", bits);
            if (t.b != null) c.putLong("b", t.b.asLong());
            list.add(c);
        }
        root.put("tapes", list);
        return root;
    }

    public static TapeData load(CompoundTag root) {
        TapeData d = new TapeData();
        ListTag list = root.getList("tapes", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag c = list.getCompound(i);
            Tape t = new Tape();
            t.id = c.getUUID("id");
            t.a = BlockPos.of(c.getLong("a"));
            t.axis = c.getInt("axis");
            t.dir = c.getInt("dir");
            for (int bits : c.getIntArray("ys")) t.ys.add(Float.intBitsToFloat(bits));
            if (c.contains("b")) t.b = BlockPos.of(c.getLong("b"));
            d.tapes.add(t);
        }
        return d;
    }
}
