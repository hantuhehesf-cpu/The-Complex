package com.thecomplex.tape;

import net.minecraft.core.BlockPos;

/** Bentuk ringkas Duct Tape yang dikirim ke klien. ys[i] = tinggi permukaan lantai pada langkah ke-(i+1). */
public record TapeView(BlockPos a, int axis, int dir, float[] ys, BlockPos b) {}
