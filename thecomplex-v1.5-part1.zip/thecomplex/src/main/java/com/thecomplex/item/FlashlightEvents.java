package com.thecomplex.item;

import com.thecomplex.ModBlocks;
import com.thecomplex.ModItems;
import com.thecomplex.TheComplex;
import com.thecomplex.block.FlashlightGlowBlock;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Senter yang menyala: menguras baterai (dicatat per detik) dan menaruh blok cahaya sementara di titik yang disorot.
 * Cahaya hanya dibuat saat senter dipegang (tangan utama atau kiri).
 */
@Mod.EventBusSubscriber(modid = TheComplex.MODID)
public final class FlashlightEvents {
    private record Glow(ResourceKey<Level> dim, Map<BlockPos, Integer> cells) {}

    private static final Map<UUID, Glow> ACTIVE = new HashMap<>();
    private static final int FLAGS = Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE;

    private FlashlightEvents() {}

    public static boolean isActive(ServerLevel level, BlockPos pos) {
        for (Glow g : ACTIVE.values()) {
            if (g.dim == level.dimension() && g.cells.containsKey(pos)) return true;
        }
        return false;
    }

    private static boolean lit(ItemStack s) {
        return s.is(ModItems.FLASHLIGHT.get()) && FlashlightItem.isOn(s);
    }

    @SubscribeEvent
    public static void onTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p)) return;
        ItemStack fl = lit(p.getMainHandItem()) ? p.getMainHandItem() : lit(p.getOffhandItem()) ? p.getOffhandItem() : ItemStack.EMPTY;
        if (fl.isEmpty()) {
            clear(p);
            if (p.tickCount % 20 == 0) shutOthers(p);
            return;
        }
        CompoundTag t = fl.getTag();
        if (p.tickCount % 20 == 0) {
            int c = t.getInt("Charge") - 20;
            if (c <= 0) {
                t.putInt("Charge", 0);
                t.putBoolean("On", false);
                p.level().playSound(null, p.blockPosition(), SoundEvents.LEVER_CLICK, SoundSource.PLAYERS, 0.6f, 0.6f);
                clear(p);
                return;
            }
            t.putInt("Charge", c);
        }
        if (p.tickCount % 4 == 0) updateGlow(p);
    }

    /** Senter yang masih "On" tapi tidak dipegang dimatikan. */
    private static void shutOthers(ServerPlayer p) {
        for (ItemStack s : p.getInventory().items) {
            if (lit(s)) s.getTag().putBoolean("On", false);
        }
    }

    private static void put(ServerLevel level, Map<BlockPos, Integer> cells, Vec3 at, int lvl) {
        BlockPos bp = BlockPos.containing(at);
        BlockState st = level.getBlockState(bp);
        if (st.isAir() || st.is(ModBlocks.FLASHLIGHT_GLOW.get())) cells.merge(bp, lvl, Math::max);
    }

    private static void updateGlow(ServerPlayer p) {
        ServerLevel level = p.serverLevel();
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        double reach = 14.0;
        BlockHitResult hit = level.clip(new ClipContext(eye, eye.add(look.scale(reach)),
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        double dist = hit.getType() == HitResult.Type.MISS ? reach : eye.distanceTo(hit.getLocation());

        Map<BlockPos, Integer> cells = new HashMap<>();
        put(level, cells, eye.add(look.scale(Math.min(2.5, dist * 0.5))), 8);
        put(level, cells, eye.add(look.scale(dist * 0.5)), 10);
        put(level, cells, eye.add(look.scale(Math.max(0.0, dist - 0.45))), 13);

        Glow old = ACTIVE.get(p.getUUID());
        if (old != null) {
            ServerLevel oldLevel = old.dim == level.dimension() ? level : p.server.getLevel(old.dim);
            if (oldLevel != null) {
                for (BlockPos bp : old.cells.keySet()) {
                    if (old.dim != level.dimension() || !cells.containsKey(bp)) removeGlow(oldLevel, bp);
                }
            }
        }
        for (Map.Entry<BlockPos, Integer> en : cells.entrySet()) {
            BlockState cur = level.getBlockState(en.getKey());
            if (cur.is(ModBlocks.FLASHLIGHT_GLOW.get()) && cur.getValue(FlashlightGlowBlock.LEVEL) == en.getValue()) continue;
            level.setBlock(en.getKey(), ModBlocks.FLASHLIGHT_GLOW.get().defaultBlockState()
                    .setValue(FlashlightGlowBlock.LEVEL, en.getValue()), FLAGS);
        }
        ACTIVE.put(p.getUUID(), new Glow(level.dimension(), cells));
    }

    private static void removeGlow(ServerLevel level, BlockPos pos) {
        if (level.getBlockState(pos).is(ModBlocks.FLASHLIGHT_GLOW.get())) {
            level.setBlock(pos, Blocks.AIR.defaultBlockState(), FLAGS);
        }
    }

    private static void clear(ServerPlayer p) {
        Glow g = ACTIVE.remove(p.getUUID());
        if (g == null) return;
        ServerLevel level = p.server.getLevel(g.dim);
        if (level == null) return;
        for (BlockPos bp : g.cells.keySet()) removeGlow(level, bp);
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) clear(p);
    }
}
