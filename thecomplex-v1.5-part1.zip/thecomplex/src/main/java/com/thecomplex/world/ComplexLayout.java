package com.thecomplex.world;

import com.thecomplex.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.levelgen.PositionalRandomFactory;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Zona tetap dan ruangan buatan.
 *
 * Main Chamber:
 *  - Kalau ada config/thecomplex/main_chamber.schem, itu yang dipakai, ditaruh sejajar chunk di sekitar (0,0).
 *    Bukaan di dinding luarmu (posisi mana pun, lebar dan tinggi bebas) langsung tembus ke Backrooms.
 *    Blok thecomplex:threshold di dalamnya menjadi pintu keluar; titik tiba dihitung dari posisinya.
 *  - Kalau tidak ada, dipakai placeholder (96x96, pilar cruciform, meja maket) dengan satu Threshold
 *    di dinding selatan. Tidak ada hallway: Threshold satu-satunya pintu.
 *
 * Ruangan: config/thecomplex/rooms/*.schem disisipkan ke grid Backrooms. Dunia dibagi jadi slot
 * SLOT x SLOT chunk; tiap slot punya peluang ROOM_CHANCE persen berisi satu ruangan, dengan posisi
 * sejajar chunk. Titik (0,0,0) schematic = sudut barat laut lantai, lapisan paling bawah = lantai (y=16).
 */
public final class ComplexLayout {
    public static final int FLOOR_Y = 16;      // lapisan karpet
    public static final int CEIL_Y = 20;       // langit-langit Backrooms (udara y=17..19, tinggi 3 blok)
    public static final int MAIN_CEIL_Y = 21;  // langit-langit Main Chamber placeholder (udara 4 blok)
    public static final int TOP_Y = 31;        // atas dimensi (bedrock di atas langit-langit)

    /** Panjang tiap lengan pilar cruciform placeholder di luar pusat 3x3. Lebar lengan = 3. */
    public static final int PILLAR_ARM_LEN = 3;

    /** Ukuran slot ruangan (dalam chunk) dan peluang satu slot berisi ruangan. */
    public static final int SLOT = 4;
    public static final int ROOM_CHANCE = 30;
    /** Ruangan unik (#5) ditaruh di salah satu slot dalam jarak ini (dalam slot) dari titik (0,0). */
    public static final int UNIQUE_RADIUS = 8;

    public record RoomPlacement(Schem room, int minCx, int minCz, int wc, int lc) {
        public boolean contains(int cx, int cz) {
            return cx >= minCx && cx < minCx + wc && cz >= minCz && cz < minCz + lc;
        }
    }

    private record Box(int x1, int y1, int z1, int x2, int y2, int z2, BlockState state) {}

    private static final List<Box> BOXES = new ArrayList<>();
    private static volatile boolean built;
    private static Schem custom;
    private static int customOx, customOz;
    private static int mainMinCx = -3, mainMaxCx = 2, mainMinCz = -3, mainMaxCz = 2;
    private static BlockPos thresholdPos;
    private static BlockState AIR, WALL, CARPET, TILE, LIGHT;

    private ComplexLayout() {}

    // ------------------------------------------------------------------ API

    /** Chunk milik Main Chamber (dan lapisan padat di sekelilingnya). */
    public static boolean reserved(int cx, int cz) {
        ensureBuilt();
        return cx >= mainMinCx && cx <= mainMaxCx && cz >= mainMinCz && cz <= mainMaxCz;
    }

    public static boolean hasCustomMainChamber() {
        ensureBuilt();
        return custom != null;
    }

    /** Titik tengah Main Chamber (dunia), dipakai untuk menentukan arah hadap saat tiba. */
    public static double chamberCenterX() {
        ensureBuilt();
        return custom != null ? customOx + custom.width / 2.0 : 0;
    }

    public static double chamberCenterZ() {
        ensureBuilt();
        return custom != null ? customOz + custom.length / 2.0 : 0;
    }

    /** Tinggi lapisan padat dasar di chunk Main Chamber. */
    public static int reservedTop() {
        ensureBuilt();
        return custom != null ? TOP_Y - 1 : MAIN_CEIL_Y;
    }

    /** Posisi dunia pusat blok Threshold di Main Chamber, atau null kalau main_chamber.schem tidak punya. */
    public static BlockPos thresholdPos() {
        ensureBuilt();
        return thresholdPos;
    }

    public static void apply(ChunkAccess chunk) {
        ensureBuilt();
        if (custom != null) {
            custom.placeInChunk(chunk, customOx, FLOOR_Y, customOz);
            return;
        }
        int x0 = chunk.getPos().getMinBlockX(), z0 = chunk.getPos().getMinBlockZ();
        int x1 = x0 + 15, z1 = z0 + 15;
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (Box b : BOXES) {
            if (b.x2() < x0 || b.x1() > x1 || b.z2() < z0 || b.z1() > z1) continue;
            int ax = Math.max(b.x1(), x0), bx = Math.min(b.x2(), x1);
            int az = Math.max(b.z1(), z0), bz = Math.min(b.z2(), z1);
            for (int x = ax; x <= bx; x++)
                for (int z = az; z <= bz; z++)
                    for (int y = b.y1(); y <= b.y2(); y++)
                        chunk.setBlockState(p.set(x, y, z), b.state(), false);
        }
    }

    // ------------------------------------------------------------------ ruangan di grid prosedural

    private static final Map<PositionalRandomFactory, Map<String, int[]>> UNIQUE_CACHE =
            Collections.synchronizedMap(new WeakHashMap<>());

    public static RoomPlacement roomFor(PositionalRandomFactory f, int slotX, int slotZ) {
        List<Schem> all = SchemStore.rooms();
        if (all.isEmpty()) return null;

        // ruangan unik (#5): tepat satu di seluruh dimensi, di slot yang ditentukan seed dunia
        for (Schem s : all) {
            if (!s.isUnique()) continue;
            int[] u = uniqueSlot(f, s);
            if (u[0] == slotX && u[1] == slotZ) return place(f, s, slotX, slotZ);
        }

        // slot (4 chunk) selalu berada di dalam satu divisi (8 chunk)
        Division div = Division.at(f, slotX * SLOT, slotZ * SLOT);
        List<Schem> rooms = new ArrayList<>();
        int total = 0;
        for (Schem s : all) {
            if (s.isUnique() || !s.allowedIn(div.id)) continue;
            rooms.add(s);
            total += s.weight();
        }
        if (rooms.isEmpty()) return null;
        RandomSource r = f.at(slotX, 5, slotZ);
        if (r.nextInt(100) >= ROOM_CHANCE) return null;
        int roll = r.nextInt(total);
        Schem chosen = rooms.get(rooms.size() - 1);
        for (Schem s : rooms) {
            roll -= s.weight();
            if (roll < 0) {
                chosen = s;
                break;
            }
        }
        return place(f, chosen, slotX, slotZ);
    }

    /** Posisi ruangan di dalam slot (sejajar chunk). Null kalau menabrak Main Chamber atau tidak muat. */
    private static RoomPlacement place(PositionalRandomFactory f, Schem s, int slotX, int slotZ) {
        int wc = (s.width + 15) / 16, lc = (s.length + 15) / 16;
        if (wc > SLOT || lc > SLOT) return null;
        RandomSource r = f.at(slotX, 12, slotZ);
        int ox = r.nextInt(SLOT - wc + 1), oz = r.nextInt(SLOT - lc + 1);
        int minCx = slotX * SLOT + ox, minCz = slotZ * SLOT + oz;
        for (int cx = minCx; cx < minCx + wc; cx++)
            for (int cz = minCz; cz < minCz + lc; cz++)
                if (reserved(cx, cz)) return null;
        return new RoomPlacement(s, minCx, minCz, wc, lc);
    }

    /** Slot tunggal untuk ruangan unik. Deterministik dari seed dunia, jadi tidak perlu disimpan. */
    private static int[] uniqueSlot(PositionalRandomFactory f, Schem s) {
        Map<String, int[]> perWorld;
        synchronized (UNIQUE_CACHE) {
            perWorld = UNIQUE_CACHE.computeIfAbsent(f, k -> new ConcurrentHashMap<>());
        }
        return perWorld.computeIfAbsent(s.name, k -> computeUnique(f, s));
    }

    private static int[] computeUnique(PositionalRandomFactory f, Schem s) {
        int h = s.name.hashCode();
        for (int i = 0; i < 256; i++) {
            RandomSource r = f.at(h, 78, i);
            int sx = r.nextInt(2 * UNIQUE_RADIUS + 1) - UNIQUE_RADIUS;
            int sz = r.nextInt(2 * UNIQUE_RADIUS + 1) - UNIQUE_RADIUS;
            if (!s.allowedIn(Division.at(f, sx * SLOT, sz * SLOT).id)) continue;
            if (place(f, s, sx, sz) == null) continue;
            return new int[]{sx, sz};
        }
        return new int[]{Integer.MIN_VALUE, Integer.MIN_VALUE};
    }

    public static RoomPlacement roomAt(PositionalRandomFactory f, int cx, int cz) {
        RoomPlacement rp = roomFor(f, Math.floorDiv(cx, SLOT), Math.floorDiv(cz, SLOT));
        return (rp != null && rp.contains(cx, cz)) ? rp : null;
    }

    /**
     * Kotak (minX, maxX, minZ, maxZ) ruangan buatan dan Main Chamber buatan yang berada di chunk (cx,cz) atau tetangganya.
     * Dipakai generator supaya jalur masuk/keluar ruangan tidak terhalang tembok atau pilar prosedural.
     */
    public static List<int[]> boxesNear(PositionalRandomFactory f, int cx, int cz) {
        ensureBuilt();
        List<int[]> out = new ArrayList<>();
        if (custom != null && cx + 1 >= mainMinCx && cx - 1 <= mainMaxCx && cz + 1 >= mainMinCz && cz - 1 <= mainMaxCz) {
            out.add(new int[]{customOx, customOx + custom.width - 1, customOz, customOz + custom.length - 1});
        }
        Set<Long> seen = new HashSet<>();
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                RoomPlacement rp = roomAt(f, cx + dx, cz + dz);
                if (rp == null || !seen.add(((long) rp.minCx() << 32) ^ (rp.minCz() & 0xFFFFFFFFL))) continue;
                int minX = rp.minCx() * 16, minZ = rp.minCz() * 16;
                out.add(new int[]{minX, minX + rp.room().width - 1, minZ, minZ + rp.room().length - 1});
            }
        }
        return out;
    }

    // ------------------------------------------------------------------ build

    private static void ensureBuilt() {
        if (!built) build();
    }

    private static synchronized void build() {
        if (built) return;
        SchemStore.load();
        Schem s = SchemStore.mainChamber();
        if (s != null) buildCustom(s);
        else buildPlaceholder();
        built = true;
    }

    private static void buildCustom(Schem s) {
        custom = s;
        // sejajar chunk dan sedekat mungkin ke (0,0), supaya pintu offset 6..9 cocok dengan grid Backrooms
        int wc = (s.width + 15) / 16, lc = (s.length + 15) / 16;
        mainMinCx = -Math.floorDiv(wc, 2);
        mainMinCz = -Math.floorDiv(lc, 2);
        mainMaxCx = mainMinCx + wc - 1;
        mainMaxCz = mainMinCz + lc - 1;
        customOx = mainMinCx * 16;
        customOz = mainMinCz * 16;

        Block thr = ModBlocks.THRESHOLD.get();
        int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE, minZ = Integer.MAX_VALUE;
        int maxX = Integer.MIN_VALUE, maxY = Integer.MIN_VALUE, maxZ = Integer.MIN_VALUE;
        boolean found = false;
        for (int y = 0; y < s.height; y++)
            for (int z = 0; z < s.length; z++)
                for (int x = 0; x < s.width; x++)
                    if (s.get(x, y, z).is(thr)) {
                        found = true;
                        minX = Math.min(minX, customOx + x); maxX = Math.max(maxX, customOx + x);
                        minY = Math.min(minY, FLOOR_Y + y);  maxY = Math.max(maxY, FLOOR_Y + y);
                        minZ = Math.min(minZ, customOz + z); maxZ = Math.max(maxZ, customOz + z);
                    }
        thresholdPos = found
                ? new BlockPos(Math.floorDiv(minX + maxX, 2), Math.floorDiv(minY + maxY, 2), Math.floorDiv(minZ + maxZ, 2))
                : null;
    }

    private static void box(int x1, int y1, int z1, int x2, int y2, int z2, BlockState s) {
        BOXES.add(new Box(Math.min(x1, x2), Math.min(y1, y2), Math.min(z1, z2),
                Math.max(x1, x2), Math.max(y1, y2), Math.max(z1, z2), s));
    }

    private static BlockState b(Block block) {
        return block.defaultBlockState();
    }

    private static void buildPlaceholder() {
        AIR = Blocks.AIR.defaultBlockState();
        WALL = b(ModBlocks.WALLPAPER.get());
        CARPET = b(ModBlocks.CARPET_FLOOR.get());
        TILE = b(ModBlocks.CEILING_TILE.get());
        LIGHT = b(ModBlocks.FLUORESCENT_PANEL.get());

        box(-47, FLOOR_Y, -47, 46, FLOOR_Y, 46, CARPET);
        box(-47, 17, -47, 46, MAIN_CEIL_Y - 1, 46, AIR);
        box(-47, MAIN_CEIL_Y, -47, 46, MAIN_CEIL_Y, 46, TILE);
        for (int x = -44; x <= 44; x += 8)
            for (int z = -44; z <= 44; z += 8)
                box(x, MAIN_CEIL_Y, z, x + 1, MAIN_CEIL_Y, z, LIGHT);

        // pilar cruciform: pusat 3x3, 4 lengan lebar 3 sepanjang PILLAR_ARM_LEN
        int[] pc = {-32, -16, 16, 32};
        for (int px : pc) {
            for (int pz : pc) {
                box(px - 1 - PILLAR_ARM_LEN, 17, pz - 1, px + 1 + PILLAR_ARM_LEN, MAIN_CEIL_Y - 1, pz + 1, WALL);
                box(px - 1, 17, pz - 1 - PILLAR_ARM_LEN, px + 1, MAIN_CEIL_Y - 1, pz + 1 + PILLAR_ARM_LEN, WALL);
            }
        }

        // meja maket di tengah
        BlockState table = b(Blocks.DARK_OAK_PLANKS);
        BlockState yellow = b(Blocks.YELLOW_TERRACOTTA);
        box(-9, 17, -4, 8, 17, 3, table);
        for (int x = -8; x <= 7; x++) {
            for (int z = -3; z <= 2; z++) {
                int h = Math.floorMod((x * 73 + z * 151) ^ (x * z), 9);
                if (h < 3) box(x, 18, z, x, 18, z, yellow);
                if (h == 0) box(x, 19, z, x, 19, z, yellow);
            }
        }

        // Threshold: satu-satunya pintu, tengah dinding selatan
        BlockState iron = b(Blocks.IRON_BLOCK);
        BlockState threshold = b(ModBlocks.THRESHOLD.get());
        box(-2, 17, 47, -2, 20, 47, iron);
        box(1, 17, 47, 1, 20, 47, iron);
        box(-2, 20, 47, 1, 20, 47, iron);
        box(-1, 17, 47, 0, 19, 47, threshold);
        thresholdPos = new BlockPos(0, 18, 47);
    }
}
