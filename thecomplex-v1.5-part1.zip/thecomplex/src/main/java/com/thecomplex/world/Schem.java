package com.thecomplex.world;

import com.thecomplex.TheComplex;
import net.minecraft.commands.arguments.blocks.BlockStateParser;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtIo;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Pembaca .schem WorldEdit (format Sponge v2 dan v3). Hanya blok; entitas dan block entity diabaikan.
 * Offset di dalam file diabaikan: titik (0,0,0) schematic = sudut barat laut di lapisan lantai.
 */
public final class Schem {
    public final String name;
    /** Huruf divisi yang boleh memuat ruangan ini (dari nama@CD.schem); kosong = semua divisi. */
    public final String divisions;
    /** Kelangkaan dari nama file (#1..#5). 1 = biasa; makin besar makin langka; 5 = hanya satu di seluruh dimensi. */
    public final int rarity;
    public final int width;    // sumbu X
    public final int height;   // sumbu Y
    public final int length;   // sumbu Z
    private final BlockState[] palette;
    private final int[] data;  // indeks = (y * length + z) * width + x

    private Schem(String name, int w, int h, int l, BlockState[] palette, int[] data) {
        this.name = name;
        java.util.regex.Matcher dm = java.util.regex.Pattern.compile("@([A-Za-z]+)").matcher(name);
        this.divisions = dm.find() ? dm.group(1).toUpperCase().replaceAll("[^A-F]", "") : "";
        java.util.regex.Matcher rm = java.util.regex.Pattern.compile("#([1-5])").matcher(name);
        this.rarity = rm.find() ? Integer.parseInt(rm.group(1)) : 1;
        this.width = w;
        this.height = h;
        this.length = l;
        this.palette = palette;
        this.data = data;
    }

    public boolean isUnique() {
        return rarity >= 5;
    }

    /** Bobot pemilihan relatif: #1 = 12, #2 = 6, #3 = 3, #4 = 1. (#5 ditangani terpisah sebagai ruangan unik.) */
    public int weight() {
        return switch (rarity) {
            case 1 -> 12;
            case 2 -> 6;
            case 3 -> 3;
            default -> 1;
        };
    }

    public boolean allowedIn(char division) {
        return divisions.isEmpty() || divisions.indexOf(Character.toUpperCase(division)) >= 0;
    }

    public BlockState get(int x, int y, int z) {
        return palette[data[(y * length + z) * width + x]];
    }

    public static Schem read(Path file) throws IOException {
        String name = file.getFileName().toString().replaceFirst("(?i)\\.schem$", "");
        CompoundTag root;
        try (InputStream in = Files.newInputStream(file)) {
            root = NbtIo.readCompressed(in);
        }
        if (root.contains("Schematic", Tag.TAG_COMPOUND)) root = root.getCompound("Schematic");

        int w = root.getShort("Width") & 0xFFFF;
        int h = root.getShort("Height") & 0xFFFF;
        int l = root.getShort("Length") & 0xFFFF;

        CompoundTag palTag;
        byte[] raw;
        if (root.contains("Blocks", Tag.TAG_COMPOUND)) {          // v3
            CompoundTag blocks = root.getCompound("Blocks");
            palTag = blocks.getCompound("Palette");
            raw = blocks.getByteArray("Data");
        } else {                                                    // v2
            palTag = root.getCompound("Palette");
            raw = root.getByteArray("BlockData");
        }
        if (w <= 0 || h <= 0 || l <= 0 || palTag.isEmpty()) throw new IOException("schematic kosong atau formatnya tidak dikenali");

        int size = 0;
        for (String key : palTag.getAllKeys()) size = Math.max(size, palTag.getInt(key) + 1);
        BlockState[] palette = new BlockState[size];
        java.util.Arrays.fill(palette, Blocks.AIR.defaultBlockState());
        for (String key : palTag.getAllKeys()) palette[palTag.getInt(key)] = parse(key, name);

        int[] data = new int[w * h * l];
        int i = 0;
        for (int n = 0; n < data.length; n++) {
            int v = 0, shift = 0;
            while (true) {
                if (i >= raw.length) throw new IOException("BlockData terlalu pendek");
                int b = raw[i++];
                v |= (b & 0x7F) << shift;
                if ((b & 0x80) == 0) break;
                shift += 7;
            }
            if (v >= size) throw new IOException("indeks palette di luar batas");
            data[n] = v;
        }
        return new Schem(name, w, h, l, palette, data);
    }

    private static BlockState parse(String s, String schem) {
        try {
            return BlockStateParser.parseForBlock(BuiltInRegistries.BLOCK.asLookup(), s, false).blockState();
        } catch (Exception e) {
            TheComplex.LOGGER.warn("[thecomplex] {}: blok tidak dikenal '{}', diganti udara", schem, s);
            return Blocks.AIR.defaultBlockState();
        }
    }

    /** Tempel bagian schematic yang jatuh di dalam chunk ini. (ox, oy, oz) = posisi dunia titik (0,0,0). */
    public void placeInChunk(ChunkAccess chunk, int ox, int oy, int oz) {
        int cx0 = chunk.getPos().getMinBlockX(), cz0 = chunk.getPos().getMinBlockZ();
        int minX = Math.max(ox, cx0), maxX = Math.min(ox + width - 1, cx0 + 15);
        int minZ = Math.max(oz, cz0), maxZ = Math.min(oz + length - 1, cz0 + 15);
        if (minX > maxX || minZ > maxZ) return;
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (int y = 0; y < height; y++) {
            int wy = oy + y;
            if (wy < 0 || wy >= ComplexLayout.TOP_Y) continue;
            for (int z = minZ; z <= maxZ; z++)
                for (int x = minX; x <= maxX; x++)
                    chunk.setBlockState(p.set(x, wy, z), get(x - ox, y, z - oz), false);
        }
    }

    /** Untuk perintah /complex room: tempel langsung ke dunia. */
    public void placeInLevel(ServerLevel level, BlockPos origin) {
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (int y = 0; y < height; y++)
            for (int z = 0; z < length; z++)
                for (int x = 0; x < width; x++)
                    level.setBlock(p.set(origin.getX() + x, origin.getY() + y, origin.getZ() + z), get(x, y, z), 2);
    }
}
