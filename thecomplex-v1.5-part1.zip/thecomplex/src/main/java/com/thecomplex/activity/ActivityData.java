package com.thecomplex.activity;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Peta "heat" per pemain: seberapa lama pemain berada di tiap chunk Overworld.
 * Kecil (maksimal MAX_CHUNKS entri per pemain), disimpan di data dunia.
 */
public class ActivityData extends SavedData {
    public static final int MAX_CHUNKS = 256;
    public static final float MAX_HEAT = 2000f;
    /** Pelapukan per sampel (5 detik): paruh waktu sekitar 5 jam bermain. */
    private static final float DECAY = 0.9998f;

    private final Map<UUID, Map<Long, Float>> heat = new HashMap<>();
    /** Null Zone alami baru boleh muncul setelah sebuah LPMDS berhasil dibuka di dunia ini. */
    private boolean activated;

    public static ActivityData get(ServerLevel overworld) {
        return overworld.getDataStorage().computeIfAbsent(ActivityData::load, ActivityData::new, "thecomplex_activity");
    }

    public boolean isActivated() {
        return activated;
    }

    public void setActivated(boolean value) {
        if (activated != value) {
            activated = value;
            setDirty();
        }
    }

    public Map<Long, Float> of(UUID id) {
        return heat.computeIfAbsent(id, k -> new HashMap<>());
    }

    public float heatAt(UUID id, ChunkPos pos) {
        return of(id).getOrDefault(pos.toLong(), 0f);
    }

    /** Catat satu sampel: pemain sedang berada di chunk ini. */
    public void sample(UUID id, ChunkPos pos) {
        Map<Long, Float> m = of(id);
        m.replaceAll((k, v) -> v * DECAY);
        m.values().removeIf(v -> v < 0.05f);
        m.merge(pos.toLong(), 1.0f, (a, b) -> Math.min(MAX_HEAT, a + b));
        if (m.size() > MAX_CHUNKS) {
            List<Map.Entry<Long, Float>> sorted = new ArrayList<>(m.entrySet());
            sorted.sort(Map.Entry.comparingByValue());
            int remove = m.size() - (MAX_CHUNKS - 32);
            for (int i = 0; i < remove; i++) m.remove(sorted.get(i).getKey());
        }
        setDirty();
    }

    /** Untuk pengujian: tambah heat langsung di satu chunk. */
    public void boost(UUID id, ChunkPos pos, float amount) {
        of(id).merge(pos.toLong(), amount, (a, b) -> Math.min(MAX_HEAT, a + b));
        setDirty();
    }

    public void clear(UUID id) {
        of(id).clear();
        setDirty();
    }

    public List<Map.Entry<Long, Float>> top(UUID id, int n) {
        List<Map.Entry<Long, Float>> list = new ArrayList<>(of(id).entrySet());
        list.sort((a, b) -> Float.compare(b.getValue(), a.getValue()));
        return list.size() > n ? list.subList(0, n) : list;
    }

    // ------------------------------------------------------------ penyimpanan

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag players = new ListTag();
        for (Map.Entry<UUID, Map<Long, Float>> p : heat.entrySet()) {
            CompoundTag pt = new CompoundTag();
            pt.putUUID("id", p.getKey());
            ListTag chunks = new ListTag();
            for (Map.Entry<Long, Float> e : p.getValue().entrySet()) {
                CompoundTag ct = new CompoundTag();
                ct.putLong("c", e.getKey());
                ct.putFloat("s", e.getValue());
                chunks.add(ct);
            }
            pt.put("chunks", chunks);
            players.add(pt);
        }
        tag.put("players", players);
        tag.putBoolean("activated", activated);
        return tag;
    }

    public static ActivityData load(CompoundTag tag) {
        ActivityData d = new ActivityData();
        d.activated = tag.getBoolean("activated");
        ListTag players = tag.getList("players", Tag.TAG_COMPOUND);
        for (int i = 0; i < players.size(); i++) {
            CompoundTag pt = players.getCompound(i);
            Map<Long, Float> m = d.of(pt.getUUID("id"));
            ListTag chunks = pt.getList("chunks", Tag.TAG_COMPOUND);
            for (int j = 0; j < chunks.size(); j++) {
                CompoundTag ct = chunks.getCompound(j);
                m.put(ct.getLong("c"), ct.getFloat("s"));
            }
        }
        return d;
    }
}
