package com.thecomplex.activity;

import com.thecomplex.TheComplex;
import com.thecomplex.fragment.FragmentCapture;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Mencatat di mana pemain paling lama berada (Overworld saja) dan memakai catatan itu untuk
 * menentukan seberapa sering Null Zone muncul di sekitarnya.
 */
@Mod.EventBusSubscriber(modid = TheComplex.MODID)
public final class ActivityTracker {
    public static final int SAMPLE_INTERVAL = 100;   // tick (5 detik)
    public static final int CHECK_INTERVAL = 200;    // tick (10 detik)

    /** Heat chunk yang dianggap "penuh" (sekitar 20 menit berdiam di sana). */
    public static final float HEAT_FULL = 240f;
    /** Peluang per pengecekan: di tempat asing vs di tempat yang sangat sering didatangi. */
    public static final double CHANCE_COLD = 1.0 / 360;   // rata-rata sekitar 1 jam
    public static final double CHANCE_HOT = 1.0 / 60;     // rata-rata sekitar 10 menit
    /** Tiap pengecekan (10 detik), 1 dari N kemungkinan menangkap satu fragmen Overworld di sekitar pemain (~5 menit). */
    public static final int AUTO_CAPTURE_ONE_IN = 30;

    private ActivityTracker() {}

    public static double chance(float heatHere) {
        double frac = Math.min(1.0, heatHere / HEAT_FULL);
        return CHANCE_COLD + (CHANCE_HOT - CHANCE_COLD) * frac;
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p)) return;
        if (p.isSpectator() || p.level().dimension() != Level.OVERWORLD) return;
        if (p.tickCount % SAMPLE_INTERVAL != 0) return;

        ServerLevel level = p.serverLevel();
        ActivityData data = ActivityData.get(level);
        data.sample(p.getUUID(), p.chunkPosition());

        if (p.tickCount % CHECK_INTERVAL != 0) return;
        float h = data.heatAt(p.getUUID(), p.chunkPosition());
        if (data.isActivated() && p.getRandom().nextDouble() < chance(h)) NullZoneSpawner.spawnFor(p, data);
        if (p.getRandom().nextInt(AUTO_CAPTURE_ONE_IN) == 0) FragmentCapture.captureAuto(p);
    }
}
