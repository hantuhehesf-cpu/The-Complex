package com.thecomplex.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.thecomplex.TheComplex;
import com.thecomplex.tape.TapeView;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

import java.util.List;

/** Menggambar Duct Tape sebagai pita rata di lantai, satu segmen per blok. */
@Mod.EventBusSubscriber(modid = TheComplex.MODID, value = Dist.CLIENT)
public final class TapeRenderer {
    public static volatile List<TapeView> TAPES = List.of();
    private static final ResourceLocation TEX = new ResourceLocation(TheComplex.MODID, "textures/entity/tape.png");
    private static final float HALF_W = 0.075f;

    private TapeRenderer() {}

    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) return;
        List<TapeView> tapes = TAPES;
        if (tapes.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        Level level = mc.level;
        if (level == null) return;
        Vec3 cam = e.getCamera().getPosition();
        PoseStack ps = e.getPoseStack();
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        RenderType type = RenderType.entityCutoutNoCull(TEX);
        VertexConsumer vc = buffers.getBuffer(type);

        ps.pushPose();
        ps.translate(-cam.x, -cam.y, -cam.z);
        Matrix4f m = ps.last().pose();
        Matrix3f n = ps.last().normal();
        double maxDist2 = 96.0 * 96.0;
        for (TapeView t : tapes) {
            if (t.axis() < 0) continue;
            double ax = t.a().getX() + 0.5, az = t.a().getZ() + 0.5;
            if (cam.distanceToSqr(ax, cam.y, az) > maxDist2 + t.ys().length * t.ys().length * 4.0) continue;
            for (int i = 0; i < t.ys().length; i++) {
                float y = t.ys()[i] + 0.02f;
                double s0 = i, s1 = i + 1;
                double x0, x1, z0, z1;
                if (t.axis() == 0) {
                    x0 = ax + s0 * t.dir();
                    x1 = ax + s1 * t.dir();
                    z0 = az - HALF_W;
                    z1 = az + HALF_W;
                } else {
                    z0 = az + s0 * t.dir();
                    z1 = az + s1 * t.dir();
                    x0 = ax - HALF_W;
                    x1 = ax + HALF_W;
                }
                double mx = (x0 + x1) * 0.5, mz = (z0 + z1) * 0.5;
                if (cam.distanceToSqr(mx, cam.y, mz) > maxDist2) continue;
                int light = LevelRenderer.getLightColor(level, BlockPos.containing(mx, y + 0.1, mz));
                float fx0 = (float) x0, fx1 = (float) x1, fz0 = (float) z0, fz1 = (float) z1;
                // u searah panjang pita
                if (t.axis() == 0) {
                    vertex(vc, m, n, fx0, y, fz0, 0f, 0f, light);
                    vertex(vc, m, n, fx0, y, fz1, 1f, 0f, light);
                    vertex(vc, m, n, fx1, y, fz1, 1f, 1f, light);
                    vertex(vc, m, n, fx1, y, fz0, 0f, 1f, light);
                } else {
                    vertex(vc, m, n, fx0, y, fz0, 0f, 0f, light);
                    vertex(vc, m, n, fx1, y, fz0, 1f, 0f, light);
                    vertex(vc, m, n, fx1, y, fz1, 1f, 1f, light);
                    vertex(vc, m, n, fx0, y, fz1, 0f, 1f, light);
                }
            }
        }
        ps.popPose();
        buffers.endBatch(type);
    }

    private static void vertex(VertexConsumer vc, Matrix4f m, Matrix3f n, float x, float y, float z, float u, float v, int light) {
        vc.vertex(m, x, y, z).color(255, 255, 255, 255).uv(u, v)
                .overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(n, 0f, 1f, 0f).endVertex();
    }
}
