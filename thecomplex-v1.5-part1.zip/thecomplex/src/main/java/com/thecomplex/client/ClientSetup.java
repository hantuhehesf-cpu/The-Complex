package com.thecomplex.client;

import com.thecomplex.ModEntities;
import com.thecomplex.ModItems;
import com.thecomplex.TheComplex;
import com.thecomplex.item.FlashlightItem;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.item.ItemProperties;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

/** Pendaftaran sisi klien: renderer Briefcase, HUD posisi lempar, properti model senter. */
@Mod.EventBusSubscriber(modid = TheComplex.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientSetup {
    private ClientSetup() {}

    @SubscribeEvent
    public static void onRenderers(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(ModEntities.BRIEFCASE.get(), BriefcaseRenderer::new);
    }

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent e) {
        e.enqueueWork(() -> ItemProperties.register(ModItems.FLASHLIGHT.get(), new ResourceLocation(TheComplex.MODID, "lit"),
                (stack, level, entity, seed) -> FlashlightItem.isOn(stack) ? 1f : 0f));
    }

    @SubscribeEvent
    public static void onOverlays(RegisterGuiOverlaysEvent e) {
        e.registerAboveAll("throw_bar", (gui, g, partial, w, h) -> drawThrowBar(g, w, h));
    }

    private static void drawThrowBar(GuiGraphics g, int w, int h) {
        if (!ThrowClient.active) return;
        net.minecraft.client.gui.Font font = net.minecraft.client.Minecraft.getInstance().font;
        int bw = 10 * 12, x = w / 2 - bw / 2, y = h / 2 + 22;
        g.fill(x - 3, y - 14, x + bw + 1, y + 24, 0xA0000000);
        g.drawCenteredString(font, "Kekuatan lempar: " + ThrowClient.power + " / 10", w / 2, y - 11, 0xFFFFFF);
        for (int i = 1; i <= 10; i++) {
            float k = (i - 1) / 9f;
            int r = (int) (70 + 185 * k), gr = (int) (220 - 150 * k);
            int color = i <= ThrowClient.power ? 0xFF000000 | (r << 16) | (gr << 8) | 0x40 : 0xFF333333;
            g.fill(x + (i - 1) * 12, y, x + (i - 1) * 12 + 10, y + 8, color);
        }
        // penggeser: penanda di segmen terpilih
        int sx = x + (ThrowClient.power - 1) * 12;
        g.fill(sx - 1, y + 10, sx + 11, y + 12, 0xFFFFFFFF);
        g.fill(sx + 3, y + 8, sx + 7, y + 10, 0xFFFFFFFF);
        g.drawCenteredString(font, "Klik kanan: lempar", w / 2, y + 14, 0xE0E0E0);
    }
}
