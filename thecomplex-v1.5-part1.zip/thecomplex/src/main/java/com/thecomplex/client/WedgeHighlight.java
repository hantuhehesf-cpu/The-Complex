package com.thecomplex.client;

import com.thecomplex.TheComplex;
import com.thecomplex.block.WedgeBlock;
import net.minecraft.client.Minecraft;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderHighlightEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Tidak menggambar garis sorot (kotak hitam) di sekitar blok baji saat pemain mengarahkan pandangan ke sana. */
@Mod.EventBusSubscriber(modid = TheComplex.MODID, value = Dist.CLIENT)
public final class WedgeHighlight {
    private WedgeHighlight() {}

    @SubscribeEvent
    public static void onHighlight(RenderHighlightEvent.Block e) {
        Level level = Minecraft.getInstance().level;
        if (level != null && level.getBlockState(e.getTarget().getBlockPos()).getBlock() instanceof WedgeBlock) {
            e.setCanceled(true);
        }
    }
}
