package com.thecomplex.block;

import com.thecomplex.ModItems;
import com.thecomplex.tape.TapeData;
import com.thecomplex.tape.TapeEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

import java.util.UUID;

/** Duct Tape Anchor (placeholder: model Grindstone). Titik awal dan akhir Duct Tape. */
public class DuctAnchorBlock extends Block {
    public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;
    private static final VoxelShape SHAPE = Block.box(2, 0, 2, 14, 14, 14);

    public DuctAnchorBlock(Properties props) {
        super(props);
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.NORTH));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        return defaultBlockState().setValue(FACING, ctx.getHorizontalDirection().getOpposite());
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return SHAPE;
    }

    @Override
    public boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
        return level.getBlockState(pos.below()).isFaceSturdy(level, pos.below(), Direction.UP);
    }

    @Override
    public BlockState updateShape(BlockState state, Direction dir, BlockState neighbor, LevelAccessor level, BlockPos pos, BlockPos neighborPos) {
        if (dir == Direction.DOWN && !state.canSurvive(level, pos)) return Blocks.AIR.defaultBlockState();
        return super.updateShape(state, dir, neighbor, level, pos, neighborPos);
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moving) {
        if (!level.isClientSide && !state.is(newState.getBlock()) && level instanceof ServerLevel sl) {
            TapeEvents.anchorRemoved(sl, pos);
        }
        super.onRemove(state, level, pos, newState, moving);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide) return InteractionResult.SUCCESS;
        if (!(player instanceof ServerPlayer p) || !(level instanceof ServerLevel sl)) return InteractionResult.PASS;
        // satu tangan saja, supaya tidak diproses dua kali
        if (hand != InteractionHand.MAIN_HAND) return InteractionResult.CONSUME;

        TapeData d = TapeData.get(sl);
        UUID tid = TapeEvents.sessionOf(p);
        TapeData.Tape active = tid == null ? null : d.find(tid);
        if (tid != null && active == null) {
            TapeEvents.end(p);
        }
        ItemStack held = p.getMainHandItem();

        if (active == null) {
            TapeData.Tape existing = d.touching(pos);
            if (p.isShiftKeyDown() && held.isEmpty() && existing != null) {
                d.remove(existing);
                TapeEvents.syncAll(sl);
                TapeEvents.msg(p, "Tape digulung kembali.");
            } else if (held.is(ModItems.DUCT_TAPE.get())) {
                if (existing != null && existing.b == null) {
                    TapeEvents.begin(p, existing);
                    TapeEvents.msg(p, "Melanjutkan tape. Jalan lurus.");
                } else if (existing != null) {
                    TapeEvents.msg(p, "Anchor ini sudah punya tape. Sneak + tangan kosong untuk menggulungnya.");
                } else {
                    TapeData.Tape t = d.start(pos);
                    TapeEvents.begin(p, t);
                    TapeEvents.syncAll(sl);
                    TapeEvents.msg(p, "Tape dimulai. Jalan LURUS, lalu pasang anchor kedua sejajar.");
                }
            } else {
                TapeEvents.msg(p, "Pegang Duct Tape lalu klik kanan anchor untuk memulai.");
            }
            return InteractionResult.CONSUME;
        }

        // sesi aktif: anchor ini akan jadi ujung tape
        TapeData.Tape t = active;
        if (pos.equals(t.a)) {
            TapeEvents.msg(p, "Ini anchor awal. Jalan lurus lalu pasang anchor kedua.");
            return InteractionResult.CONSUME;
        }
        if (t.axis < 0) {
            TapeEvents.msg(p, "Jalan dulu menjauhi anchor awal supaya arah tape terkunci.");
            return InteractionResult.CONSUME;
        }
        int ddx = pos.getX() - t.a.getX(), ddz = pos.getZ() - t.a.getZ();
        int along = (t.axis == 0 ? ddx : ddz) * t.dir;
        int lat = t.axis == 0 ? ddz : ddx;
        if (lat != 0) {
            TapeEvents.msg(p, "Anchor tidak sejajar dengan anchor awal. Pindahkan sampai lurus.");
        } else if (along < 1) {
            TapeEvents.msg(p, "Anchor harus ada di depan, searah tape.");
        } else if (along > t.ys.size() + 3) {
            TapeEvents.msg(p, "Terlalu jauh: tape baru sampai " + t.ys.size() + " blok. Lanjutkan jalan.");
        } else {
            boolean ok = true;
            while (t.ys.size() < along) {
                if (!TapeEvents.consumeUnit(p)) {
                    ok = false;
                    break;
                }
                t.ys.add((float) pos.getY());
            }
            if (!ok) {
                TapeEvents.msg(p, "Roll habis sebelum sampai. Bawa Duct Tape lain.");
                d.setDirty();
                TapeEvents.syncAll(sl);
            } else {
                t.b = pos;
                d.setDirty();
                TapeEvents.end(p);
                TapeEvents.syncAll(sl);
                TapeEvents.msg(p, "Tape terpasang (" + t.ys.size() + " blok).");
            }
        }
        return InteractionResult.CONSUME;
    }
}
