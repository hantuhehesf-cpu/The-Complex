package com.thecomplex;

import com.thecomplex.briefcase.BriefcaseEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, TheComplex.MODID);

    public static final RegistryObject<EntityType<BriefcaseEntity>> BRIEFCASE = ENTITIES.register("briefcase",
            () -> EntityType.Builder.<BriefcaseEntity>of(BriefcaseEntity::new, MobCategory.MISC)
                    .sized(0.6f, 0.3f).clientTrackingRange(8).updateInterval(1).fireImmune().build("briefcase"));

    private ModEntities() {}
}
