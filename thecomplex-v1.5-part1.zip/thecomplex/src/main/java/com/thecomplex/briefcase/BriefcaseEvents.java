package com.thecomplex.briefcase;

import com.thecomplex.TheComplex;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Sisi server: pemain di tali tidak mengumpulkan jarak jatuh; sesi inventori dibersihkan saat keluar. */
@Mod.EventBusSubscriber(modid = TheComplex.MODID)
public final class BriefcaseEvents {
    private BriefcaseEvents() {}

    @SubscribeEvent
    public static void onTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p) || p.tickCount % 2 != 0) return;
        if (RopeHelper.find(p) != null) p.fallDistance = 0f;
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        BriefcaseSessions.forget(e.getEntity().getUUID());
    }
}
