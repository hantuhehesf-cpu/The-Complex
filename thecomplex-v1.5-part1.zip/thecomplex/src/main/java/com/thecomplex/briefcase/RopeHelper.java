package com.thecomplex.briefcase;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

import java.util.List;

/** Menentukan apakah pemain sedang berada di tali yang menggantung dari sebuah Briefcase. Dipakai klien dan server. */
public final class RopeHelper {
    public record Hit(BriefcaseEntity entity, double top, double bottom, double x, double z) {}

    private RopeHelper() {}

    public static Hit find(Player p) {
        Level level = p.level();
        List<BriefcaseEntity> list = level.getEntitiesOfClass(BriefcaseEntity.class, p.getBoundingBox().inflate(1.0, 14.0, 1.0));
        for (BriefcaseEntity e : list) {
            float len = e.getRopeLen();
            if (len < 0.5f) continue;
            double top = e.getRopeTop();
            double bottom = top - len;
            double dx = p.getX() - e.getRopeX(), dz = p.getZ() - e.getRopeZ();
            if (dx * dx + dz * dz > 0.55 * 0.55) continue;
            double y = p.getY();
            if (y < bottom - 0.3 || y > top + 0.9) continue;
            return new Hit(e, top, bottom, e.getRopeX(), e.getRopeZ());
        }
        return null;
    }
}
