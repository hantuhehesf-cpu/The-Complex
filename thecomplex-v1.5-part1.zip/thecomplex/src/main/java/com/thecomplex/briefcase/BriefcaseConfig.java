package com.thecomplex.briefcase;

import net.minecraftforge.common.ForgeConfigSpec;

import java.util.List;

/** Pengaturan Briefcase, senter, tali. File: config/thecomplex-briefcase.toml */
public final class BriefcaseConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.IntValue ROWS;
    public static final ForgeConfigSpec.IntValue ROPE_MAX;
    public static final ForgeConfigSpec.IntValue FLASHLIGHT_SLOT_MINUTES;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> EXTRA_SIZES;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.comment("Exploration Briefcase").push("briefcase");
        ROWS = b.comment("Tinggi grid inventori Briefcase (lebar selalu 8). 3 atau 4.")
                .defineInRange("rows", 4, 3, 4);
        ROPE_MAX = b.comment("Panjang maksimum tali (blok).")
                .defineInRange("ropeMaxLength", 12, 2, 24);
        EXTRA_SIZES = b.comment("Ukuran item mod lain di grid, format \"modid:item=LebarxTinggi\". Contoh: \"exposure:camera=2x2\".",
                        "Item tanpa data ukuran dianggap 1x1. Blok (BlockItem) tidak boleh masuk, kecuali Duct Anchor.")
                .defineList("extraSizes", List.of("exposure:camera=2x2"), o -> o instanceof String);
        b.pop();
        b.comment("Senter").push("flashlight");
        FLASHLIGHT_SLOT_MINUTES = b.comment("Lama satu slot baterai (menit). Senter punya 2 slot.")
                .defineInRange("slotMinutes", 7, 1, 120);
        b.pop();
        SPEC = b.build();
    }

    private BriefcaseConfig() {}
}
