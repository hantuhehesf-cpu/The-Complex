package com.thecomplex.briefcase;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;

/** Isi Briefcase disimpan di NBT item: Briefcase{ Items:[{x,y,Item}], Rope:{...} }. */
public final class BriefcaseData {
    public static final int COLS = 8;

    private BriefcaseData() {}

    public static final class Entry {
        public int x, y, w, h;
        public ItemStack stack;

        public Entry(int x, int y, int w, int h, ItemStack stack) {
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
            this.stack = stack;
        }
    }

    public static int rows() {
        return BriefcaseConfig.ROWS.get();
    }

    /** Baca dari NBT (dipakai server dari item, dan klien dari paket; w/h dibaca kalau ada). */
    public static List<Entry> read(CompoundTag root) {
        List<Entry> out = new ArrayList<>();
        ListTag list = root.getList("Items", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag c = list.getCompound(i);
            ItemStack st = ItemStack.of(c.getCompound("Item"));
            if (st.isEmpty()) continue;
            int w = c.getInt("w"), h = c.getInt("h");
            if (w <= 0 || h <= 0) {
                BriefcaseSizes.Size s = BriefcaseSizes.of(st);
                w = s == null ? 1 : s.w();
                h = s == null ? 1 : s.h();
            }
            out.add(new Entry(c.getInt("x"), c.getInt("y"), w, h, st));
        }
        return out;
    }

    public static List<Entry> read(ItemStack briefcase) {
        CompoundTag t = briefcase.getTagElement("Briefcase");
        return t == null ? new ArrayList<>() : read(t);
    }

    public static void write(ItemStack briefcase, List<Entry> list) {
        CompoundTag root = briefcase.getOrCreateTagElement("Briefcase");
        ListTag out = new ListTag();
        for (Entry e : list) {
            CompoundTag c = new CompoundTag();
            c.putInt("x", e.x);
            c.putInt("y", e.y);
            c.put("Item", e.stack.save(new CompoundTag()));
            out.add(c);
        }
        root.put("Items", out);
    }

    public static ItemStack getRope(ItemStack briefcase) {
        CompoundTag t = briefcase.getTagElement("Briefcase");
        if (t == null || !t.contains("Rope", Tag.TAG_COMPOUND)) return ItemStack.EMPTY;
        return ItemStack.of(t.getCompound("Rope"));
    }

    public static void setRope(ItemStack briefcase, ItemStack rope) {
        CompoundTag root = briefcase.getOrCreateTagElement("Briefcase");
        if (rope.isEmpty()) root.remove("Rope");
        else root.put("Rope", rope.save(new CompoundTag()));
    }

    /** Salinan NBT untuk dikirim ke klien, lengkap dengan ukuran tiap entri. */
    public static CompoundTag syncTag(ItemStack briefcase) {
        CompoundTag root = new CompoundTag();
        ListTag out = new ListTag();
        for (Entry e : read(briefcase)) {
            CompoundTag c = new CompoundTag();
            c.putInt("x", e.x);
            c.putInt("y", e.y);
            c.putInt("w", e.w);
            c.putInt("h", e.h);
            c.put("Item", e.stack.save(new CompoundTag()));
            out.add(c);
        }
        root.put("Items", out);
        ItemStack rope = getRope(briefcase);
        if (!rope.isEmpty()) root.put("Rope", rope.save(new CompoundTag()));
        return root;
    }

    public static boolean fits(List<Entry> list, int ignore, int x, int y, int w, int h, int rows) {
        if (x < 0 || y < 0 || x + w > COLS || y + h > rows) return false;
        for (int i = 0; i < list.size(); i++) {
            if (i == ignore) continue;
            Entry e = list.get(i);
            if (x < e.x + e.w && e.x < x + w && y < e.y + e.h && e.y < y + h) return false;
        }
        return true;
    }

    /** Tempat kosong pertama (kiri-atas ke kanan-bawah) untuk benda w x h, atau null. */
    public static int[] findFree(List<Entry> list, int w, int h, int rows) {
        for (int y = 0; y + h <= rows; y++) {
            for (int x = 0; x + w <= COLS; x++) {
                if (fits(list, -1, x, y, w, h, rows)) return new int[]{x, y};
            }
        }
        return null;
    }
}
