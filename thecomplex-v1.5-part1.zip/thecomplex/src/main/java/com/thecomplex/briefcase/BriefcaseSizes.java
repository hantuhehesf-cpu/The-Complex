package com.thecomplex.briefcase;

import com.thecomplex.ModBlocks;
import com.thecomplex.ModItems;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.Locale;

/** Data ukuran item di grid Briefcase. null = item ini tidak boleh dimasukkan. */
public final class BriefcaseSizes {
    public record Size(int w, int h) {}

    private BriefcaseSizes() {}

    private static Size builtin(Item item) {
        if (item == ModItems.FLASHLIGHT.get()) return new Size(1, 2);
        if (item == ModItems.FLASHLIGHT_BATTERY.get()) return new Size(1, 1);
        if (item == ModItems.DUCT_TAPE.get()) return new Size(1, 1);
        if (item == ModBlocks.DUCT_ANCHOR.get().asItem()) return new Size(2, 1);
        if (item == ModItems.ROPE.get()) return new Size(2, 1);
        return null;
    }

    public static Size of(ItemStack stack) {
        if (stack.isEmpty()) return null;
        Item item = stack.getItem();
        if (item instanceof BriefcaseItem) return null;
        Size b = builtin(item);
        if (b != null) return b;
        ResourceLocation key = ForgeRegistries.ITEMS.getKey(item);
        if (key != null) {
            try {
                for (String s : BriefcaseConfig.EXTRA_SIZES.get()) {
                    int eq = s.indexOf('=');
                    if (eq < 0 || !s.substring(0, eq).trim().equals(key.toString())) continue;
                    String[] wh = s.substring(eq + 1).trim().toLowerCase(Locale.ROOT).split("x");
                    int w = Math.max(1, Math.min(BriefcaseData.COLS, Integer.parseInt(wh[0].trim())));
                    int h = Math.max(1, Math.min(4, Integer.parseInt(wh[1].trim())));
                    return new Size(w, h);
                }
            } catch (RuntimeException ignored) {
                // config rusak: pakai ukuran bawaan
            }
        }
        if (item instanceof BlockItem) return null;
        return new Size(1, 1);
    }
}
