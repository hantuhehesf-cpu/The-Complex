package com.thecomplex.net;

import com.thecomplex.client.ClientHooks;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Server -> klien: buka (mode 0) atau segarkan (mode 1) layar Briefcase dengan isi terbaru. */
public record BriefcaseSyncPacket(int mode, int rows, CompoundTag data) {
    public static void encode(BriefcaseSyncPacket m, FriendlyByteBuf buf) {
        buf.writeVarInt(m.mode);
        buf.writeVarInt(m.rows);
        buf.writeNbt(m.data);
    }

    public static BriefcaseSyncPacket decode(FriendlyByteBuf buf) {
        int mode = buf.readVarInt();
        int rows = buf.readVarInt();
        CompoundTag t = buf.readNbt();
        return new BriefcaseSyncPacket(mode, rows, t == null ? new CompoundTag() : t);
    }

    public static void handle(BriefcaseSyncPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> ClientHooks.briefcaseSync(m.mode, m.rows, m.data)));
        ctx.get().setPacketHandled(true);
    }
}
