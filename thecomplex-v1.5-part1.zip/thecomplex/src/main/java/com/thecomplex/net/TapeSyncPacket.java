package com.thecomplex.net;

import com.thecomplex.client.ClientHooks;
import com.thecomplex.tape.TapeView;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/** Server -> klien: semua Duct Tape di dimensi pemain (untuk digambar). */
public record TapeSyncPacket(List<TapeView> tapes) {
    public static void encode(TapeSyncPacket m, FriendlyByteBuf buf) {
        buf.writeVarInt(m.tapes.size());
        for (TapeView t : m.tapes) {
            buf.writeBlockPos(t.a());
            buf.writeVarInt(t.axis() + 1);
            buf.writeVarInt(t.dir() + 1);
            buf.writeVarInt(t.ys().length);
            for (float y : t.ys()) buf.writeFloat(y);
            buf.writeBoolean(t.b() != null);
            if (t.b() != null) buf.writeBlockPos(t.b());
        }
    }

    public static TapeSyncPacket decode(FriendlyByteBuf buf) {
        int n = buf.readVarInt();
        List<TapeView> out = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            var a = buf.readBlockPos();
            int axis = buf.readVarInt() - 1;
            int dir = buf.readVarInt() - 1;
            float[] ys = new float[buf.readVarInt()];
            for (int k = 0; k < ys.length; k++) ys[k] = buf.readFloat();
            var b = buf.readBoolean() ? buf.readBlockPos() : null;
            out.add(new TapeView(a, axis, dir, ys, b));
        }
        return new TapeSyncPacket(out);
    }

    public static void handle(TapeSyncPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> ClientHooks.setTapes(m.tapes)));
        ctx.get().setPacketHandled(true);
    }
}
