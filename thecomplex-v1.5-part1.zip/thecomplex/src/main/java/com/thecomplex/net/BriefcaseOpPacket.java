package com.thecomplex.net;

import com.thecomplex.briefcase.BriefcaseSessions;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Klien -> server: satu operasi di inventori Briefcase (lihat BriefcaseSessions.OP_*). */
public record BriefcaseOpPacket(int op, int a, int b, int c) {
    public static void encode(BriefcaseOpPacket m, FriendlyByteBuf buf) {
        buf.writeVarInt(m.op);
        buf.writeInt(m.a);
        buf.writeInt(m.b);
        buf.writeInt(m.c);
    }

    public static BriefcaseOpPacket decode(FriendlyByteBuf buf) {
        return new BriefcaseOpPacket(buf.readVarInt(), buf.readInt(), buf.readInt(), buf.readInt());
    }

    public static void handle(BriefcaseOpPacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> {
            ServerPlayer p = c.getSender();
            if (p != null) BriefcaseSessions.handleOp(p, m.op, m.a, m.b, m.c);
        });
        c.setPacketHandled(true);
    }
}
