package com.thecomplex.net;

import com.thecomplex.briefcase.BriefcaseItem;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Klien -> server: lempar Briefcase di tangan utama dengan kekuatan 1..10. */
public record ThrowPacket(int power) {
    public static void encode(ThrowPacket m, FriendlyByteBuf buf) {
        buf.writeVarInt(m.power);
    }

    public static ThrowPacket decode(FriendlyByteBuf buf) {
        return new ThrowPacket(buf.readVarInt());
    }

    public static void handle(ThrowPacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> {
            ServerPlayer p = c.getSender();
            if (p != null) BriefcaseItem.throwFrom(p, m.power);
        });
        c.setPacketHandled(true);
    }
}
