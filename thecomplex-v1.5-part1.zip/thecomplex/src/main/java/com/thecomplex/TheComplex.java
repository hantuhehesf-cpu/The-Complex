package com.thecomplex;

import com.mojang.logging.LogUtils;
import com.mojang.serialization.Codec;
import com.thecomplex.briefcase.BriefcaseConfig;
import com.thecomplex.item.FlashlightItem;
import com.thecomplex.lpmds.LpmdsConfig;
import com.thecomplex.net.Net;
import com.thecomplex.world.ComplexChunkGenerator;
import com.thecomplex.world.SchemStore;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import org.slf4j.Logger;

@Mod(TheComplex.MODID)
public class TheComplex {
    public static final String MODID = "thecomplex";
    public static final Logger LOGGER = LogUtils.getLogger();
    public static final ResourceKey<Level> COMPLEX =
            ResourceKey.create(Registries.DIMENSION, new ResourceLocation(MODID, "the_complex"));

    private static final DeferredRegister<Codec<? extends ChunkGenerator>> CHUNK_GENS =
            DeferredRegister.create(Registries.CHUNK_GENERATOR, MODID);

    public TheComplex() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(bus);
        ModBlocks.ITEMS.register(bus);
        ModBlockEntities.BLOCK_ENTITIES.register(bus);
        ModItems.ITEMS.register(bus);
        ModEntities.ENTITIES.register(bus);
        ModSounds.SOUNDS.register(bus);
        CHUNK_GENS.register("complex", () -> ComplexChunkGenerator.CODEC);
        CHUNK_GENS.register(bus);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, LpmdsConfig.SPEC);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, BriefcaseConfig.SPEC, "thecomplex-briefcase.toml");
        bus.addListener(this::commonSetup);
        bus.addListener(this::addCreative);
    }

    private void commonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(() -> {
            Net.register();
            SchemStore.load();
        });
    }

    private void addCreative(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
            ModBlocks.ITEMS.getEntries().forEach(event::accept);
        }
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            event.accept(ModItems.DEV_TOOL);
            event.accept(ModItems.LPMDS_MARKER);
            event.accept(ModItems.BRIEFCASE);
            event.accept(FlashlightItem.charged());
            event.accept(ModItems.FLASHLIGHT);
            event.accept(ModItems.FLASHLIGHT_BATTERY);
            event.accept(ModItems.DUCT_TAPE);
            event.accept(ModBlocks.DUCT_ANCHOR.get());
            event.accept(ModItems.ROPE);
        }
    }
}
