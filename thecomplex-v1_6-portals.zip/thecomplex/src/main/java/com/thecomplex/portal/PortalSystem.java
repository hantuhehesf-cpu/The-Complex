package com.thecomplex.portal;

import com.thecomplex.ComplexTeleporter;
import com.thecomplex.ModBlocks;
import com.thecomplex.TheComplex;
import com.thecomplex.block.NullZoneBlockEntity;
import com.thecomplex.block.NullZoneLife;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Otak portal di server. Tiap tick tiap pemain:
 *  - mengikuti posisi mata pemain, dan kalau mata melewati BIDANG sebuah portal (Threshold, Null Zone, Stable Wild Null Zone)
 *    pemain dipindah seketika (tanpa menunggu beberapa tick di dalam blok seperti dulu),
 *  - tiap 1 detik, kalau ada portal dalam jangkauan: muat chunk seberangnya lebih dulu dan kirim cuplikan see-through.
 */
@Mod.EventBusSubscriber(modid = TheComplex.MODID)
public final class PortalSystem {
    /** Jarak (blok) dari portal ketika chunk seberang mulai dimuat. */
    private static final double PRELOAD_RANGE = 20.0;
    /** Jarak (blok) ketika Null Zone liar mulai menyiapkan tujuan. */
    private static final double NULLZONE_RANGE = 14.0;

    private static final Map<UUID, Vec3> PREV_EYE = new HashMap<>();
    private static final Map<UUID, ResourceKey<Level>> PREV_DIM = new HashMap<>();

    private PortalSystem() {}

    /** Lupakan posisi sebelumnya (dipanggil setelah pemain dipindah, supaya tidak dikira "melewati" portal tujuan). */
    public static void forget(ServerPlayer p) {
        PREV_EYE.remove(p.getUUID());
        PREV_DIM.remove(p.getUUID());
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        UUID id = e.getEntity().getUUID();
        PREV_EYE.remove(id);
        PREV_DIM.remove(id);
        PortalPreloader.forget(id);
        PortalView.forget(id);
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p)) return;
        ServerLevel level = p.serverLevel();
        Vec3 eye = p.getEyePosition();
        Vec3 prev = PREV_EYE.put(p.getUUID(), eye);
        ResourceKey<Level> prevDim = PREV_DIM.put(p.getUUID(), level.dimension());

        PortalPreloader.tick(p);
        if (p.isSpectator()) return;
        if (p.tickCount % 20 == 7) scan(p, level);

        if (prev == null || prevDim != level.dimension() || prev.distanceToSqr(eye) > 36.0) return;
        if (ComplexTeleporter.onCooldown(p)) return;

        // semua blok yang disentuh pemain sejak tick lalu, sedikit diperlebar
        AABB box = p.getBoundingBox().expandTowards(prev.subtract(eye)).inflate(0.3, 0.2, 0.3);
        int x0 = Mth.floor(box.minX), x1 = Mth.floor(box.maxX);
        int y0 = Mth.floor(box.minY), y1 = Mth.floor(box.maxY);
        int z0 = Mth.floor(box.minZ), z1 = Mth.floor(box.maxZ);
        Vec3 vel = eye.subtract(prev);
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int x = x0; x <= x1; x++) {
            for (int y = y0; y <= y1; y++) {
                for (int z = z0; z <= z1; z++) {
                    m.set(x, y, z);
                    BlockState s = level.getBlockState(m);
                    if (s.is(ModBlocks.THRESHOLD.get())) {
                        if (tryThreshold(p, level, m.immutable(), prev, eye, vel)) return;
                    } else if (s.is(ModBlocks.NULL_ZONE.get())) {
                        if (tryNullZone(p, level, m.immutable(), prev, eye, vel)) return;
                    }
                }
            }
        }
    }

    // ---------------------------------------------------------------- menembus bidang

    private static boolean tryThreshold(ServerPlayer p, ServerLevel level, BlockPos pos, Vec3 prev, Vec3 eye, Vec3 vel) {
        PortalFrame f = PortalFrame.of(level, pos);
        if (f == null) return false;
        Vec3 n = f.normal();
        double sp = prev.subtract(f.center).dot(n), sc = eye.subtract(f.center).dot(n);
        if (!crossed(sp, sc)) return false;
        Vec3 hit = prev.add(eye.subtract(prev).scale(sp / (sp - sc)));
        if (!f.containsOnPlane(hit, 0.3, 0.3)) return false;
        Vec3 travel = n.scale(sc > sp ? 1 : -1);
        ComplexTeleporter.throughThreshold(p, level, f, pos, travel, vel);
        return true;
    }

    private static boolean tryNullZone(ServerPlayer p, ServerLevel level, BlockPos pos, Vec3 prev, Vec3 eye, Vec3 vel) {
        if (!(level.getBlockEntity(pos) instanceof NullZoneBlockEntity nz)) return false;
        Direction dir = nz.getNormal();
        if (dir == null) return false;                                   // Null Zone lama / manual: cara lama di NullZoneBlock
        if (!nz.isStable() && level.dimension() == TheComplex.COMPLEX) return false;
        Vec3 nv = new Vec3(dir.getStepX(), dir.getStepY(), dir.getStepZ());
        double sp = prev.dot(nv) - nz.getPlane(), sc = eye.dot(nv) - nz.getPlane();
        if (!crossed(sp, sc)) return false;
        Vec3 hit = prev.add(eye.subtract(prev).scale(sp / (sp - sc)));
        // titik tembus harus di dalam sel ini (pada dua sumbu yang bukan sumbu normal), dengan sedikit toleransi
        double mg = 0.3;
        if (dir.getAxis() != Direction.Axis.X && (hit.x < pos.getX() - mg || hit.x > pos.getX() + 1 + mg)) return false;
        if (dir.getAxis() != Direction.Axis.Y && (hit.y < pos.getY() - mg || hit.y > pos.getY() + 1 + mg)) return false;
        if (dir.getAxis() != Direction.Axis.Z && (hit.z < pos.getZ() - mg || hit.z > pos.getZ() + 1 + mg)) return false;

        if (nz.isStable()) {
            Vec3 travel = nv.scale(sc > sp ? 1 : -1);
            WildPortals.cross(p, nz, travel, vel);
        } else {
            ComplexTeleporter.throughNullZone(p, dir, vel);
            NullZoneLife.onTriggered(level, pos, nz);
        }
        return true;
    }

    /** Mata berpindah dari satu sisi bidang ke sisi lain (atau tepat mendarat di bidang). */
    private static boolean crossed(double sp, double sc) {
        return (sp < 0 && sc >= 0) || (sp > 0 && sc <= 0);
    }

    // ---------------------------------------------------------------- persiapan (tiap 1 detik)

    private static void scan(ServerPlayer p, ServerLevel level) {
        BlockPos pp = p.blockPosition();

        // Threshold terdekat: muat chunk seberang dan kirim cuplikan see-through
        List<BlockPos> thr = PortalRegistry.near(level, pp, PRELOAD_RANGE);
        if (!thr.isEmpty()) {
            PortalFrame f = PortalFrame.of(level, thr.get(0));
            if (f != null) {
                ComplexTeleporter.Dest d = ComplexTeleporter.destFor(p, level, false);
                if (d == null) {
                    requestDestChunks(p, level);
                } else {
                    PortalPreloader.request(p, d.level(), Mth.floor(d.frame().center.x) >> 4, Mth.floor(d.frame().center.z) >> 4, 2);
                    PortalView.maybeSend(p, level, f, d.level(), d.frame(), d.exit());
                }
            }
        }

        // Null Zone di sekitar (lewat data blok di chunk sekitar)
        ChunkPos cp = p.chunkPosition();
        double r2 = NULLZONE_RANGE * NULLZONE_RANGE;
        boolean planned = false;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                LevelChunk ch = level.getChunkSource().getChunkNow(cp.x + dx, cp.z + dz);
                if (ch == null) continue;
                for (BlockEntity be : ch.getBlockEntities().values()) {
                    if (!(be instanceof NullZoneBlockEntity nz) || nz.getNormal() == null) continue;
                    if (be.getBlockPos().distSqr(pp) > r2) continue;
                    if (nz.isStable()) {
                        WildPortalData.End other = WildPortals.otherEnd(p.server, nz);
                        if (other == null) continue;
                        ServerLevel dest = WildPortals.levelOf(p.server, other);
                        if (dest == null) continue;
                        BlockPos oc = BlockPos.of(other.cell());
                        PortalPreloader.request(p, dest, oc.getX() >> 4, oc.getZ() >> 4, 1);
                    } else if (!planned && level.dimension() != TheComplex.COMPLEX) {
                        PortalPreloader.planBackrooms(p);
                        planned = true;
                    }
                }
            }
        }
    }

    /** Tujuan Threshold belum diketahui (chunk belum dimuat): minta dimuat. */
    private static void requestDestChunks(ServerPlayer p, ServerLevel level) {
        if (level.dimension() != TheComplex.COMPLEX) {
            BlockPos t = com.thecomplex.world.ComplexLayout.thresholdPos();
            ServerLevel cx = p.server.getLevel(TheComplex.COMPLEX);
            if (t != null && cx != null) PortalPreloader.request(p, cx, t.getX() >> 4, t.getZ() >> 4, 2);
        } else {
            net.minecraft.nbt.CompoundTag d = p.getPersistentData();
            if (d.getBoolean("complex_ret_gate_set")) {
                BlockPos gate = BlockPos.of(d.getLong("complex_ret_gate"));
                net.minecraft.resources.ResourceLocation id = net.minecraft.resources.ResourceLocation.tryParse(d.getString("complex_ret_dim"));
                if (id != null) {
                    ServerLevel target = p.server.getLevel(ResourceKey.create(net.minecraft.core.registries.Registries.DIMENSION, id));
                    if (target != null) PortalPreloader.request(p, target, gate.getX() >> 4, gate.getZ() >> 4, 2);
                }
            }
        }
    }
}
