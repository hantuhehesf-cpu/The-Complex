package com.thecomplex.portal;

import com.thecomplex.ModBlocks;
import com.thecomplex.block.NullZoneBlockEntity;
import com.thecomplex.net.Net;
import com.thecomplex.net.PortalViewPacket;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Cuplikan sisi seberang sebuah Threshold untuk efek see-through. Tidak ada rendering dunia kedua:
 * server mengirim blok-blok yang terlihat (kotak kecil di depan bingkai tujuan), klien menggambarnya ke tekstur kecil
 * dan menempelkannya pada bukaan Threshold. Dikirim ulang paling cepat tiap 10 detik.
 */
public final class PortalView {
    /** Setengah lebar, kedalaman, dan tinggi kotak cuplikan (blok). */
    private static final int HALF_WIDTH = 14;
    private static final int DEPTH = 28;
    private static final int BELOW = 3;
    private static final int ABOVE = 8;
    private static final int MAX_CELLS = 5000;
    private static final int RESEND_TICKS = 200;

    private static final Map<UUID, Map<Long, Long>> SENT = new HashMap<>();

    private PortalView() {}

    /** Kirim cuplikan tujuan bingkai src ke pemain, kalau belum pernah atau sudah lama. */
    public static void maybeSend(ServerPlayer p, ServerLevel srcLevel, PortalFrame src, ServerLevel dest, PortalFrame dstFrame, Vec3 exit) {
        long now = srcLevel.getGameTime();
        Map<Long, Long> sent = SENT.computeIfAbsent(p.getUUID(), k -> new HashMap<>());
        Long last = sent.get(src.key());
        if (last != null && now - last < RESEND_TICKS) return;
        PortalViewPacket pkt = build(dest, srcLevel.dimension().location().toString(), src, dstFrame, exit);
        if (pkt == null) return;
        sent.put(src.key(), now);
        Net.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), pkt);
    }

    public static void forget(UUID id) {
        SENT.remove(id);
    }

    /** Null kalau chunk tujuan belum dimuat. */
    private static PortalViewPacket build(ServerLevel dest, String srcDim, PortalFrame src, PortalFrame dst, Vec3 exit) {
        Vec3 c = dst.center;
        int ex = (int) Math.signum(exit.x), ez = (int) Math.signum(exit.z);
        int bx = Mth.floor(c.x), by = Mth.floor(c.y), bz = Mth.floor(c.z);
        int minX, maxX, minZ, maxZ;
        if (ex != 0) {
            minX = ex > 0 ? bx + 1 : bx - DEPTH;
            maxX = ex > 0 ? bx + DEPTH : bx - 1;
            minZ = bz - HALF_WIDTH;
            maxZ = bz + HALF_WIDTH;
        } else {
            minZ = ez > 0 ? bz + 1 : bz - DEPTH;
            maxZ = ez > 0 ? bz + DEPTH : bz - 1;
            minX = bx - HALF_WIDTH;
            maxX = bx + HALF_WIDTH;
        }
        int minY = by - BELOW, maxY = by + ABOVE;
        if (dest.getChunkSource().getChunkNow(bx >> 4, bz >> 4) == null) return null;

        int w = maxX - minX + 1, h = maxY - minY + 1, d = maxZ - minZ + 1;
        long[] packed = new long[MAX_CELLS];
        byte[] maskOf = new byte[w * h * d];
        int n = 0;
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        // dari dekat ke jauh: kalau kebanyakan, yang terpotong adalah yang paling jauh
        for (int step = 0; step < Math.max(w, d) && n < MAX_CELLS; step++) {
            for (int x = minX; x <= maxX && n < MAX_CELLS; x++) {
                for (int z = minZ; z <= maxZ && n < MAX_CELLS; z++) {
                    int depth = ex != 0 ? (ex > 0 ? x - minX : maxX - x) : (ez > 0 ? z - minZ : maxZ - z);
                    if (depth != step) continue;
                    for (int y = minY; y <= maxY && n < MAX_CELLS; y++) {
                        m.set(x, y, z);
                        if (!dest.hasChunkAt(m)) continue;
                        BlockState s = dest.getBlockState(m);
                        if (s.isAir() || s.getRenderShape() != RenderShape.MODEL) continue;
                        if (s.is(ModBlocks.THRESHOLD.get())) continue;
                        if (s.is(ModBlocks.NULL_ZONE.get())) {
                            BlockEntity be = dest.getBlockEntity(m);
                            if (be instanceof NullZoneBlockEntity nz && nz.getOriginal() != null) s = nz.getOriginal();
                        }
                        int mask = 0x3F;
                        if (s.isSolidRender(dest, m)) {
                            mask = exposedMask(dest, m, minX, maxX, minY, maxY, minZ, maxZ);
                            if (mask == 0) continue;
                        }
                        int idx = ((y - minY) * d + (z - minZ)) * w + (x - minX);
                        maskOf[idx] = (byte) mask;
                        packed[n++] = ((long) idx << 32) | (Block.BLOCK_STATE_REGISTRY.getId(s) & 0xFFFFFFFFL);
                    }
                }
            }
        }
        long[] cut = Arrays.copyOf(packed, n);
        Arrays.sort(cut);
        int[] idx = new int[n], ids = new int[n];
        byte[] masks = new byte[n];
        for (int i = 0; i < n; i++) {
            idx[i] = (int) (cut[i] >>> 32);
            ids[i] = (int) (cut[i] & 0xFFFFFFFFL);
            masks[i] = maskOf[idx[i]];
        }
        int ambient = dest.getMaxLocalRawBrightness(BlockPos.containing(c.x + exit.x * 3, c.y, c.z + exit.z * 3));
        int axis = src.normalAxis == net.minecraft.core.Direction.Axis.X ? 0 : 1;
        return new PortalViewPacket(src.key(), srcDim, src.center.x, src.center.y, src.center.z, axis,
                (float) src.halfWidth, (float) src.halfHeight, c.x, c.y, c.z, ex, ez,
                minX, minY, minZ, w, h, d, ambient, idx, ids, masks);
    }

    /** Sisi blok padat yang menghadap ruang kosong di dalam kotak (bit = Direction.get3DDataValue). 0 = tersembunyi sepenuhnya. */
    private static int exposedMask(ServerLevel l, BlockPos p, int minX, int maxX, int minY, int maxY, int minZ, int maxZ) {
        BlockPos.MutableBlockPos q = new BlockPos.MutableBlockPos();
        int mask = 0;
        for (net.minecraft.core.Direction dir : net.minecraft.core.Direction.values()) {
            int nx = p.getX() + dir.getStepX(), ny = p.getY() + dir.getStepY(), nz = p.getZ() + dir.getStepZ();
            if (nx < minX || nx > maxX || ny < minY || ny > maxY || nz < minZ || nz > maxZ) continue;
            q.set(nx, ny, nz);
            if (!l.getBlockState(q).isSolidRender(l, q)) mask |= 1 << dir.get3DDataValue();
        }
        return mask;
    }
}
