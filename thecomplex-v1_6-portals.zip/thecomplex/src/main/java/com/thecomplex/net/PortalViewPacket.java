package com.thecomplex.net;

import com.thecomplex.client.PortalViewClient;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Server -> klien: cuplikan kecil sisi seberang sebuah Threshold, untuk efek see-through.
 * Berisi bingkai sumber, titik tengah dan arah keluar di tujuan, kotak ruang tujuan, dan blok-blok yang terlihat di dalamnya.
 * idx = indeks linear ((y * d + z) * w + x) di dalam kotak, ids = id BlockState, masks = sisi mana yang menghadap ruang kosong
 * (bit = Direction.get3DDataValue). dim = dimensi sumber. Tidak ada sel berarti "hapus pandangan ini".
 */
public record PortalViewPacket(long key, String dim, double sx, double sy, double sz, int axis, float halfW, float halfH,
                               double dx, double dy, double dz, int ex, int ez,
                               int bx, int by, int bz, int w, int h, int d, int ambient,
                               int[] idx, int[] ids, byte[] masks) {
    public static void encode(PortalViewPacket m, FriendlyByteBuf buf) {
        buf.writeLong(m.key);
        buf.writeUtf(m.dim, 128);
        buf.writeDouble(m.sx);
        buf.writeDouble(m.sy);
        buf.writeDouble(m.sz);
        buf.writeByte(m.axis);
        buf.writeFloat(m.halfW);
        buf.writeFloat(m.halfH);
        buf.writeDouble(m.dx);
        buf.writeDouble(m.dy);
        buf.writeDouble(m.dz);
        buf.writeByte(m.ex);
        buf.writeByte(m.ez);
        buf.writeInt(m.bx);
        buf.writeInt(m.by);
        buf.writeInt(m.bz);
        buf.writeVarInt(m.w);
        buf.writeVarInt(m.h);
        buf.writeVarInt(m.d);
        buf.writeByte(m.ambient);
        buf.writeVarInt(m.idx.length);
        int prev = 0;
        for (int i = 0; i < m.idx.length; i++) {
            buf.writeVarInt(m.idx[i] - prev);
            prev = m.idx[i];
            buf.writeVarInt(m.ids[i]);
            buf.writeByte(m.masks[i]);
        }
    }

    public static PortalViewPacket decode(FriendlyByteBuf buf) {
        long key = buf.readLong();
        String dim = buf.readUtf(128);
        double sx = buf.readDouble(), sy = buf.readDouble(), sz = buf.readDouble();
        int axis = buf.readByte();
        float hw = buf.readFloat(), hh = buf.readFloat();
        double dx = buf.readDouble(), dy = buf.readDouble(), dz = buf.readDouble();
        int ex = buf.readByte(), ez = buf.readByte();
        int bx = buf.readInt(), by = buf.readInt(), bz = buf.readInt();
        int w = buf.readVarInt(), h = buf.readVarInt(), d = buf.readVarInt();
        int ambient = buf.readByte();
        int n = buf.readVarInt();
        int[] idx = new int[n], ids = new int[n];
        byte[] masks = new byte[n];
        int prev = 0;
        for (int i = 0; i < n; i++) {
            prev += buf.readVarInt();
            idx[i] = prev;
            ids[i] = buf.readVarInt();
            masks[i] = buf.readByte();
        }
        return new PortalViewPacket(key, dim, sx, sy, sz, axis, hw, hh, dx, dy, dz, ex, ez, bx, by, bz, w, h, d, ambient, idx, ids, masks);
    }

    public static void handle(PortalViewPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> PortalViewClient.receive(m)));
        ctx.get().setPacketHandled(true);
    }
}
