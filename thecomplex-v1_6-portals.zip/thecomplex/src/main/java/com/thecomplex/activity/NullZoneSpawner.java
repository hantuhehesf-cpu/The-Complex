package com.thecomplex.activity;

import com.thecomplex.ModBlocks;
import com.thecomplex.block.NullZoneBlockEntity;
import com.thecomplex.fragment.Fragment;
import com.thecomplex.fragment.FragmentCapture;
import com.thecomplex.portal.WildPortals;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Menaruh Null Zone di dinding atau lantai, condong ke chunk yang paling sering dikunjungi pemain.
 * Null Zone menyamar sebagai blok aslinya dan memulihkannya setelah dipakai atau kedaluwarsa.
 *
 * Bisa muncul di blok padat penuh apa pun: semua jenis kayu (papan, batang), cobblestone dan variannya, batu, bata,
 * lantai rumah umum, Dirt, dan Grass Block (di luar ruangan, hanya sebagai lantai/tanah).
 * Tidak di bedrock, blok yang punya data (peti, tungku), dan blok portal lain.
 */
public final class NullZoneSpawner {
    public static final int MODE_ANY = 0;
    public static final int MODE_WALL = 1;
    public static final int MODE_FLOOR = 2;
    /** Tanah di luar ruangan: hanya Grass Block dan Dirt. */
    public static final int MODE_GROUND = 3;
    /** Stable Wild Null Zone (dinding, permanen, dua arah). */
    public static final int MODE_STABLE = 4;

    /** Umur Null Zone liar sebelum dinding kembali normal: 10 sampai 30 menit. */
    public static final int LIFETIME_MIN = 12000;
    public static final int LIFETIME_VAR = 24000;
    /** Peluang (persen) satu Null Zone yang berhasil dibuat sekaligus menangkap fragmen bangunan di tempat itu. */
    public static final int CAPTURE_CHANCE = 30;
    /** Peluang (persen) sebuah percobaan di dinding menjadi Stable Wild Null Zone (sangat langka). */
    public static final int STABLE_CHANCE = 3;
    /** Peluang (persen) Null Zone liar bisa membesar, dan berapa kali paling banyak. */
    public static final int GROW_CHANCE = 25;
    public static final int MAX_GROWS = 3;
    /** Peluang (persen) mode acak mencoba tanah di luar ruangan lebih dulu. */
    public static final int OUTDOOR_CHANCE = 30;
    private static final int CHUNK_RADIUS = 5;

    private NullZoneSpawner() {}

    public static boolean spawnFor(ServerPlayer p, ActivityData data) {
        return spawnFor(p, data, MODE_ANY);
    }

    public static boolean spawnFor(ServerPlayer p, ActivityData data, int mode) {
        ServerLevel level = p.serverLevel();
        RandomSource r = p.getRandom();
        ChunkPos target = pickChunk(level, data, p, r);

        if (mode == MODE_GROUND || (mode == MODE_ANY && r.nextInt(100) < OUTDOOR_CHANCE)) {
            for (int i = 0; i < 24; i++) {
                BlockPos floor = findSurface(level, target, r);
                if (floor == null) continue;
                BlockPos center = placeFloor(level, floor, p, r, true);
                if (center != null) {
                    NullZoneTracker.add(level, center, "ground");
                    return true;
                }
            }
            if (mode == MODE_GROUND) return false;
        }

        for (int i = 0; i < 48; i++) {
            BlockPos floor = findIndoorFloor(level, target, r);
            if (floor == null) continue;
            boolean asFloor = mode == MODE_FLOOR || (mode == MODE_ANY && r.nextInt(100) < 40);
            if (mode == MODE_STABLE) asFloor = false;
            boolean wantStable = mode == MODE_STABLE || (mode == MODE_ANY && r.nextInt(100) < STABLE_CHANCE);
            boolean[] madeStable = new boolean[1];
            BlockPos center = asFloor ? placeFloor(level, floor, p, r, false) : placeWall(level, floor, p, r, wantStable, madeStable);
            if (center != null) {
                NullZoneTracker.add(level, center, asFloor ? "floor" : madeStable[0] ? "stable" : "wall");
                if (!madeStable[0] && r.nextInt(100) < CAPTURE_CHANCE) {
                    Fragment f = FragmentCapture.captureBuilding(level, floor);
                    FragmentCapture.store(level, f, r);
                }
                return true;
            }
        }
        return false;
    }

    /** Roulette berbobot heat, hanya chunk yang sedang dimuat dan dekat pemain. */
    private static ChunkPos pickChunk(ServerLevel level, ActivityData data, ServerPlayer p, RandomSource r) {
        ChunkPos pc = p.chunkPosition();
        List<ChunkPos> chunks = new ArrayList<>();
        List<Float> weights = new ArrayList<>();
        double total = 0;
        for (Map.Entry<Long, Float> e : data.of(p.getUUID()).entrySet()) {
            ChunkPos c = new ChunkPos(e.getKey());
            if (Math.abs(c.x - pc.x) > CHUNK_RADIUS || Math.abs(c.z - pc.z) > CHUNK_RADIUS) continue;
            if (!level.hasChunk(c.x, c.z)) continue;
            chunks.add(c);
            weights.add(e.getValue());
            total += e.getValue();
        }
        if (chunks.isEmpty() || total <= 0) return pc;
        double roll = r.nextDouble() * total;
        for (int i = 0; i < chunks.size(); i++) {
            roll -= weights.get(i);
            if (roll <= 0) return chunks.get(i);
        }
        return chunks.get(chunks.size() - 1);
    }

    /** Sel udara acak di dalam ruangan (di bawah atap) yang lantainya blok padat. Null kalau tidak ketemu. */
    public static BlockPos findIndoorFloor(ServerLevel level, ChunkPos cp, RandomSource r) {
        int x = cp.getMinBlockX() + r.nextInt(16);
        int z = cp.getMinBlockZ() + r.nextInt(16);
        int top = level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z);
        int bottom = Math.max(level.getMinBuildHeight() + 1, top - 24);
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int y = top - 1; y >= bottom; y--) {
            m.set(x, y, z);
            BlockPos below = m.below();
            if (!level.getBlockState(m).isAir() || !level.getBlockState(m.above()).isAir()) continue;
            if (!level.getBlockState(below).isCollisionShapeFullBlock(level, below)) continue;
            if (level.canSeeSky(m.above())) continue;               // harus di bawah atap
            return m.immutable();
        }
        return null;
    }

    /** Sel udara tepat di atas tanah di luar ruangan (langit terbuka). Null kalau tidak ketemu. */
    public static BlockPos findSurface(ServerLevel level, ChunkPos cp, RandomSource r) {
        int x = cp.getMinBlockX() + r.nextInt(16);
        int z = cp.getMinBlockZ() + r.nextInt(16);
        BlockPos surface = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, new BlockPos(x, 0, z));
        if (!level.getBlockState(surface).isAir() || !level.canSeeSky(surface)) return null;
        return surface;
    }

    // ---------------------------------------------------------------- penempatan

    private static BlockPos placeWall(ServerLevel level, BlockPos floor, ServerPlayer p, RandomSource r, boolean wantStable, boolean[] madeStable) {
        for (Direction d : shuffled(r)) {
            BlockPos a = floor.relative(d);
            BlockPos b = a.above();
            if (!level.hasChunkAt(a)) continue;
            if (p.distanceToSqr(a.getX() + 0.5, a.getY(), a.getZ() + 0.5) < 4) continue;
            if (!canHost(level, a) || !canHost(level, b)) continue;

            double plane = planeOf(d, a.getX() + 0.5, a.getY() + 0.5, a.getZ() + 0.5);
            int pairId = 0;
            boolean stable = false;
            if (wantStable) {
                pairId = WildPortals.createPair(level, a, d, r);
                stable = pairId > 0;
            }
            long expires = stable ? 0 : level.getGameTime() + LIFETIME_MIN + r.nextInt(LIFETIME_VAR);
            int grows = !stable && r.nextInt(100) < GROW_CHANCE ? MAX_GROWS : 0;
            placeCell(level, a, d, plane, a.asLong(), expires, stable, pairId, 0, grows, true);
            placeCell(level, b, d, plane, a.asLong(), expires, stable, pairId, 0, 0, false);
            madeStable[0] = stable;
            return a;
        }
        return null;
    }

    /** Lantai: area 2x2, dua blok dalam, supaya pemain yang melangkah di atasnya benar-benar tenggelam. */
    private static BlockPos placeFloor(ServerLevel level, BlockPos floor, ServerPlayer p, RandomSource r, boolean groundOnly) {
        if (p.distanceToSqr(floor.getX() + 1.0, floor.getY(), floor.getZ() + 1.0) < 4) return null;
        List<BlockPos> cells = new ArrayList<>(8);
        for (int dx = 0; dx <= 1; dx++) {
            for (int dz = 0; dz <= 1; dz++) {
                BlockPos top = floor.offset(dx, -1, dz);
                BlockPos deep = top.below();
                if (!level.hasChunkAt(top) || !level.getBlockState(top.above()).getCollisionShape(level, top.above()).isEmpty()) return null;
                if (!level.getBlockState(top.above()).getFluidState().isEmpty()) return null;
                if (groundOnly && !isGround(level.getBlockState(top))) return null;
                if (!canHost(level, top) || !canHost(level, deep)) return null;
                cells.add(top);
                cells.add(deep);
            }
        }
        BlockPos anchor = floor.below();
        // bidang portal: sedikit di bawah permukaan. Mata pemain yang tenggelam melewatinya sebelum kaki mencapai dasar gugus.
        double plane = planeOf(Direction.DOWN, 0, floor.getY() - 0.25, 0);
        long expires = level.getGameTime() + LIFETIME_MIN + r.nextInt(LIFETIME_VAR);
        int grows = r.nextInt(100) < GROW_CHANCE ? MAX_GROWS : 0;
        for (BlockPos c : cells) {
            placeCell(level, c, Direction.DOWN, plane, anchor.asLong(), expires, false, 0, 0, c.equals(anchor) ? grows : 0, c.equals(anchor));
        }
        return anchor;
    }

    /** n dot titik: dipakai PortalSystem untuk mengetahui di sisi mana bidang portal sebuah titik berada. */
    public static double planeOf(Direction n, double x, double y, double z) {
        return n.getStepX() * x + n.getStepY() * y + n.getStepZ() * z;
    }

    /** Ganti blok pos menjadi Null Zone yang menyimpan blok aslinya. Dipakai juga oleh WildPortals untuk ujung di The Complex. */
    public static void placeCell(ServerLevel level, BlockPos pos, Direction normal, double plane, long anchor, long expires,
                                 boolean stable, int pairId, int end, int grows, boolean isAnchor) {
        BlockState old = level.getBlockState(pos);
        level.setBlock(pos, ModBlocks.NULL_ZONE.get().defaultBlockState(), 3);
        if (level.getBlockEntity(pos) instanceof NullZoneBlockEntity be) {
            be.setup(old, normal, plane, stable, pairId, end, expires, anchor, isAnchor, grows);
        }
        if (!stable) {
            long now = level.getGameTime();
            long delay = grows > 0 ? Math.min(expires - now, com.thecomplex.block.NullZoneLife.GROW_INTERVAL) : expires - now;
            level.scheduleTick(pos, ModBlocks.NULL_ZONE.get(), (int) Math.max(1, delay));
        }
    }

    /** Perbesar Null Zone satu langkah: satu cincin sel baru di sekeliling gugus (di bidang dinding, atau di lantai). */
    public static void expand(ServerLevel level, BlockPos anchor, NullZoneBlockEntity be) {
        Direction n = be.getNormal();
        if (n == null) return;
        int nr = be.getRadius() + 1;
        be.setRadius(nr);
        long expires = be.getExpiresAt();
        double plane = be.getPlane();
        if (n == Direction.DOWN) {
            for (int dx = -nr; dx <= 1 + nr; dx++) {
                for (int dz = -nr; dz <= 1 + nr; dz++) {
                    BlockPos top = anchor.offset(dx, 0, dz);
                    BlockPos deep = top.below();
                    if (level.getBlockState(top).is(ModBlocks.NULL_ZONE.get())) continue;
                    if (!level.hasChunkAt(top)) continue;
                    BlockPos above = top.above();
                    if (!level.getBlockState(above).getCollisionShape(level, above).isEmpty()) continue;
                    if (!canHost(level, top) || !canHost(level, deep)) continue;
                    placeCell(level, top, n, plane, anchor.asLong(), expires, false, 0, 0, 0, false);
                    placeCell(level, deep, n, plane, anchor.asLong(), expires, false, 0, 0, 0, false);
                }
            }
        } else {
            Direction lat = n.getClockWise();
            for (int u = -nr; u <= nr; u++) {
                for (int v = 0; v <= 1 + nr; v++) {
                    BlockPos c = anchor.relative(lat, u).above(v);
                    if (level.getBlockState(c).is(ModBlocks.NULL_ZONE.get())) continue;
                    if (!level.hasChunkAt(c)) continue;
                    BlockPos front = c.relative(n.getOpposite());
                    if (!level.getBlockState(front).getCollisionShape(level, front).isEmpty()) continue;   // harus bisa didatangi
                    if (!canHost(level, c)) continue;
                    placeCell(level, c, n, plane, anchor.asLong(), expires, false, 0, 0, 0, false);
                }
            }
        }
    }

    // ---------------------------------------------------------------- blok yang boleh ditiru

    /** Tanah di luar ruangan: Grass Block dan Dirt. */
    public static boolean isGround(BlockState s) {
        return s.is(Blocks.GRASS_BLOCK) || s.is(Blocks.DIRT);
    }

    /**
     * Blok padat penuh yang tidak punya data: semua jenis kayu, cobblestone dan variannya, batu, bata, lantai rumah,
     * Dirt, Grass Block, dst. Warna biome (rumput) ditiru oleh pewarna klien, jadi Grass Block aman.
     */
    public static boolean canHost(ServerLevel l, BlockPos pos) {
        BlockState s = l.getBlockState(pos);
        return s.isCollisionShapeFullBlock(l, pos) && s.canOcclude() && s.getDestroySpeed(l, pos) >= 0
                && !s.hasBlockEntity() && !s.is(Blocks.BEDROCK)
                && !s.is(ModBlocks.NULL_ZONE.get()) && !s.is(ModBlocks.THRESHOLD.get());
    }

    private static Direction[] shuffled(RandomSource r) {
        Direction[] dirs = {Direction.NORTH, Direction.EAST, Direction.SOUTH, Direction.WEST};
        for (int i = dirs.length - 1; i > 0; i--) {
            int j = r.nextInt(i + 1);
            Direction t = dirs[i];
            dirs[i] = dirs[j];
            dirs[j] = t;
        }
        return dirs;
    }
}
