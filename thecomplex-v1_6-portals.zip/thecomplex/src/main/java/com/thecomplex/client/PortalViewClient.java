package com.thecomplex.client;

import com.mojang.blaze3d.pipeline.TextureTarget;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.thecomplex.TheComplex;
import com.thecomplex.net.PortalViewPacket;
import com.thecomplex.portal.PortalMath;
import net.minecraft.Util;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.EmptyBlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterClientCommandsEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.client.model.data.ModelData;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.loading.FMLPaths;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Efek see-through untuk Threshold, tanpa stencil dan tanpa dunia kedua (jadi aman untuk MobileGlues):
 *  1. Server mengirim cuplikan blok sisi seberang (PortalViewPacket). Klien mengubahnya jadi daftar quad kecil.
 *  2. Tiap frame, untuk Threshold terdekat yang terlihat, daftar quad itu digambar dari "kamera bayangan"
 *     (kamera pemain yang dipindah lewat transformasi portal) ke tekstur kecil (setengah resolusi layar).
 *  3. Tekstur itu ditempelkan pada bukaan Threshold dengan koordinat layar, dipecah jadi kisi kecil supaya perspektifnya benar.
 * Shader yang dipakai hanya shader bawaan Minecraft. Semua dibungkus pengaman:
 *  - kalau ada kesalahan, efek mati sendiri dan Threshold tampil seperti biasa,
 *  - kalau game sempat crash saat efek menyala, saat game dibuka lagi efek otomatis mati (berkas penanda),
 *  - perintah /complexview on|off|status.
 */
@Mod.EventBusSubscriber(modid = TheComplex.MODID, value = Dist.CLIENT)
public final class PortalViewClient {
    private static final double MAX_DIST = 18.0;
    private static final int MAX_QUADS = 3200;
    private static final int GRID_X = 6, GRID_Y = 9;
    private static final long STALE_MS = 45_000;
    private static final int OK_FRAMES_TO_CLEAR_MARKER = 180;

    private static final class View {
        long key;
        String dim;
        Vec3 src, dest;
        boolean axisX;
        float halfW, halfH;
        int ex, ez;
        float[] verts = new float[0];     // 8 float per titik: x y z (relatif ke pusat tujuan), u v, r g b
        int vertCount;
        float ambient;
        int hash;
        long lastMs;
    }

    private static final Map<Long, View> VIEWS = new HashMap<>();
    private static TextureTarget target;

    private static boolean disabled;       // dimatikan otomatis karena kesalahan / crash sebelumnya
    private static boolean userOff;        // dimatikan pemain lewat /complexview off
    private static int okFrames;
    private static boolean markerWritten;
    private static String notice;

    private static final Path MARKER = FMLPaths.CONFIGDIR.get().resolve("thecomplex-portalview.attempt");
    private static final Path SETTING = FMLPaths.CONFIGDIR.get().resolve("thecomplex-portalview.txt");

    static {
        try {
            if (Files.exists(SETTING) && Files.readString(SETTING).trim().equalsIgnoreCase("off")) userOff = true;
            if (Files.exists(MARKER)) {
                // sesi sebelumnya berhenti saat efek menyala: matikan dulu
                userOff = true;
                disabled = true;
                Files.writeString(SETTING, "off");
                Files.deleteIfExists(MARKER);
                notice = "The Threshold see-through effect was switched off because the game stopped while it was on last time. "
                        + "Type /complexview on to try again.";
            }
        } catch (Throwable ignored) {
            // berkas tidak bisa dibaca: lanjut dengan nilai awal
        }
    }

    private PortalViewClient() {}

    // ---------------------------------------------------------------- data dari server

    public static void receive(PortalViewPacket m) {
        if (userOff || disabled) return;
        try {
            if (m.idx().length == 0) {
                VIEWS.remove(m.key());
                return;
            }
            int hash = Arrays.hashCode(m.idx()) * 31 + Arrays.hashCode(m.ids()) + m.ambient() * 7 + Arrays.hashCode(m.masks());
            View old = VIEWS.get(m.key());
            if (old != null && old.hash == hash && old.dest.x == m.dx() && old.dest.z == m.dz()) {
                old.lastMs = Util.getMillis();                 // tidak berubah: tidak perlu dirakit ulang
                return;
            }
            View v = bake(m);
            v.hash = hash;
            VIEWS.put(m.key(), v);
        } catch (Throwable t) {
            fail("baking the portal view", t);
        }
    }

    /** Dipanggil saat pemain dipindah (dimensi berganti): cuplikan lama tidak berlaku lagi. */
    public static void onTeleport() {
        VIEWS.clear();
    }

    private static float faceShade(Direction d) {
        return switch (d) {
            case UP -> 1.0f;
            case DOWN -> 0.5f;
            case NORTH, SOUTH -> 0.8f;
            default -> 0.6f;
        };
    }

    private static View bake(PortalViewPacket m) {
        Minecraft mc = Minecraft.getInstance();
        BlockRenderDispatcher disp = mc.getBlockRenderer();
        View v = new View();
        v.key = m.key();
        v.dim = m.dim();
        v.src = new Vec3(m.sx(), m.sy(), m.sz());
        v.dest = new Vec3(m.dx(), m.dy(), m.dz());
        v.axisX = m.axis() == 0;
        v.halfW = m.halfW();
        v.halfH = m.halfH();
        v.ex = m.ex();
        v.ez = m.ez();
        v.ambient = m.ambient();
        v.lastMs = Util.getMillis();

        float amb = 0.28f + 0.72f * Mth.clamp(m.ambient() / 15f, 0f, 1f);
        float[] out = new float[8 * 4 * 256];
        int n = 0, quads = 0;
        RandomSource rs = RandomSource.create(42L);
        for (int i = 0; i < m.idx().length && quads < MAX_QUADS; i++) {
            BlockState st = Block.BLOCK_STATE_REGISTRY.byId(m.ids()[i]);
            if (st == null || st.isAir()) continue;
            int idx = m.idx()[i];
            int lx = idx % m.w(), lz = (idx / m.w()) % m.d(), ly = idx / (m.w() * m.d());
            float wx = (float) (m.bx() + lx - m.dx()), wy = (float) (m.by() + ly - m.dy()), wz = (float) (m.bz() + lz - m.dz());
            BakedModel model = disp.getBlockModel(st);
            boolean solid = st.isSolidRender(EmptyBlockGetter.INSTANCE, BlockPos.ZERO);
            int mask = m.masks()[i] & 0x3F;
            float br = st.getLightEmission() >= 8 ? 1f : amb;

            List<BakedQuad> list = new ArrayList<>();
            for (Direction dir : Direction.values()) {
                if (solid && (mask & (1 << dir.get3DDataValue())) == 0) continue;
                list.addAll(model.getQuads(st, dir, rs, ModelData.EMPTY, null));
            }
            if (!solid) list.addAll(model.getQuads(st, null, rs, ModelData.EMPTY, null));

            for (BakedQuad q : list) {
                if (quads >= MAX_QUADS) break;
                if (n + 32 > out.length) out = Arrays.copyOf(out, out.length * 2);
                float sh = q.isShade() ? faceShade(q.getDirection()) : 1f;
                float cr = 1f, cg = 1f, cb = 1f;
                if (q.isTinted()) {
                    int tint = -1;
                    try {
                        tint = mc.getBlockColors().getColor(st, null, null, q.getTintIndex());
                    } catch (Throwable ignored) {
                        // pewarna yang butuh dunia: pakai putih
                    }
                    if (tint != -1) {
                        cr = ((tint >> 16) & 255) / 255f;
                        cg = ((tint >> 8) & 255) / 255f;
                        cb = (tint & 255) / 255f;
                    }
                }
                int[] vd = q.getVertices();
                for (int k = 0; k < 4; k++) {
                    int o = k * 8;
                    out[n++] = Float.intBitsToFloat(vd[o]) + wx;
                    out[n++] = Float.intBitsToFloat(vd[o + 1]) + wy;
                    out[n++] = Float.intBitsToFloat(vd[o + 2]) + wz;
                    out[n++] = Float.intBitsToFloat(vd[o + 4]);
                    out[n++] = Float.intBitsToFloat(vd[o + 5]);
                    out[n++] = cr * sh * br;
                    out[n++] = cg * sh * br;
                    out[n++] = cb * sh * br;
                }
                quads++;
            }
        }
        v.verts = Arrays.copyOf(out, n);
        v.vertCount = n / 8;
        return v;
    }

    // ---------------------------------------------------------------- menggambar

    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) return;
        if (disabled || userOff || VIEWS.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        try {
            renderNearest(e, mc);
        } catch (Throwable t) {
            fail("drawing the portal view", t);
        }
    }

    private static void renderNearest(RenderLevelStageEvent e, Minecraft mc) {
        Camera cam = e.getCamera();
        Vec3 cp = cam.getPosition();
        Vector3f lv = cam.getLookVector();
        Vec3 look = new Vec3(lv.x, lv.y, lv.z);
        String dimNow = mc.level.dimension().location().toString();
        long now = Util.getMillis();

        View best = null;
        double bestD = MAX_DIST * MAX_DIST, bestS = 0;
        for (Iterator<View> it = VIEWS.values().iterator(); it.hasNext(); ) {
            View v = it.next();
            if (now - v.lastMs > STALE_MS) {
                it.remove();
                continue;
            }
            if (!v.dim.equals(dimNow)) continue;
            Vec3 rel = cp.subtract(v.src);
            double d2 = rel.lengthSqr();
            if (d2 > bestD) continue;
            double s = rel.dot(v.axisX ? new Vec3(1, 0, 0) : new Vec3(0, 0, 1));
            if (Math.abs(s) < 0.03) continue;
            if (v.src.subtract(cp).dot(look) <= 0) continue;         // di belakang pemain
            best = v;
            bestD = d2;
            bestS = s;
        }
        if (best == null) return;
        View v = best;

        if (!markerWritten) {
            markerWritten = true;
            try {
                Files.writeString(MARKER, "portal view started");
            } catch (Throwable ignored) {
                // tidak apa-apa: hanya pengaman tambahan
            }
        }

        Vec3 n = v.axisX ? new Vec3(1, 0, 0) : new Vec3(0, 0, 1);
        Vec3 lat = v.axisX ? new Vec3(0, 0, 1) : new Vec3(1, 0, 0);
        double sgn = bestS > 0 ? 1 : -1;
        Vec3 travel = n.scale(-sgn);                                  // arah dari pemain menembus portal
        Vec3 exit = new Vec3(v.ex, 0, v.ez);
        double dyaw = PortalMath.yawOf(exit) - PortalMath.yawOf(travel);
        Vec3 vcam = v.dest.add(PortalMath.rotateYaw(cp.subtract(v.src), dyaw));

        int tw = Math.max(64, mc.getMainRenderTarget().width / 2);
        int th = Math.max(64, mc.getMainRenderTarget().height / 2);
        if (target == null || target.width != tw || target.height != th) {
            if (target != null) target.destroyBuffers();
            target = new TextureTarget(tw, th, true, Minecraft.ON_OSX);
            target.setFilterMode(9729);                                // GL_LINEAR
        }
        float amb = 0.28f + 0.72f * Mth.clamp(v.ambient / 15f, 0f, 1f);
        target.setClearColor(0.55f * amb, 0.5f * amb, 0.3f * amb, 1f);
        target.clear(Minecraft.ON_OSX);

        Matrix4f proj = e.getProjectionMatrix();
        Matrix4f mainView = e.getPoseStack().last().pose();

        // ---- 1. sisi seberang ke tekstur kecil
        // kamera bayangan = kamera pemain yang diputar sebesar dyaw (pitch, roll, dan goyangan kamera ikut terbawa)
        Matrix4f virtualView = new Matrix4f(mainView).rotateY((float) Math.toRadians(dyaw));
        target.bindWrite(true);
        RenderSystem.setShader(GameRenderer::getPositionTexColorShader);
        RenderSystem.setShaderTexture(0, TextureAtlas.LOCATION_BLOCKS);
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(true);
        RenderSystem.disableBlend();
        RenderSystem.disableCull();
        PoseStack mv = RenderSystem.getModelViewStack();
        mv.pushPose();
        mv.setIdentity();
        mv.mulPoseMatrix(virtualView);
        RenderSystem.applyModelViewMatrix();
        BufferBuilder bb = Tesselator.getInstance().getBuilder();
        bb.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_TEX_COLOR);
        float ox = (float) (v.dest.x - vcam.x), oy = (float) (v.dest.y - vcam.y), oz = (float) (v.dest.z - vcam.z);
        float[] a = v.verts;
        for (int i = 0; i < a.length; i += 8) {
            bb.vertex(a[i] + ox, a[i + 1] + oy, a[i + 2] + oz).uv(a[i + 3], a[i + 4]).color(a[i + 5], a[i + 6], a[i + 7], 1f).endVertex();
        }
        BufferUploader.drawWithShader(bb.end());
        mv.popPose();
        RenderSystem.applyModelViewMatrix();
        mc.getMainRenderTarget().bindWrite(true);

        // ---- 2. tekstur itu ke bukaan Threshold
        double off = Math.abs(bestS) > 0.55 ? 0.52 : 0.0;             // di depan permukaan blok; di dalam blok: di bidang tengah
        Vec3 pc = v.src.add(n.scale(sgn * off));
        Matrix4f pm = new Matrix4f(proj).mul(mainView);
        int gx = GRID_X, gy = GRID_Y;
        float[] gp = new float[(gx + 1) * (gy + 1) * 5];
        Vector4f tmp = new Vector4f();
        int gi = 0;
        for (int iy = 0; iy <= gy; iy++) {
            for (int ix = 0; ix <= gx; ix++) {
                double fx = (ix / (double) gx * 2 - 1) * v.halfW, fy = (iy / (double) gy * 2 - 1) * v.halfH;
                Vec3 p = pc.add(lat.scale(fx)).add(0, fy, 0).subtract(cp);
                tmp.set((float) p.x, (float) p.y, (float) p.z, 1f);
                pm.transform(tmp);
                if (tmp.w < 0.02f) {
                    afterDraw();
                    return;                                            // sebagian di belakang kamera: biarkan Threshold biasa
                }
                gp[gi++] = (float) p.x;
                gp[gi++] = (float) p.y;
                gp[gi++] = (float) p.z;
                gp[gi++] = (tmp.x / tmp.w) * 0.5f + 0.5f;
                gp[gi++] = (tmp.y / tmp.w) * 0.5f + 0.5f;
            }
        }
        RenderSystem.setShader(GameRenderer::getPositionTexShader);
        RenderSystem.setShaderTexture(0, target.getColorTextureId());
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        mv.pushPose();
        mv.setIdentity();
        mv.mulPoseMatrix(mainView);
        RenderSystem.applyModelViewMatrix();
        bb.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_TEX);
        for (int iy = 0; iy < gy; iy++) {
            for (int ix = 0; ix < gx; ix++) {
                int a0 = (iy * (gx + 1) + ix) * 5, a1 = a0 + 5, a2 = a0 + (gx + 1) * 5 + 5, a3 = a0 + (gx + 1) * 5;
                // urutan berlawanan jarum jam dilihat dari sisi pemain; culling dimatikan jadi arah tidak penting
                int[] corners = {a0, a1, a2, a3};
                for (int c : corners) bb.vertex(gp[c], gp[c + 1], gp[c + 2]).uv(gp[c + 3], gp[c + 4]).endVertex();
            }
        }
        BufferUploader.drawWithShader(bb.end());
        mv.popPose();
        RenderSystem.applyModelViewMatrix();
        afterDraw();
    }

    private static void afterDraw() {
        RenderSystem.enableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(true);
        if (++okFrames == OK_FRAMES_TO_CLEAR_MARKER) {
            try {
                Files.deleteIfExists(MARKER);
            } catch (Throwable ignored) {
                // tidak apa-apa
            }
        }
    }

    private static void fail(String what, Throwable t) {
        disabled = true;
        VIEWS.clear();
        try {
            Minecraft.getInstance().getMainRenderTarget().bindWrite(true);
            RenderSystem.enableCull();
        } catch (Throwable ignored) {
            // sudah mati juga
        }
        try {
            Files.deleteIfExists(MARKER);
        } catch (Throwable ignored) {
            // tidak apa-apa
        }
        TheComplex.LOGGER.error("Threshold see-through failed while " + what + ", switching it off for this session", t);
        notice = "The Threshold see-through effect hit an error and was switched off (the Threshold still works). See latest.log.";
    }

    // ---------------------------------------------------------------- pesan dan perintah

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END || notice == null) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        mc.player.sendSystemMessage(Component.literal("[Complex] " + notice));
        notice = null;
    }

    @SubscribeEvent
    public static void onCommands(RegisterClientCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("complexview")
                .then(Commands.literal("on").executes(c -> {
                    userOff = false;
                    disabled = false;
                    okFrames = 0;
                    markerWritten = false;
                    save("on");
                    c.getSource().sendSuccess(() -> Component.literal("Threshold see-through: ON"), false);
                    return 1;
                }))
                .then(Commands.literal("off").executes(c -> {
                    userOff = true;
                    VIEWS.clear();
                    save("off");
                    c.getSource().sendSuccess(() -> Component.literal("Threshold see-through: OFF"), false);
                    return 1;
                }))
                .then(Commands.literal("status").executes(c -> {
                    String s = disabled ? "switched off after an error" : userOff ? "OFF" : "ON";
                    c.getSource().sendSuccess(() -> Component.literal("Threshold see-through: " + s + " (views loaded: " + VIEWS.size() + ")"), false);
                    return 1;
                })));
    }

    private static void save(String value) {
        try {
            Files.writeString(SETTING, value);
        } catch (Throwable ignored) {
            // tidak apa-apa: pengaturan berlaku sampai game ditutup
        }
    }
}
