package com.thecomplex.world;

import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.levelgen.PositionalRandomFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * Architectural planner for one 16x16 chunk of the Backrooms.
 *
 * The planner is pure and deterministic: the same world seed always gives the same plan for a chunk, and a chunk never reads
 * another chunk's plan (only the shared EDGE functions, which both neighbors evaluate identically). That keeps generation
 * stateless, thread-safe and cheap.
 *
 * Pipeline per chunk:
 *  1. Edges: west and north walls are owned by this chunk, east and south walls by the neighbors. Door sizes are slightly
 *     off-scale (3 to 6 wide, a little off-center).
 *  2. Template: one of ten architectural layouts picked by the division (colonnade, partitions, corridors, arcade, cell, ...).
 *  3. Landing strips in front of every door are cleared, rooms (.schem) get breathing space.
 *  4. Pilasters, thin vertical-slab ribs, buttress wedges along the walls.
 *  5. Density pass: any 5x5 window of open floor is broken up by a centerpiece (pillars, half-walls, piers, benches).
 *  6. Optional set pieces: raised carpet platform with a wedge ramp, lowered soffit strips.
 *  7. Connectivity: flood fill from the doors. Doors that cannot reach each other get a carved passage and every sealed
 *     pocket is filled in. Every decoration step is validated by the same flood fill and reverted if it would seal anything.
 *
 * Macro connectivity (between chunks): the world is split into 8x8-chunk blocks. Inside a block, chunk links form a random
 * spanning tree (each chunk links north OR west), plus extra random openings for loops. Between blocks, every shared
 * boundary has at least one guaranteed gateway. So every chunk can reach every other chunk, by construction.
 */
public final class BackroomsDesigner {
    // ---- column kinds
    public static final byte OPEN = 0, WALL = 1, PILLAR = 2, HALF_PILLAR = 3, HALF_WALL = 4, VSLAB = 5, LOW_SLAB = 6,
            DOOR_ARCH = 7, SOFFIT = 8, PLATFORM = 9, RAMP = 10, BUTTRESS = 11;
    // ---- material families (white only exists as a full wall block)
    public static final byte CLASSIC = 0, OFFICE = 1, WHITE = 2;

    private static final int N = 16;
    /** No bare floor window larger than this (in cells) is allowed. */
    private static final int WINDOW = 5;
    // Direction.get2DDataValue(): 0 south, 1 west, 2 north, 3 east
    private static final int D_S = 0, D_W = 1, D_N = 2, D_E = 3;

    public static final class Plan {
        public final byte[] kind = new byte[N * N];
        public final byte[] fam = new byte[N * N];
        /** Direction.get2DDataValue(); for DOOR_ARCH: 0 = passage along X, 1 = passage along Z. */
        public final byte[] dir = new byte[N * N];
        final boolean[] keep = new boolean[N * N];

        Plan copy() {
            Plan c = new Plan();
            System.arraycopy(kind, 0, c.kind, 0, kind.length);
            System.arraycopy(fam, 0, c.fam, 0, fam.length);
            System.arraycopy(dir, 0, c.dir, 0, dir.length);
            System.arraycopy(keep, 0, c.keep, 0, keep.length);
            return c;
        }

        void restore(Plan o) {
            System.arraycopy(o.kind, 0, kind, 0, kind.length);
            System.arraycopy(o.fam, 0, fam, 0, fam.length);
            System.arraycopy(o.dir, 0, dir, 0, dir.length);
        }

        public byte kindAt(int x, int z) {
            return x < 0 || z < 0 || x >= N || z >= N ? WALL : kind[z * N + x];
        }

        void set(int x, int z, byte k, byte f, int d) {
            if (x < 0 || z < 0 || x >= N || z >= N) return;
            int i = z * N + x;
            kind[i] = k;
            fam[i] = f;
            dir[i] = (byte) d;
        }

        boolean isOpen(int x, int z) {
            return x >= 1 && z >= 1 && x < N && z < N && kind[z * N + x] == OPEN && !keep[z * N + x];
        }
    }

    /** One side of a chunk. state: 0 wall, 1 door (start, width), 2 fully open. */
    public record Edge(int state, int start, int width) {
        public boolean passable() {
            return state > 0;
        }

        public boolean isDoor(int i) {
            return state == 2 || (state == 1 && i >= start && i < start + width);
        }

        public int mid() {
            return state == 2 ? 8 : start + width / 2;
        }
    }

    private BackroomsDesigner() {}

    // =====================================================================================================
    // Edges and macro connectivity
    // =====================================================================================================

    /** The west (or north) edge owned by chunk (cx, cz). Neighbors call this for their east / south side. */
    public static Edge edge(PositionalRandomFactory f, int cx, int cz, boolean west) {
        int ncx = west ? cx - 1 : cx, ncz = west ? cz : cz - 1;
        if (ComplexLayout.reserved(ncx, ncz)) {
            // custom Main Chamber: no extra wall, so openings in the chamber wall lead straight into the Backrooms
            return new Edge(ComplexLayout.hasCustomMainChamber() ? 2 : 0, 0, 0);
        }
        int state;
        if (ComplexLayout.roomAt(f, ncx, ncz) != null) state = 1;     // next to a hand-built room: always a door
        else state = treeState(f, cx, cz, west);
        // different ceiling heights meet: door only, never a fully open hall
        if (state == 2 && Division.at(f, cx, cz).air != Division.at(f, ncx, ncz).air) state = 1;

        RandomSource r = f.at(cx, west ? 45 : 46, cz);
        int roll = r.nextInt(100);
        int w = roll < 20 ? 3 : roll < 65 ? 4 : roll < 85 ? 5 : 6;     // slightly wrong proportions
        int start = Mth.clamp(8 - w / 2 + (r.nextInt(3) - 1), 2, 14 - w);
        return new Edge(state, start, w);
    }

    private static boolean linksWest(PositionalRandomFactory f, int cx, int cz) {
        int lx = Math.floorMod(cx, Division.REGION), lz = Math.floorMod(cz, Division.REGION);
        if (lx == 0) return false;
        if (lz == 0) return true;
        return f.at(cx, 44, cz).nextBoolean();
    }

    private static int treeState(PositionalRandomFactory f, int cx, int cz, boolean west) {
        int R = Division.REGION;
        int lx = Math.floorMod(cx, R), lz = Math.floorMod(cz, R);
        RandomSource r = f.at(cx, west ? 40 : 41, cz);
        boolean boundary = west ? lx == 0 : lz == 0;
        if (boundary) {
            // gateway between two 8x8 blocks: one guaranteed per boundary line, a few extra
            int idx = west ? lz : lx;
            int base = f.at(Math.floorDiv(cx, R), west ? 42 : 43, Math.floorDiv(cz, R)).nextInt(R);
            boolean open = idx == base || r.nextInt(100) < 22;
            return open ? (r.nextInt(100) < 25 ? 2 : 1) : 0;
        }
        boolean tree = west == linksWest(f, cx, cz);
        if (tree) return r.nextInt(100) < 25 ? 2 : 1;
        int openness = Division.at(f, cx, cz).openness;
        return r.nextInt(100) < openness ? (r.nextInt(100) < 20 ? 2 : 1) : 0;
    }

    // =====================================================================================================
    // Materials: mono-yellow palette, classic wallpaper dominant, plain office wall in districts, rare white
    // =====================================================================================================

    private static byte districtFamily(PositionalRandomFactory f, int cx, int cz) {
        return (byte) (f.at(Math.floorDiv(cx, 4), 31, Math.floorDiv(cz, 4)).nextInt(100) < 65 ? CLASSIC : OFFICE);
    }

    private static byte edgeFamily(PositionalRandomFactory f, int cx, int cz, boolean west) {
        if (f.at(cx, west ? 32 : 33, cz).nextInt(100) < 6) return WHITE;
        return districtFamily(f, cx, cz);
    }

    private static byte interiorFamily(PositionalRandomFactory f, int cx, int cz) {
        byte base = districtFamily(f, cx, cz);
        return f.at(cx, 34, cz).nextInt(100) < 25 ? (byte) (1 - base) : base;
    }

    private static byte nonWhite(byte fam) {
        return fam == WHITE ? OFFICE : fam;
    }

    // =====================================================================================================
    // Plan
    // =====================================================================================================

    /** @param air ceiling height in blocks (3 in Standard areas) */
    public static Plan design(PositionalRandomFactory f, int cx, int cz, Division div, List<int[]> roomBoxes, int x0, int z0) {
        Plan p = new Plan();
        Edge ew = edge(f, cx, cz, true), en = edge(f, cx, cz, false);
        Edge ee = edge(f, cx + 1, cz, true), es = edge(f, cx, cz + 1, false);
        byte fam = interiorFamily(f, cx, cz);
        byte famW = edgeFamily(f, cx, cz, true), famN = edgeFamily(f, cx, cz, false);

        // 1. edge walls
        for (int i = 0; i < N; i++) {
            if (ew.isDoor(i)) {
                p.set(0, i, ew.state() == 2 ? OPEN : DOOR_ARCH, nonWhite(famW), 0);
            } else {
                p.set(0, i, WALL, famW, 0);
            }
            if (en.isDoor(i)) {
                p.set(i, 0, en.state() == 2 ? OPEN : DOOR_ARCH, nonWhite(famN), 1);
            } else {
                p.set(i, 0, WALL, famN, 0);
            }
        }
        p.set(0, 0, WALL, famW, 0);

        // portals: one cell per passable side
        List<int[]> portals = new ArrayList<>();
        if (ew.passable()) portals.add(new int[]{0, ew.mid()});
        if (en.passable()) portals.add(new int[]{en.mid(), 0});
        if (ee.passable()) portals.add(new int[]{15, ee.mid()});
        if (es.passable()) portals.add(new int[]{es.mid(), 15});

        // landing strips (2 deep) in front of each door stay clear
        markLanding(p, ew, true, 0);
        markLanding(p, en, false, 0);
        markLanding(p, ee, true, 14);
        markLanding(p, es, false, 14);

        // 2. template
        RandomSource r = f.at(cx, 2, cz);
        template(p, div.pickPattern(r.nextInt(100)), r, fam);

        // 3. clear landings, give hand-built rooms breathing room
        for (int i = 0; i < N * N; i++) {
            if (p.keep[i] && (i % N) != 0 && (i / N) != 0) p.kind[i] = OPEN;
        }
        for (int[] box : roomBoxes) {
            for (int lx = 1; lx < N; lx++) {
                for (int lz = 1; lz < N; lz++) {
                    int wx = x0 + lx, wz = z0 + lz;
                    if (wx >= box[0] - 2 && wx <= box[1] + 2 && wz >= box[2] - 2 && wz <= box[3] + 2) p.kind[lz * N + lx] = OPEN;
                }
            }
        }

        // 4 to 6. decoration, each step validated against connectivity
        RandomSource dr = f.at(cx, 6, cz);
        decorate(p, portals, dr, fam, div);

        // 7. final guarantee
        enforce(p, portals, fam);
        return p;
    }

    private static void markLanding(Plan p, Edge e, boolean vertical, int inner) {
        if (!e.passable()) return;
        for (int i = 0; i < N; i++) {
            if (!e.isDoor(i)) continue;
            for (int d = 0; d < 2; d++) {
                int a = vertical ? (inner == 0 ? 1 + d : 14 + d) : i;
                int b = vertical ? i : (inner == 0 ? 1 + d : 14 + d);
                if (a >= 1 && a < N && b >= 1 && b < N) p.keep[b * N + a] = true;
            }
        }
    }

    // =====================================================================================================
    // Templates
    // =====================================================================================================

    private static byte accent(RandomSource r, byte fam) {
        return r.nextInt(100) < 4 ? WHITE : fam;
    }

    private static void template(Plan p, int id, RandomSource r, byte fam) {
        switch (id) {
            case 0 -> {   // pillar forest: dense 1x1 pillar lattice, one heavy pier
                int o = 3 + r.nextInt(2);
                for (int x = o; x < N; x += 3) for (int z = o; z < N; z += 3) p.set(x, z, PILLAR, nonWhite(fam), 0);
                int px = o + 3 * r.nextInt(3), pz = o + 3 * r.nextInt(3);
                if (px + 1 < N && pz + 1 < N) {
                    for (int dx = 0; dx < 2; dx++) for (int dz = 0; dz < 2; dz++) p.set(px + dx, pz + dz, WALL, accent(r, fam), 0);
                }
            }
            case 1 -> {   // central pier with half-wall arms and pilasters
                for (int x = 6; x <= 9; x++) for (int z = 6; z <= 9; z++) p.set(x, z, WALL, fam, 0);
                for (int i = 2; i <= 4; i++) {
                    p.set(i, 7, HALF_WALL, fam, 0);
                    p.set(15 - i + 1, 8, HALF_WALL, fam, 0);
                    p.set(7, i, HALF_WALL, fam, 0);
                    p.set(8, 15 - i + 1, HALF_WALL, fam, 0);
                }
                p.set(5, 7, HALF_PILLAR, nonWhite(fam), D_E);
                p.set(10, 8, HALF_PILLAR, nonWhite(fam), D_W);
            }
            case 2, 3 -> {   // thin partition with an arched gap
                boolean alongX = id == 2;
                int o = 2 + r.nextInt(9), w = 3 + r.nextInt(3);
                byte f2 = accent(r, fam);
                for (int i = 1; i < N; i++) {
                    boolean gap = i >= o && i < o + w;
                    int x = alongX ? i : 8, z = alongX ? 8 : i;
                    if (gap) p.set(x, z, DOOR_ARCH, nonWhite(fam), alongX ? 1 : 0);
                    else if (i == o - 1 || i == o + w) p.set(x, z, WALL, f2, 0);
                    else p.set(x, z, VSLAB, nonWhite(fam), alongX ? D_S : D_E);
                }
            }
            case 4 -> {   // colonnade hall: two pillar rows, low benches, lowered soffit down the middle
                for (int x = 3; x < N; x += 3) {
                    p.set(x, 4, PILLAR, nonWhite(fam), 0);
                    p.set(x, 11, PILLAR, nonWhite(fam), 0);
                }
                for (int x = 4; x <= 6; x++) p.set(x, 2, LOW_SLAB, nonWhite(fam), 0);
                for (int x = 10; x <= 12; x++) p.set(x, 13, LOW_SLAB, nonWhite(fam), 0);
                if (r.nextInt(100) < 60) for (int x = 2; x <= 13; x++) for (int z = 7; z <= 8; z++) p.set(x, z, SOFFIT, nonWhite(fam), 0);
            }
            case 5, 6 -> {   // narrow corridor with arched cross-gaps
                boolean alongX = id == 5;
                int g1 = 1 + r.nextInt(11), g2 = 1 + r.nextInt(11);
                byte f2 = accent(r, fam);
                for (int i = 1; i < N; i++) {
                    for (int line : new int[]{5, 10}) {
                        int g = line == 5 ? g1 : g2;
                        boolean gap = i >= g && i < g + 4;
                        int x = alongX ? i : line, z = alongX ? line : i;
                        if (gap) p.set(x, z, DOOR_ARCH, nonWhite(fam), alongX ? 1 : 0);
                        else p.set(x, z, WALL, f2, 0);
                    }
                }
                if (r.nextInt(100) < 45) {
                    for (int i = 2; i <= 13; i++) for (int w = 6; w <= 9; w++) {
                        if (p.kindAt(alongX ? i : w, alongX ? w : i) == OPEN) p.set(alongX ? i : w, alongX ? w : i, SOFFIT, nonWhite(fam), 0);
                    }
                }
            }
            case 7 -> {   // arcade: pillar posts joined by half-walls
                for (int x : new int[]{2, 5, 8, 11, 14}) {
                    p.set(x, 4, PILLAR, nonWhite(fam), 0);
                    p.set(x, 11, PILLAR, nonWhite(fam), 0);
                }
                for (int x : new int[]{2, 8, 14}) {
                    for (int dx = 1; dx <= 2; dx++) {
                        p.set(x + dx, 4, HALF_WALL, fam, 0);
                        p.set(x + dx, 11, HALF_WALL, fam, 0);
                    }
                }
            }
            case 8 -> {   // small cell: arched door, raised carpet inside
                for (int i = 4; i <= 11; i++) {
                    p.set(i, 4, WALL, fam, 0);
                    p.set(i, 11, WALL, fam, 0);
                    p.set(4, i, WALL, fam, 0);
                    p.set(11, i, WALL, fam, 0);
                }
                int side = r.nextInt(4), p0 = 5 + r.nextInt(4);
                switch (side) {
                    case 0 -> { p.set(p0, 4, DOOR_ARCH, nonWhite(fam), 1); p.set(p0 + 1, 4, DOOR_ARCH, nonWhite(fam), 1); }
                    case 1 -> { p.set(p0, 11, DOOR_ARCH, nonWhite(fam), 1); p.set(p0 + 1, 11, DOOR_ARCH, nonWhite(fam), 1); }
                    case 2 -> { p.set(4, p0, DOOR_ARCH, nonWhite(fam), 0); p.set(4, p0 + 1, DOOR_ARCH, nonWhite(fam), 0); }
                    default -> { p.set(11, p0, DOOR_ARCH, nonWhite(fam), 0); p.set(11, p0 + 1, DOOR_ARCH, nonWhite(fam), 0); }
                }
                for (int x = 6; x <= 9; x++) { p.set(x, 9, PLATFORM, fam, 0); p.set(x, 10, LOW_SLAB, nonWhite(fam), 0); }
            }
            default -> {   // L wall with buttress wedges and an arched gap
                for (int x = 1; x <= 10; x++) p.set(x, 5, WALL, fam, 0);
                for (int z = 5; z <= 13; z++) {
                    if (z >= 7 && z <= 10) p.set(10, z, DOOR_ARCH, nonWhite(fam), 0);
                    else p.set(10, z, WALL, fam, 0);
                }
                for (int x : new int[]{3, 6, 8}) p.set(x, 6, BUTTRESS, nonWhite(fam), D_N);
            }
        }
    }

    // =====================================================================================================
    // Decoration
    // =====================================================================================================

    private static void decorate(Plan p, List<int[]> portals, RandomSource r, byte fam, Division div) {
        // pilasters (half pillars) on the two owned walls, thin vertical-slab ribs between them
        for (int i : new int[]{4, 12}) {
            if (p.kindAt(0, i) == WALL && p.isOpen(1, i)) place(p, portals, 1, i, HALF_PILLAR, nonWhite(fam), D_W);
            if (p.kindAt(i, 0) == WALL && p.isOpen(i, 1)) place(p, portals, i, 1, HALF_PILLAR, nonWhite(fam), D_N);
        }
        for (int i : new int[]{2, 7, 13}) {
            if (r.nextInt(100) < 55 && p.kindAt(0, i) == WALL && p.isOpen(1, i)) place(p, portals, 1, i, VSLAB, nonWhite(fam), D_W);
            if (r.nextInt(100) < 55 && p.kindAt(i, 0) == WALL && p.isOpen(i, 1)) place(p, portals, i, 1, VSLAB, nonWhite(fam), D_N);
        }
        // buttress wedges against walls
        for (int tries = 0; tries < 6; tries++) {
            int x = 2 + r.nextInt(13), z = 2 + r.nextInt(13);
            if (!p.isOpen(x, z)) continue;
            int[][] dirs = {{0, 1, D_S}, {-1, 0, D_W}, {0, -1, D_N}, {1, 0, D_E}};
            int[] d = dirs[r.nextInt(4)];
            if (p.kindAt(x + d[0], z + d[1]) == WALL && r.nextInt(100) < 35) {
                if (place(p, portals, x, z, BUTTRESS, nonWhite(fam), d[2])) break;
            }
        }
        // density: no 5x5 window of bare floor
        for (int pass = 0; pass < 12; pass++) {
            int[] w = findEmptyWindow(p, r.nextInt(100));
            if (w == null) break;
            boolean done = false;
            int style = r.nextInt(4);
            for (int k = 0; k < 4 && !done; k++) done = centerpiece(p, portals, w[0], w[1], (style + k) % 4, nonWhite(fam), r);
            if (!done) {
                // could not break it up without sealing anything: raise one pillar in the middle as a last resort
                p.set(w[0] + 2, w[1] + 2, PILLAR, nonWhite(fam), 0);
                if (!connected(p, portals)) p.set(w[0] + 2, w[1] + 2, OPEN, fam, 0);
            }
        }
        // raised carpet platform with a wedge ramp
        if (r.nextInt(100) < 22) platform(p, portals, r);
    }

    private static boolean place(Plan p, List<int[]> portals, int x, int z, byte k, byte fam, int d) {
        Plan snap = p.copy();
        p.set(x, z, k, fam, d);
        if (connected(p, portals)) return true;
        p.restore(snap);
        return false;
    }

    private static int[] findEmptyWindow(Plan p, int offset) {
        for (int a = 0; a < 121; a++) {
            int i = (a + offset) % 121;
            int x0 = 1 + (i % 11), z0 = 1 + (i / 11);
            boolean empty = true;
            for (int x = x0; x < x0 + WINDOW && empty; x++) for (int z = z0; z < z0 + WINDOW; z++) if (p.kindAt(x, z) != OPEN) { empty = false; break; }
            if (empty) return new int[]{x0, z0};
        }
        return null;
    }

    private static boolean centerpiece(Plan p, List<int[]> portals, int x0, int z0, int style, byte fam, RandomSource r) {
        Plan snap = p.copy();
        int cx = x0 + 2, cz = z0 + 2;
        boolean clear = true;
        switch (style) {
            case 0 -> {
                p.set(cx, cz, PILLAR, fam, 0);
                p.set(cx + 1, cz + 1, PILLAR, fam, 0);
            }
            case 1 -> {
                for (int x = x0; x <= x0 + 3; x++) p.set(x, cz + 1, HALF_WALL, fam, 0);
            }
            case 2 -> {
                for (int dx = 0; dx < 2; dx++) for (int dz = 0; dz < 2; dz++) p.set(cx + dx, cz + dz, WALL, fam, 0);
                p.set(cx - 1, cz, HALF_PILLAR, fam, D_E);
                p.set(cx + 2, cz, HALF_PILLAR, fam, D_W);
            }
            default -> {
                for (int x = x0; x <= x0 + 2; x++) p.set(x, cz, LOW_SLAB, fam, 0);
                p.set(x0 + 3, cz, PILLAR, fam, 0);
            }
        }
        for (int x = x0; x < x0 + WINDOW && clear; x++) for (int z = z0; z < z0 + WINDOW; z++) if (p.keep[z * N + x] && p.kindAt(x, z) != OPEN) { clear = false; break; }
        if (clear && connected(p, portals)) return true;
        p.restore(snap);
        return false;
    }

    private static void platform(Plan p, List<int[]> portals, RandomSource r) {
        for (int tries = 0; tries < 6; tries++) {
            int o = r.nextInt(4);
            int x = 2 + r.nextInt(10), z = 2 + r.nextInt(10);
            Plan snap = p.copy();
            boolean ok = true;
            for (int dx = 0; dx < 3 && ok; dx++) for (int dz = 0; dz < 3; dz++) if (!p.isOpen(x + dx, z + dz)) { ok = false; break; }
            if (!ok) continue;
            for (int i = 0; i < 3 && ok; i++) {
                int rx, rz, face;
                switch (o) {
                    case 0 -> { rx = x + i; rz = z + 3; face = D_N; }
                    case 1 -> { rx = x + i; rz = z - 1; face = D_S; }
                    case 2 -> { rx = x - 1; rz = z + i; face = D_E; }
                    default -> { rx = x + 3; rz = z + i; face = D_W; }
                }
                if (!p.isOpen(rx, rz)) { ok = false; break; }
                p.set(rx, rz, RAMP, OFFICE, face);
            }
            if (!ok) { p.restore(snap); continue; }
            for (int dx = 0; dx < 3; dx++) for (int dz = 0; dz < 3; dz++) p.set(x + dx, z + dz, PLATFORM, OFFICE, 0);
            if (connected(p, portals)) return;
            p.restore(snap);
        }
    }

    // =====================================================================================================
    // Connectivity
    // =====================================================================================================

    private static boolean walkable(byte k) {
        return k == OPEN || k == DOOR_ARCH || k == SOFFIT || k == PLATFORM || k == RAMP || k == LOW_SLAB || k == HALF_WALL;
    }

    private static boolean[] reach(Plan p, int sx, int sz) {
        boolean[] seen = new boolean[N * N];
        if (sx < 0 || sz < 0 || sx >= N || sz >= N || !walkable(p.kind[sz * N + sx])) return seen;
        int[] stack = new int[N * N];
        int sp = 0;
        stack[sp++] = sz * N + sx;
        seen[sz * N + sx] = true;
        while (sp > 0) {
            int i = stack[--sp];
            int x = i % N, z = i / N;
            if (x > 0 && !seen[i - 1] && walkable(p.kind[i - 1])) { seen[i - 1] = true; stack[sp++] = i - 1; }
            if (x < N - 1 && !seen[i + 1] && walkable(p.kind[i + 1])) { seen[i + 1] = true; stack[sp++] = i + 1; }
            if (z > 0 && !seen[i - N] && walkable(p.kind[i - N])) { seen[i - N] = true; stack[sp++] = i - N; }
            if (z < N - 1 && !seen[i + N] && walkable(p.kind[i + N])) { seen[i + N] = true; stack[sp++] = i + N; }
        }
        return seen;
    }

    /** True when all portals reach each other and no walkable cell is sealed off. */
    private static boolean connected(Plan p, List<int[]> portals) {
        int sx, sz;
        if (!portals.isEmpty()) {
            sx = portals.get(0)[0];
            sz = portals.get(0)[1];
        } else {
            sx = -1;
            sz = -1;
            for (int i = 0; i < N * N; i++) if (walkable(p.kind[i])) { sx = i % N; sz = i / N; break; }
            if (sx < 0) return true;
        }
        boolean[] seen = reach(p, sx, sz);
        for (int[] q : portals) if (!seen[q[1] * N + q[0]]) return false;
        for (int i = 0; i < N * N; i++) if (walkable(p.kind[i]) && !seen[i]) return false;
        return true;
    }

    private static void carve(Plan p, int ax, int az, int bx, int bz) {
        int x = ax, z = az;
        while (x != bx) {
            clearCell(p, x, z);
            clearCell(p, x, z + 1);
            x += Integer.compare(bx, x);
        }
        while (z != bz) {
            clearCell(p, x, z);
            clearCell(p, x + 1, z);
            z += Integer.compare(bz, z);
        }
        clearCell(p, bx, bz);
    }

    private static void clearCell(Plan p, int x, int z) {
        if (x < 1 || z < 1 || x >= N || z >= N) return;     // never touch the edge walls
        p.kind[z * N + x] = OPEN;
    }

    /** Last line of defense: make connectivity true no matter what the templates did. */
    private static void enforce(Plan p, List<int[]> portals, byte fam) {
        if (!portals.isEmpty()) {
            int[] root = portals.get(0);
            if (!walkable(p.kind[root[1] * N + root[0]])) p.kind[root[1] * N + root[0]] = OPEN;
            for (int k = 1; k < portals.size(); k++) {
                int[] q = portals.get(k);
                boolean[] seen = reach(p, root[0], root[1]);
                if (!seen[q[1] * N + q[0]]) {
                    if (!walkable(p.kind[q[1] * N + q[0]])) p.kind[q[1] * N + q[0]] = OPEN;
                    carve(p, q[0], q[1], root[0], root[1]);
                }
            }
        }
        // fill every sealed pocket
        int sx = -1, sz = -1;
        if (!portals.isEmpty()) {
            sx = portals.get(0)[0];
            sz = portals.get(0)[1];
        } else {
            // no doors at all: keep the largest area
            int best = 0;
            for (int i = 0; i < N * N; i++) {
                if (!walkable(p.kind[i])) continue;
                boolean[] seen = reach(p, i % N, i / N);
                int c = 0;
                for (boolean b : seen) if (b) c++;
                if (c > best) { best = c; sx = i % N; sz = i / N; }
            }
        }
        if (sx < 0) return;
        boolean[] seen = reach(p, sx, sz);
        for (int i = 0; i < N * N; i++) {
            if (walkable(p.kind[i]) && !seen[i]) {
                p.kind[i] = WALL;
                p.fam[i] = fam;
            }
        }
    }
}
