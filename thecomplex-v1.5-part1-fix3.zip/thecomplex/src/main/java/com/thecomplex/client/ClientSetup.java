package com.thecomplex.client;

import com.thecomplex.ModEntities;
import com.thecomplex.ModItems;
import com.thecomplex.TheComplex;
import com.thecomplex.item.FlashlightItem;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.item.ItemProperties;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

/** Pendaftaran sisi klien: renderer Briefcase, HUD posisi lempar, properti model senter. */
@Mod.EventBusSubscriber(modid = TheComplex.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientSetup {
    private ClientSetup() {}

    @SubscribeEvent
    public static void onRenderers(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(ModEntities.BRIEFCASE.get(), BriefcaseRenderer::new);
    }

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent e) {
        e.enqueueWork(() -> ItemProperties.register(ModItems.FLASHLIGHT.get(), new ResourceLocation(TheComplex.MODID, "lit"),
                (stack, level, entity, seed) -> FlashlightItem.isOn(stack) ? 1f : 0f));
    }

    @SubscribeEvent
    public static void onOverlays(RegisterGuiOverlaysEvent e) {
        e.registerAboveAll("throw_bar", (gui, g, partial, w, h) -> drawThrowBar(g, w, h));
    }

    private static void drawThrowBar(GuiGraphics g, int w, int h) {
        if (!ThrowClient.active) return;
        net.minecraft.client.gui.Font font = net.minecraft.client.Minecraft.getInstance().font;
        int n = com.thecomplex.briefcase.BriefcaseItem.MAX_POWER;
        int seg = 22, gap = 3, bw = n * seg + (n - 1) * gap, x = w / 2 - bw / 2, y = h / 2 + 24;
        g.fill(x - 4, y - 16, x + bw + 4, y + 28, 0xA0000000);
        String dist = String.format("%.1f", ThrowClient.power * 1.6);
        g.drawCenteredString(font, "Throw power " + ThrowClient.power + " / " + n + "  (about " + dist + " blocks)", w / 2, y - 12, 0xFFFFFF);
        for (int i = 1; i <= n; i++) {
            float k = (i - 1) / (float) (n - 1);
            int r = (int) (70 + 185 * k), gr = (int) (220 - 150 * k);
            int color = i <= ThrowClient.power ? 0xFF000000 | (r << 16) | (gr << 8) | 0x40 : 0xFF333333;
            int sx = x + (i - 1) * (seg + gap);
            g.fill(sx, y, sx + seg, y + 9, color);
        }
        // penggeser: penanda di segmen terpilih
        int sx = x + (ThrowClient.power - 1) * (seg + gap);
        g.fill(sx, y + 11, sx + seg, y + 13, 0xFFFFFFFF);
        g.fill(sx + seg / 2 - 2, y + 9, sx + seg / 2 + 2, y + 11, 0xFFFFFFFF);
        g.drawCenteredString(font, "Right-click: throw", w / 2, y + 16, 0xE0E0E0);
    }
}
