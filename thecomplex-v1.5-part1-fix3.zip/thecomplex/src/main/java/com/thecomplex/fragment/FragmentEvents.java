package com.thecomplex.fragment;

import com.thecomplex.TheComplex;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = TheComplex.MODID)
public final class FragmentEvents {
    private FragmentEvents() {}

    @SubscribeEvent
    public static void onServerStarted(ServerStartedEvent e) {
        FragmentStore.set(FragmentData.get(e.getServer().overworld()).all());
        TheComplex.LOGGER.info("[thecomplex] {} overworld fragments loaded", FragmentStore.all().size());
    }
}
