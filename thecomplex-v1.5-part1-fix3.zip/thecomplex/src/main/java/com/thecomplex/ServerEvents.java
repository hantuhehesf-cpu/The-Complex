package com.thecomplex;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.thecomplex.activity.ActivityData;
import com.thecomplex.activity.ActivityTracker;
import com.thecomplex.activity.NullZoneSpawner;
import com.thecomplex.world.Schem;
import com.thecomplex.world.SchemStore;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.ChunkPos;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Map;

@Mod.EventBusSubscriber(modid = TheComplex.MODID)
public final class ServerEvents {
    private ServerEvents() {}

    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("complex").requires(s -> s.hasPermission(2))
                .then(Commands.literal("enter").executes(c -> {
                    ComplexTeleporter.toArrival(c.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("backrooms").executes(c -> {
                    ComplexTeleporter.toBackrooms(c.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("leave").executes(c -> {
                    ComplexTeleporter.leave(c.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("rooms").executes(c -> {
                    StringBuilder sb = new StringBuilder("Rooms: ");
                    for (Schem r : SchemStore.rooms()) sb.append(r.name).append(" (").append(r.width).append('x')
                            .append(r.height).append('x').append(r.length).append(") ");
                    sb.append("| ").append(SchemStore.mainChamberStatus());
                    c.getSource().sendSuccess(() -> Component.literal(sb.toString()), false);
                    return 1;
                }))
                .then(Commands.literal("reload").executes(c -> {
                    int n = SchemStore.reloadRooms();
                    c.getSource().sendSuccess(() -> Component.literal("Reloaded: " + n + " rooms"), true);
                    return n;
                }))
                .then(Commands.literal("room").then(Commands.argument("name", StringArgumentType.word()).executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    String name = StringArgumentType.getString(c, "name");
                    Schem s = SchemStore.find(name);
                    if (s == null) {
                        c.getSource().sendFailure(Component.literal("Room not found: " + name));
                        return 0;
                    }
                    s.placeInLevel(p.serverLevel(), p.blockPosition().below());
                    c.getSource().sendSuccess(() -> Component.literal("Pasted: " + s.name), true);
                    return 1;
                })))
                .then(Commands.literal("heat").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    ActivityData d = ActivityData.get(p.server.overworld());
                    float here = d.heatAt(p.getUUID(), p.chunkPosition());
                    long oneIn = Math.round(1.0 / ActivityTracker.chance(here));
                    StringBuilder sb = new StringBuilder();
                    sb.append(String.format("Heat at this chunk: %.1f (Null Zone chance every 10 seconds: 1/%d)", here, oneIn));
                    sb.append(" | Top:");
                    for (Map.Entry<Long, Float> en : d.top(p.getUUID(), 5)) {
                        ChunkPos cp = new ChunkPos(en.getKey());
                        sb.append(String.format(" [%d,%d]=%.0f", cp.getMiddleBlockX(), cp.getMiddleBlockZ(), en.getValue()));
                    }
                    c.getSource().sendSuccess(() -> Component.literal(sb.toString()), false);
                    return 1;
                }))
                .then(Commands.literal("spawnnz").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    boolean ok = NullZoneSpawner.spawnFor(p, ActivityData.get(p.server.overworld()));
                    if (ok) c.getSource().sendSuccess(() -> Component.literal("Null Zone created near you"), true);
                    else c.getSource().sendFailure(Component.literal("No suitable indoor wall found, try again inside a building"));
                    return ok ? 1 : 0;
                })));
    }
}
