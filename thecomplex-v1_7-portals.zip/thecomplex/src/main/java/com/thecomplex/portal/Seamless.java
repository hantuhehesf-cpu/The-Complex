package com.thecomplex.portal;

import com.thecomplex.ComplexTeleporter;
import com.thecomplex.net.Net;
import com.thecomplex.net.SeamlessPacket;
import net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;

/**
 * Pemindahan pemain tanpa layar loading dan tanpa lag pemuatan dimensi:
 *  1. chunk tujuan dimuat lebih dulu (biasanya sudah, oleh PortalPreloader),
 *  2. klien diberi tahu supaya menyimpan bingkai terakhir (pemudar lintas-bingkai) dan menyembunyikan layar loading,
 *  3. pemain dipindah, lalu kecepatannya dikirim ulang supaya momentum terbawa.
 */
public final class Seamless {
    public static final int STYLE_THRESHOLD = 0;
    public static final int STYLE_NULL_ZONE = 1;
    public static final int STYLE_WILD = 2;

    private Seamless() {}

    public static void send(ServerPlayer p, ServerLevel dest, Vec3 pos, float yaw, float pitch, Vec3 velocity, int style) {
        int cx = (int) Math.floor(pos.x) >> 4, cz = (int) Math.floor(pos.z) >> 4;
        for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) dest.getChunk(cx + dx, cz + dz);

        Net.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), new SeamlessPacket(style));
        p.teleportTo(dest, pos.x, pos.y, pos.z, yaw, pitch);
        p.resetFallDistance();
        p.setDeltaMovement(velocity);
        p.connection.send(new ClientboundSetEntityMotionPacket(p));
        ComplexTeleporter.startCooldown(p);
        PortalSystem.forget(p);
    }
}
