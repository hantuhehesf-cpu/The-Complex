package com.thecomplex.client;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.pipeline.TextureTarget;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.thecomplex.TheComplex;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.ProgressScreen;
import net.minecraft.client.gui.screens.ReceivingLevelScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix4f;

/**
 * Sisi klien perpindahan mulus lewat portal.
 *  - Layar loading ("Loading terrain") disembunyikan selama beberapa detik sesudah server memberi tahu ada perpindahan.
 *  - Bingkai terakhir sebelum pindah disimpan ke tekstur dan ditampilkan sebentar lalu memudar ke dunia baru
 *    (pada Threshold, bingkai itu hampir sama dengan pemandangan di seberang, jadi terasa menyambung).
 * Kalau penyimpanan bingkai gagal, dipakai pemudar warna polos.
 */
@Mod.EventBusSubscriber(modid = TheComplex.MODID, value = Dist.CLIENT)
public final class SeamlessClient {
    private static final long HOLD_MS = 240;
    private static final long FADE_MS = 520;
    private static final long ARM_MS = 6000;

    private static TextureTarget freeze;
    private static boolean freezeValid;
    private static long armedUntil;
    private static long startMs;
    private static int style;

    private SeamlessClient() {}

    /** Dipanggil saat paket dari server tiba (tepat sebelum paket pindah dimensi). */
    public static void begin(int s) {
        Minecraft mc = Minecraft.getInstance();
        style = s;
        long now = Util.getMillis();
        armedUntil = now + ARM_MS;
        startMs = now;
        capture(mc);
        PortalViewClient.onTeleport();
    }

    private static void capture(Minecraft mc) {
        freezeValid = false;
        try {
            RenderTarget main = mc.getMainRenderTarget();
            int w = main.width, h = main.height;
            if (w <= 0 || h <= 0) return;
            if (freeze == null || freeze.width != w || freeze.height != h) {
                if (freeze != null) freeze.destroyBuffers();
                freeze = new TextureTarget(w, h, false, Minecraft.ON_OSX);
            }
            freeze.bindWrite(false);
            main.blitToScreen(w, h);
            main.bindWrite(true);
            freezeValid = true;
        } catch (Throwable t) {
            freezeValid = false;
            TheComplex.LOGGER.warn("Seamless: could not store the last frame, using a plain fade instead", t);
        }
    }

    /** Sembunyikan layar loading yang dibuat game saat dimensi berganti. */
    @SubscribeEvent
    public static void onScreen(ScreenEvent.Opening e) {
        if (Util.getMillis() > armedUntil) return;
        Screen s = e.getNewScreen();
        if (s instanceof ReceivingLevelScreen || s instanceof ProgressScreen) e.setNewScreen(null);
    }

    /** Digambar di bawah HUD. */
    public static void drawOverlay(GuiGraphics g, int w, int h) {
        if (startMs == 0) return;
        long age = Util.getMillis() - startMs;
        if (age > HOLD_MS + FADE_MS) return;
        float a = age <= HOLD_MS ? 1f : 1f - (age - HOLD_MS) / (float) FADE_MS;
        a = Mth.clamp(a, 0f, 1f);
        a = a * a * (3f - 2f * a);
        if (!freezeValid || freeze == null) {
            int color = style == 0 ? 0xF0EBCB : 0x000000;
            g.fill(0, 0, w, h, ((int) (a * 255f) << 24) | color);
            return;
        }
        try {
            Matrix4f m = g.pose().last().pose();
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.disableDepthTest();
            RenderSystem.setShader(GameRenderer::getPositionTexColorShader);
            RenderSystem.setShaderTexture(0, freeze.getColorTextureId());
            BufferBuilder bb = Tesselator.getInstance().getBuilder();
            bb.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_TEX_COLOR);
            bb.vertex(m, 0, 0, 0).uv(0f, 1f).color(1f, 1f, 1f, a).endVertex();
            bb.vertex(m, 0, h, 0).uv(0f, 0f).color(1f, 1f, 1f, a).endVertex();
            bb.vertex(m, w, h, 0).uv(1f, 0f).color(1f, 1f, 1f, a).endVertex();
            bb.vertex(m, w, 0, 0).uv(1f, 1f).color(1f, 1f, 1f, a).endVertex();
            BufferUploader.drawWithShader(bb.end());
            RenderSystem.enableDepthTest();
            RenderSystem.disableBlend();
        } catch (Throwable t) {
            freezeValid = false;
            TheComplex.LOGGER.warn("Seamless: drawing the stored frame failed, using a plain fade from now on", t);
        }
    }
}
