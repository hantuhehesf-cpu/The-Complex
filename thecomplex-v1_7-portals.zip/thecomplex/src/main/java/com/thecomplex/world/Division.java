package com.thecomplex.world;

import net.minecraft.util.RandomSource;
import net.minecraft.world.level.levelgen.PositionalRandomFactory;

/**
 * Divisi: wilayah besar (REGION x REGION chunk) dengan "karakter" sendiri, seperti biome tetapi untuk Backrooms.
 *
 * Setiap divisi punya BAHAN DINDING TETAP (family). Satu divisi = satu jenis dinding, tidak dicampur:
 *   A Standard          : Classic Wallpaper (paling banyak)
 *   D No Lighting Tile  : Classic Wallpaper, tanpa panel lampu
 *   F Fragments         : Classic Wallpaper, aula lapang tempat fragmen Overworld muncul
 *   B Plain Office Wall : dinding polos kuning terang
 *   C White Office Wall : dinding polos putih
 * Divisi B dan C ("divisi baru") TIDAK PERNAH muncul di dekat Main Chamber: dalam radius HOME_RADIUS chunk
 * dari pusat Main Chamber hanya divisi A, D, dan F.
 *
 * Satu divisi punya tinggi atap tetap, pola ruangan khas, tingkat kegelapan, dan peluang fragmen.
 * Ruangan .schem bisa dibatasi ke divisi tertentu lewat nama file: namaruangan@AD.schem (hanya di divisi A dan D).
 */
public final class Division {
    /** Ukuran wilayah satu divisi, dalam chunk. Harus kelipatan ComplexLayout.SLOT. */
    public static final int REGION = 8;

    /** Radius (chunk) di sekitar Main Chamber yang hanya boleh berisi divisi "rumah" (Classic Wallpaper). */
    public static final int HOME_RADIUS = 24;

    /**
     * Urutan pola: 0 hutan pilar, 1 pilar besar, 2 sekat X, 3 sekat Z, 4 aula kosong (papan catur pilar), 5 lorong X, 6 lorong Z,
     * 7 persimpangan, 8 galeri, 9 kamar dengan lorong keliling. Pola 10 (aula kosong tanpa isi) hanya dipakai sebagai pengganti.
     */
    public static final int PATTERNS = 10;

    public final char id;
    public final String name;
    public final int weight;          // bobot kemunculan wilayah (total 100)
    public final int air;             // tinggi udara (blok)
    public final int[] patterns;      // bobot pola (total 100)
    public final int darkChance;      // persen chunk yang gelap total
    public final int deadPanel;       // persen panel lampu mati
    public final int fragmentPermille; // peluang per seribu chunk memuat fragmen Overworld
    public final boolean noLights;    // true = no fluorescent panels at all
    public final int openness;        // percent of non-spanning-tree chunk links that are opened (higher = more loops)
    public final byte family;         // BackroomsDesigner.CLASSIC / OFFICE / WHITE
    public final boolean home;        // boleh muncul di dekat Main Chamber
    public final int pillarPct;       // persen chunk yang BOLEH berisi pilar (sisanya tanpa pilar sama sekali)

    private Division(char id, String name, int weight, int air, int[] patterns, int dark, int dead, int frag, boolean noLights,
                     int openness, byte family, boolean home, int pillarPct) {
        this.id = id;
        this.name = name;
        this.weight = weight;
        this.air = air;
        this.patterns = patterns;
        this.darkChance = dark;
        this.deadPanel = dead;
        this.fragmentPermille = frag;
        this.noLights = noLights;
        this.openness = openness;
        this.family = family;
        this.home = home;
        this.pillarPct = pillarPct;
    }

    private static final byte CLASSIC = BackroomsDesigner.CLASSIC;
    private static final byte OFFICE = BackroomsDesigner.OFFICE;
    private static final byte WHITE = BackroomsDesigner.WHITE;

    public static final Division[] ALL = {
            // Standar: Classic Wallpaper, udara 3 blok. Paling banyak.
            new Division('A', "Standard", 36, 3, new int[]{6, 3, 14, 14, 3, 16, 16, 8, 8, 12}, 8, 15, 3, false, 12, CLASSIC, true, 10),
            // Tanpa Lampu (No Lighting Tile): tidak ada panel lampu sama sekali. Tetap Classic Wallpaper.
            new Division('D', "No Lighting Tile", 12, 3, new int[]{8, 4, 14, 14, 4, 14, 14, 8, 8, 12}, 0, 100, 3, true, 12, CLASSIC, true, 8),
            // Fragmen: aula lapang, tempat fragmen Overworld paling sering muncul. Udara 4 blok. Classic Wallpaper.
            new Division('F', "Fragments", 14, 4, new int[]{8, 8, 8, 8, 30, 4, 4, 6, 8, 16}, 15, 20, 60, false, 25, CLASSIC, true, 22),
            // Plain Office Wall: dinding polos kuning terang.
            new Division('B', "Plain Office Wall", 24, 3, new int[]{6, 3, 14, 14, 3, 14, 14, 8, 10, 14}, 6, 12, 2, false, 12, OFFICE, false, 10),
            // White Office Wall: dinding polos putih (hanya ada sebagai blok penuh, jadi tanpa pilar dan tanpa rusuk).
            new Division('C', "White Office Wall", 14, 3, new int[]{0, 0, 16, 16, 0, 18, 18, 10, 10, 12}, 4, 10, 2, false, 12, WHITE, false, 0),
    };

    public static Division byId(char c) {
        for (Division d : ALL) if (d.id == Character.toUpperCase(c)) return d;
        return null;
    }

    /** Apakah wilayah yang memuat chunk (cx, cz) berada dalam radius "rumah" Main Chamber. */
    public static boolean nearHome(int cx, int cz) {
        int hx = (int) Math.floor(ComplexLayout.chamberCenterX() / 16.0);
        int hz = (int) Math.floor(ComplexLayout.chamberCenterZ() / 16.0);
        // diukur dari titik tengah wilayah, supaya seluruh wilayah mendapat jawaban yang sama
        int mx = Math.floorDiv(cx, REGION) * REGION + REGION / 2;
        int mz = Math.floorDiv(cz, REGION) * REGION + REGION / 2;
        return Math.max(Math.abs(mx - hx), Math.abs(mz - hz)) <= HOME_RADIUS;
    }

    /** Divisi untuk chunk (cx, cz). Sama untuk seluruh wilayah REGION x REGION chunk. */
    public static Division at(PositionalRandomFactory f, int cx, int cz) {
        RandomSource r = f.at(Math.floorDiv(cx, REGION), 11, Math.floorDiv(cz, REGION));
        int roll = r.nextInt(100);
        if (nearHome(cx, cz)) {
            int homeTotal = 0;
            for (Division d : ALL) if (d.home) homeTotal += d.weight;
            roll = roll * homeTotal / 100;
            for (Division d : ALL) {
                if (!d.home) continue;
                roll -= d.weight;
                if (roll < 0) return d;
            }
            return ALL[0];
        }
        for (Division d : ALL) {
            roll -= d.weight;
            if (roll < 0) return d;
        }
        return ALL[0];
    }

    /** Pilih indeks pola dari bobot divisi ini (roll 0..99). */
    public int pickPattern(int roll) {
        for (int i = 0; i < patterns.length; i++) {
            roll -= patterns[i];
            if (roll < 0) return i;
        }
        return 4;
    }
}
