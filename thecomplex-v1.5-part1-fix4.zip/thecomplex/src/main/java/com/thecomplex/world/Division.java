package com.thecomplex.world;

import net.minecraft.util.RandomSource;
import net.minecraft.world.level.levelgen.PositionalRandomFactory;

/**
 * Divisi: wilayah besar (REGION x REGION chunk) dengan "karakter" sendiri, seperti biome tetapi untuk Backrooms.
 * Ada tiga divisi: A Standar (paling banyak), D Tanpa Lampu, F Fragmen.
 * Satu divisi punya tinggi atap tetap, pola ruangan khas, tingkat kegelapan, dan peluang fragmen.
 * Ruangan .schem bisa dibatasi ke divisi tertentu lewat nama file: namaruangan@AD.schem (hanya di divisi A dan D).
 */
public final class Division {
    /** Ukuran wilayah satu divisi, dalam chunk. Harus kelipatan ComplexLayout.SLOT. */
    public static final int REGION = 8;

    /** Urutan pola: 0 hutan pilar, 1 pilar besar, 2 sekat X, 3 sekat Z, 4 aula kosong, 5 lorong X, 6 lorong Z, 7 dua deret tiang, 8 kamar kecil, 9 dinding L. */
    public static final int PATTERNS = 10;

    public final char id;
    public final String name;
    public final int weight;          // bobot kemunculan wilayah (total 100)
    public final int air;             // tinggi udara (blok)
    public final int[] patterns;      // bobot pola (total 100)
    public final int darkChance;      // persen chunk yang gelap total
    public final int deadPanel;       // persen panel lampu mati
    public final int fragmentPermille; // peluang per seribu chunk memuat fragmen Overworld
    public final boolean noLights;    // true = no fluorescent panels at all
    public final int openness;        // percent of non-spanning-tree chunk links that are opened (higher = more loops, wider halls)

    private Division(char id, String name, int weight, int air, int[] patterns, int dark, int dead, int frag, boolean noLights, int openness) {
        this.id = id;
        this.name = name;
        this.weight = weight;
        this.air = air;
        this.patterns = patterns;
        this.darkChance = dark;
        this.deadPanel = dead;
        this.fragmentPermille = frag;
        this.noLights = noLights;
        this.openness = openness;
    }

    public static final Division[] ALL = {
            // Standar: campuran pola Labirin dan Standar, udara 3 blok. Paling banyak (60%).
            new Division('A', "Standard", 60, 3, new int[]{10, 5, 12, 12, 5, 16, 16, 8, 8, 8}, 8, 15, 3, false, 30),
            // Tanpa Lampu (No Lighting Tile): tidak ada panel lampu sama sekali.
            new Division('D', "No Lighting Tile", 20, 3, new int[]{16, 8, 8, 8, 10, 12, 12, 8, 8, 10}, 0, 100, 3, true, 30),
            // Fragmen: aula lapang, tempat fragmen Overworld paling sering muncul. Udara 4 blok.
            new Division('F', "Fragments", 20, 4, new int[]{10, 10, 8, 8, 40, 4, 4, 4, 6, 6}, 15, 20, 60, false, 55),
    };

    public static Division byId(char c) {
        for (Division d : ALL) if (d.id == Character.toUpperCase(c)) return d;
        return null;
    }

    /** Divisi untuk chunk (cx, cz). Sama untuk seluruh wilayah REGION x REGION chunk. */
    public static Division at(PositionalRandomFactory f, int cx, int cz) {
        RandomSource r = f.at(Math.floorDiv(cx, REGION), 11, Math.floorDiv(cz, REGION));
        int roll = r.nextInt(100);
        for (Division d : ALL) {
            roll -= d.weight;
            if (roll < 0) return d;
        }
        return ALL[0];
    }

    /** Pilih indeks pola dari bobot divisi ini (roll 0..99). */
    public int pickPattern(int roll) {
        for (int i = 0; i < patterns.length; i++) {
            roll -= patterns[i];
            if (roll < 0) return i;
        }
        return 4;
    }
}
