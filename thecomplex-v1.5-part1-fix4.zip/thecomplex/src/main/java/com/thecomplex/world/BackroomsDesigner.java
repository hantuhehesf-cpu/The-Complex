package com.thecomplex.world;

import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.levelgen.PositionalRandomFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * Architectural planner for one 16x16 chunk of the Backrooms.
 *
 * The planner is pure and deterministic: the same world seed always gives the same plan for a chunk, and a chunk never reads
 * another chunk's plan (only the shared EDGE functions, which both neighbors evaluate identically).
 *
 * Room logic comes first. Every chunk is ONE of a few clear archetypes, built in this order:
 *  1. edges (walls and door spans, matching the neighbors),
 *  2. the archetype (pillar hall, split hall, corridor with rooms, junction with four rooms, gallery, big room with ring corridor),
 *  3. cleared landings in front of doors, space around hand-built rooms,
 *  4. wall ribs aligned with the pillar lattice,
 *  5. density: any empty 5x5 window gets a pillar ON THE GRID (pillars sit on a 4-cell lattice that continues across chunk borders),
 *  6. connectivity guarantee (flood fill, carved passage, sealed pockets filled).
 * The ceiling is always flat. Doorways are a lintel row of wall blocks with a Left Arch + Right Arch pair over the center.
 *
 * Macro connectivity: the world is split into 8x8-chunk blocks. Inside a block, chunk links form a random spanning tree
 * plus extra random openings for loops. Between blocks every boundary has at least one guaranteed gateway.
 */
public final class BackroomsDesigner {
    // ---- column kinds
    public static final byte OPEN = 0, WALL = 1, PILLAR = 2, HALF_PILLAR = 3, VSLAB = 4, LINTEL = 5, ARCH_L = 6, ARCH_R = 7;
    // ---- material families (white only exists as a full wall block)
    public static final byte CLASSIC = 0, OFFICE = 1, WHITE = 2;

    private static final int N = 16;
    /** No bare floor window larger than this (in cells) is allowed. */
    private static final int WINDOW = 5;
    // Direction.get2DDataValue(): 0 south, 1 west, 2 north, 3 east
    private static final int D_S = 0, D_W = 1, D_N = 2, D_E = 3;

    public static final class Plan {
        public final byte[] kind = new byte[N * N];
        public final byte[] fam = new byte[N * N];
        /** Direction.get2DDataValue() (facing for half pillars, slabs and arch pieces). */
        public final byte[] dir = new byte[N * N];
        final boolean[] keep = new boolean[N * N];

        Plan copy() {
            Plan c = new Plan();
            System.arraycopy(kind, 0, c.kind, 0, kind.length);
            System.arraycopy(fam, 0, c.fam, 0, fam.length);
            System.arraycopy(dir, 0, c.dir, 0, dir.length);
            System.arraycopy(keep, 0, c.keep, 0, keep.length);
            return c;
        }

        void restore(Plan o) {
            System.arraycopy(o.kind, 0, kind, 0, kind.length);
            System.arraycopy(o.fam, 0, fam, 0, fam.length);
            System.arraycopy(o.dir, 0, dir, 0, dir.length);
        }

        public byte kindAt(int x, int z) {
            return x < 0 || z < 0 || x >= N || z >= N ? WALL : kind[z * N + x];
        }

        void set(int x, int z, byte k, byte f, int d) {
            if (x < 0 || z < 0 || x >= N || z >= N) return;
            int i = z * N + x;
            kind[i] = k;
            fam[i] = f;
            dir[i] = (byte) d;
        }

        boolean isOpen(int x, int z) {
            return x >= 1 && z >= 1 && x < N && z < N && kind[z * N + x] == OPEN && !keep[z * N + x];
        }
    }

    /** One side of a chunk. state: 0 wall, 1 door (start, width), 2 fully open. */
    public record Edge(int state, int start, int width) {
        public boolean passable() {
            return state > 0;
        }

        public boolean isDoor(int i) {
            return state == 2 || (state == 1 && i >= start && i < start + width);
        }

        public int mid() {
            return state == 2 ? 8 : start + width / 2;
        }
    }

    private BackroomsDesigner() {}

    // =====================================================================================================
    // Edges and macro connectivity
    // =====================================================================================================

    /** The west (or north) edge owned by chunk (cx, cz). Neighbors call this for their east / south side. */
    public static Edge edge(PositionalRandomFactory f, int cx, int cz, boolean west) {
        int ncx = west ? cx - 1 : cx, ncz = west ? cz : cz - 1;
        if (ComplexLayout.reserved(ncx, ncz)) {
            // custom Main Chamber: no extra wall, so openings in the chamber wall lead straight into the Backrooms
            return new Edge(ComplexLayout.hasCustomMainChamber() ? 2 : 0, 0, 0);
        }
        int state;
        if (ComplexLayout.roomAt(f, ncx, ncz) != null) state = 1;     // next to a hand-built room: always a door
        else state = treeState(f, cx, cz, west);
        // different ceiling heights meet: door only, never a fully open hall
        if (state == 2 && Division.at(f, cx, cz).air != Division.at(f, ncx, ncz).air) state = 1;

        RandomSource r = f.at(cx, west ? 45 : 46, cz);
        int roll = r.nextInt(100);
        int w = roll < 20 ? 3 : roll < 65 ? 4 : roll < 85 ? 5 : 6;     // slightly wrong proportions
        int start = Mth.clamp(8 - w / 2 + (r.nextInt(3) - 1), 2, 14 - w);
        return new Edge(state, start, w);
    }

    private static boolean linksWest(PositionalRandomFactory f, int cx, int cz) {
        int lx = Math.floorMod(cx, Division.REGION), lz = Math.floorMod(cz, Division.REGION);
        if (lx == 0) return false;
        if (lz == 0) return true;
        return f.at(cx, 44, cz).nextBoolean();
    }

    private static int treeState(PositionalRandomFactory f, int cx, int cz, boolean west) {
        int R = Division.REGION;
        int lx = Math.floorMod(cx, R), lz = Math.floorMod(cz, R);
        RandomSource r = f.at(cx, west ? 40 : 41, cz);
        boolean boundary = west ? lx == 0 : lz == 0;
        if (boundary) {
            // gateway between two 8x8 blocks: one guaranteed per boundary line, a few extra
            int idx = west ? lz : lx;
            int base = f.at(Math.floorDiv(cx, R), west ? 42 : 43, Math.floorDiv(cz, R)).nextInt(R);
            boolean open = idx == base || r.nextInt(100) < 22;
            return open ? (r.nextInt(100) < 25 ? 2 : 1) : 0;
        }
        boolean tree = west == linksWest(f, cx, cz);
        if (tree) return r.nextInt(100) < 25 ? 2 : 1;
        int openness = Division.at(f, cx, cz).openness;
        return r.nextInt(100) < openness ? (r.nextInt(100) < 20 ? 2 : 1) : 0;
    }

    // =====================================================================================================
    // Materials: mono-yellow palette, classic wallpaper dominant, plain office wall in districts, rare white
    // =====================================================================================================

    private static byte districtFamily(PositionalRandomFactory f, int cx, int cz) {
        return (byte) (f.at(Math.floorDiv(cx, 4), 31, Math.floorDiv(cz, 4)).nextInt(100) < 65 ? CLASSIC : OFFICE);
    }

    private static byte edgeFamily(PositionalRandomFactory f, int cx, int cz, boolean west) {
        if (f.at(cx, west ? 32 : 33, cz).nextInt(100) < 3) return WHITE;
        return districtFamily(f, cx, cz);
    }

    private static byte interiorFamily(PositionalRandomFactory f, int cx, int cz) {
        byte base = districtFamily(f, cx, cz);
        return f.at(cx, 34, cz).nextInt(100) < 25 ? (byte) (1 - base) : base;
    }

    private static byte nonWhite(byte fam) {
        return fam == WHITE ? OFFICE : fam;
    }

    // =====================================================================================================
    // Plan
    // =====================================================================================================

    public static Plan design(PositionalRandomFactory f, int cx, int cz, Division div, List<int[]> roomBoxes, int x0, int z0) {
        Plan p = new Plan();
        Edge ew = edge(f, cx, cz, true), en = edge(f, cx, cz, false);
        Edge ee = edge(f, cx + 1, cz, true), es = edge(f, cx, cz + 1, false);
        byte fam = nonWhite(interiorFamily(f, cx, cz));
        byte famW = edgeFamily(f, cx, cz, true), famN = edgeFamily(f, cx, cz, false);

        // 1. edge walls with door spans
        for (int i = 0; i < N; i++) {
            p.set(0, i, WALL, famW, 0);
            p.set(i, 0, WALL, famN, 0);
        }
        if (ew.state() == 2) for (int i = 1; i < N; i++) p.set(0, i, OPEN, famW, 0);
        else if (ew.state() == 1) door(p, true, 0, ew.start(), ew.width(), nonWhite(famW));
        if (en.state() == 2) for (int i = 1; i < N; i++) p.set(i, 0, OPEN, famN, 0);
        else if (en.state() == 1) door(p, false, 0, en.start(), en.width(), nonWhite(famN));
        p.set(0, 0, WALL, famW, 0);

        // portals: one cell per passable side
        List<int[]> portals = new ArrayList<>();
        if (ew.passable()) portals.add(new int[]{0, ew.mid()});
        if (en.passable()) portals.add(new int[]{en.mid(), 0});
        if (ee.passable()) portals.add(new int[]{15, ee.mid()});
        if (es.passable()) portals.add(new int[]{es.mid(), 15});

        // landing strips (2 deep) in front of each door stay clear
        markLanding(p, ew, true, 0);
        markLanding(p, en, false, 0);
        markLanding(p, ee, true, 14);
        markLanding(p, es, false, 14);

        // 2. archetype
        RandomSource r = f.at(cx, 2, cz);
        template(p, div.pickPattern(r.nextInt(100)), r, fam);

        // 3. clear landings, give hand-built rooms breathing room
        for (int i = 0; i < N * N; i++) {
            if (p.keep[i] && (i % N) != 0 && (i / N) != 0) p.kind[i] = OPEN;
        }
        for (int[] box : roomBoxes) {
            for (int lx = 1; lx < N; lx++) {
                for (int lz = 1; lz < N; lz++) {
                    int wx = x0 + lx, wz = z0 + lz;
                    if (wx >= box[0] - 2 && wx <= box[1] + 2 && wz >= box[2] - 2 && wz <= box[3] + 2) p.kind[lz * N + lx] = OPEN;
                }
            }
        }

        // 4 and 5. ribs and density, each step validated against connectivity
        decorate(p, portals, f.at(cx, 6, cz), fam);

        // 6. final guarantee
        enforce(p, portals, fam);
        return p;
    }

    private static void markLanding(Plan p, Edge e, boolean vertical, int inner) {
        if (!e.passable()) return;
        for (int i = 0; i < N; i++) {
            if (!e.isDoor(i)) continue;
            for (int d = 0; d < 2; d++) {
                int a = vertical ? (inner == 0 ? 1 + d : 14 + d) : i;
                int b = vertical ? i : (inner == 0 ? 1 + d : 14 + d);
                if (a >= 1 && a < N && b >= 1 && b < N) p.keep[b * N + a] = true;
            }
        }
    }

    // =====================================================================================================
    // Doorways: a lintel row of wall blocks, with the Left + Right Arch pair over the center two cells
    // =====================================================================================================

    /**
     * @param wallRunsAlongZ true for a wall on a fixed x (running along Z): the passage then runs along X
     * @param line           the fixed x (or z) of the wall
     * @param start          first cell along the wall
     * @param w              door width in cells
     */
    private static void door(Plan p, boolean wallRunsAlongZ, int line, int start, int w, byte fam) {
        int archStart = Math.max(0, (w - 2) / 2);
        // Looking through the doorway: facing EAST for X passages (left = lower z), facing NORTH for Z passages (left = lower x).
        int facing = wallRunsAlongZ ? D_E : D_N;
        for (int i = start; i < start + w; i++) {
            int x = wallRunsAlongZ ? line : i, z = wallRunsAlongZ ? i : line;
            int rel = i - start;
            if (w >= 2 && rel == archStart) p.set(x, z, ARCH_L, fam, facing);
            else if (w >= 2 && rel == archStart + 1) p.set(x, z, ARCH_R, fam, facing);
            else p.set(x, z, LINTEL, fam, 0);
        }
    }

    // =====================================================================================================
    // Archetypes
    // =====================================================================================================

    private static byte accent(RandomSource r, byte fam) {
        return r.nextInt(100) < 3 ? WHITE : fam;
    }

    /** Pillars sit on a 4-cell lattice (2, 6, 10, 14) that continues seamlessly across chunk borders. */
    private static void lattice(Plan p, byte fam, int mode) {
        for (int ix = 0; ix < 4; ix++) {
            for (int iz = 0; iz < 4; iz++) {
                boolean on = switch (mode) {
                    case 0 -> true;                     // every lattice point
                    case 1 -> iz == 1 || iz == 2;       // two rows (a nave between them)
                    default -> (ix + iz) % 2 == 0;      // checkerboard
                };
                if (on) p.set(2 + 4 * ix, 2 + 4 * iz, PILLAR, fam, 0);
            }
        }
    }

    /** Wall along one axis from a to b at a fixed line, with door gaps. Used for partitions and room walls. */
    private static void wallLine(Plan p, boolean alongX, int line, int a, int b, byte fam) {
        for (int i = a; i <= b; i++) p.set(alongX ? i : line, alongX ? line : i, WALL, fam, 0);
    }

    private static void template(Plan p, int id, RandomSource r, byte fam) {
        switch (id) {
            case 0 -> lattice(p, fam, 0);                       // pillar hall
            case 1 -> lattice(p, fam, 1);                       // colonnade with a nave
            case 4 -> lattice(p, fam, 2);                       // checkerboard hall
            case 2, 3 -> {                                      // hall split by one partition with an arched door
                boolean alongX = id == 2;
                int line = r.nextBoolean() ? 4 : 12;
                byte f2 = accent(r, fam);
                int w = 3 + r.nextInt(3), o = 2 + r.nextInt(12 - w);
                wallLine(p, alongX, line, 1, 15, f2);
                door(p, !alongX, line, o, w, fam);
                // the big side gets its pillars from the density pass (on the lattice), the narrow gallery stays clear
            }
            case 5, 6 -> corridor(p, id == 5, r, fam, true);    // corridor with a row of rooms on each side
            case 8 -> corridor(p, r.nextBoolean(), r, fam, false);   // gallery: rooms on one side, a pillar hall on the other
            case 7 -> {                                         // junction: two corridors cross, four rooms in the corners
                byte f2 = accent(r, fam);
                for (int i : new int[]{5, 10}) {
                    wallLine(p, true, i, 1, 4, f2);
                    wallLine(p, true, i, 11, 15, f2);
                    wallLine(p, false, i, 1, 4, f2);
                    wallLine(p, false, i, 11, 15, f2);
                }
                door(p, true, 5, 2, 2, fam);       // NW room: door on its east wall (x = 5)
                door(p, true, 10, 2, 2, fam);      // NE room: door on its west wall (x = 10)
                door(p, true, 5, 12, 2, fam);      // SW room
                door(p, true, 10, 12, 2, fam);     // SE room
            }
            default -> {                                        // big room with a ring corridor around it
                byte f2 = accent(r, fam);
                wallLine(p, false, 3, 3, 12, f2);
                wallLine(p, false, 12, 3, 12, f2);
                wallLine(p, true, 3, 3, 12, f2);
                wallLine(p, true, 12, 3, 12, f2);
                door(p, true, 3, 7, 2, fam);
                door(p, true, 12, 7, 2, fam);
                if (r.nextBoolean()) { door(p, false, 3, 7, 2, fam); door(p, false, 12, 7, 2, fam); }
                for (int x : new int[]{6, 10}) for (int z : new int[]{6, 10}) p.set(x, z, PILLAR, fam, 0);
            }
        }
    }

    /**
     * Corridor 4 wide (cells 6..9) with walls at 5 and 10. The side bands are cut into rooms by partitions at 5 and 10,
     * each room opens onto the corridor through a 2-wide arched door.
     * @param rooms false = rooms only on the low side, the other side stays an open pillar hall
     */
    private static void corridor(Plan p, boolean alongX, RandomSource r, byte fam, boolean rooms) {
        byte f2 = accent(r, fam);
        // corridor walls (axis: along X means the corridor runs along X, walls are lines of constant z)
        wallLine(p, alongX, 5, 1, 15, f2);
        if (rooms) wallLine(p, alongX, 10, 1, 15, f2);
        // room partitions across both bands
        for (int x : new int[]{5, 10}) {
            wallLine(p, !alongX, x, 1, 4, f2);
            if (rooms) wallLine(p, !alongX, x, 11, 15, f2);
        }
        // doors from each room onto the corridor (room centers 2.5, 7.5, 12.5 -> door cells 2-3, 7-8, 12-13)
        for (int c : new int[]{2, 7, 12}) {
            door(p, !alongX, 5, c, 2, fam);
            if (rooms) door(p, !alongX, 10, c, 2, fam);
        }
        if (!rooms) {
            // the far side is a pillar hall on the lattice
            for (int ix = 0; ix < 4; ix++) for (int iz = 2; iz < 4; iz++) p.set(alongX ? 2 + 4 * ix : 2 + 4 * iz, alongX ? 2 + 4 * iz : 2 + 4 * ix, PILLAR, fam, 0);
        }
    }

    // =====================================================================================================
    // Decoration (on the grid only)
    // =====================================================================================================

    private static void decorate(Plan p, List<int[]> portals, RandomSource r, byte fam) {
        // thin vertical-slab ribs against the owned walls, aligned with the pillar lattice rows and columns
        for (int i : new int[]{2, 6, 10, 14}) {
            if (p.kindAt(0, i) == WALL && p.isOpen(1, i) && r.nextInt(100) < 70) place(p, portals, 1, i, VSLAB, fam, D_W);
            if (p.kindAt(i, 0) == WALL && p.isOpen(i, 1) && r.nextInt(100) < 70) place(p, portals, i, 1, VSLAB, fam, D_N);
        }
        // density: no 5x5 window of bare floor. Break it with a pillar ON the lattice.
        boolean[] tried = new boolean[N * N];
        for (int pass = 0; pass < 40; pass++) {
            int[] w = findEmptyWindow(p, tried);
            if (w == null) break;
            tried[w[1] * N + w[0]] = true;
            boolean done = false;
            for (int x = w[0]; x < w[0] + WINDOW && !done; x++) {
                for (int z = w[1]; z < w[1] + WINDOW && !done; z++) {
                    if ((x - 2) % 4 != 0 || (z - 2) % 4 != 0) continue;
                    if (!p.isOpen(x, z)) continue;
                    done = place(p, portals, x, z, PILLAR, fam, 0);
                }
            }
            // The lattice points of this window are all taken by door landings: fall back to the open cell nearest to the
            // window center (one pillar slightly off the grid is better than a bare plate).
            for (int ring = 0; ring <= 2 && !done; ring++) {
                for (int dx = -ring; dx <= ring && !done; dx++) {
                    for (int dz = -ring; dz <= ring && !done; dz++) {
                        if (Math.max(Math.abs(dx), Math.abs(dz)) != ring) continue;
                        int x = w[0] + 2 + dx, z = w[1] + 2 + dz;
                        if (p.isOpen(x, z)) done = place(p, portals, x, z, PILLAR, fam, 0);
                    }
                }
            }
        }
    }

    private static boolean place(Plan p, List<int[]> portals, int x, int z, byte k, byte fam, int d) {
        Plan snap = p.copy();
        p.set(x, z, k, fam, d);
        if (connected(p, portals)) return true;
        p.restore(snap);
        return false;
    }

    private static int[] findEmptyWindow(Plan p, boolean[] tried) {
        for (int z0 = 1; z0 <= N - WINDOW; z0++) {
            for (int x0 = 1; x0 <= N - WINDOW; x0++) {
                if (tried[z0 * N + x0]) continue;
                boolean empty = true;
                for (int x = x0; x < x0 + WINDOW && empty; x++) for (int z = z0; z < z0 + WINDOW; z++) if (p.kindAt(x, z) != OPEN) { empty = false; break; }
                if (empty) return new int[]{x0, z0};
            }
        }
        return null;
    }

    // =====================================================================================================
    // Connectivity
    // =====================================================================================================

    private static boolean walkable(byte k) {
        return k == OPEN || k == LINTEL || k == ARCH_L || k == ARCH_R;
    }

    private static boolean[] reach(Plan p, int sx, int sz) {
        boolean[] seen = new boolean[N * N];
        if (sx < 0 || sz < 0 || sx >= N || sz >= N || !walkable(p.kind[sz * N + sx])) return seen;
        int[] stack = new int[N * N];
        int sp = 0;
        stack[sp++] = sz * N + sx;
        seen[sz * N + sx] = true;
        while (sp > 0) {
            int i = stack[--sp];
            int x = i % N, z = i / N;
            if (x > 0 && !seen[i - 1] && walkable(p.kind[i - 1])) { seen[i - 1] = true; stack[sp++] = i - 1; }
            if (x < N - 1 && !seen[i + 1] && walkable(p.kind[i + 1])) { seen[i + 1] = true; stack[sp++] = i + 1; }
            if (z > 0 && !seen[i - N] && walkable(p.kind[i - N])) { seen[i - N] = true; stack[sp++] = i - N; }
            if (z < N - 1 && !seen[i + N] && walkable(p.kind[i + N])) { seen[i + N] = true; stack[sp++] = i + N; }
        }
        return seen;
    }

    /** True when all portals reach each other and no walkable cell is sealed off. */
    private static boolean connected(Plan p, List<int[]> portals) {
        int sx, sz;
        if (!portals.isEmpty()) {
            sx = portals.get(0)[0];
            sz = portals.get(0)[1];
        } else {
            sx = -1;
            sz = -1;
            for (int i = 0; i < N * N; i++) if (walkable(p.kind[i])) { sx = i % N; sz = i / N; break; }
            if (sx < 0) return true;
        }
        boolean[] seen = reach(p, sx, sz);
        for (int[] q : portals) if (!seen[q[1] * N + q[0]]) return false;
        for (int i = 0; i < N * N; i++) if (walkable(p.kind[i]) && !seen[i]) return false;
        return true;
    }

    private static void carve(Plan p, int ax, int az, int bx, int bz) {
        int x = ax, z = az;
        while (x != bx) {
            clearCell(p, x, z);
            clearCell(p, x, z + 1);
            x += Integer.compare(bx, x);
        }
        while (z != bz) {
            clearCell(p, x, z);
            clearCell(p, x + 1, z);
            z += Integer.compare(bz, z);
        }
        clearCell(p, bx, bz);
    }

    private static void clearCell(Plan p, int x, int z) {
        if (x < 1 || z < 1 || x >= N || z >= N) return;     // never touch the edge walls
        p.kind[z * N + x] = OPEN;
    }

    /** Last line of defense: make connectivity true no matter what the templates did. */
    private static void enforce(Plan p, List<int[]> portals, byte fam) {
        if (!portals.isEmpty()) {
            int[] root = portals.get(0);
            if (!walkable(p.kind[root[1] * N + root[0]])) p.kind[root[1] * N + root[0]] = OPEN;
            for (int k = 1; k < portals.size(); k++) {
                int[] q = portals.get(k);
                boolean[] seen = reach(p, root[0], root[1]);
                if (!seen[q[1] * N + q[0]]) {
                    if (!walkable(p.kind[q[1] * N + q[0]])) p.kind[q[1] * N + q[0]] = OPEN;
                    carve(p, q[0], q[1], root[0], root[1]);
                }
            }
        }
        // fill every sealed pocket
        int sx = -1, sz = -1;
        if (!portals.isEmpty()) {
            sx = portals.get(0)[0];
            sz = portals.get(0)[1];
        } else {
            // no doors at all: keep the largest area
            int best = 0;
            for (int i = 0; i < N * N; i++) {
                if (!walkable(p.kind[i])) continue;
                boolean[] seen = reach(p, i % N, i / N);
                int c = 0;
                for (boolean b : seen) if (b) c++;
                if (c > best) { best = c; sx = i % N; sz = i / N; }
            }
        }
        if (sx < 0) return;
        boolean[] seen = reach(p, sx, sz);
        for (int i = 0; i < N * N; i++) {
            if (walkable(p.kind[i]) && !seen[i]) {
                p.kind[i] = WALL;
                p.fam[i] = fam;
            }
        }
    }
}
