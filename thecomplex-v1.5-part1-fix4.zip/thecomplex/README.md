# The Complex — Forge 1.20.1

Not compiled or tested in the authoring environment, so the first build may need small fixes (see "Most likely compile checks" at the end).
All player-facing text in the mod is American English.

## Build
GitHub Actions (`build.yml`). Java 17. The jar is the `thecomplex-jar` artifact.

## Schematics (WorldEdit `.schem`) live INSIDE the mod
- Bundled Main Chamber: `src/main/resources/data/thecomplex/schem/main_chamber.schem`
- Bundled rooms: `src/main/resources/data/thecomplex/schem/rooms/*.schem`
- Through GitHub: upload `.schem` files to the repo root (next to the ZIP). The workflow copies them into the mod automatically.
  A file named `mainchamber` / `main_chamber` / `Main Chamber` replaces the Main Chamber, any other name becomes a room.
- Quick test without rebuilding (optional): `config/thecomplex/main_chamber.schem` and `config/thecomplex/rooms/` win over the bundled ones.
  Empty them to go back to the bundled versions.
- Room rules: schematic point (0,0,0) = north-west corner of the floor; the lowest layer is the floor (y=16); maximum size 64x64
  (4x4 chunks); air height is free (3 to 6 or more). Blocks only (no entities or chest contents).
- The Main Chamber is chunk-aligned around (0,0). Openings in its outer wall (any position, width or height) lead straight into the Backrooms.
  A `thecomplex:threshold` block inside it is the door to the outside world; the arrival point is computed from its position.
  After replacing the Main Chamber, delete the `dimensions/thecomplex/the_complex` folder in the world save.

## Procedural Backrooms (rewritten generator)

Goal: dense, intentional, liminal. Full of architecture, empty of purpose, slightly wrong proportions, one mono-yellow palette.
Everything is deterministic from the single world seed, and every chunk is generated statelessly (no dependency on other chunks), so it is thread-safe and cheap on Android.

### Placement logic (`world/BackroomsDesigner.java`)
Room logic comes first, details last. Each 16x16 chunk is planned as a grid of 256 columns (wall, pillar, half pillar, vertical slab, doorway lintel,
left or right arch piece) and rendered to blocks by `ComplexChunkGenerator`. The ceiling is always flat (tile + fluorescent panels); there are no stepped ceilings, platforms or wedges in the generated halls.
1. **Edges.** A chunk owns its west and north wall; the east and south walls are owned by the neighbors, and both sides evaluate the same function, so openings always match.
   Doors are slightly off-scale: 3 to 6 blocks wide and a little off-center.
2. **Archetype.** One clear room type per chunk, chosen from the division's weights:
   pillar hall, colonnade with a nave, checkerboard hall, hall split by one partition with an arched door, corridor with a row of rooms on each side,
   gallery (rooms on one side, pillar hall on the other), junction (two corridors cross, four corner rooms), big room with a ring corridor.
3. **Doorways.** A door is a row of wall-block lintels in the top air layer, with a **Left Arch + Right Arch** pair over the center two cells
   (the pair spans 2 blocks and leaves a stepped arched opening up to the ceiling). Every room door and every edge door is built this way.
4. **Landing strips.** The two cells in front of every door are always kept clear. Walls near hand-built rooms are cleared so every room door leads out.
5. **Grid-aligned details.** Pillars sit on a 4-cell lattice (cells 2, 6, 10, 14) that continues seamlessly across chunk borders; thin vertical-slab ribs against walls line up with the lattice.
6. **Density pass.** No 5x5 window of bare floor may exist: each one gets a pillar on the lattice (or, if door landings occupy the lattice points, one pillar at the nearest open cell).
7. **Connectivity guarantee.** See below.

### Density and connectivity
- Density is a hard rule of step 6 (offline test over 3 seeds: no chunk has an empty 5x5 window; about 77% of cells remain open floor, 14% walls).
- **Inside a chunk:** after every decoration step a flood fill checks that all doors reach each other and that no walkable cell is sealed off; a step that would break this is reverted.
  As a last resort, doors that still cannot reach each other get a carved 2-wide passage and every sealed pocket is filled in.
- **Between chunks:** the world is split into 8x8-chunk blocks. Inside a block, chunk links form a random spanning tree (each chunk links north OR west) plus extra random openings for loops.
  Every boundary between two blocks has at least one guaranteed gateway. So every chunk can reach every other chunk by construction
  (verified: 576 of 576 chunks reachable on each tested seed). Hand-built rooms are the one exception you control: a fully closed room with no doors can block its own chunks.

### Module library and rarity tags
The generator uses: Classic Wallpaper and Plain Office Wall (a lighter yellow, used for whole districts and for rooms inside classic districts), rare White Office Wall accents (about 3%),
full wall blocks (rooms, corridors, lintels), Left/Right arch pieces (doorways), pillars (lattice), vertical slabs (thin wall ribs), and the existing ceiling tile and fluorescent panel grid (3 blocks of air in Standard areas).
Half pillars, horizontal slabs, wedges, carpet wedges and half walls remain available as building blocks and for your hand-built rooms; the generator no longer scatters them.
Material consistency: about 65% of 4x4-chunk districts are classic wallpaper, the rest plain office wall; a chunk's interior may flip family 25% of the time.

Hand-built `.schem` rooms are the rare set-pieces (gallery, village street, living rooms, ...). The file name can end with two codes:
- `@` + division letters: `pitfalls@A.schem` (division A only), `office@AD.schem` (A and D). No `@` = every division.
- `#` + rarity: `#1` common (default), `#2` half as common as #1, `#3` a quarter, `#4` very rare, **`#5` = exactly one in the whole dimension**.
  A #5 room is placed in one slot chosen by the world seed, within 8 slots (about 512 blocks) of the origin, in a division its name allows.
- Examples: `village_street@A#2.schem`, `strange_door@F#5.schem`.
Each 4x4-chunk slot has a 30% chance to hold one room (`ComplexLayout.ROOM_CHANCE`). New rooms are simply dropped into the rooms folder; the generator core does not change.
The remaining chunk area around a room is filled with procedural Backrooms, so there is no void.

### Divisions
The world is split into 8x8-chunk regions called **divisions**:

| Division | Name | Air | Region chance | Character |
|---|---|---|---|---|
| A | Standard | 3 | 60% | mix of Labyrinth and Standard patterns, normal lights, 30% extra openings |
| D | No Lighting Tile | 3 | 20% | no fluorescent panels at all, 30% extra openings |
| F | Fragments | 4 | 20% | wide halls (55% extra openings), Overworld fragments appear most often (6% of chunks) |

The ceiling height is constant within a division. Where heights differ, the edge is a wall or a door, never fully open. Settings live in `Division.java`
(`openness` is the percent of non-spanning-tree links that are opened).

### Null Zones and the LPMDS
Null Zones are not placed by the generator. Natural Null Zones appear only after an LPMDS has been opened in the world (`ActivityData`);
the Dev UI LPMDS tab has a "Natural Null Zones ON/OFF" toggle for testing. The generator only provides the architecture they hide in.

### Ambience
The fluorescent panel hum (`fluorescent_hum.ogg`) loops across The Complex. The current file is a 20.6-second seamless loop made from the
"Factory Fluorescent Light Buzz" recording (mono, 44.1 kHz, normalized, crackle bursts tamed). Base volume: `HumSound.VOLUME`.

## Activity, Null Zones, fragments
- Every 5 seconds in the Overworld, the chunk you are in is recorded (max 256 chunks per player, slowly decaying).
- Natural Null Zones **only appear after an LPMDS has been opened** in this world (stored in world data; toggle with Dev UI LPMDS tab, "Natural Null Zones ON/OFF").
  The Dev UI test buttons can still create one at any time.
- Null Zones are checked every 10 seconds; the chance rises from 1/360 (unfamiliar place) to 1/60 (a place you visit very often).
  They appear on indoor walls (1x2) or floors (2x2, two blocks deep), biased toward the chunks with the highest heat.
- A Null Zone disguises itself as the block it replaces (biome-tinted blocks such as grass are not used) and restores it after use or after 10 to 30 minutes.
  Ones placed by hand or from a `.schem` are permanent and look like wallpaper.
- Overworld fragments (max 12x9x12, stored in world data, max 24): a building where a Null Zone appeared (30% chance), trees, or vanilla structure pieces.
  Captured automatically now and then (about every 5 minutes per player) or through the Dev UI.
- In the Backrooms, fragments appear per division (0.3% in most divisions, 6% in division F), cut off by the Backrooms ceiling. Each fragment is rotated randomly,
  part of the floor becomes carpet, some blocks become wallpaper, foliage becomes wallpaper or stays without decaying, and there are small holes (`Division.java`, `fragmentPermille`).

## Developer UI (no commands)
The **Complex Dev Tool** item (creative tab "Tools & Utilities"): right-click. Operators or creative mode only.
Tabs: Enter (Main Chamber, random Backrooms, leave, toggle creative/survival, restore health), Null Zone (random/floor/wall, add heat, clear heat),
**Tracker** (list of recent Null Zones: tap a row to teleport, teleport to nearest, restore all), Fragments (capture building/tree/structure, paste random, delete all),
Rooms (select, paste, reload), LPMDS, Case (Briefcase set, recall Briefcases on the ground).
Status (dimension, Main Chamber, counts, position, heat) is shown at the top. While the Dev Tool is held, the action bar shows an arrow and distance to the nearest Null Zone,
and air cells touching a Null Zone within 40 blocks get light sparks. The old `/complex ...` commands still exist.

## LPMDS + Threshold (needs power)
1. Place the **LPMDS**. Connect a **Forge Energy (FE)** source to any side: an FE converter from Create: Power Grid, or another mod that outputs FE
   (e.g. a Create Crafts & Additions alternator). Power is stored in the machine (default 200,000 FE).
2. Attach an **LPMDS Emitter Chute** to the side of the machine. Right-click rotates clockwise (16 steps of 22.5 degrees), sneak + click (empty hand) counterclockwise.
   Step 0 = south, 4 = west, 8 = north, 12 = east.
3. Use the **Magnetic Marker**: right-click the LPMDS, then click two opposite corner cells of a frame 2 wide x 3 tall x 1 thick
   (the empty cell in front of the clicked face, like placing a block). Yellow lines = the frame, blue line = the link to the machine. Sneak + click clears the marking.
4. Right-click the LPMDS (empty hand) to start a test. If something is wrong (power, distance, blocked area), the machine explains it and the test does not count.
5. **Tests 1, 2 and 3 always fail** (a different effect each time: field collapse, phase surge, lock failed; camera shake, sound, particles and a log in chat).
   After an 8-second cooldown, try again. The number of failed tests and the cooldown are configurable.
6. The **final test** succeeds if power is sufficient (90,000 FE), the target area is clear, and the chute faces the frame (the nearest step toward the frame).
   The field beam shows the chute's real direction, so a miss is obvious. On success: a "THRESHOLD STABLE" screen, a flash, a long shake, and 6 Threshold blocks form.
   The Threshold stays open until closed (sneak + click, empty hand) or the machine is destroyed.
- Without a marked frame, the field follows the chute direction (or the machine's front if there is no chute) and opens a 3-block Threshold in front of it.
- Configuration: `config/thecomplex-common.toml` (requirePower, capacity, maxReceivePerTick, failedTestCost, finalTestCost, scriptedFailures, cooldownTicks, range).
  `requirePower=false` runs the machine without power.
- Power integration uses the Forge Energy interface (no compile-time dependency on Create or Power Grid). `create` and `powergrid` are optional dependencies in mods.toml.

## Building blocks (yellow palette)
Every yellow surface has two variants: **Classic Wallpaper** (`wallpaper`, striped pattern) and **Plain Office Wall** (`office_wall`, lighter plain yellow).
There is also **White Office Wall** (`white_wall`). All are in the Building Blocks creative tab.

| Part | Classic Wallpaper | Plain Office Wall |
|---|---|---|
| Full block | `wallpaper` | `office_wall` (+ `white_wall`) |
| Horizontal slab | `wallpaper_slab` | `office_wall_slab` |
| Vertical slab | `wallpaper_vertical_slab` | `office_wall_vertical_slab` |
| Arch (single block with a hole) | `wallpaper_arch` | `office_wall_arch` |
| Arch, left piece | `wallpaper_arch_left` | `office_wall_arch_left` |
| Arch, right piece | `wallpaper_arch_right` | `office_wall_arch_right` |
| Wedge / slope | `wallpaper_wedge` | `office_wall_wedge` |
| 12x12 pillar | `wallpaper_pillar` | `office_wall_pillar` |
| Half pillar (against a wall) | `wallpaper_half_pillar` | `office_wall_half_pillar` |
| Half wall (connecting) | `wallpaper_half_wall` | `office_wall_half_wall` |

Also: `carpet_wedge` (a wedge with carpet texture).
- Vertical slab: click the side of a block to attach to it; click the inner side with the same slab to merge into a full block.
- Arch: placed facing your view; a single block with an arched hole.
- Left Arch + Right Arch: place them side by side in the top layer of a 2-block-high doorway (facing = the direction you look through the door); the pair spans 2 blocks.
- Wedge: rises in the direction you face when placing; its collision is 8 steps of 2 pixels, so it is a smooth ramp.
- Half wall: a thin 12-pixel-high divider that connects automatically (tag `minecraft:walls`); can be jumped over.

## V1.5 Part I: Exploration Briefcase

New items (creative tab "Tools & Utilities", or Dev UI tab **Case** > "Give Briefcase set"): `briefcase`, `flashlight`, `flashlight_battery`,
`duct_tape`, `duct_anchor` (block, placeholder Grindstone model), `rope`. Settings: `config/thecomplex-briefcase.toml`.

**Using the Briefcase**
- Right-click (Briefcase in hand): open the inventory. The camera moves closer (FOV narrows) and the Briefcase opens from the center.
- Left-click: enter the **throw stance**. A **5-segment** bar appears below the crosshair. Set the value with the mouse wheel (the hotbar does not change during the stance)
  or by left-clicking repeatedly (5 wraps to 1; the easiest way on a touch screen). **Right-click = throw**, only while the bar is shown.
  Changing hotbar slot, ESC, or opening any screen cancels it.
- The physics imitate an **arrow / fishing bobber**: it flies along your full view direction (up or down), gravity pulls it, and it **sticks as soon as it hits something**
  (no bouncing, no tumbling; it only tilts along its flight direction). Flight distance is limited to 1.45 blocks per power level: power 5 is about 8 blocks (including a short slide), in any direction.
  On stairs and wedges it slides downhill. The simulation runs on both client and server (smooth), and resting Briefcases sleep.
- Right-click a Briefcase on the ground: open its inventory. Sneak + right-click: pick it up.
- Dev UI tab Case > "Recall Briefcases on the ground" returns every Briefcase within 48 blocks (if one gets stuck).

**Tetris-style inventory**: an 8-wide x 4-high grid (`rows` in the config, may be 3). Click an item in your inventory (gold highlight), then click a grid cell.
A green shadow means it fits, red means it does not. Click an item in the grid and then another cell to move it; click a slot in your inventory to take it out.
Shift + click puts it in the first free spot. The **Rope** slot on the right is for Rope only (every Briefcase has one).
Item sizes (width x height): Flashlight 1x2, Battery 1x1, Duct Tape 1x1, Duct Anchor 2x1, Rope 2x1, other items 1x1.
Items from other mods (camera, flares, radio) are sized in the config `extraSizes`, format `"modid:item=2x2"` (default example: `exposure:camera=2x2`).
Blocks cannot be stored (except the Duct Anchor). Rotating items is not implemented.

**Rope**: put a Rope in the Rope slot and throw the Briefcase. If it stops at an edge (the neighboring cell is open downward), the rope hangs from that edge,
at most 12 blocks (`ropeMaxLength`); water counts as the bottom. To grab it: stand close to the rope (0.6 blocks or less) and press **jump (climb) or sneak (descend)**.
Then: jump = climb, sneak = descend, no key = hang (0.25 blocks from the rope, so the rope does not clip through your body). **Pressing a movement key lets go.**
At the top, press jump or a movement key to vault onto the ledge next to the Briefcase. To go down from a ledge: step into the rope's column, then press sneak.
Walking past a rope no longer holds you in the air.

**Flashlight**: right-click = on/off. 2 battery slots, 1 slot = 7 minutes (`slotMinutes`). Recharge: hold a Flashlight Battery in your other hand and right-click.
The light is made by invisible light blocks at the point you aim at, only while the flashlight is held. Those blocks remove themselves if the game stops unexpectedly.

**Duct Tape** (a **block** on the floor, like Redstone: no clipping into the floor, breakable one by one, drops nothing):
1. Place a Duct Anchor, hold Duct Tape, right-click the anchor.
2. Walk in a STRAIGHT line away (the direction locks to the X or Z axis). Tape blocks are laid on the floor where you walk, 1 roll = 8 blocks (spare rolls in your inventory are used automatically). Straying more than 1 block off the line pauses the tape until you return.
3. Place the second anchor exactly in line with the first and right-click it: the last gap is filled and the tape is done.
Sneak + empty hand on an anchor reels in all tape attached to it. Cells without a solid floor (for example on top of a wedge) are skipped.

**Not implemented / good to know**
- No crafting recipes or loot yet: everything comes from creative or the Dev UI.
- Moving items inside the grid exists but is untested: if something goes wrong, take the item out and put it back.
- Rope: a dedicated server with `allow-flight=false` may kick a player hanging for more than 4 seconds. Singleplayer is fine.
- The Briefcase and flashlight models and textures are code-made placeholders (16x16).
- Entity Culling: if the rope still disappears, make sure `thecomplex:briefcase` is in that mod's skip/whitelist.

## Most likely compile checks
- `RandomState.getOrCreateRandomFactory`, `Heightmap.primeHeightmaps`, `ViewportEvent.RenderFog`
- `BlockStateParser.parseForBlock`, `NbtIo.readCompressed`, `NbtUtils.readBlockState`, `SavedData`
- `IModFile.findResource` (SchemStore), `ModelEvent.ModifyBakingResult` and `BakedModelWrapper` (MimicModel)
- `Screen.rebuildWidgets` (DevScreen), `AbstractTickableSoundInstance` (HumSound)
- Briefcase: `ItemRenderer.renderStatic` + `ItemDisplayContext`, `RenderLevelStageEvent`, `InputEvent.InteractionKeyMappingTriggered`/`MouseScrollingEvent`,
  `RegisterGuiOverlaysEvent`, `NetworkHooks.getEntitySpawningPacket`, `BlockBehaviour.Properties.replaceable()`, `ItemProperties.register`,
  `Entity.getBoundingBoxForCulling`, `ArchPieceBlock` shapes
- Generator: `WallBlock.UP/NORTH_WALL...` and `WallSide` (half-wall states), `SlabBlock.TYPE`, `VerticalSlabBlock.FACING`
- LPMDS: `ForgeCapabilities.ENERGY` + `LazyOptional`, `ForgeConfigSpec`, screen title packet (`ClientboundSetTitleTextPacket`), `SoundEvents.WARDEN_SONIC_CHARGE`

## Next phase
V1.5 Part II, then entities (Lifeform, then Still Lifes).
