package com.thecomplex.client;

import com.thecomplex.TheComplex;
import com.thecomplex.briefcase.RopeHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.Input;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.LogicalSide;

/**
 * Memanjat tali di klien (gerak pemain lokal ditentukan klien).
 * Berpegangan HANYA kalau kamu menekan lompat (naik) atau sneak (turun) saat berada dekat tali (maks. 0,6 blok dari garis tali).
 * Setelah berpegangan: lompat = naik, sneak = turun, tanpa tombol = menggantung di titik 0,25 blok dari tali.
 * Menekan arah jalan melepas pegangan. Pemain yang sekadar lewat dekat tali tidak tertahan di udara.
 */
@Mod.EventBusSubscriber(modid = TheComplex.MODID, value = Dist.CLIENT)
public final class RopeClient {
    private static boolean attached;

    private RopeClient() {}

    @SubscribeEvent
    public static void onTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.side != LogicalSide.CLIENT) return;
        Minecraft mc = Minecraft.getInstance();
        if (!(e.player instanceof LocalPlayer p) || p != mc.player) return;
        if (p.getAbilities().flying || p.isPassenger() || p.isSpectator() || p.isDeadOrDying()) {
            attached = false;
            return;
        }

        RopeHelper.Hit h = RopeHelper.find(p);
        if (h == null) {
            attached = false;
            return;
        }

        Input in = p.input;
        boolean free = mc.screen == null;
        boolean up = free && in.jumping;
        boolean down = free && in.shiftKeyDown;
        boolean steering = free && (Math.abs(in.forwardImpulse) > 0.05f || Math.abs(in.leftImpulse) > 0.05f);

        if (!attached) {
            if (!(up || down)) return;     // belum berpegangan: perilaku normal
            attached = true;
        } else if (steering) {
            attached = false;              // lepas
            return;
        }
        p.fallDistance = 0f;

        double y = p.getY();
        double vy = 0;
        if (up) vy = 0.2;
        else if (down) vy = -0.2;
        if (vy > 0) {
            // jangan naik melewati permukaan tepian
            double room = h.top() + 0.02 - y;
            vy = room <= 0 ? 0 : Math.min(vy, room);
        }
        if (vy < 0 && y <= h.bottom() + 0.01) vy = 0;

        double vx = 0, vz = 0;
        if (y < h.top() - 0.01) {
            // tarik pelan ke titik gantung (dekat tali)
            vx = clamp((h.tx() - p.getX()) * 0.5, 0.1);
            vz = clamp((h.tz() - p.getZ()) * 0.5, 0.1);
        }
        p.setDeltaMovement(vx, vy, vz);
    }

    private static double clamp(double v, double m) {
        return Math.max(-m, Math.min(m, v));
    }
}
