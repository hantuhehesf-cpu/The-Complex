package com.thecomplex.block;

import com.thecomplex.ComplexTeleporter;
import com.thecomplex.TheComplex;
import com.thecomplex.portal.EntityPortals;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Null Zone: tanpa collision, menyamar sebagai blok aslinya. Di belakang "dinding" ini ada portal tak terlihat:
 * saat mata pemain melewati bidangnya, PortalSystem memindahkan pemain tanpa layar loading.
 * Null Zone liar punya umur dan bisa tumbuh; Stable Wild Null Zone permanen dan dua arah.
 * Yang tidak punya data portal (kreatif, .schem, versi lama) dipicu dengan cara lama: berdiri beberapa tick di dalamnya.
 */
public class NullZoneBlock extends Block implements EntityBlock {
    /** Berapa tick pemain harus berada di dalam blok sebelum jatuh tembus (hanya Null Zone lama / manual). */
    public static final int TRIGGER_TICKS = 8;

    public NullZoneBlock(Properties props) {
        super(props);
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new NullZoneBlockEntity(pos, state);
    }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        if (!(level instanceof ServerLevel sl)) return;
        if (!(entity instanceof ServerPlayer player)) {
            // mobs, animals, villagers and dropped items can use Null Zones too (v1.8); players are handled below and by PortalSystem
            if (!(entity instanceof Player)) EntityPortals.onInside(sl, pos, entity);
            return;
        }
        if (level.dimension() == TheComplex.COMPLEX) return;
        if (sl.getBlockEntity(pos) instanceof NullZoneBlockEntity be && be.getNormal() != null) return;   // ditangani PortalSystem
        if (ComplexTeleporter.onCooldown(player)) return;
        CompoundTag data = player.getPersistentData();
        long now = level.getGameTime();
        int count = (now - data.getLong("complex_nz_last") <= 3) ? data.getInt("complex_nz_count") + 1 : 1;
        data.putLong("complex_nz_last", now);
        data.putInt("complex_nz_count", count);
        if (count >= TRIGGER_TICKS) {
            data.putInt("complex_nz_count", 0);
            ComplexTeleporter.toBackrooms(player);
            for (int dx = -1; dx <= 1; dx++)
                for (int dy = -1; dy <= 1; dy++)
                    for (int dz = -1; dz <= 1; dz++)
                        restore(sl, pos.offset(dx, dy, dz));
        }
    }

    @Override
    public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        NullZoneLife.onTick(level, pos);
    }

    /** Stable Wild Null Zone tidak bisa dihancurkan di mode survival. */
    @Override
    public float getDestroyProgress(BlockState state, Player player, BlockGetter level, BlockPos pos) {
        if (level.getBlockEntity(pos) instanceof NullZoneBlockEntity be && (be.isStable() || be.getExpiresAt() < 0)) return 0f;
        return super.getDestroyProgress(state, player, level, pos);
    }

    /** Kembalikan blok asli (kalau ada). Yang stabil dan yang manual tidak pernah dipulihkan. */
    public static void restore(ServerLevel level, BlockPos pos) {
        NullZoneLife.restore(level, pos);
    }
}
