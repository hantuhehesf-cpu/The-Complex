package com.thecomplex.portal;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.Mth;
import net.minecraft.world.level.saveddata.SavedData;

/**
 * Pengaturan portal per dunia (diatur lewat /complex portal ...).
 * full = mode penuh ala Immersive Portals: sisi seberang digambar sampai {@code distance} chunk, chunk di sana dimuat dan
 * ikut di-tick selama pemain di dekat portal, dan cuplikan diperbarui hampir real-time. Berat: mati secara bawaan.
 */
public class PortalSettings extends SavedData {
    public static final int MIN_DISTANCE = 8;
    public static final int MAX_DISTANCE = 12;
    public static final int DEFAULT_DISTANCE = 10;

    private boolean full;
    private int distance = DEFAULT_DISTANCE;

    public static PortalSettings get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(PortalSettings::load, PortalSettings::new, "thecomplex_portal_settings");
    }

    public static PortalSettings load(CompoundTag tag) {
        PortalSettings s = new PortalSettings();
        s.full = tag.getBoolean("full");
        s.distance = tag.contains("distance") ? Mth.clamp(tag.getInt("distance"), MIN_DISTANCE, MAX_DISTANCE) : DEFAULT_DISTANCE;
        return s;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putBoolean("full", full);
        tag.putInt("distance", distance);
        return tag;
    }

    public boolean isFull() {
        return full;
    }

    public void setFull(boolean v) {
        full = v;
        setDirty();
    }

    public int getDistance() {
        return distance;
    }

    public void setDistance(int v) {
        distance = Mth.clamp(v, MIN_DISTANCE, MAX_DISTANCE);
        setDirty();
    }
}
