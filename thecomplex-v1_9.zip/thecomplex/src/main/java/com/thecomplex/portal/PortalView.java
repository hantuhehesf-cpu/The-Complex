package com.thecomplex.portal;

import com.thecomplex.ModBlocks;
import com.thecomplex.TheComplex;
import com.thecomplex.block.NullZoneBlockEntity;
import com.thecomplex.net.Net;
import com.thecomplex.net.PortalFarPacket;
import com.thecomplex.net.PortalViewPacket;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Cuplikan sisi seberang sebuah Threshold untuk efek see-through. Tidak ada rendering dunia kedua:
 * server mengirim blok-blok yang terlihat (kotak di depan bingkai tujuan), klien menggambarnya ke tekstur kecil
 * dan menempelkannya pada bukaan Threshold.
 *
 * Mode biasa: kotak kecil (sekitar 2 chunk). Mode penuh ({@link PortalSettings#isFull()}): kotak lebih besar dan, di dunia terbuka,
 * medan jauh sebagai kisi tile 4x4 blok sampai 8-12 chunk, diperbarui hampir real-time.
 */
public final class PortalView {
    private static final int FAR_TILE = 4;
    private static final long FAR_SALT = 0x5F5F5F5F5F5F5F5FL;

    /** Ukuran kotak cuplikan dekat (blok). */
    private record Cfg(int half, int depth, int below, int above, int maxCells) {}

    private static final Map<UUID, Map<Long, Long>> NEXT = new HashMap<>();
    /** Hash dan waktu kirim terakhir per bingkai: cuplikan yang tidak berubah tidak dikirim ulang (kecuali tiap 30 detik, supaya klien tidak menganggapnya basi). */
    private static final Map<UUID, Map<Long, long[]>> LAST = new HashMap<>();

    private PortalView() {}

    private static Cfg cfg(boolean full, boolean complex) {
        if (complex) return full ? new Cfg(32, 96, 3, 8, 16000) : new Cfg(14, 28, 3, 8, 5000);
        return full ? new Cfg(24, 48, 6, 24, 16000) : new Cfg(14, 28, 3, 16, 5000);
    }

    /** Kirim cuplikan tujuan bingkai src ke pemain (dan medan jauh kalau mode penuh), kalau sudah waktunya. */
    public static void maybeSend(ServerPlayer p, ServerLevel srcLevel, PortalFrame src, ServerLevel dest, PortalFrame dstFrame, Vec3 exit,
                                 PortalSettings st) {
        long now = srcLevel.getGameTime();
        boolean full = st.isFull();
        boolean complex = dest.dimension() == TheComplex.COMPLEX;
        Cfg cfg = cfg(full, complex);
        Map<Long, Long> next = NEXT.computeIfAbsent(p.getUUID(), k -> new HashMap<>());

        Long due = next.get(src.key());
        if (due == null || now >= due) {
            PortalViewPacket pkt = build(dest, srcLevel.dimension().location().toString(), src, dstFrame, exit, cfg);
            if (pkt != null) {
                next.put(src.key(), now + (full ? 60 : 200));
                long h = (Arrays.hashCode(pkt.idx()) * 31L + Arrays.hashCode(pkt.ids())) * 31L + Arrays.hashCode(pkt.masks()) + pkt.ambient();
                Map<Long, long[]> last = LAST.computeIfAbsent(p.getUUID(), k -> new HashMap<>());
                long[] prev = last.get(src.key());
                if (prev == null || prev[0] != h || now - prev[1] >= 600) {
                    last.put(src.key(), new long[]{h, now});
                    Net.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), pkt);
                }
            }
        }
        if (full && !complex) {
            Long dueFar = next.get(src.key() ^ FAR_SALT);
            if (dueFar == null || now >= dueFar) {
                int[] complete = new int[1];
                PortalFarPacket far = buildFar(dest, src, dstFrame, exit, st.getDistance(), cfg, complete);
                if (far != null) {
                    // chunk jauh dimuat bertahap: kirim lagi lebih cepat selama masih bolong
                    next.put(src.key() ^ FAR_SALT, now + (complete[0] == 1 ? 600 : 100));
                    Net.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), far);
                }
            }
        }
    }

    public static void forget(UUID id) {
        NEXT.remove(id);
        LAST.remove(id);
    }

    /**
     * Bounds of the near snapshot box: {minX, maxX, minZ, maxZ}.
     * The box STARTS AT the frame's own cell. It used to start one cell further out, so the floor and the wall reveals
     * exactly at the frame plane were never baked; seen from up close, that strip showed the plain clear color
     * (a flat olive patch on the floor). The Threshold blocks themselves are still skipped in build().
     */
    private static int[] nearBox(Vec3 c, int ex, int ez, Cfg cfg) {
        int bx = Mth.floor(c.x), bz = Mth.floor(c.z);
        if (ex != 0) {
            return new int[]{ex > 0 ? bx : bx - cfg.depth(), ex > 0 ? bx + cfg.depth() : bx, bz - cfg.half(), bz + cfg.half()};
        }
        return new int[]{bx - cfg.half(), bx + cfg.half(), ez > 0 ? bz : bz - cfg.depth(), ez > 0 ? bz + cfg.depth() : bz};
    }

    private static int skyColor(ServerLevel dest, int ambient) {
        if (dest.dimension() == TheComplex.COMPLEX) return 0x6B6538;
        float f = 0.10f + 0.90f * Mth.clamp(ambient / 15f, 0f, 1f);
        return ((int) (0.47f * f * 255) << 16) | ((int) (0.65f * f * 255) << 8) | (int) (1.0f * f * 255);
    }

    /** Null kalau chunk tujuan belum dimuat. */
    private static PortalViewPacket build(ServerLevel dest, String srcDim, PortalFrame src, PortalFrame dst, Vec3 exit, Cfg cfg) {
        Vec3 c = dst.center;
        int ex = (int) Math.signum(exit.x), ez = (int) Math.signum(exit.z);
        int by = Mth.floor(c.y);
        int[] box = nearBox(c, ex, ez, cfg);
        int minX = box[0], maxX = box[1], minZ = box[2], maxZ = box[3];
        int minY = by - cfg.below(), maxY = by + cfg.above();
        if (dest.getChunkSource().getChunkNow(Mth.floor(c.x) >> 4, Mth.floor(c.z) >> 4) == null) return null;

        int w = maxX - minX + 1, h = maxY - minY + 1, d = maxZ - minZ + 1;
        long[] packed = new long[cfg.maxCells()];
        byte[] maskOf = new byte[w * h * d];
        int n = 0;
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        int depthLen = ex != 0 ? w : d;
        int latMin = ex != 0 ? minZ : minX, latMax = ex != 0 ? maxZ : maxX;
        // dari dekat ke jauh: kalau kebanyakan, yang terpotong adalah yang paling jauh
        for (int step = 0; step < depthLen && n < cfg.maxCells(); step++) {
            for (int lat = latMin; lat <= latMax && n < cfg.maxCells(); lat++) {
                int x, z;
                if (ex != 0) {
                    x = ex > 0 ? minX + step : maxX - step;
                    z = lat;
                } else {
                    z = ez > 0 ? minZ + step : maxZ - step;
                    x = lat;
                }
                for (int y = minY; y <= maxY && n < cfg.maxCells(); y++) {
                    m.set(x, y, z);
                    if (!dest.hasChunkAt(m)) continue;
                    BlockState s = dest.getBlockState(m);
                    if (s.isAir() || s.getRenderShape() != RenderShape.MODEL) continue;
                    if (s.is(ModBlocks.THRESHOLD.get())) continue;
                    if (s.is(ModBlocks.NULL_ZONE.get())) {
                        BlockEntity be = dest.getBlockEntity(m);
                        if (be instanceof NullZoneBlockEntity nz && nz.getOriginal() != null) s = nz.getOriginal();
                    }
                    int mask = 0x3F;
                    if (s.isSolidRender(dest, m)) {
                        mask = exposedMask(dest, m, minX, maxX, minY, maxY, minZ, maxZ);
                        if (mask == 0) continue;
                    }
                    int idx = ((y - minY) * d + (z - minZ)) * w + (x - minX);
                    maskOf[idx] = (byte) mask;
                    packed[n++] = ((long) idx << 32) | (Block.BLOCK_STATE_REGISTRY.getId(s) & 0xFFFFFFFFL);
                }
            }
        }
        long[] cut = Arrays.copyOf(packed, n);
        Arrays.sort(cut);
        int[] idx = new int[n], ids = new int[n];
        byte[] masks = new byte[n];
        for (int i = 0; i < n; i++) {
            idx[i] = (int) (cut[i] >>> 32);
            ids[i] = (int) (cut[i] & 0xFFFFFFFFL);
            masks[i] = maskOf[idx[i]];
        }
        int ambient = dest.getMaxLocalRawBrightness(BlockPos.containing(c.x + exit.x * 3, c.y, c.z + exit.z * 3));
        int axis = src.normalAxis == Direction.Axis.X ? 0 : 1;
        return new PortalViewPacket(src.key(), srcDim, src.center.x, src.center.y, src.center.z, axis,
                (float) src.halfWidth, (float) src.halfHeight, c.x, c.y, c.z, ex, ez,
                minX, minY, minZ, w, h, d, ambient, skyColor(dest, ambient), idx, ids, masks);
    }

    /** Sisi blok padat yang menghadap ruang kosong di dalam kotak (bit = Direction.get3DDataValue). 0 = tersembunyi sepenuhnya. */
    private static int exposedMask(ServerLevel l, BlockPos p, int minX, int maxX, int minY, int maxY, int minZ, int maxZ) {
        BlockPos.MutableBlockPos q = new BlockPos.MutableBlockPos();
        int mask = 0;
        for (Direction dir : Direction.values()) {
            int nx = p.getX() + dir.getStepX(), ny = p.getY() + dir.getStepY(), nz = p.getZ() + dir.getStepZ();
            if (nx < minX || nx > maxX || ny < minY || ny > maxY || nz < minZ || nz > maxZ) continue;
            q.set(nx, ny, nz);
            if (!l.getBlockState(q).isSolidRender(l, q)) mask |= 1 << dir.get3DDataValue();
        }
        return mask;
    }

    // ---------------------------------------------------------------- medan jauh (mode penuh, dunia terbuka)

    /**
     * v1.9: tiles whose chunk is not loaded used to stay empty, and the sky showed through them as holes in the skyline.
     * Each such tile now copies its lowest known neighbor (lowest, so a hole never becomes a false tall pillar). Repeated
     * for a few rounds so a hole several tiles wide closes from the edges inward.
     */
    private static void fillHoles(byte[] pal, short[] heights, boolean[] unloaded, int gw, int gd) {
        int[] dx = {1, -1, 0, 0}, dz = {0, 0, 1, -1};
        for (int round = 0; round < 6; round++) {
            byte[] np = pal.clone();
            short[] nh = heights.clone();
            boolean any = false;
            for (int iz = 0; iz < gd; iz++) {
                for (int ix = 0; ix < gw; ix++) {
                    int i = iz * gw + ix;
                    if (!unloaded[i] || pal[i] != (byte) 255) continue;
                    int best = -1;
                    for (int k = 0; k < 4; k++) {
                        int nx = ix + dx[k], nz = iz + dz[k];
                        if (nx < 0 || nz < 0 || nx >= gw || nz >= gd) continue;
                        int ni = nz * gw + nx;
                        if (pal[ni] == (byte) 255) continue;
                        if (best < 0 || heights[ni] < heights[best]) best = ni;
                    }
                    if (best >= 0) {
                        np[i] = pal[best];
                        nh[i] = heights[best];
                        any = true;
                    }
                }
            }
            System.arraycopy(np, 0, pal, 0, pal.length);
            System.arraycopy(nh, 0, heights, 0, heights.length);
            if (!any) break;
        }
    }

    /** Tinggi dan jenis blok permukaan per tile 4x4 blok di luar kotak dekat, sampai distChunks chunk dari bingkai tujuan. */
    private static PortalFarPacket buildFar(ServerLevel dest, PortalFrame src, PortalFrame dst, Vec3 exit, int distChunks, Cfg near, int[] complete) {
        Vec3 c = dst.center;
        int ex = (int) Math.signum(exit.x), ez = (int) Math.signum(exit.z);
        int r = distChunks * 16;
        int bx = Mth.floor(c.x), bz = Mth.floor(c.z);
        int minX, maxX, minZ, maxZ;
        if (ex != 0) {
            minX = ex > 0 ? bx + 1 : bx - r;
            maxX = ex > 0 ? bx + r : bx - 1;
            minZ = bz - r;
            maxZ = bz + r;
        } else {
            minZ = ez > 0 ? bz + 1 : bz - r;
            maxZ = ez > 0 ? bz + r : bz - 1;
            minX = bx - r;
            maxX = bx + r;
        }
        int t = FAR_TILE;
        int tx0 = Math.floorDiv(minX, t), tx1 = Math.floorDiv(maxX, t);
        int tz0 = Math.floorDiv(minZ, t), tz1 = Math.floorDiv(maxZ, t);
        int gw = tx1 - tx0 + 1, gd = tz1 - tz0 + 1;
        int[] nb = nearBox(c, ex, ez, near);

        byte[] pal = new byte[gw * gd];
        short[] heights = new short[gw * gd];
        boolean[] unloaded = new boolean[gw * gd];
        Map<Block, Integer> palette = new HashMap<>();
        int[] palIds = new int[250];
        int present = 0, expected = 0;
        BlockPos.MutableBlockPos q = new BlockPos.MutableBlockPos();
        for (int iz = 0; iz < gd; iz++) {
            for (int ix = 0; ix < gw; ix++) {
                int i = iz * gw + ix;
                pal[i] = (byte) 255;
                int x = (tx0 + ix) * t + t / 2, z = (tz0 + iz) * t + t / 2;
                if (x >= nb[0] && x <= nb[1] && z >= nb[2] && z <= nb[3]) continue;            // sudah tercakup kotak dekat
                if (x < minX || x > maxX || z < minZ || z > maxZ) continue;
                expected++;
                LevelChunk ch = dest.getChunkSource().getChunkNow(x >> 4, z >> 4);
                if (ch == null) {
                    unloaded[i] = true;                  // a hole for now: filled from its neighbors below
                    continue;
                }
                int top = ch.getHeight(Heightmap.Types.WORLD_SURFACE, x & 15, z & 15) - 1;
                BlockState s = null;
                int y = top;
                for (int k = 0; k < 6 && y > dest.getMinBuildHeight(); k++, y--) {
                    q.set(x, y, z);
                    BlockState cand = ch.getBlockState(q);
                    if (cand.isAir()) continue;
                    if (cand.is(Blocks.SNOW) || cand.is(BlockTags.LEAVES) || !cand.getFluidState().isEmpty() || cand.isSolidRender(dest, q)) {
                        s = cand;
                        break;
                    }
                }
                if (s == null) continue;
                Block b = s.getBlock();
                Integer pi = palette.get(b);
                if (pi == null) {
                    if (palette.size() >= palIds.length) pi = 0;
                    else {
                        pi = palette.size();
                        palette.put(b, pi);
                        palIds[pi] = Block.BLOCK_STATE_REGISTRY.getId(b.defaultBlockState());
                    }
                }
                pal[i] = (byte) (int) pi;
                heights[i] = (short) (y + 1);
                present++;
            }
        }
        complete[0] = expected > 0 && present * 10L >= expected * 9L ? 1 : 0;
        if (present == 0) return null;
        fillHoles(pal, heights, unloaded, gw, gd);
        int ambient = dest.getMaxLocalRawBrightness(BlockPos.containing(c.x + exit.x * 3, c.y, c.z + exit.z * 3));
        return new PortalFarPacket(src.key(), c.x, c.y, c.z, t, tx0, tz0, gw, gd, ambient, Arrays.copyOf(palIds, palette.size()), pal, heights);
    }
}
