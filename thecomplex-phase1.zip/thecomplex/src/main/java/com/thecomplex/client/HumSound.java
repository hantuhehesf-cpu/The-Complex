package com.thecomplex.client;

import com.thecomplex.ModSounds;
import com.thecomplex.TheComplex;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.SoundSource;

/** Dengung panel lampu yang terus berputar selama pemain berada di The Complex. */
public class HumSound extends AbstractTickableSoundInstance {
    /** Volume dasar (0..1). Bisa diubah lewat slider "Ambient/Environment" di pengaturan suara. */
    public static final float VOLUME = 0.35f;

    public HumSound() {
        super(ModSounds.FLUORESCENT_HUM.get(), SoundSource.AMBIENT, SoundInstance.createUnseededRandom());
        this.looping = true;
        this.delay = 0;
        this.volume = VOLUME;
        this.relative = true;
        this.attenuation = SoundInstance.Attenuation.NONE;
    }

    @Override
    public void tick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.level.dimension() != TheComplex.COMPLEX) stop();
    }
}
