package com.thecomplex.client;

import com.thecomplex.block.NullZoneBlockEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.client.ChunkRenderTypeSet;
import net.minecraftforge.client.model.BakedModelWrapper;
import net.minecraftforge.client.model.data.ModelData;

import java.util.List;

/** Model Null Zone yang menggambar blok asli yang ditirunya (kalau datanya ada), bukan wallpaper. */
public class MimicModel extends BakedModelWrapper<BakedModel> {
    public MimicModel(BakedModel original) {
        super(original);
    }

    private static BlockState mimic(ModelData data) {
        BlockState m = data.get(NullZoneBlockEntity.MIMIC);
        return (m == null || m.isAir()) ? null : m;
    }

    private static BakedModel modelOf(BlockState m) {
        return Minecraft.getInstance().getBlockRenderer().getBlockModel(m);
    }

    @Override
    public List<BakedQuad> getQuads(BlockState state, Direction side, RandomSource rand, ModelData data, RenderType renderType) {
        BlockState m = mimic(data);
        if (m == null) return originalModel.getQuads(state, side, rand, data, renderType);
        return modelOf(m).getQuads(m, side, rand, ModelData.EMPTY, renderType);
    }

    @Override
    public ChunkRenderTypeSet getRenderTypes(BlockState state, RandomSource rand, ModelData data) {
        BlockState m = mimic(data);
        if (m == null) return originalModel.getRenderTypes(state, rand, data);
        return modelOf(m).getRenderTypes(m, rand, ModelData.EMPTY);
    }

    @Override
    public TextureAtlasSprite getParticleIcon(ModelData data) {
        BlockState m = mimic(data);
        if (m == null) return originalModel.getParticleIcon(data);
        return modelOf(m).getParticleIcon(ModelData.EMPTY);
    }
}
