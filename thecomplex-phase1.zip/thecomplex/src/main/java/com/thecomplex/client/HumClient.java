package com.thecomplex.client;

import com.thecomplex.TheComplex;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = TheComplex.MODID, value = Dist.CLIENT)
public final class HumClient {
    private static HumSound hum;

    private HumClient() {}

    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.level.dimension() != TheComplex.COMPLEX) {
            hum = null;
            return;
        }
        if (hum == null || hum.isStopped()) {
            hum = new HumSound();
            mc.getSoundManager().play(hum);
        }
    }
}
