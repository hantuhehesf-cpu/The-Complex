package com.thecomplex.client;

import com.thecomplex.dev.DevActions;
import com.thecomplex.net.DevActionPacket;
import com.thecomplex.net.Net;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.List;

/** Developer UI: semua uji coba lewat tombol, tanpa mengetik command. Dibuka dengan item "Complex Dev Tool" (klik kanan). */
public class DevScreen extends Screen {
    private static int page = 0;
    private static int roomIndex = 0;

    private final String status;
    private final List<String> rooms;
    private final List<String> zones;     // "id|teks"

    public DevScreen(String status, List<String> rooms, List<String> zones) {
        super(Component.literal("The Complex - Dev"));
        this.status = status;
        this.rooms = rooms;
        this.zones = zones;
        if (roomIndex >= rooms.size()) roomIndex = 0;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private void send(int action, String arg) {
        Net.CHANNEL.sendToServer(new DevActionPacket(action, arg));
    }

    private int colWidth() {
        return Math.min(150, (width - 20) / 2);
    }

    private void button(String label, int col, int row, Button.OnPress press) {
        int bw = colWidth();
        int x = width / 2 - bw - 2 + col * (bw + 4);
        int y = 74 + row * 22;
        addRenderableWidget(Button.builder(Component.literal(label), press).bounds(x, y, bw, 20).build());
    }

    private void action(String label, int col, int row, int action) {
        button(label, col, row, b -> send(action, ""));
    }

    @Override
    protected void init() {
        String[] tabs = {"Masuk", "Null Zone", "Pelacak", "Fragmen", "Ruangan", "Tutup"};
        int tw = Math.min(80, (width - 10) / tabs.length);
        int tx = (width - tw * tabs.length) / 2;
        for (int i = 0; i < tabs.length; i++) {
            final int idx = i;
            addRenderableWidget(Button.builder(Component.literal(tabs[i]), b -> {
                if (idx == tabs.length - 1) {
                    onClose();
                } else {
                    page = idx;
                    rebuildWidgets();
                }
            }).bounds(tx + i * tw, 50, tw, 18).build());
        }

        switch (page) {
            case 0 -> {
                action("Masuk Main Chamber", 0, 0, DevActions.ENTER);
                action("Backrooms acak", 1, 0, DevActions.BACKROOMS);
                action("Keluar ke Overworld", 0, 1, DevActions.LEAVE);
                action("Segarkan status", 1, 1, DevActions.REFRESH);
                action("Ganti kreatif / survival", 0, 2, DevActions.TOGGLE_MODE);
                action("Pulihkan nyawa & lapar", 1, 2, DevActions.HEAL);
            }
            case 1 -> {
                action("Null Zone (acak)", 0, 0, DevActions.NZ_ANY);
                action("Null Zone di lantai", 1, 0, DevActions.NZ_FLOOR);
                action("Null Zone di dinding", 0, 1, DevActions.NZ_WALL);
                action("Heat chunk ini +240", 1, 1, DevActions.HEAT_BOOST);
                action("Hapus catatan heat", 0, 2, DevActions.HEAT_RESET);
            }
            case 2 -> {
                action("Teleport ke terdekat", 0, 0, DevActions.ZONE_NEAREST);
                action("Pulihkan semua", 1, 0, DevActions.ZONES_CLEAR);
                int bw = colWidth() * 2 + 4;
                int x = width / 2 - bw / 2;
                for (int i = 0; i < Math.min(3, zones.size()); i++) {
                    String entry = zones.get(i);
                    int bar = entry.indexOf('|');
                    String id = bar < 0 ? "" : entry.substring(0, bar);
                    String text = bar < 0 ? entry : entry.substring(bar + 1);
                    addRenderableWidget(Button.builder(Component.literal(text), b -> send(DevActions.ZONE_TP, id))
                            .bounds(x, 74 + (i + 1) * 22, bw, 20).build());
                }
            }
            case 3 -> {
                action("Tangkap bangunan di sini", 0, 0, DevActions.CAP_BUILDING);
                action("Tangkap pohon terdekat", 1, 0, DevActions.CAP_TREE);
                action("Tangkap struktur terdekat", 0, 1, DevActions.CAP_STRUCTURE);
                action("Tempel fragmen acak", 1, 1, DevActions.FRAG_PLACE);
                action("Hapus semua fragmen", 0, 2, DevActions.FRAG_CLEAR);
            }
            default -> {
                int bw = colWidth();
                int cx = width / 2;
                addRenderableWidget(Button.builder(Component.literal("<"), b -> {
                    if (!rooms.isEmpty()) roomIndex = (roomIndex - 1 + rooms.size()) % rooms.size();
                    rebuildWidgets();
                }).bounds(cx - bw - 2, 74, 30, 20).build());
                addRenderableWidget(Button.builder(Component.literal(">"), b -> {
                    if (!rooms.isEmpty()) roomIndex = (roomIndex + 1) % rooms.size();
                    rebuildWidgets();
                }).bounds(cx + bw + 2 - 30, 74, 30, 20).build());
                button("Tempel di sini", 0, 1, b -> {
                    if (!rooms.isEmpty()) send(DevActions.ROOM_PASTE, rooms.get(roomIndex));
                });
                action("Muat ulang ruangan", 1, 1, DevActions.ROOM_RELOAD);
            }
        }
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        int y = 4;
        for (String line : status.split("\n")) {
            g.drawString(font, font.plainSubstrByWidth(line, width - 16), 8, y, 0xFFFFFF);
            y += 9;
        }
        if (page == 2) {
            String hint = zones.isEmpty()
                    ? "Belum ada Null Zone tercatat. Buat lewat tab Null Zone."
                    : "Ketuk baris untuk teleport. Pegang Dev Tool: kompas di action bar + percikan cahaya.";
            g.drawCenteredString(font, font.plainSubstrByWidth(hint, width - 16), width / 2, 74 + 22 + (zones.isEmpty() ? 6 : 78), 0xAAAAAA);
        }
        if (page == 4) {
            String name = rooms.isEmpty() ? "(belum ada ruangan)" : (roomIndex + 1) + "/" + rooms.size() + "  " + rooms.get(roomIndex);
            g.drawCenteredString(font, font.plainSubstrByWidth(name, width - 80), width / 2, 80, 0xFFFFAA);
        }
        super.render(g, mouseX, mouseY, partialTick);
    }
}
