package com.thecomplex.client;

import com.thecomplex.dev.DevActions;
import com.thecomplex.net.DevActionPacket;
import com.thecomplex.net.Net;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.List;

/** Developer UI: semua uji coba lewat tombol, tanpa mengetik command. Dibuka dengan item "Complex Dev Tool" (klik kanan). */
public class DevScreen extends Screen {
    private static int page = 0;
    private static int roomIndex = 0;

    private final String status;
    private final List<String> rooms;

    public DevScreen(String status, List<String> rooms) {
        super(Component.literal("The Complex - Dev"));
        this.status = status;
        this.rooms = rooms;
        if (roomIndex >= rooms.size()) roomIndex = 0;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private void send(int action, String arg) {
        Net.CHANNEL.sendToServer(new DevActionPacket(action, arg));
    }

    private void button(String label, int col, int row, Button.OnPress press) {
        int bw = Math.min(150, (width - 20) / 2);
        int x = width / 2 - bw - 2 + col * (bw + 4);
        int y = 74 + row * 22;
        addRenderableWidget(Button.builder(Component.literal(label), press).bounds(x, y, bw, 20).build());
    }

    private void action(String label, int col, int row, int action) {
        button(label, col, row, b -> send(action, ""));
    }

    @Override
    protected void init() {
        String[] tabs = {"Masuk", "Null Zone", "Fragmen", "Ruangan", "Tutup"};
        int tw = Math.min(80, (width - 10) / tabs.length);
        int tx = (width - tw * tabs.length) / 2;
        for (int i = 0; i < tabs.length; i++) {
            final int idx = i;
            addRenderableWidget(Button.builder(Component.literal(tabs[i]), b -> {
                if (idx == tabs.length - 1) {
                    onClose();
                } else {
                    page = idx;
                    rebuildWidgets();
                }
            }).bounds(tx + i * tw, 50, tw, 18).build());
        }

        switch (page) {
            case 0 -> {
                action("Masuk Main Chamber", 0, 0, DevActions.ENTER);
                action("Backrooms acak", 1, 0, DevActions.BACKROOMS);
                action("Keluar ke Overworld", 0, 1, DevActions.LEAVE);
                action("Segarkan status", 1, 1, DevActions.REFRESH);
            }
            case 1 -> {
                action("Null Zone (acak)", 0, 0, DevActions.NZ_ANY);
                action("Null Zone di lantai", 1, 0, DevActions.NZ_FLOOR);
                action("Null Zone di dinding", 0, 1, DevActions.NZ_WALL);
                action("Heat chunk ini +240", 1, 1, DevActions.HEAT_BOOST);
                action("Hapus catatan heat", 0, 2, DevActions.HEAT_RESET);
            }
            case 2 -> {
                action("Tangkap bangunan di sini", 0, 0, DevActions.CAP_BUILDING);
                action("Tangkap pohon terdekat", 1, 0, DevActions.CAP_TREE);
                action("Tangkap struktur terdekat", 0, 1, DevActions.CAP_STRUCTURE);
                action("Tempel fragmen acak", 1, 1, DevActions.FRAG_PLACE);
                action("Hapus semua fragmen", 0, 2, DevActions.FRAG_CLEAR);
            }
            default -> {
                int bw = Math.min(150, (width - 20) / 2);
                int cx = width / 2;
                addRenderableWidget(Button.builder(Component.literal("<"), b -> {
                    if (!rooms.isEmpty()) roomIndex = (roomIndex - 1 + rooms.size()) % rooms.size();
                    rebuildWidgets();
                }).bounds(cx - bw - 2, 74, 30, 20).build());
                addRenderableWidget(Button.builder(Component.literal(">"), b -> {
                    if (!rooms.isEmpty()) roomIndex = (roomIndex + 1) % rooms.size();
                    rebuildWidgets();
                }).bounds(cx + bw + 2 - 30, 74, 30, 20).build());
                button("Tempel di sini", 0, 1, b -> {
                    if (!rooms.isEmpty()) send(DevActions.ROOM_PASTE, rooms.get(roomIndex));
                });
                action("Muat ulang ruangan", 1, 1, DevActions.ROOM_RELOAD);
            }
        }
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        int y = 6;
        for (String line : status.split("\n")) {
            g.drawString(font, font.plainSubstrByWidth(line, width - 16), 8, y, 0xFFFFFF);
            y += 10;
        }
        if (page == 3) {
            String name = rooms.isEmpty() ? "(belum ada ruangan)" : (roomIndex + 1) + "/" + rooms.size() + "  " + rooms.get(roomIndex);
            g.drawCenteredString(font, font.plainSubstrByWidth(name, width - 80), width / 2, 80, 0xFFFFAA);
        }
        super.render(g, mouseX, mouseY, partialTick);
    }
}
