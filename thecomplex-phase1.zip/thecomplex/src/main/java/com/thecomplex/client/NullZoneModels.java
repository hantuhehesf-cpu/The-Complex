package com.thecomplex.client;

import com.thecomplex.TheComplex;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ModelEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = TheComplex.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class NullZoneModels {
    private NullZoneModels() {}

    @SubscribeEvent
    public static void onBake(ModelEvent.ModifyBakingResult e) {
        ModelResourceLocation key = new ModelResourceLocation(new ResourceLocation(TheComplex.MODID, "null_zone"), "");
        BakedModel base = e.getModels().get(key);
        if (base != null) e.getModels().put(key, new MimicModel(base));
    }
}
