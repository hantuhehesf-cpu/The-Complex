package com.thecomplex.client;

import com.thecomplex.TheComplex;
import net.minecraft.client.Minecraft;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.material.FogType;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Menghilangkan kabut di dimensi The Complex dengan mendorong jarak kabut jauh melewati jarak render. */
@Mod.EventBusSubscriber(modid = TheComplex.MODID, value = Dist.CLIENT)
public final class FogClient {
    @SubscribeEvent
    public static void onFog(ViewportEvent.RenderFog e) {
        Level level = Minecraft.getInstance().level;
        if (level == null || level.dimension() != TheComplex.COMPLEX) return;
        if (e.getType() != FogType.NONE) return;
        float far = e.getFarPlaneDistance();
        e.setNearPlaneDistance(far * 2f);
        e.setFarPlaneDistance(far * 4f);
        e.setCanceled(true);
    }

    private FogClient() {}
}
