package com.thecomplex.client;

import com.thecomplex.TheComplex;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Camera shake untuk gempa LPMDS. Murni di klien, nol biaya render. */
@Mod.EventBusSubscriber(modid = TheComplex.MODID, value = Dist.CLIENT)
public final class QuakeClient {
    private static int remaining;
    private static int total = 1;
    private static float intensity;

    public static void start(int ticks, float power) {
        remaining = ticks;
        total = Math.max(1, ticks);
        intensity = power;
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase == TickEvent.Phase.END && remaining > 0) remaining--;
    }

    @SubscribeEvent
    public static void onCamera(ViewportEvent.ComputeCameraAngles e) {
        if (remaining <= 0) return;
        float progress = 1f - remaining / (float) total;
        // naik pelan-pelan di awal, mereda di 15% terakhir
        float envelope = Math.min(progress * 6f, 1f) * Math.min((1f - progress) * 6.6f, 1f);
        double t = (total - remaining) + e.getPartialTick();
        float amp = intensity * envelope;
        e.setYaw(e.getYaw() + (float) (Math.sin(t * 1.7) * 1.2 * amp));
        e.setPitch(e.getPitch() + (float) (Math.sin(t * 2.9 + 1.3) * 0.9 * amp));
        e.setRoll(e.getRoll() + (float) (Math.sin(t * 2.3 + 0.7) * 2.5 * amp));
    }

    private QuakeClient() {}
}
