package com.thecomplex.client;

import net.minecraft.client.Minecraft;

import java.util.List;

public final class ClientHooks {
    private ClientHooks() {}

    public static void openDev(String status, List<String> rooms) {
        Minecraft.getInstance().setScreen(new DevScreen(status, rooms));
    }
}
