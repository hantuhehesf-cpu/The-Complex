package com.thecomplex.net;

import com.thecomplex.client.QuakeClient;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public record QuakePacket(int ticks, float intensity) {
    public static void encode(QuakePacket m, FriendlyByteBuf buf) {
        buf.writeVarInt(m.ticks);
        buf.writeFloat(m.intensity);
    }

    public static QuakePacket decode(FriendlyByteBuf buf) {
        return new QuakePacket(buf.readVarInt(), buf.readFloat());
    }

    public static void handle(QuakePacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> QuakeClient.start(m.ticks, m.intensity)));
        ctx.get().setPacketHandled(true);
    }
}
