package com.thecomplex.net;

import com.thecomplex.TheComplex;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

public final class Net {
    private static final String PROTOCOL = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(TheComplex.MODID, "main"), () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    public static void register() {
        CHANNEL.registerMessage(0, QuakePacket.class, QuakePacket::encode, QuakePacket::decode, QuakePacket::handle);
    }

    public static void sendQuake(ServerLevel level, BlockPos pos, int ticks, float intensity) {
        CHANNEL.send(PacketDistributor.NEAR.with(() -> new PacketDistributor.TargetPoint(
                pos.getX(), pos.getY(), pos.getZ(), 48, level.dimension())), new QuakePacket(ticks, intensity));
    }

    public static void sendQuakeTo(ServerPlayer player, int ticks, float intensity) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new QuakePacket(ticks, intensity));
    }

    private Net() {}
}
