package com.thecomplex.net;

import com.thecomplex.client.ClientHooks;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/** Server -> klien: buka (atau segarkan) Developer UI dengan status terbaru dan daftar ruangan. */
public record OpenDevPacket(String status, List<String> rooms) {
    public static void encode(OpenDevPacket m, FriendlyByteBuf buf) {
        buf.writeUtf(m.status, 1024);
        buf.writeVarInt(m.rooms.size());
        for (String s : m.rooms) buf.writeUtf(s, 128);
    }

    public static OpenDevPacket decode(FriendlyByteBuf buf) {
        String status = buf.readUtf(1024);
        int n = buf.readVarInt();
        List<String> rooms = new ArrayList<>();
        for (int i = 0; i < n; i++) rooms.add(buf.readUtf(128));
        return new OpenDevPacket(status, rooms);
    }

    public static void handle(OpenDevPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> ClientHooks.openDev(m.status, m.rooms)));
        ctx.get().setPacketHandled(true);
    }
}
