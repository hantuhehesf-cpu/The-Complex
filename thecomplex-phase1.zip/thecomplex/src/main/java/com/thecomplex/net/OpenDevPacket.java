package com.thecomplex.net;

import com.thecomplex.client.ClientHooks;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/** Server -> klien: buka (atau segarkan) Developer UI dengan status terbaru dan daftar ruangan. */
public record OpenDevPacket(String status, List<String> rooms, List<String> zones) {
    public static void encode(OpenDevPacket m, FriendlyByteBuf buf) {
        buf.writeUtf(m.status, 1024);
        buf.writeVarInt(m.rooms.size());
        for (String s : m.rooms) buf.writeUtf(s, 128);
        buf.writeVarInt(m.zones.size());
        for (String s : m.zones) buf.writeUtf(s, 256);
    }

    public static OpenDevPacket decode(FriendlyByteBuf buf) {
        String status = buf.readUtf(1024);
        int n = buf.readVarInt();
        List<String> rooms = new ArrayList<>();
        for (int i = 0; i < n; i++) rooms.add(buf.readUtf(128));
        int z = buf.readVarInt();
        List<String> zones = new ArrayList<>();
        for (int i = 0; i < z; i++) zones.add(buf.readUtf(256));
        return new OpenDevPacket(status, rooms, zones);
    }

    public static void handle(OpenDevPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> ClientHooks.openDev(m.status, m.rooms, m.zones)));
        ctx.get().setPacketHandled(true);
    }
}
