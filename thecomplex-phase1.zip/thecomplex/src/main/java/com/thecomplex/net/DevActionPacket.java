package com.thecomplex.net;

import com.thecomplex.dev.DevActions;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Klien -> server: tombol di Developer UI ditekan. */
public record DevActionPacket(int action, String arg) {
    public static void encode(DevActionPacket m, FriendlyByteBuf buf) {
        buf.writeVarInt(m.action);
        buf.writeUtf(m.arg, 128);
    }

    public static DevActionPacket decode(FriendlyByteBuf buf) {
        return new DevActionPacket(buf.readVarInt(), buf.readUtf(128));
    }

    public static void handle(DevActionPacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> {
            ServerPlayer p = c.getSender();
            if (p != null) DevActions.handle(p, m.action, m.arg);
        });
        c.setPacketHandled(true);
    }
}
