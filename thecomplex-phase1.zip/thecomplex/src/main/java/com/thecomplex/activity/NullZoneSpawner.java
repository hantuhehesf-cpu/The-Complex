package com.thecomplex.activity;

import com.thecomplex.ModBlocks;
import com.thecomplex.block.NullZoneBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Menaruh Null Zone di dinding bagian dalam ruangan, condong ke chunk yang paling sering dikunjungi pemain. */
public final class NullZoneSpawner {
    /** Umur Null Zone liar sebelum dinding kembali normal: 10 sampai 30 menit. */
    public static final int LIFETIME_MIN = 12000;
    public static final int LIFETIME_VAR = 24000;
    private static final int CHUNK_RADIUS = 5;

    private NullZoneSpawner() {}

    public static boolean spawnFor(ServerPlayer p, ActivityData data) {
        ServerLevel level = p.serverLevel();
        RandomSource r = p.getRandom();
        ChunkPos target = pickChunk(level, data, p, r);
        for (int i = 0; i < 48; i++) {
            if (tryPlace(level, target, p, r)) return true;
        }
        return false;
    }

    /** Roulette berbobot heat, hanya chunk yang sedang dimuat dan dekat pemain. */
    private static ChunkPos pickChunk(ServerLevel level, ActivityData data, ServerPlayer p, RandomSource r) {
        ChunkPos pc = p.chunkPosition();
        List<ChunkPos> chunks = new ArrayList<>();
        List<Float> weights = new ArrayList<>();
        double total = 0;
        for (Map.Entry<Long, Float> e : data.of(p.getUUID()).entrySet()) {
            ChunkPos c = new ChunkPos(e.getKey());
            if (Math.abs(c.x - pc.x) > CHUNK_RADIUS || Math.abs(c.z - pc.z) > CHUNK_RADIUS) continue;
            if (!level.hasChunk(c.x, c.z)) continue;
            chunks.add(c);
            weights.add(e.getValue());
            total += e.getValue();
        }
        if (chunks.isEmpty() || total <= 0) return pc;
        double roll = r.nextDouble() * total;
        for (int i = 0; i < chunks.size(); i++) {
            roll -= weights.get(i);
            if (roll <= 0) return chunks.get(i);
        }
        return chunks.get(chunks.size() - 1);
    }

    private static boolean tryPlace(ServerLevel level, ChunkPos cp, ServerPlayer p, RandomSource r) {
        int x = cp.getMinBlockX() + r.nextInt(16);
        int z = cp.getMinBlockZ() + r.nextInt(16);
        int top = level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z);
        int bottom = Math.max(level.getMinBuildHeight() + 1, top - 24);
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int y = top - 1; y >= bottom; y--) {
            m.set(x, y, z);
            BlockPos below = m.below();
            if (!level.getBlockState(m).isAir() || !level.getBlockState(m.above()).isAir()) continue;
            if (!level.getBlockState(below).isCollisionShapeFullBlock(level, below)) continue;
            if (level.canSeeSky(m.above())) continue;               // harus di bawah atap
            BlockPos floor = m.immutable();
            for (Direction d : shuffled(r)) {
                BlockPos a = floor.relative(d);
                BlockPos b = a.above();
                if (!level.hasChunkAt(a)) continue;
                if (p.distanceToSqr(a.getX() + 0.5, a.getY(), a.getZ() + 0.5) < 4) continue;
                if (isWall(level, a) && isWall(level, b)) {
                    place(level, a, r);
                    place(level, b, r);
                    return true;
                }
            }
            return false;                                           // satu kolom per percobaan
        }
        return false;
    }

    private static Direction[] shuffled(RandomSource r) {
        Direction[] dirs = {Direction.NORTH, Direction.EAST, Direction.SOUTH, Direction.WEST};
        for (int i = dirs.length - 1; i > 0; i--) {
            int j = r.nextInt(i + 1);
            Direction t = dirs[i];
            dirs[i] = dirs[j];
            dirs[j] = t;
        }
        return dirs;
    }

    private static boolean isWall(ServerLevel l, BlockPos pos) {
        BlockState s = l.getBlockState(pos);
        return s.isCollisionShapeFullBlock(l, pos) && s.getDestroySpeed(l, pos) >= 0
                && !s.hasBlockEntity() && !s.is(Blocks.BEDROCK) && !s.is(ModBlocks.NULL_ZONE.get());
    }

    private static void place(ServerLevel level, BlockPos pos, RandomSource r) {
        BlockState old = level.getBlockState(pos);
        level.setBlock(pos, ModBlocks.NULL_ZONE.get().defaultBlockState(), 3);
        if (level.getBlockEntity(pos) instanceof NullZoneBlockEntity be) be.setOriginal(old);
        level.scheduleTick(pos, ModBlocks.NULL_ZONE.get(), LIFETIME_MIN + r.nextInt(LIFETIME_VAR));
    }
}
