package com.thecomplex.activity;

import com.thecomplex.ModBlocks;
import com.thecomplex.block.NullZoneBlockEntity;
import com.thecomplex.fragment.Fragment;
import com.thecomplex.fragment.FragmentCapture;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Menaruh Null Zone di dinding atau lantai bagian dalam ruangan, condong ke chunk yang paling sering dikunjungi pemain.
 * Null Zone menyamar sebagai blok aslinya dan memulihkannya setelah dipakai atau kedaluwarsa.
 */
public final class NullZoneSpawner {
    public static final int MODE_ANY = 0;
    public static final int MODE_WALL = 1;
    public static final int MODE_FLOOR = 2;

    /** Umur Null Zone liar sebelum dinding kembali normal: 10 sampai 30 menit. */
    public static final int LIFETIME_MIN = 12000;
    public static final int LIFETIME_VAR = 24000;
    /** Peluang (persen) satu Null Zone yang berhasil dibuat sekaligus menangkap fragmen bangunan di tempat itu. */
    public static final int CAPTURE_CHANCE = 30;
    private static final int CHUNK_RADIUS = 5;

    private NullZoneSpawner() {}

    public static boolean spawnFor(ServerPlayer p, ActivityData data) {
        return spawnFor(p, data, MODE_ANY);
    }

    public static boolean spawnFor(ServerPlayer p, ActivityData data, int mode) {
        ServerLevel level = p.serverLevel();
        RandomSource r = p.getRandom();
        ChunkPos target = pickChunk(level, data, p, r);
        for (int i = 0; i < 48; i++) {
            BlockPos floor = findIndoorFloor(level, target, r);
            if (floor == null) continue;
            boolean asFloor = mode == MODE_FLOOR || (mode == MODE_ANY && r.nextInt(100) < 40);
            BlockPos center = asFloor ? placeFloor(level, floor, p, r) : placeWall(level, floor, p, r);
            if (center != null) {
                NullZoneTracker.add(level, center, asFloor ? "lantai" : "dinding");
                if (r.nextInt(100) < CAPTURE_CHANCE) {
                    Fragment f = FragmentCapture.captureBuilding(level, floor);
                    FragmentCapture.store(level, f, r);
                }
                return true;
            }
        }
        return false;
    }

    /** Roulette berbobot heat, hanya chunk yang sedang dimuat dan dekat pemain. */
    private static ChunkPos pickChunk(ServerLevel level, ActivityData data, ServerPlayer p, RandomSource r) {
        ChunkPos pc = p.chunkPosition();
        List<ChunkPos> chunks = new ArrayList<>();
        List<Float> weights = new ArrayList<>();
        double total = 0;
        for (Map.Entry<Long, Float> e : data.of(p.getUUID()).entrySet()) {
            ChunkPos c = new ChunkPos(e.getKey());
            if (Math.abs(c.x - pc.x) > CHUNK_RADIUS || Math.abs(c.z - pc.z) > CHUNK_RADIUS) continue;
            if (!level.hasChunk(c.x, c.z)) continue;
            chunks.add(c);
            weights.add(e.getValue());
            total += e.getValue();
        }
        if (chunks.isEmpty() || total <= 0) return pc;
        double roll = r.nextDouble() * total;
        for (int i = 0; i < chunks.size(); i++) {
            roll -= weights.get(i);
            if (roll <= 0) return chunks.get(i);
        }
        return chunks.get(chunks.size() - 1);
    }

    /** Sel udara acak di dalam ruangan (di bawah atap) yang lantainya blok padat. Null kalau tidak ketemu. */
    public static BlockPos findIndoorFloor(ServerLevel level, ChunkPos cp, RandomSource r) {
        int x = cp.getMinBlockX() + r.nextInt(16);
        int z = cp.getMinBlockZ() + r.nextInt(16);
        int top = level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z);
        int bottom = Math.max(level.getMinBuildHeight() + 1, top - 24);
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int y = top - 1; y >= bottom; y--) {
            m.set(x, y, z);
            BlockPos below = m.below();
            if (!level.getBlockState(m).isAir() || !level.getBlockState(m.above()).isAir()) continue;
            if (!level.getBlockState(below).isCollisionShapeFullBlock(level, below)) continue;
            if (level.canSeeSky(m.above())) continue;               // harus di bawah atap
            return m.immutable();
        }
        return null;
    }

    private static BlockPos placeWall(ServerLevel level, BlockPos floor, ServerPlayer p, RandomSource r) {
        for (Direction d : shuffled(r)) {
            BlockPos a = floor.relative(d);
            BlockPos b = a.above();
            if (!level.hasChunkAt(a)) continue;
            if (p.distanceToSqr(a.getX() + 0.5, a.getY(), a.getZ() + 0.5) < 4) continue;
            if (isWall(level, a) && isWall(level, b)) {
                place(level, a, r);
                place(level, b, r);
                return a;
            }
        }
        return null;
    }

    /** Lantai: area 2x2, dua blok dalam, supaya pemain yang melangkah di atasnya benar-benar tenggelam. */
    private static BlockPos placeFloor(ServerLevel level, BlockPos floor, ServerPlayer p, RandomSource r) {
        if (p.distanceToSqr(floor.getX() + 1.0, floor.getY(), floor.getZ() + 1.0) < 4) return null;
        BlockPos[] cells = new BlockPos[8];
        int n = 0;
        for (int dx = 0; dx <= 1; dx++) {
            for (int dz = 0; dz <= 1; dz++) {
                BlockPos top = floor.offset(dx, -1, dz);
                BlockPos deep = top.below();
                if (!level.hasChunkAt(top) || !level.getBlockState(top.above()).isAir()) return null;
                if (!isWall(level, top) || !isWall(level, deep)) return null;
                cells[n++] = top;
                cells[n++] = deep;
            }
        }
        for (BlockPos c : cells) place(level, c, r);
        return floor.below();
    }

    private static Direction[] shuffled(RandomSource r) {
        Direction[] dirs = {Direction.NORTH, Direction.EAST, Direction.SOUTH, Direction.WEST};
        for (int i = dirs.length - 1; i > 0; i--) {
            int j = r.nextInt(i + 1);
            Direction t = dirs[i];
            dirs[i] = dirs[j];
            dirs[j] = t;
        }
        return dirs;
    }

    /** Hanya blok padat buram tanpa warna biome, supaya tiruannya terlihat benar-benar sama. */
    private static boolean isWall(ServerLevel l, BlockPos pos) {
        BlockState s = l.getBlockState(pos);
        return s.isCollisionShapeFullBlock(l, pos) && s.canOcclude() && s.getDestroySpeed(l, pos) >= 0
                && !s.hasBlockEntity() && !s.is(Blocks.BEDROCK) && !s.is(Blocks.GRASS_BLOCK)
                && !s.is(ModBlocks.NULL_ZONE.get());
    }

    private static void place(ServerLevel level, BlockPos pos, RandomSource r) {
        BlockState old = level.getBlockState(pos);
        level.setBlock(pos, ModBlocks.NULL_ZONE.get().defaultBlockState(), 3);
        if (level.getBlockEntity(pos) instanceof NullZoneBlockEntity be) be.setOriginal(old);
        level.scheduleTick(pos, ModBlocks.NULL_ZONE.get(), LIFETIME_MIN + r.nextInt(LIFETIME_VAR));
    }
}
