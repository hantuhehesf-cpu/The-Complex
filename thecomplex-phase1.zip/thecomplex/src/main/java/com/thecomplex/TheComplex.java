package com.thecomplex;

import com.mojang.serialization.Codec;
import com.thecomplex.net.Net;
import com.thecomplex.world.ComplexChunkGenerator;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;

@Mod(TheComplex.MODID)
public class TheComplex {
    public static final String MODID = "thecomplex";
    public static final ResourceKey<Level> COMPLEX =
            ResourceKey.create(Registries.DIMENSION, new ResourceLocation(MODID, "the_complex"));

    private static final DeferredRegister<Codec<? extends ChunkGenerator>> CHUNK_GENS =
            DeferredRegister.create(Registries.CHUNK_GENERATOR, MODID);

    public TheComplex() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(bus);
        ModBlocks.ITEMS.register(bus);
        CHUNK_GENS.register("complex", () -> ComplexChunkGenerator.CODEC);
        CHUNK_GENS.register(bus);
        bus.addListener(this::commonSetup);
        bus.addListener(this::addCreative);
    }

    private void commonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(Net::register);
    }

    private void addCreative(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
            ModBlocks.ITEMS.getEntries().forEach(event::accept);
        }
    }
}
