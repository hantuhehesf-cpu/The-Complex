package com.thecomplex;

import com.thecomplex.block.NullZoneBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, TheComplex.MODID);

    public static final RegistryObject<BlockEntityType<NullZoneBlockEntity>> NULL_ZONE = BLOCK_ENTITIES.register("null_zone",
            () -> BlockEntityType.Builder.of(NullZoneBlockEntity::new, ModBlocks.NULL_ZONE.get()).build(null));

    private ModBlockEntities() {}
}
