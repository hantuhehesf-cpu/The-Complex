package com.thecomplex.fragment;

import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.tags.BlockTags;

/**
 * Menempel fragmen dengan "keanehan": diputar acak, sebagian blok jadi wallpaper, lantai sebagian jadi karpet,
 * dedaunan jadi wallpaper atau tetap ada tanpa bisa luruh, dan beberapa lubang kecil.
 */
public final class FragmentPlacer {
    @FunctionalInterface
    public interface Sink {
        void accept(int x, int y, int z, BlockState state);
    }

    private FragmentPlacer() {}

    public static int neededAir(Fragment f) {
        return Math.max(3, Math.min(f.height, 9));
    }

    public static int sizeX(Fragment f, int rot) {
        return (rot & 1) == 1 ? f.length : f.width;
    }

    public static int sizeZ(Fragment f, int rot) {
        return (rot & 1) == 1 ? f.width : f.length;
    }

    /** Memanggil sink untuk setiap blok bukan-udara, dalam koordinat setelah rotasi (0..sizeX-1, 0..height-1, 0..sizeZ-1). */
    public static void transform(Fragment f, int rot, RandomSource r, BlockState carpet, BlockState wallpaper, Sink sink) {
        for (int y = 0; y < f.height; y++) {
            for (int z = 0; z < f.length; z++) {
                for (int x = 0; x < f.width; x++) {
                    BlockState s = f.get(x, y, z);
                    if (s.isAir()) continue;
                    int rx, rz;
                    if (rot == 0) { rx = x; rz = z; }
                    else if (rot == 1) { rx = f.length - 1 - z; rz = x; }
                    else if (rot == 2) { rx = f.width - 1 - x; rz = f.length - 1 - z; }
                    else { rx = z; rz = f.width - 1 - x; }
                    BlockState out = distort(s, y, r, carpet, wallpaper);
                    if (out != null) sink.accept(rx, y, rz, out);
                }
            }
        }
    }

    private static BlockState distort(BlockState s, int layer, RandomSource r, BlockState carpet, BlockState wallpaper) {
        if (layer == 0) return r.nextInt(100) < 75 ? carpet : s;
        if (r.nextInt(100) < 3) return null;
        if (s.getBlock() instanceof LeavesBlock) {
            if (s.hasProperty(BlockStateProperties.PERSISTENT)) s = s.setValue(BlockStateProperties.PERSISTENT, true);
            return r.nextInt(100) < 50 ? wallpaper : s;
        }
        if (!s.is(BlockTags.LOGS) && s.canOcclude() && r.nextInt(100) < 35) return wallpaper;
        return s;
    }
}
