package com.thecomplex.fragment;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.ArrayList;
import java.util.List;

/** Fragmen yang sudah ditangkap, disimpan di data dunia (Overworld). Penuh = fragmen acak tertua diganti. */
public class FragmentData extends SavedData {
    public static final int MAX = 24;
    private final List<Fragment> list = new ArrayList<>();

    public static FragmentData get(ServerLevel overworld) {
        return overworld.getDataStorage().computeIfAbsent(FragmentData::load, FragmentData::new, "thecomplex_fragments");
    }

    public List<Fragment> all() {
        return List.copyOf(list);
    }

    public void add(Fragment f, RandomSource r) {
        if (list.size() >= MAX) list.remove(r.nextInt(list.size()));
        list.add(f);
        setDirty();
        FragmentStore.set(list);
    }

    public void clear() {
        list.clear();
        setDirty();
        FragmentStore.set(list);
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag out = new ListTag();
        for (Fragment f : list) out.add(f.toTag());
        tag.put("fragments", out);
        return tag;
    }

    public static FragmentData load(CompoundTag tag) {
        FragmentData d = new FragmentData();
        ListTag in = tag.getList("fragments", Tag.TAG_COMPOUND);
        for (int i = 0; i < in.size(); i++) {
            Fragment f = Fragment.fromTag(in.getCompound(i));
            if (f != null) d.list.add(f);
        }
        return d;
    }
}
