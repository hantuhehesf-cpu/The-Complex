package com.thecomplex.fragment;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.Tag;
import net.minecraft.world.level.block.state.BlockState;

/** Potongan kecil Overworld (maksimal 12 x 9 x 12) yang dibawa The Complex sebagai "ingatan". Tidak bisa diubah setelah dibuat. */
public final class Fragment {
    public final String kind;
    public final int width;    // X
    public final int height;   // Y (lapisan 0 = lantai)
    public final int length;   // Z
    private final BlockState[] palette;
    private final int[] data;  // indeks = (y * length + z) * width + x

    public Fragment(String kind, int w, int h, int l, BlockState[] palette, int[] data) {
        this.kind = kind;
        this.width = w;
        this.height = h;
        this.length = l;
        this.palette = palette;
        this.data = data;
    }

    public BlockState get(int x, int y, int z) {
        return palette[data[(y * length + z) * width + x]];
    }

    public CompoundTag toTag() {
        CompoundTag t = new CompoundTag();
        t.putString("kind", kind);
        t.putInt("w", width);
        t.putInt("h", height);
        t.putInt("l", length);
        ListTag pal = new ListTag();
        for (BlockState s : palette) pal.add(NbtUtils.writeBlockState(s));
        t.put("palette", pal);
        t.putIntArray("data", data);
        return t;
    }

    public static Fragment fromTag(CompoundTag t) {
        int w = t.getInt("w"), h = t.getInt("h"), l = t.getInt("l");
        int[] data = t.getIntArray("data");
        ListTag pal = t.getList("palette", Tag.TAG_COMPOUND);
        if (w <= 0 || h <= 0 || l <= 0 || data.length != w * h * l || pal.isEmpty()) return null;
        BlockState[] palette = new BlockState[pal.size()];
        for (int i = 0; i < palette.length; i++) {
            palette[i] = NbtUtils.readBlockState(BuiltInRegistries.BLOCK.asLookup(), pal.getCompound(i));
        }
        for (int v : data) if (v < 0 || v >= palette.length) return null;
        return new Fragment(t.getString("kind"), w, h, l, palette, data);
    }
}
