package com.thecomplex.fragment;

import com.thecomplex.activity.NullZoneSpawner;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.StructurePiece;
import net.minecraft.world.level.levelgen.structure.StructureStart;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Menangkap potongan kecil Overworld (di thread server) untuk dipakai sebagai fragmen di The Complex. */
public final class FragmentCapture {
    public static final int MAX_XZ = 12;
    public static final int MAX_Y = 9;

    private FragmentCapture() {}

    public static Fragment captureBox(ServerLevel level, BlockPos min, int w, int h, int l, String kind) {
        w = Math.max(1, Math.min(w, MAX_XZ));
        h = Math.max(1, Math.min(h, MAX_Y));
        l = Math.max(1, Math.min(l, MAX_XZ));
        Map<BlockState, Integer> ids = new HashMap<>();
        List<BlockState> palette = new ArrayList<>();
        int[] data = new int[w * h * l];
        int solid = 0;
        BlockState air = Blocks.AIR.defaultBlockState();
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int y = 0; y < h; y++) {
            for (int z = 0; z < l; z++) {
                for (int x = 0; x < w; x++) {
                    m.set(min.getX() + x, min.getY() + y, min.getZ() + z);
                    BlockState s = level.hasChunkAt(m) ? level.getBlockState(m) : air;
                    if (s.hasBlockEntity() || !s.getFluidState().isEmpty() || s.is(Blocks.BEDROCK)) s = air;
                    if (!s.isAir()) solid++;
                    Integer id = ids.get(s);
                    if (id == null) {
                        id = palette.size();
                        ids.put(s, id);
                        palette.add(s);
                    }
                    data[(y * l + z) * w + x] = id;
                }
            }
        }
        if (solid < w * h * l * 0.06) return null;     // hampir kosong, tidak menarik
        return new Fragment(kind, w, h, l, palette.toArray(new BlockState[0]), data);
    }

    /** Bangunan: lapisan 0 = blok lantai di bawah sel udara yang diberikan. */
    public static Fragment captureBuilding(ServerLevel level, BlockPos floorAir) {
        return captureBox(level, floorAir.offset(-6, -1, -6), MAX_XZ, MAX_Y, MAX_XZ, "building");
    }

    /** Pohon: cari batang pohon dalam radius 16 dari titik asal. */
    public static Fragment captureTree(ServerLevel level, BlockPos near, RandomSource r) {
        for (int i = 0; i < 80; i++) {
            int x = near.getX() + r.nextInt(33) - 16;
            int z = near.getZ() + r.nextInt(33) - 16;
            if (!level.hasChunkAt(new BlockPos(x, near.getY(), z))) continue;
            int top = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
            BlockPos p = new BlockPos(x, top - 1, z);
            if (!level.getBlockState(p).is(BlockTags.LOGS)) continue;
            while (level.getBlockState(p.below()).is(BlockTags.LOGS)) p = p.below();
            return captureBox(level, new BlockPos(x - 6, p.getY() - 1, z - 6), MAX_XZ, MAX_Y, MAX_XZ, "tree");
        }
        return null;
    }

    /** Potongan struktur vanilla (rumah desa, reruntuhan, dll.) di chunk yang sedang dimuat dekat titik asal. */
    public static Fragment captureStructure(ServerLevel level, BlockPos near, RandomSource r) {
        ChunkPos c0 = new ChunkPos(near);
        List<BoundingBox> boxes = new ArrayList<>();
        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                ChunkPos cp = new ChunkPos(c0.x + dx, c0.z + dz);
                if (!level.hasChunk(cp.x, cp.z)) continue;
                try {
                    for (StructureStart start : level.structureManager().startsForStructure(cp, s -> true)) {
                        for (StructurePiece piece : start.getPieces()) {
                            BoundingBox b = piece.getBoundingBox();
                            if (b.getXSpan() >= 5 && b.getZSpan() >= 5 && b.getYSpan() >= 3
                                    && b.getXSpan() <= 24 && b.getZSpan() <= 24) boxes.add(b);
                        }
                    }
                } catch (Exception ignored) {
                    // struktur tidak bisa dibaca di chunk ini; lewati
                }
            }
        }
        if (boxes.isEmpty()) return null;
        BoundingBox b = boxes.get(r.nextInt(boxes.size()));
        return captureBox(level, new BlockPos(b.minX(), b.minY(), b.minZ()),
                Math.min(b.getXSpan(), MAX_XZ), Math.min(b.getYSpan() + 1, MAX_Y), Math.min(b.getZSpan(), MAX_XZ), "structure");
    }

    public static boolean store(ServerLevel anyLevel, Fragment f, RandomSource r) {
        if (f == null) return false;
        FragmentData.get(anyLevel.getServer().overworld()).add(f, r);
        return true;
    }

    /** Tangkap salah satu jenis secara acak di sekitar pemain. Mengembalikan jenisnya, atau null kalau tidak ada yang cocok. */
    public static String captureAuto(ServerPlayer p) {
        ServerLevel level = p.serverLevel();
        RandomSource r = p.getRandom();
        int start = r.nextInt(3);
        for (int i = 0; i < 3; i++) {
            Fragment f;
            switch ((start + i) % 3) {
                case 0 -> {
                    BlockPos floor = NullZoneSpawner.findIndoorFloor(level, p.chunkPosition(), r);
                    f = floor == null ? null : captureBuilding(level, floor);
                }
                case 1 -> f = captureTree(level, p.blockPosition(), r);
                default -> f = captureStructure(level, p.blockPosition(), r);
            }
            if (f != null) {
                store(level, f, r);
                return f.kind;
            }
        }
        return null;
    }
}
