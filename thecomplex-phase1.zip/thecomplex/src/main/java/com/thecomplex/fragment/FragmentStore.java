package com.thecomplex.fragment;

import java.util.List;

/** Daftar fragmen yang boleh dibaca generator dunia (thread worker). Selalu berupa daftar yang tidak bisa diubah. */
public final class FragmentStore {
    private static volatile List<Fragment> list = List.of();

    private FragmentStore() {}

    public static List<Fragment> all() {
        return list;
    }

    public static void set(List<Fragment> fragments) {
        list = List.copyOf(fragments);
    }
}
