package com.thecomplex;

import com.thecomplex.net.Net;
import com.thecomplex.world.ComplexLayout;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;

public final class ComplexTeleporter {
    private static final String CD = "complex_tp_cd";
    private static final String RET_SET = "complex_ret_set";
    private static final String RET_DIM = "complex_ret_dim";

    private ComplexTeleporter() {}

    public static boolean onCooldown(ServerPlayer p) {
        return p.tickCount < p.getPersistentData().getInt(CD);
    }

    private static void startCooldown(ServerPlayer p) {
        p.getPersistentData().putInt(CD, p.tickCount + 60);
    }

    /** Ingat dari mana pemain masuk, supaya Threshold di dalam The Complex bisa mengantar pulang. */
    private static void rememberReturn(ServerPlayer p) {
        if (p.level().dimension() == TheComplex.COMPLEX) return;
        CompoundTag d = p.getPersistentData();
        d.putBoolean(RET_SET, true);
        d.putString(RET_DIM, p.level().dimension().location().toString());
        d.putInt("complex_ret_x", p.getBlockX());
        d.putInt("complex_ret_y", p.getBlockY());
        d.putInt("complex_ret_z", p.getBlockZ());
    }

    /** Lewat Threshold stabil: tiba di Main Chamber, di dekat Threshold-nya, menghadap isi ruangan. */
    public static void toArrival(ServerPlayer p) {
        ServerLevel lvl = p.server.getLevel(TheComplex.COMPLEX);
        if (lvl == null) return;
        rememberReturn(p);
        BlockPos t = ComplexLayout.thresholdPos();
        BlockPos base = t != null ? t : new BlockPos(0, ComplexLayout.FLOOR_Y + 1, 0);
        lvl.getChunk(base.getX() >> 4, base.getZ() >> 4);
        BlockPos spot = safeSpotNear(lvl, base, t != null ? 2 : 0);
        p.teleportTo(lvl, spot.getX() + 0.5, spot.getY(), spot.getZ() + 0.5, yawToward(spot, ComplexLayout.chamberCenterX(), ComplexLayout.chamberCenterZ()), 0f);
        startCooldown(p);
        Net.sendQuakeTo(p, 40, 1.4f);
    }

    public static float yawToward(BlockPos from, double tx, double tz) {
        double dx = tx - (from.getX() + 0.5), dz = tz - (from.getZ() + 0.5);
        if (dx * dx + dz * dz < 0.25) return 0f;
        return (float) Math.toDegrees(Math.atan2(-dx, dz));
    }

    /** Lewat Null Zone liar: jatuh ke Backrooms prosedural, jauh dari Main Chamber. */
    public static void toBackrooms(ServerPlayer p) {
        ServerLevel lvl = p.server.getLevel(TheComplex.COMPLEX);
        if (lvl == null) return;
        rememberReturn(p);
        RandomSource r = p.getRandom();
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int tries = 0; tries < 16; tries++) {
            int cx = (12 + r.nextInt(30)) * (r.nextBoolean() ? 1 : -1);
            int cz = (12 + r.nextInt(30)) * (r.nextBoolean() ? 1 : -1);
            lvl.getChunk(cx, cz);
            for (int i = 0; i < 64; i++) {
                int x = cx * 16 + r.nextInt(16);
                int z = cz * 16 + r.nextInt(16);
                m.set(x, ComplexLayout.FLOOR_Y + 1, z);
                if (lvl.getBlockState(m).isAir()
                        && lvl.getBlockState(m.above()).isAir()
                        && lvl.getBlockState(m.below()).is(ModBlocks.CARPET_FLOOR.get())) {
                    p.teleportTo(lvl, x + 0.5, ComplexLayout.FLOOR_Y + 1, z + 0.5, r.nextFloat() * 360f, 0f);
                    startCooldown(p);
                    return;
                }
            }
        }
    }

    /** Threshold di dalam The Complex: pulang ke tempat terakhir pemain masuk, atau spawn dunia. */
    public static void returnFromComplex(ServerPlayer p, BlockPos from) {
        CompoundTag d = p.getPersistentData();
        ServerLevel target = null;
        BlockPos base = null;
        if (d.getBoolean(RET_SET)) {
            ResourceLocation id = ResourceLocation.tryParse(d.getString(RET_DIM));
            if (id != null) target = p.server.getLevel(ResourceKey.create(Registries.DIMENSION, id));
            base = new BlockPos(d.getInt("complex_ret_x"), d.getInt("complex_ret_y"), d.getInt("complex_ret_z"));
        }
        if (target == null) {
            target = p.server.overworld();
            base = target.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, target.getSharedSpawnPos());
        }
        BlockPos spot = safeSpotNear(target, base, 0);
        p.teleportTo(target, spot.getX() + 0.5, spot.getY(), spot.getZ() + 0.5, p.getYRot(), 0f);
        startCooldown(p);
    }

    public static void leave(ServerPlayer p) {
        returnFromComplex(p, p.blockPosition());
    }

    /** Tempat berdiri bebas terdekat dari titik asal (minimal radius minR), bukan di dalam Threshold/Null Zone. */
    public static BlockPos safeSpotNear(ServerLevel level, BlockPos base, int minR) {
        BlockPos best = null;
        double bestD = Double.MAX_VALUE;
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int dx = -6; dx <= 6; dx++) {
            for (int dz = -6; dz <= 6; dz++) {
                if (Math.max(Math.abs(dx), Math.abs(dz)) < minR) continue;
                for (int dy = -2; dy <= 2; dy++) {
                    m.set(base.getX() + dx, base.getY() + dy, base.getZ() + dz);
                    BlockPos below = m.below();
                    if (isFree(level, m) && isFree(level, m.above())
                            && level.getBlockState(below).isCollisionShapeFullBlock(level, below)) {
                        double d = dx * dx + dz * dz + dy * dy * 4.0;
                        if (d < bestD) {
                            bestD = d;
                            best = m.immutable();
                        }
                    }
                }
            }
        }
        return best != null ? best : base;
    }

    private static boolean isFree(ServerLevel level, BlockPos pos) {
        BlockState s = level.getBlockState(pos);
        return s.getCollisionShape(level, pos).isEmpty()
                && s.getFluidState().isEmpty()
                && !s.is(ModBlocks.THRESHOLD.get())
                && !s.is(ModBlocks.NULL_ZONE.get());
    }
}
