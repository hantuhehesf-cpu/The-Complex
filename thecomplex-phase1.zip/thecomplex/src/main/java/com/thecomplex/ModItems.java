package com.thecomplex;

import com.thecomplex.dev.DevToolItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, TheComplex.MODID);

    /** Klik kanan untuk membuka panel uji (Developer UI). Hanya untuk OP atau mode kreatif. */
    public static final RegistryObject<Item> DEV_TOOL = ITEMS.register("dev_tool",
            () -> new DevToolItem(new Item.Properties().stacksTo(1)));

    private ModItems() {}
}
