package com.thecomplex.lpmds;

import com.thecomplex.ModItems;
import com.thecomplex.TheComplex;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Vector3f;

/** Selama Magnetic Marker dipegang: garis tepi bingkai (kuning) dan garis ke mesin (biru) ditampilkan sebagai partikel. */
@Mod.EventBusSubscriber(modid = TheComplex.MODID)
public final class LpmdsMarkerEvents {
    private static final DustParticleOptions YELLOW = new DustParticleOptions(new Vector3f(1.0f, 0.85f, 0.2f), 1.0f);
    private static final DustParticleOptions BLUE = new DustParticleOptions(new Vector3f(0.3f, 0.7f, 1.0f), 0.8f);
    private static final DustParticleOptions GREEN = new DustParticleOptions(new Vector3f(0.3f, 1.0f, 0.4f), 1.0f);

    private LpmdsMarkerEvents() {}

    private static ItemStack held(ServerPlayer p) {
        if (p.getMainHandItem().is(ModItems.LPMDS_MARKER.get())) return p.getMainHandItem();
        if (p.getOffhandItem().is(ModItems.LPMDS_MARKER.get())) return p.getOffhandItem();
        return ItemStack.EMPTY;
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p) || p.tickCount % 10 != 0) return;
        ItemStack st = held(p);
        if (st.isEmpty() || !st.hasTag()) return;
        CompoundTag t = st.getTag();
        ServerLevel level = p.serverLevel();

        if (t.contains("p1") && !t.contains("frameMin")) {
            cell(level, p, BlockPos.of(t.getLong("p1")), GREEN);
        }
        if (t.contains("frameMin")) {
            LpmdsFrame f = new LpmdsFrame(BlockPos.of(t.getLong("frameMin")), t.getInt("frameAxis"));
            outline(level, p, f);
            if (t.contains("lpmds")) {
                Vec3 a = Vec3.atCenterOf(BlockPos.of(t.getLong("lpmds")));
                Vec3 b = f.center();
                int n = (int) Math.min(40, a.distanceTo(b));
                for (int i = 1; i < n; i++) {
                    Vec3 q = a.lerp(b, i / (double) n);
                    level.sendParticles(p, BLUE, true, q.x, q.y, q.z, 1, 0, 0, 0, 0);
                }
            }
        }
    }

    private static void cell(ServerLevel level, ServerPlayer p, BlockPos c, DustParticleOptions o) {
        for (int i = 0; i < 6; i++) {
            level.sendParticles(p, o, true, c.getX() + (i % 2), c.getY() + (i / 2) % 2, c.getZ() + (i / 4), 1, 0, 0, 0, 0);
        }
    }

    private static void outline(ServerLevel level, ServerPlayer p, LpmdsFrame f) {
        BlockPos m = f.min();
        double x0 = m.getX(), y0 = m.getY(), z0 = m.getZ();
        double w = 2, h = 3;
        double x1 = f.axis() == 0 ? x0 + w : x0 + 1;
        double z1 = f.axis() == 0 ? z0 + 1 : z0 + w;
        // dua sisi tipis bingkai: gambar tepi persegi panjang pada bidangnya
        for (double s = 0; s <= 1.0001; s += 0.25) {
            double u = f.axis() == 0 ? x0 + w * s : x0 + 0.5;
            double v = f.axis() == 0 ? z0 + 0.5 : z0 + w * s;
            level.sendParticles(p, YELLOW, true, u, y0, v, 1, 0, 0, 0, 0);
            level.sendParticles(p, YELLOW, true, u, y0 + h, v, 1, 0, 0, 0, 0);
        }
        for (double s = 0; s <= h + 0.0001; s += 0.5) {
            double ya = y0 + s;
            if (f.axis() == 0) {
                level.sendParticles(p, YELLOW, true, x0, ya, z0 + 0.5, 1, 0, 0, 0, 0);
                level.sendParticles(p, YELLOW, true, x1, ya, z0 + 0.5, 1, 0, 0, 0, 0);
            } else {
                level.sendParticles(p, YELLOW, true, x0 + 0.5, ya, z0, 1, 0, 0, 0, 0);
                level.sendParticles(p, YELLOW, true, x0 + 0.5, ya, z1, 1, 0, 0, 0, 0);
            }
        }
    }
}
