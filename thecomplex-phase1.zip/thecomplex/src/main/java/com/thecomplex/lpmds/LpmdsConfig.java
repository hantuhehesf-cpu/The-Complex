package com.thecomplex.lpmds;

import net.minecraftforge.common.ForgeConfigSpec;

/** Pengaturan LPMDS. File: config/thecomplex-common.toml (bisa diubah tanpa build ulang). */
public final class LpmdsConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue REQUIRE_POWER;
    public static final ForgeConfigSpec.IntValue CAPACITY;
    public static final ForgeConfigSpec.IntValue MAX_RECEIVE;
    public static final ForgeConfigSpec.IntValue TEST_COST;
    public static final ForgeConfigSpec.IntValue FINAL_COST;
    public static final ForgeConfigSpec.IntValue FAILED_TESTS;
    public static final ForgeConfigSpec.IntValue COOLDOWN;
    public static final ForgeConfigSpec.IntValue RANGE;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.comment("LPMDS (Low-Proximity Magnetic Distortion System)").push("lpmds");
        REQUIRE_POWER = b.comment("Butuh daya Forge Energy (FE) dari Create: Power Grid atau mod lain. false = mesin jalan tanpa daya (untuk uji).")
                .define("requirePower", true);
        CAPACITY = b.comment("Kapasitas penyimpanan daya mesin (FE).")
                .defineInRange("capacity", 200000, 1000, 100000000);
        MAX_RECEIVE = b.comment("Daya maksimum yang diterima mesin per tick (FE).")
                .defineInRange("maxReceivePerTick", 5000, 1, 1000000);
        TEST_COST = b.comment("Daya yang dipakai satu tes yang gagal (FE).")
                .defineInRange("failedTestCost", 30000, 0, 100000000);
        FINAL_COST = b.comment("Daya yang dipakai tes akhir yang berhasil (FE).")
                .defineInRange("finalTestCost", 90000, 0, 100000000);
        FAILED_TESTS = b.comment("Jumlah tes yang pasti gagal sebelum tes berikutnya boleh berhasil.")
                .defineInRange("scriptedFailures", 3, 0, 12);
        COOLDOWN = b.comment("Pendinginan setelah tes gagal (tick, 20 tick = 1 detik).")
                .defineInRange("cooldownTicks", 160, 20, 12000);
        RANGE = b.comment("Jarak maksimum mesin ke bingkai target (blok).")
                .defineInRange("range", 24, 4, 64);
        b.pop();
        SPEC = b.build();
    }

    private LpmdsConfig() {}
}
