package com.thecomplex.lpmds;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * Bingkai target 2 lebar x 3 tinggi x 1 tebal.
 * axis 0 = lebar 2 searah sumbu X; axis 1 = lebar 2 searah sumbu Z. min = sudut dengan koordinat terkecil.
 */
public record LpmdsFrame(BlockPos min, int axis) {
    /** Dari dua sel sudut berlawanan; null kalau bentuknya bukan 2x3x1. */
    public static LpmdsFrame fromCorners(BlockPos a, BlockPos b) {
        int sx = Math.abs(a.getX() - b.getX()) + 1;
        int sy = Math.abs(a.getY() - b.getY()) + 1;
        int sz = Math.abs(a.getZ() - b.getZ()) + 1;
        if (sy != 3) return null;
        int axis;
        if (sx == 2 && sz == 1) axis = 0;
        else if (sx == 1 && sz == 2) axis = 1;
        else return null;
        return new LpmdsFrame(new BlockPos(Math.min(a.getX(), b.getX()), Math.min(a.getY(), b.getY()),
                Math.min(a.getZ(), b.getZ())), axis);
    }

    public List<BlockPos> cells() {
        List<BlockPos> list = new ArrayList<>(6);
        for (int h = 0; h < 3; h++) {
            for (int w = 0; w < 2; w++) {
                list.add(axis == 0 ? min.offset(w, h, 0) : min.offset(0, h, w));
            }
        }
        return list;
    }

    public Vec3 center() {
        return axis == 0
                ? new Vec3(min.getX() + 1.0, min.getY() + 1.5, min.getZ() + 0.5)
                : new Vec3(min.getX() + 0.5, min.getY() + 1.5, min.getZ() + 1.0);
    }

    public CompoundTag toTag() {
        CompoundTag t = new CompoundTag();
        t.putLong("min", min.asLong());
        t.putInt("axis", axis);
        return t;
    }

    public static LpmdsFrame fromTag(CompoundTag t) {
        return new LpmdsFrame(BlockPos.of(t.getLong("min")), t.getInt("axis") == 1 ? 1 : 0);
    }
}
