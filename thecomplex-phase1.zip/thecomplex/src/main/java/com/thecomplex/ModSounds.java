package com.thecomplex;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, TheComplex.MODID);

    public static final RegistryObject<SoundEvent> FLUORESCENT_HUM = SOUNDS.register("ambient.fluorescent_hum",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(TheComplex.MODID, "ambient.fluorescent_hum")));

    private ModSounds() {}
}
