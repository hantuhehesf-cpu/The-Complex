package com.thecomplex;

import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = TheComplex.MODID)
public final class ServerEvents {
    /** Dicek tiap 10 detik per pemain di Overworld; 1 dari N berarti rata-rata ~30 menit. Ubah sesuka hati. */
    public static final int NULL_ZONE_ONE_IN = 180;

    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("complex").requires(s -> s.hasPermission(2))
                .then(Commands.literal("enter").executes(c -> {
                    ComplexTeleporter.toArrival(c.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("backrooms").executes(c -> {
                    ComplexTeleporter.toBackrooms(c.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("leave").executes(c -> {
                    ComplexTeleporter.leave(c.getSource().getPlayerOrException());
                    return 1;
                })));
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p)) return;
        if (p.level().dimension() != Level.OVERWORLD || p.tickCount % 200 != 0) return;
        if (p.getRandom().nextInt(NULL_ZONE_ONE_IN) != 0) return;
        trySpawnNullZone(p);
    }

    /** Fase 1: acak. Fase 2: bobot berdasarkan tempat pemain paling lama berada. */
    private static void trySpawnNullZone(ServerPlayer p) {
        ServerLevel level = p.serverLevel();
        RandomSource r = p.getRandom();
        BlockState nz = ModBlocks.NULL_ZONE.get().defaultBlockState();
        for (int i = 0; i < 32; i++) {
            double a = r.nextDouble() * Math.PI * 2;
            int d = 5 + r.nextInt(14);
            BlockPos c = p.blockPosition().offset((int) (Math.cos(a) * d), r.nextInt(5) - 1, (int) (Math.sin(a) * d));
            if (!isWall(level, c) || !isWall(level, c.above())) continue;
            boolean exposed = false;
            for (Direction dir : Direction.Plane.HORIZONTAL) {
                if (level.getBlockState(c.relative(dir)).isAir()) exposed = true;
            }
            if (!exposed) continue;
            level.setBlock(c, nz, 3);
            level.setBlock(c.above(), nz, 3);
            return;
        }
    }

    private static boolean isWall(ServerLevel l, BlockPos pos) {
        BlockState s = l.getBlockState(pos);
        return s.isCollisionShapeFullBlock(l, pos) && s.getDestroySpeed(l, pos) >= 0
                && !s.hasBlockEntity() && !s.is(Blocks.BEDROCK);
    }

    private ServerEvents() {}
}
