package com.thecomplex.dev;

import com.thecomplex.ComplexTeleporter;
import com.thecomplex.ModBlocks;
import com.thecomplex.activity.ActivityData;
import com.thecomplex.activity.ActivityTracker;
import com.thecomplex.activity.NullZoneSpawner;
import com.thecomplex.activity.NullZoneTracker;
import com.thecomplex.fragment.Fragment;
import com.thecomplex.fragment.FragmentCapture;
import com.thecomplex.fragment.FragmentData;
import com.thecomplex.fragment.FragmentPlacer;
import com.thecomplex.fragment.FragmentStore;
import com.thecomplex.lpmds.LpmdsBlockEntity;
import com.thecomplex.net.Net;
import com.thecomplex.net.OpenDevPacket;
import com.thecomplex.world.Schem;
import com.thecomplex.world.SchemStore;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Semua tombol di Developer UI berujung di sini (dijalankan di server, setelah dicek izinnya). */
public final class DevActions {
    public static final int ENTER = 0, BACKROOMS = 1, LEAVE = 2, REFRESH = 3,
            NZ_ANY = 4, NZ_FLOOR = 5, NZ_WALL = 6, HEAT_BOOST = 7, HEAT_RESET = 8,
            CAP_BUILDING = 9, CAP_TREE = 10, CAP_STRUCTURE = 11, FRAG_PLACE = 12, FRAG_CLEAR = 13,
            ROOM_PASTE = 14, ROOM_RELOAD = 15,
            ZONE_TP = 16, ZONE_NEAREST = 17, ZONES_CLEAR = 18, TOGGLE_MODE = 19, HEAL = 20,
            LPMDS_CHARGE = 21, LPMDS_SKIP = 22, LPMDS_RESET = 23, LPMDS_OPEN = 24, LPMDS_CLOSE = 25, LPMDS_GIVE = 26, LPMDS_INFO = 27, LPMDS_FLAG = 28;

    private DevActions() {}

    public static boolean allowed(ServerPlayer p) {
        return p.hasPermissions(2) || p.isCreative();
    }

    private static void msg(ServerPlayer p, String text) {
        p.sendSystemMessage(Component.literal("[Complex] " + text));
    }

    public static void handle(ServerPlayer p, int action, String arg) {
        if (!allowed(p)) {
            msg(p, "Hanya untuk OP atau mode kreatif.");
            return;
        }
        ServerLevel ow = p.server.overworld();
        ServerLevel level = p.serverLevel();
        RandomSource r = p.getRandom();
        switch (action) {
            case ENTER -> ComplexTeleporter.toArrival(p);
            case BACKROOMS -> ComplexTeleporter.toBackrooms(p);
            case LEAVE -> ComplexTeleporter.leave(p);
            case NZ_ANY, NZ_FLOOR, NZ_WALL -> {
                int mode = action == NZ_FLOOR ? NullZoneSpawner.MODE_FLOOR
                        : action == NZ_WALL ? NullZoneSpawner.MODE_WALL : NullZoneSpawner.MODE_ANY;
                boolean ok = NullZoneSpawner.spawnFor(p, ActivityData.get(ow), mode);
                msg(p, ok ? "Null Zone dibuat di dekatmu." : "Tidak ada tempat yang cocok. Berdirilah di dalam bangunan beratap.");
            }
            case HEAT_BOOST -> {
                ActivityData.get(ow).boost(p.getUUID(), p.chunkPosition(), 240f);
                msg(p, "Heat chunk ini +240.");
            }
            case HEAT_RESET -> {
                ActivityData.get(ow).clear(p.getUUID());
                msg(p, "Catatan aktivitasmu dihapus.");
            }
            case CAP_BUILDING -> report(p, FragmentCapture.captureBuilding(level, p.blockPosition()), r, "bangunan");
            case CAP_TREE -> report(p, FragmentCapture.captureTree(level, p.blockPosition(), r), r, "pohon");
            case CAP_STRUCTURE -> report(p, FragmentCapture.captureStructure(level, p.blockPosition(), r), r, "struktur");
            case FRAG_PLACE -> placeFragment(p, level, r);
            case FRAG_CLEAR -> {
                FragmentData.get(ow).clear();
                msg(p, "Semua fragmen dihapus.");
            }
            case ROOM_PASTE -> {
                Schem s = SchemStore.find(arg);
                if (s == null) {
                    msg(p, "Ruangan tidak ditemukan: " + arg);
                } else {
                    s.placeInLevel(level, p.blockPosition().below());
                    msg(p, "Ditempel: " + s.name + " (" + s.width + "x" + s.height + "x" + s.length + ")");
                }
            }
            case ROOM_RELOAD -> msg(p, "Dimuat ulang: " + SchemStore.reloadRooms() + " ruangan.");
            case ZONE_TP, ZONE_NEAREST -> {
                NullZoneTracker.Entry en = null;
                if (action == ZONE_NEAREST) {
                    en = NullZoneTracker.nearest(p);
                } else {
                    try {
                        en = NullZoneTracker.find(Long.parseLong(arg));
                    } catch (NumberFormatException ignored) {
                        // id tidak valid
                    }
                }
                if (en == null) {
                    msg(p, "Null Zone tidak ditemukan (mungkin sudah pulih).");
                } else {
                    ServerLevel target = p.server.getLevel(en.dim());
                    if (target == null) {
                        msg(p, "Dimensinya tidak tersedia.");
                    } else {
                        BlockPos spot = ComplexTeleporter.safeSpotNear(target, en.pos(), 2);
                        float yaw = ComplexTeleporter.yawToward(spot, en.pos().getX() + 0.5, en.pos().getZ() + 0.5);
                        p.teleportTo(target, spot.getX() + 0.5, spot.getY(), spot.getZ() + 0.5, yaw, 0f);
                        msg(p, "Teleport dekat Null Zone " + en.kind() + " di " + en.pos().toShortString());
                    }
                }
            }
            case ZONES_CLEAR -> msg(p, NullZoneTracker.clearAll(p.server) + " Null Zone liar dipulihkan.");
            case TOGGLE_MODE -> {
                boolean toCreative = !p.isCreative();
                p.setGameMode(toCreative ? GameType.CREATIVE : GameType.SURVIVAL);
                msg(p, toCreative ? "Mode kreatif." : "Mode survival.");
            }
            case HEAL -> {
                p.setHealth(p.getMaxHealth());
                p.getFoodData().setFoodLevel(20);
                p.getFoodData().setSaturation(20f);
                msg(p, "Nyawa dan lapar dipulihkan.");
            }
            case LPMDS_GIVE -> {
                p.getInventory().add(new ItemStack(ModBlocks.LPMDS.get()));
                p.getInventory().add(new ItemStack(ModBlocks.LPMDS_CHUTE.get()));
                p.getInventory().add(new ItemStack(com.thecomplex.ModItems.LPMDS_MARKER.get()));
                msg(p, "Diberi: LPMDS, Emitter Chute, Magnetic Marker.");
            }
            case LPMDS_CHARGE, LPMDS_SKIP, LPMDS_RESET, LPMDS_OPEN, LPMDS_CLOSE, LPMDS_INFO -> {
                LpmdsBlockEntity be = LpmdsBlockEntity.findNear(level, p.blockPosition(), 10);
                if (be == null) {
                    msg(p, "Tidak ada LPMDS dalam radius 10 blok.");
                } else if (action == LPMDS_CHARGE) {
                    be.devCharge();
                    msg(p, "Daya LPMDS terdekat diisi penuh.");
                } else if (action == LPMDS_SKIP) {
                    be.devSkipTests();
                    msg(p, "Tes gagal dianggap selesai: tes berikutnya adalah tes akhir.");
                } else if (action == LPMDS_RESET) {
                    be.devReset(level);
                    msg(p, "LPMDS terdekat di-reset (tes 0, daya 0, penandaan dihapus).");
                } else if (action == LPMDS_OPEN) {
                    be.devForceOpen(level);
                    msg(p, "Membuka Threshold paksa.");
                } else if (action == LPMDS_CLOSE) {
                    be.closeFrame(level, true);
                    msg(p, "Threshold ditutup.");
                } else {
                    msg(p, be.statusLine(level));
                }
            }
            case LPMDS_FLAG -> {
                ActivityData d = ActivityData.get(ow);
                d.setActivated(!d.isActivated());
                msg(p, "Null Zone alami: " + (d.isActivated() ? "AKTIF (dianggap LPMDS sudah diaktifkan)." : "NONAKTIF (menunggu LPMDS diaktifkan)."));
            }
            default -> { }
        }
        sendOpen(p);
    }

    private static void report(ServerPlayer p, Fragment f, RandomSource r, String what) {
        if (f == null) {
            msg(p, "Tidak ada " + what + " yang cocok di dekatmu.");
            return;
        }
        FragmentCapture.store(p.serverLevel(), f, r);
        msg(p, "Fragmen " + what + " tersimpan (" + f.width + "x" + f.height + "x" + f.length + "). Total: " + FragmentStore.all().size());
    }

    /** Tempel satu fragmen acak di dekatmu, supaya kamu bisa melihat bentuknya (dengan keanehannya). */
    private static void placeFragment(ServerPlayer p, ServerLevel level, RandomSource r) {
        List<Fragment> all = FragmentStore.all();
        if (all.isEmpty()) {
            msg(p, "Belum ada fragmen tersimpan.");
            return;
        }
        Fragment f = all.get(r.nextInt(all.size()));
        BlockPos base = p.blockPosition().below().offset(3, 0, 3);
        BlockState carpet = ModBlocks.CARPET_FLOOR.get().defaultBlockState();
        BlockState wall = ModBlocks.WALLPAPER.get().defaultBlockState();
        FragmentPlacer.transform(f, r.nextInt(4), r, carpet, wall,
                (x, y, z, s) -> level.setBlock(base.offset(x, y, z), s, 2));
        msg(p, "Fragmen " + f.kind + " ditempel di depanmu.");
    }

    public static String status(ServerPlayer p) {
        ActivityData d = ActivityData.get(p.server.overworld());
        float heat = d.heatAt(p.getUUID(), p.chunkPosition());
        long oneIn = Math.round(1.0 / ActivityTracker.chance(heat));
        return "Dimensi: " + p.level().dimension().location() + "\n"
                + SchemStore.mainChamberStatus() + "\n"
                + "Ruangan: " + SchemStore.rooms().size() + " | Fragmen: " + FragmentStore.all().size()
                + " | Null Zone terlacak: " + NullZoneTracker.forPlayer(p).size() + "\n"
                + "Posisi: " + p.blockPosition().toShortString() + " | Null Zone alami: " + (d.isActivated() ? "aktif" : "mati (LPMDS belum aktif)") + "\n"
                + String.format(Locale.ROOT, "Heat chunk ini: %.1f (Null Zone sekitar 1/%d per 10 detik)", heat, oneIn);
    }

    public static void sendOpen(ServerPlayer p) {
        List<String> names = new ArrayList<>();
        for (Schem s : SchemStore.rooms()) names.add(s.name);
        List<String> zones = new ArrayList<>();
        for (NullZoneTracker.Entry e : NullZoneTracker.forPlayer(p)) {
            if (zones.size() >= 6) break;
            zones.add(e.id() + "|" + NullZoneTracker.describe(p, e));
        }
        Net.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), new OpenDevPacket(status(p), names, zones));
    }
}
