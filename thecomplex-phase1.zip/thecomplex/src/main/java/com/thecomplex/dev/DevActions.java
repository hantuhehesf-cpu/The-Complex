package com.thecomplex.dev;

import com.thecomplex.ComplexTeleporter;
import com.thecomplex.ModBlocks;
import com.thecomplex.activity.ActivityData;
import com.thecomplex.activity.ActivityTracker;
import com.thecomplex.activity.NullZoneSpawner;
import com.thecomplex.fragment.Fragment;
import com.thecomplex.fragment.FragmentCapture;
import com.thecomplex.fragment.FragmentData;
import com.thecomplex.fragment.FragmentPlacer;
import com.thecomplex.fragment.FragmentStore;
import com.thecomplex.net.Net;
import com.thecomplex.net.OpenDevPacket;
import com.thecomplex.world.Schem;
import com.thecomplex.world.SchemStore;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Semua tombol di Developer UI berujung di sini (dijalankan di server, setelah dicek izinnya). */
public final class DevActions {
    public static final int ENTER = 0, BACKROOMS = 1, LEAVE = 2, REFRESH = 3,
            NZ_ANY = 4, NZ_FLOOR = 5, NZ_WALL = 6, HEAT_BOOST = 7, HEAT_RESET = 8,
            CAP_BUILDING = 9, CAP_TREE = 10, CAP_STRUCTURE = 11, FRAG_PLACE = 12, FRAG_CLEAR = 13,
            ROOM_PASTE = 14, ROOM_RELOAD = 15;

    private DevActions() {}

    public static boolean allowed(ServerPlayer p) {
        return p.hasPermissions(2) || p.isCreative();
    }

    private static void msg(ServerPlayer p, String text) {
        p.sendSystemMessage(Component.literal("[Complex] " + text));
    }

    public static void handle(ServerPlayer p, int action, String arg) {
        if (!allowed(p)) {
            msg(p, "Hanya untuk OP atau mode kreatif.");
            return;
        }
        ServerLevel ow = p.server.overworld();
        ServerLevel level = p.serverLevel();
        RandomSource r = p.getRandom();
        switch (action) {
            case ENTER -> ComplexTeleporter.toArrival(p);
            case BACKROOMS -> ComplexTeleporter.toBackrooms(p);
            case LEAVE -> ComplexTeleporter.leave(p);
            case NZ_ANY, NZ_FLOOR, NZ_WALL -> {
                int mode = action == NZ_FLOOR ? NullZoneSpawner.MODE_FLOOR
                        : action == NZ_WALL ? NullZoneSpawner.MODE_WALL : NullZoneSpawner.MODE_ANY;
                boolean ok = NullZoneSpawner.spawnFor(p, ActivityData.get(ow), mode);
                msg(p, ok ? "Null Zone dibuat di dekatmu." : "Tidak ada tempat yang cocok. Berdirilah di dalam bangunan beratap.");
            }
            case HEAT_BOOST -> {
                ActivityData.get(ow).boost(p.getUUID(), p.chunkPosition(), 240f);
                msg(p, "Heat chunk ini +240.");
            }
            case HEAT_RESET -> {
                ActivityData.get(ow).clear(p.getUUID());
                msg(p, "Catatan aktivitasmu dihapus.");
            }
            case CAP_BUILDING -> report(p, FragmentCapture.captureBuilding(level, p.blockPosition()), r, "bangunan");
            case CAP_TREE -> report(p, FragmentCapture.captureTree(level, p.blockPosition(), r), r, "pohon");
            case CAP_STRUCTURE -> report(p, FragmentCapture.captureStructure(level, p.blockPosition(), r), r, "struktur");
            case FRAG_PLACE -> placeFragment(p, level, r);
            case FRAG_CLEAR -> {
                FragmentData.get(ow).clear();
                msg(p, "Semua fragmen dihapus.");
            }
            case ROOM_PASTE -> {
                Schem s = SchemStore.find(arg);
                if (s == null) {
                    msg(p, "Ruangan tidak ditemukan: " + arg);
                } else {
                    s.placeInLevel(level, p.blockPosition().below());
                    msg(p, "Ditempel: " + s.name + " (" + s.width + "x" + s.height + "x" + s.length + ")");
                }
            }
            case ROOM_RELOAD -> msg(p, "Dimuat ulang: " + SchemStore.reloadRooms() + " ruangan.");
            default -> { }
        }
        sendOpen(p);
    }

    private static void report(ServerPlayer p, Fragment f, RandomSource r, String what) {
        if (f == null) {
            msg(p, "Tidak ada " + what + " yang cocok di dekatmu.");
            return;
        }
        FragmentCapture.store(p.serverLevel(), f, r);
        msg(p, "Fragmen " + what + " tersimpan (" + f.width + "x" + f.height + "x" + f.length + "). Total: " + FragmentStore.all().size());
    }

    /** Tempel satu fragmen acak di dekatmu, supaya kamu bisa melihat bentuknya (dengan keanehannya). */
    private static void placeFragment(ServerPlayer p, ServerLevel level, RandomSource r) {
        List<Fragment> all = FragmentStore.all();
        if (all.isEmpty()) {
            msg(p, "Belum ada fragmen tersimpan.");
            return;
        }
        Fragment f = all.get(r.nextInt(all.size()));
        BlockPos base = p.blockPosition().below().offset(3, 0, 3);
        BlockState carpet = ModBlocks.CARPET_FLOOR.get().defaultBlockState();
        BlockState wall = ModBlocks.WALLPAPER.get().defaultBlockState();
        FragmentPlacer.transform(f, r.nextInt(4), r, carpet, wall,
                (x, y, z, s) -> level.setBlock(base.offset(x, y, z), s, 2));
        msg(p, "Fragmen " + f.kind + " ditempel di depanmu.");
    }

    public static String status(ServerPlayer p) {
        ActivityData d = ActivityData.get(p.server.overworld());
        float heat = d.heatAt(p.getUUID(), p.chunkPosition());
        long oneIn = Math.round(1.0 / ActivityTracker.chance(heat));
        return "Dimensi: " + p.level().dimension().location() + "\n"
                + SchemStore.mainChamberStatus() + "\n"
                + "Ruangan: " + SchemStore.rooms().size() + " | Fragmen: " + FragmentStore.all().size() + "\n"
                + String.format(Locale.ROOT, "Heat chunk ini: %.1f (Null Zone sekitar 1/%d per 10 detik)", heat, oneIn);
    }

    public static void sendOpen(ServerPlayer p) {
        List<String> names = new ArrayList<>();
        for (Schem s : SchemStore.rooms()) names.add(s.name);
        Net.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), new OpenDevPacket(status(p), names));
    }
}
