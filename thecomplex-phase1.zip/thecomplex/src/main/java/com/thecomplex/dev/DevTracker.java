package com.thecomplex.dev;

import com.thecomplex.ModItems;
import com.thecomplex.TheComplex;
import com.thecomplex.activity.NullZoneTracker;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.List;

/**
 * Selama pemain memegang Complex Dev Tool: kompas Null Zone terdekat di action bar,
 * dan percikan cahaya di sel udara yang menempel pada Null Zone dalam radius 40 blok.
 */
@Mod.EventBusSubscriber(modid = TheComplex.MODID)
public final class DevTracker {
    private static final double SHOW_RADIUS_SQ = 40.0 * 40.0;

    private DevTracker() {}

    private static boolean holdsTool(ServerPlayer p) {
        return p.getMainHandItem().is(ModItems.DEV_TOOL.get()) || p.getOffhandItem().is(ModItems.DEV_TOOL.get());
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p)) return;
        if (p.tickCount % 10 != 0 || !holdsTool(p) || !DevActions.allowed(p)) return;

        List<NullZoneTracker.Entry> list = NullZoneTracker.forPlayer(p);
        if (list.isEmpty()) {
            p.displayClientMessage(Component.literal("Null Zone: belum ada yang tercatat"), true);
            return;
        }
        p.displayClientMessage(Component.literal("Null Zone terdekat: " + NullZoneTracker.describe(p, list.get(0))), true);

        ServerLevel level = p.serverLevel();
        for (NullZoneTracker.Entry en : list) {
            if (NullZoneTracker.distSq(p, en) > SHOW_RADIUS_SQ) continue;
            for (Direction d : Direction.values()) {
                BlockPos n = en.pos().relative(d);
                if (!level.hasChunkAt(n) || !level.getBlockState(n).isAir()) continue;
                level.sendParticles(p, ParticleTypes.END_ROD, true, n.getX() + 0.5, n.getY() + 0.5, n.getZ() + 0.5,
                        1, 0.25, 0.25, 0.25, 0.0);
            }
        }
    }
}
