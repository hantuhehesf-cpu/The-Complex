package com.thecomplex.world;

import com.thecomplex.TheComplex;
import net.minecraftforge.fml.loading.FMLPaths;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

/**
 * Membaca schematic dari folder config:
 *   config/thecomplex/main_chamber.schem   (opsional, menggantikan Main Chamber placeholder)
 *   config/thecomplex/rooms/*.schem        (ruangan untuk Backrooms prosedural)
 */
public final class SchemStore {
    private static volatile boolean loaded;
    private static volatile Schem mainChamber;
    private static volatile Path mainChamberFile;
    private static volatile List<Schem> rooms = List.of();

    private SchemStore() {}

    public static Path dir() {
        return FMLPaths.CONFIGDIR.get().resolve("thecomplex");
    }

    public static synchronized void load() {
        if (loaded) return;
        try {
            Files.createDirectories(dir().resolve("rooms"));
        } catch (IOException e) {
            TheComplex.LOGGER.warn("[thecomplex] tidak bisa membuat folder config: {}", e.toString());
        }
        Path found = findMainChamber();
        mainChamberFile = found;
        mainChamber = readOne(found);
        if (found == null) {
            TheComplex.LOGGER.info("[thecomplex] main_chamber.schem tidak ditemukan di {} maupun config/worldedit/schematics; memakai placeholder", dir());
        }
        rooms = readRooms();
        loaded = true;
    }

    public static Schem mainChamber() {
        if (!loaded) load();
        return mainChamber;
    }

    public static List<Schem> rooms() {
        if (!loaded) load();
        return rooms;
    }

    /** Hanya ruangan; Main Chamber tidak dimuat ulang supaya dunia yang sudah jadi tetap konsisten. */
    public static synchronized int reloadRooms() {
        rooms = readRooms();
        return rooms.size();
    }

    /** Teks status untuk perintah /complex rooms. */
    public static String mainChamberStatus() {
        if (mainChamber() != null) return "main_chamber dimuat dari " + mainChamberFile.getFileName();
        return "main_chamber TIDAK ditemukan; taruh di " + dir().resolve("main_chamber.schem");
    }

    /** Cari file Main Chamber: nama longgar (mainchamber, main_chamber, Main Chamber, main-chamber), huruf besar/kecil bebas. */
    private static Path findMainChamber() {
        Path[] dirs = {dir(), FMLPaths.CONFIGDIR.get().resolve("worldedit").resolve("schematics")};
        for (Path d : dirs) {
            if (!Files.isDirectory(d)) continue;
            try (Stream<Path> files = Files.list(d)) {
                java.util.Optional<Path> hit = files.filter(p -> {
                    String n = p.getFileName().toString().toLowerCase();
                    if (!n.endsWith(".schem")) return false;
                    String base = n.substring(0, n.length() - 6).replaceAll("[ _\\-]", "");
                    return base.equals("mainchamber");
                }).sorted().findFirst();
                if (hit.isPresent()) return hit.get();
            } catch (IOException e) {
                TheComplex.LOGGER.warn("[thecomplex] gagal membaca folder {}: {}", d, e.toString());
            }
        }
        return null;
    }

    public static Schem find(String name) {
        for (Schem s : rooms()) if (s.name.equalsIgnoreCase(name)) return s;
        Schem m = mainChamber();
        return (m != null && name.equalsIgnoreCase("main_chamber")) ? m : null;
    }

    private static Schem readOne(Path file) {
        if (file == null || !Files.isRegularFile(file)) return null;
        try {
            Schem s = Schem.read(file);
            TheComplex.LOGGER.info("[thecomplex] dimuat {} ({}x{}x{})", file.getFileName(), s.width, s.height, s.length);
            return s;
        } catch (Exception e) {
            TheComplex.LOGGER.error("[thecomplex] gagal membaca {}: {}", file.getFileName(), e.toString());
            return null;
        }
    }

    private static List<Schem> readRooms() {
        List<Schem> out = new ArrayList<>();
        Path dir = dir().resolve("rooms");
        if (!Files.isDirectory(dir)) return List.of();
        try (Stream<Path> files = Files.list(dir)) {
            files.filter(p -> p.getFileName().toString().toLowerCase().endsWith(".schem"))
                    .sorted()
                    .forEach(p -> {
                        Schem s = readOne(p);
                        if (s == null) return;
                        if ((s.width + 15) / 16 > ComplexLayout.SLOT || (s.length + 15) / 16 > ComplexLayout.SLOT) {
                            TheComplex.LOGGER.warn("[thecomplex] {} terlalu besar untuk slot {}x{} chunk, dilewati",
                                    s.name, ComplexLayout.SLOT, ComplexLayout.SLOT);
                            return;
                        }
                        out.add(s);
                    });
        } catch (IOException e) {
            TheComplex.LOGGER.warn("[thecomplex] gagal membaca folder rooms: {}", e.toString());
        }
        return List.copyOf(out);
    }
}
