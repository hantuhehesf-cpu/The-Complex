package com.thecomplex.world;

import com.thecomplex.TheComplex;
import net.minecraftforge.fml.loading.FMLPaths;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

/**
 * Membaca schematic dari folder config:
 *   config/thecomplex/main_chamber.schem   (opsional, menggantikan Main Chamber placeholder)
 *   config/thecomplex/rooms/*.schem        (ruangan untuk Backrooms prosedural)
 */
public final class SchemStore {
    private static volatile boolean loaded;
    private static volatile Schem mainChamber;
    private static volatile List<Schem> rooms = List.of();

    private SchemStore() {}

    public static Path dir() {
        return FMLPaths.CONFIGDIR.get().resolve("thecomplex");
    }

    public static synchronized void load() {
        if (loaded) return;
        try {
            Files.createDirectories(dir().resolve("rooms"));
        } catch (IOException e) {
            TheComplex.LOGGER.warn("[thecomplex] tidak bisa membuat folder config: {}", e.toString());
        }
        mainChamber = readOne(dir().resolve("main_chamber.schem"));
        rooms = readRooms();
        loaded = true;
    }

    public static Schem mainChamber() {
        if (!loaded) load();
        return mainChamber;
    }

    public static List<Schem> rooms() {
        if (!loaded) load();
        return rooms;
    }

    /** Hanya ruangan; Main Chamber tidak dimuat ulang supaya dunia yang sudah jadi tetap konsisten. */
    public static synchronized int reloadRooms() {
        rooms = readRooms();
        return rooms.size();
    }

    public static Schem find(String name) {
        for (Schem s : rooms()) if (s.name.equalsIgnoreCase(name)) return s;
        Schem m = mainChamber();
        return (m != null && name.equalsIgnoreCase("main_chamber")) ? m : null;
    }

    private static Schem readOne(Path file) {
        if (!Files.isRegularFile(file)) return null;
        try {
            Schem s = Schem.read(file);
            TheComplex.LOGGER.info("[thecomplex] dimuat {} ({}x{}x{})", file.getFileName(), s.width, s.height, s.length);
            return s;
        } catch (Exception e) {
            TheComplex.LOGGER.error("[thecomplex] gagal membaca {}: {}", file.getFileName(), e.toString());
            return null;
        }
    }

    private static List<Schem> readRooms() {
        List<Schem> out = new ArrayList<>();
        Path dir = dir().resolve("rooms");
        if (!Files.isDirectory(dir)) return List.of();
        try (Stream<Path> files = Files.list(dir)) {
            files.filter(p -> p.getFileName().toString().toLowerCase().endsWith(".schem"))
                    .sorted()
                    .forEach(p -> {
                        Schem s = readOne(p);
                        if (s == null) return;
                        if ((s.width + 15) / 16 > ComplexLayout.SLOT || (s.length + 15) / 16 > ComplexLayout.SLOT) {
                            TheComplex.LOGGER.warn("[thecomplex] {} terlalu besar untuk slot {}x{} chunk, dilewati",
                                    s.name, ComplexLayout.SLOT, ComplexLayout.SLOT);
                            return;
                        }
                        out.add(s);
                    });
        } catch (IOException e) {
            TheComplex.LOGGER.warn("[thecomplex] gagal membaca folder rooms: {}", e.toString());
        }
        return List.copyOf(out);
    }
}
