package com.thecomplex.world;

import com.thecomplex.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;

import java.util.ArrayList;
import java.util.List;

/**
 * Blueprint tetap (sama di setiap dunia) untuk zona wajib:
 *
 *  - Main Chamber : x,z dalam [-48, 47] (chunk -3..2), langit-langit y=21 (udara 4 blok), pilar cruciform
 *  - Threshold permanen (jalan pulang) di dinding selatan, x -1..0, z=47; titik tiba di depannya
 *  - 6 hallway lurus (2 utara, 2 barat, 2 timur), tiap hallway 48 blok, lebar 4, tinggi 3
 *
 * Setelah hallway berakhir, Backrooms prosedural dimulai.
 * Semua pintu memakai offset 6..9 di dalam chunk, sama seperti sel prosedural,
 * jadi ruangan buatanmu nanti bisa memakai standar yang sama.
 */
public final class ComplexLayout {
    public static final int FLOOR_Y = 16;      // lapisan karpet
    public static final int CEIL_Y = 20;       // langit-langit Backrooms (udara y=17..19, tinggi 3 blok)
    public static final int MAIN_CEIL_Y = 21;  // langit-langit Main Chamber (udara y=17..20, tinggi 4 blok)
    public static final int TOP_Y = 31;        // atas dimensi (bedrock di atas langit-langit)

    /** Panjang tiap lengan pilar cruciform di luar pusat 3x3. Lebar lengan = 3. */
    public static final int PILLAR_ARM_LEN = 3;

    public static final double ARRIVAL_X = 0.5;
    public static final double ARRIVAL_Z = 42.5;

    private record Box(int x1, int y1, int z1, int x2, int y2, int z2, BlockState state) {}

    private static final List<Box> BOXES = new ArrayList<>();
    private static volatile boolean built;
    private static BlockState AIR, WALL, CARPET, TILE, LIGHT;

    public static boolean reserved(int cx, int cz) {
        if (cx >= -3 && cx <= 2 && cz >= -3 && cz <= 2) return true;                   // Main Chamber
        if ((cx == -2 || cx == 1) && cz >= -6 && cz <= -4) return true;               // hallway utara
        if ((cz == -2 || cz == 1) && ((cx >= -6 && cx <= -4) || (cx >= 3 && cx <= 5))) return true; // barat/timur
        return false;
    }

    public static void apply(ChunkAccess chunk) {
        if (!built) build();
        int x0 = chunk.getPos().getMinBlockX(), z0 = chunk.getPos().getMinBlockZ();
        int x1 = x0 + 15, z1 = z0 + 15;
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (Box b : BOXES) {
            if (b.x2() < x0 || b.x1() > x1 || b.z2() < z0 || b.z1() > z1) continue;
            int ax = Math.max(b.x1(), x0), bx = Math.min(b.x2(), x1);
            int az = Math.max(b.z1(), z0), bz = Math.min(b.z2(), z1);
            for (int x = ax; x <= bx; x++)
                for (int z = az; z <= bz; z++)
                    for (int y = b.y1(); y <= b.y2(); y++)
                        chunk.setBlockState(p.set(x, y, z), b.state(), false);
        }
    }

    private static void box(int x1, int y1, int z1, int x2, int y2, int z2, BlockState s) {
        BOXES.add(new Box(Math.min(x1, x2), Math.min(y1, y2), Math.min(z1, z2),
                Math.max(x1, x2), Math.max(y1, y2), Math.max(z1, z2), s));
    }

    private static BlockState b(net.minecraft.world.level.block.Block block) {
        return block.defaultBlockState();
    }

    /** Hallway sepanjang sumbu Z, x = sisi kiri (lebar 4). */
    private static void tunnelZ(int x, int z1, int z2) {
        box(x, FLOOR_Y, z1, x + 3, FLOOR_Y, z2, CARPET);
        box(x, FLOOR_Y + 1, z1, x + 3, CEIL_Y - 1, z2, AIR);
        box(x, CEIL_Y, z1, x + 3, CEIL_Y, z2, TILE);
        for (int z = z1 + 4; z < z2 - 2; z += 8) box(x + 1, CEIL_Y, z, x + 2, CEIL_Y, z, LIGHT);
    }

    /** Hallway sepanjang sumbu X, z = sisi atas (lebar 4). */
    private static void tunnelX(int x1, int x2, int z) {
        box(x1, FLOOR_Y, z, x2, FLOOR_Y, z + 3, CARPET);
        box(x1, FLOOR_Y + 1, z, x2, CEIL_Y - 1, z + 3, AIR);
        box(x1, CEIL_Y, z, x2, CEIL_Y, z + 3, TILE);
        for (int x = x1 + 4; x < x2 - 2; x += 8) box(x, CEIL_Y, z + 1, x, CEIL_Y, z + 2, LIGHT);
    }

    private static synchronized void build() {
        if (built) return;
        AIR = Blocks.AIR.defaultBlockState();
        WALL = b(ModBlocks.WALLPAPER.get());
        CARPET = b(ModBlocks.CARPET_FLOOR.get());
        TILE = b(ModBlocks.CEILING_TILE.get());
        LIGHT = b(ModBlocks.FLUORESCENT_PANEL.get());

        // ---------------- Main Chamber ----------------
        box(-47, FLOOR_Y, -47, 46, FLOOR_Y, 46, CARPET);
        box(-47, 17, -47, 46, MAIN_CEIL_Y - 1, 46, AIR);
        box(-47, MAIN_CEIL_Y, -47, 46, MAIN_CEIL_Y, 46, TILE);
        for (int x = -44; x <= 44; x += 8)
            for (int z = -44; z <= 44; z += 8)
                box(x, MAIN_CEIL_Y, z, x + 1, MAIN_CEIL_Y, z, LIGHT);

        // pilar cruciform (placeholder): pusat 3x3, 4 lengan lebar 3 sepanjang PILLAR_ARM_LEN.
        // Pusat di +-16 dan +-32, jadi lorong tengah (x/z -3..2) dan bukaan hallway tetap lapang.
        int[] pc = {-32, -16, 16, 32};
        for (int px : pc) {
            for (int pz : pc) {
                box(px - 1 - PILLAR_ARM_LEN, 17, pz - 1, px + 1 + PILLAR_ARM_LEN, MAIN_CEIL_Y - 1, pz + 1, WALL);
                box(px - 1, 17, pz - 1 - PILLAR_ARM_LEN, px + 1, MAIN_CEIL_Y - 1, pz + 1 + PILLAR_ARM_LEN, WALL);
            }
        }

        // meja maket di tengah (foto 6): meja kayu + kubus kuning sebagai "peta" Backrooms
        BlockState table = b(Blocks.DARK_OAK_PLANKS);
        BlockState yellow = b(Blocks.YELLOW_TERRACOTTA);
        box(-9, 17, -4, 8, 17, 3, table);
        for (int x = -8; x <= 7; x++) {
            for (int z = -3; z <= 2; z++) {
                int h = Math.floorMod((x * 73 + z * 151) ^ (x * z), 9);
                if (h < 3) box(x, 18, z, x, 18, z, yellow);
                if (h == 0) box(x, 19, z, x, 19, z, yellow);
            }
        }

        // ---------------- Hallway keluar (6 buah) ----------------
        for (int c : new int[]{-2, 1}) {
            tunnelZ(c * 16 + 6, -96, -48);      // utara: x -26..-23 dan 22..25
            tunnelX(-96, -48, c * 16 + 6);      // barat: z -26..-23 dan 22..25
            tunnelX(47, 95, c * 16 + 6);        // timur
        }

        // ---------------- Threshold permanen (jalan pulang) ----------------
        // di dinding selatan Main Chamber, tepat di belakang titik tiba
        BlockState iron = b(Blocks.IRON_BLOCK);
        BlockState threshold = b(ModBlocks.THRESHOLD.get());
        box(-2, 17, 47, -2, 20, 47, iron);
        box(1, 17, 47, 1, 20, 47, iron);
        box(-2, 20, 47, 1, 20, 47, iron);
        box(-1, 17, 47, 0, 19, 47, threshold);

        built = true;
    }

    private ComplexLayout() {}
}
