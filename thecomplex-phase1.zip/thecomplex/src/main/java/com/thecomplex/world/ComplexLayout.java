package com.thecomplex.world;

import com.thecomplex.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;

import java.util.ArrayList;
import java.util.List;

/**
 * Blueprint tetap (sama di setiap dunia) untuk zona wajib:
 *
 *  - Main Chamber : x,z dalam [-48, 47] (chunk -3..2), langit-langit y=29
 *  - Ruang industri + gerbang Threshold di sisi selatan: x [-16,15], z [48,79]
 *  - Threshold permanen (jalan pulang) di dinding selatan ruang industri, x -1..0, z=79
 *  - 6 hallway lurus (2 utara, 2 barat, 2 timur), tiap hallway 48 blok, lebar 4, tinggi 5
 *
 * Setelah hallway berakhir, Backrooms prosedural dimulai.
 * Semua pintu memakai offset 6..9 di dalam chunk, sama seperti sel prosedural,
 * jadi ruangan buatanmu nanti bisa memakai standar yang sama.
 */
public final class ComplexLayout {
    public static final int FLOOR_Y = 16;      // lapisan karpet
    public static final int CEIL_Y = 22;       // langit-langit Backrooms (udara y=17..21)
    public static final int MAIN_CEIL_Y = 29;  // langit-langit Main Chamber & ruang industri
    public static final int TOP_Y = 31;        // atas dimensi (bedrock di y=30..31)

    public static final double ARRIVAL_X = 0.5;
    public static final double ARRIVAL_Z = 74.5;

    private record Box(int x1, int y1, int z1, int x2, int y2, int z2, BlockState state) {}

    private static final List<Box> BOXES = new ArrayList<>();
    private static volatile boolean built;
    private static BlockState AIR, WALL, CARPET, TILE, LIGHT;

    public static boolean reserved(int cx, int cz) {
        if (cx >= -3 && cx <= 2 && cz >= -3 && cz <= 2) return true;                   // Main Chamber
        if ((cx == -1 || cx == 0) && (cz == 3 || cz == 4)) return true;               // ruang industri
        if ((cx == -2 || cx == 1) && cz >= -6 && cz <= -4) return true;               // hallway utara
        if ((cz == -2 || cz == 1) && ((cx >= -6 && cx <= -4) || (cx >= 3 && cx <= 5))) return true; // barat/timur
        return false;
    }

    public static void apply(ChunkAccess chunk) {
        if (!built) build();
        int x0 = chunk.getPos().getMinBlockX(), z0 = chunk.getPos().getMinBlockZ();
        int x1 = x0 + 15, z1 = z0 + 15;
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (Box b : BOXES) {
            if (b.x2() < x0 || b.x1() > x1 || b.z2() < z0 || b.z1() > z1) continue;
            int ax = Math.max(b.x1(), x0), bx = Math.min(b.x2(), x1);
            int az = Math.max(b.z1(), z0), bz = Math.min(b.z2(), z1);
            for (int x = ax; x <= bx; x++)
                for (int z = az; z <= bz; z++)
                    for (int y = b.y1(); y <= b.y2(); y++)
                        chunk.setBlockState(p.set(x, y, z), b.state(), false);
        }
    }

    private static void box(int x1, int y1, int z1, int x2, int y2, int z2, BlockState s) {
        BOXES.add(new Box(Math.min(x1, x2), Math.min(y1, y2), Math.min(z1, z2),
                Math.max(x1, x2), Math.max(y1, y2), Math.max(z1, z2), s));
    }

    private static BlockState b(net.minecraft.world.level.block.Block block) {
        return block.defaultBlockState();
    }

    /** Hallway sepanjang sumbu Z, x = sisi kiri (lebar 4). */
    private static void tunnelZ(int x, int z1, int z2) {
        box(x, FLOOR_Y, z1, x + 3, FLOOR_Y, z2, CARPET);
        box(x, FLOOR_Y + 1, z1, x + 3, CEIL_Y - 1, z2, AIR);
        box(x, CEIL_Y, z1, x + 3, CEIL_Y, z2, TILE);
        for (int z = z1 + 4; z < z2 - 2; z += 8) box(x + 1, CEIL_Y, z, x + 2, CEIL_Y, z, LIGHT);
    }

    /** Hallway sepanjang sumbu X, z = sisi atas (lebar 4). */
    private static void tunnelX(int x1, int x2, int z) {
        box(x1, FLOOR_Y, z, x2, FLOOR_Y, z + 3, CARPET);
        box(x1, FLOOR_Y + 1, z, x2, CEIL_Y - 1, z + 3, AIR);
        box(x1, CEIL_Y, z, x2, CEIL_Y, z + 3, TILE);
        for (int x = x1 + 4; x < x2 - 2; x += 8) box(x, CEIL_Y, z + 1, x, CEIL_Y, z + 2, LIGHT);
    }

    private static synchronized void build() {
        if (built) return;
        AIR = Blocks.AIR.defaultBlockState();
        WALL = b(ModBlocks.WALLPAPER.get());
        CARPET = b(ModBlocks.CARPET_FLOOR.get());
        TILE = b(ModBlocks.CEILING_TILE.get());
        LIGHT = b(ModBlocks.FLUORESCENT_PANEL.get());

        // ---------------- Main Chamber ----------------
        box(-47, FLOOR_Y, -47, 46, FLOOR_Y, 46, CARPET);
        box(-47, 17, -47, 46, 28, 46, AIR);
        box(-47, MAIN_CEIL_Y, -47, 46, MAIN_CEIL_Y, 46, TILE);
        for (int x = -44; x <= 44; x += 8)
            for (int z = -44; z <= 44; z += 8)
                box(x, MAIN_CEIL_Y, z, x + 1, MAIN_CEIL_Y, z, LIGHT);

        // pilar besar 4x4 (foto 1), jalur tengah x -3..2 dibiarkan kosong supaya terlihat dari gerbang
        int[] pc = {-32, -16, 16, 32};
        for (int cx : pc)
            for (int cz : pc)
                box(cx - 2, 17, cz - 2, cx + 1, 28, cz + 1, WALL);

        // meja maket di tengah (foto 6): meja kayu + kubus kuning sebagai "peta" Backrooms
        BlockState table = b(Blocks.DARK_OAK_PLANKS);
        BlockState yellow = b(Blocks.YELLOW_TERRACOTTA);
        box(-9, 17, -4, 8, 17, 3, table);
        for (int x = -8; x <= 7; x++) {
            for (int z = -3; z <= 2; z++) {
                int h = Math.floorMod((x * 73 + z * 151) ^ (x * z), 9);
                if (h < 3) box(x, 18, z, x, 18, z, yellow);
                if (h == 0) box(x, 19, z, x, 19, z, yellow);
            }
        }

        // ---------------- Hallway keluar (6 buah) ----------------
        for (int c : new int[]{-2, 1}) {
            tunnelZ(c * 16 + 6, -96, -48);      // utara: x -26..-23 dan 22..25
            tunnelX(-96, -48, c * 16 + 6);      // barat: z -26..-23 dan 22..25
            tunnelX(47, 95, c * 16 + 6);        // timur
        }

        // ---------------- Ruang industri di balik Threshold ----------------
        BlockState bricks = b(Blocks.BRICKS);
        BlockState gray = b(Blocks.GRAY_CONCRETE);
        BlockState iron = b(Blocks.IRON_BLOCK);
        BlockState tiles = b(Blocks.DEEPSLATE_TILES);
        BlockState dBricks = b(Blocks.DEEPSLATE_BRICKS);
        BlockState andesite = b(Blocks.POLISHED_ANDESITE);
        BlockState panel = b(Blocks.POLISHED_BLACKSTONE_BRICKS);
        BlockState lantern = b(Blocks.SEA_LANTERN);

        box(-16, FLOOR_Y, 48, 15, MAIN_CEIL_Y, 79, bricks);                // cangkang
        box(-16, 17, 48, -16, 21, 79, gray);                               // pita beton bawah
        box(15, 17, 48, 15, 21, 79, gray);
        box(-16, 17, 79, 15, 21, 79, gray);
        box(-15, 17, 48, 14, 28, 78, AIR);                                 // interior
        box(-15, FLOOR_Y, 48, 14, FLOOR_Y, 78, tiles);
        box(-15, MAIN_CEIL_Y, 48, 14, MAIN_CEIL_Y, 78, dBricks);
        box(0, FLOOR_Y, 52, 0, FLOOR_Y, 78, b(Blocks.RED_TERRACOTTA));    // garis merah di lantai (foto 5)

        // gerbang Threshold (foto 5): dinding beton tebal 3, bukaan 6x10, tiang besi di kedua sisi
        box(-12, 17, 48, 11, 28, 50, gray);
        box(-3, 17, 48, 2, 26, 50, AIR);
        box(-5, 17, 48, -4, 28, 50, iron);
        box(3, 17, 48, 4, 28, 50, iron);
        box(-11, 22, 48, -7, 27, 50, panel);
        box(6, 22, 48, 10, 27, 50, panel);
        // bukaan menembus dinding selatan Main Chamber (z=47)
        box(-3, FLOOR_Y, 47, 2, FLOOR_Y, 47, CARPET);
        box(-3, 17, 47, 2, 26, 47, AIR);

        // pipa, girder, lampu
        for (int z = 52; z <= 76; z += 8) {
            box(-14, 17, z, -14, 28, z, iron);
            box(13, 17, z, 13, 28, z, iron);
        }
        for (int z = 56; z <= 72; z += 8) box(-15, 28, z, 14, 28, z, andesite);
        for (int x : new int[]{-9, 0, 9})
            for (int z : new int[]{56, 64, 72})
                box(x, MAIN_CEIL_Y, z, x, MAIN_CEIL_Y, z, lantern);

        // Threshold permanen sebagai jalan pulang: di dinding selatan, di belakang titik tiba
        BlockState threshold = b(ModBlocks.THRESHOLD.get());
        box(-2, 17, 79, -2, 20, 79, iron);
        box(1, 17, 79, 1, 20, 79, iron);
        box(-2, 20, 79, 1, 20, 79, iron);
        box(-1, 17, 79, 0, 19, 79, threshold);

        built = true;
    }

    private ComplexLayout() {}
}
