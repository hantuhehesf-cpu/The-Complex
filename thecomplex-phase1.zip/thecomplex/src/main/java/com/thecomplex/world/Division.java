package com.thecomplex.world;

import net.minecraft.util.RandomSource;
import net.minecraft.world.level.levelgen.PositionalRandomFactory;

/**
 * Divisi: wilayah besar (REGION x REGION chunk) dengan "karakter" sendiri, seperti biome tetapi untuk Backrooms.
 * Satu divisi punya tinggi udara tetap (3 atau 4 blok), pola ruangan khas, tingkat kegelapan, dan peluang fragmen.
 * Ruangan .schem bisa dibatasi ke divisi tertentu lewat nama file: namaruangan@CD.schem (hanya di divisi C dan D).
 */
public final class Division {
    /** Ukuran wilayah satu divisi, dalam chunk. Harus kelipatan ComplexLayout.SLOT. */
    public static final int REGION = 8;

    /** Urutan pola: 0 hutan pilar, 1 pilar besar, 2 sekat X, 3 sekat Z, 4 aula kosong, 5 lorong X, 6 lorong Z, 7 dua deret tiang, 8 kamar kecil, 9 dinding L. */
    public static final int PATTERNS = 10;

    public final char id;
    public final String name;
    public final int weight;          // bobot kemunculan wilayah (total 100)
    public final int air;             // tinggi udara (blok)
    public final int[] patterns;      // bobot pola (total 100)
    public final int darkChance;      // persen chunk yang gelap total
    public final int deadPanel;       // persen panel lampu mati
    public final int fragmentPermille; // peluang per seribu chunk memuat fragmen Overworld

    private Division(char id, String name, int weight, int air, int[] patterns, int dark, int dead, int frag) {
        this.id = id;
        this.name = name;
        this.weight = weight;
        this.air = air;
        this.patterns = patterns;
        this.darkChance = dark;
        this.deadPanel = dead;
        this.fragmentPermille = frag;
    }

    public static final Division[] ALL = {
            new Division('A', "Standar",   28, 3, new int[]{22, 10, 12, 12,  8,  8,  8,  6,  8,  6},  8, 15,  3),
            new Division('B', "Aula",      16, 4, new int[]{14, 16,  4,  4, 30,  3,  3, 12,  4, 10},  6, 12,  3),
            new Division('C', "Labirin",   16, 3, new int[]{ 4,  2, 18, 18,  2, 16, 16,  4, 14,  6}, 10, 18,  3),
            new Division('D', "Gelap",     12, 3, new int[]{20,  8, 10, 10,  8,  8,  8,  8, 10, 10}, 40, 45,  5),
            new Division('E', "Tinggi",    12, 4, new int[]{26, 10,  4,  4, 16,  4,  4, 22,  4,  6},  8, 15,  3),
            new Division('F', "Kenangan",  16, 4, new int[]{ 6,  6,  6,  6, 50,  4,  4,  6,  6,  6}, 15, 20, 60),
    };

    public static Division byId(char c) {
        for (Division d : ALL) if (d.id == Character.toUpperCase(c)) return d;
        return null;
    }

    /** Divisi untuk chunk (cx, cz). Sama untuk seluruh wilayah REGION x REGION chunk. */
    public static Division at(PositionalRandomFactory f, int cx, int cz) {
        RandomSource r = f.at(Math.floorDiv(cx, REGION), 11, Math.floorDiv(cz, REGION));
        int roll = r.nextInt(100);
        for (Division d : ALL) {
            roll -= d.weight;
            if (roll < 0) return d;
        }
        return ALL[0];
    }

    /** Pilih indeks pola dari bobot divisi ini (roll 0..99). */
    public int pickPattern(int roll) {
        for (int i = 0; i < patterns.length; i++) {
            roll -= patterns[i];
            if (roll < 0) return i;
        }
        return 4;
    }
}
