package com.thecomplex.world;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.thecomplex.ModBlocks;
import com.thecomplex.TheComplex;
import com.thecomplex.fragment.Fragment;
import com.thecomplex.fragment.FragmentPlacer;
import com.thecomplex.fragment.FragmentStore;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.WorldGenRegion;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.LevelHeightAccessor;
import net.minecraft.world.level.NoiseColumn;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.biome.BiomeManager;
import net.minecraft.world.level.biome.BiomeSource;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.PositionalRandomFactory;
import net.minecraft.world.level.levelgen.RandomState;
import net.minecraft.world.level.levelgen.blending.Blender;

import java.util.EnumSet;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

import static com.thecomplex.world.ComplexLayout.*;

/**
 * Generator tanpa noise. Setiap chunk = satu sel 16x16.
 * Chunk memiliki sisi barat (x lokal 0) dan utara (z lokal 0) miliknya sendiri,
 * jadi tidak ada ketergantungan antar-chunk (tanpa state, aman untuk multithread).
 *
 * Status sisi: 0 = tembok, 1 = pintu selebar 4 di offset 6..9, 2 = terbuka penuh (aula besar).
 * Tinggi udara 3 sampai 6 blok, sama di seluruh slot SLOT x SLOT chunk.
 */
public class ComplexChunkGenerator extends ChunkGenerator {
    public static final Codec<ComplexChunkGenerator> CODEC = RecordCodecBuilder.create(i -> i.group(
            BiomeSource.CODEC.fieldOf("biome_source").forGetter(g -> g.biomeSource)
    ).apply(i, i.stable(ComplexChunkGenerator::new)));

    private static final ResourceLocation LAYOUT = new ResourceLocation(TheComplex.MODID, "layout");

    private final BlockState bedrock = Blocks.BEDROCK.defaultBlockState();
    private final BlockState air = Blocks.AIR.defaultBlockState();
    private final BlockState wall = ModBlocks.WALLPAPER.get().defaultBlockState();
    private final BlockState carpet = ModBlocks.CARPET_FLOOR.get().defaultBlockState();
    private final BlockState tile = ModBlocks.CEILING_TILE.get().defaultBlockState();
    private final BlockState light = ModBlocks.FLUORESCENT_PANEL.get().defaultBlockState();

    public ComplexChunkGenerator(BiomeSource source) {
        super(source);
    }

    @Override
    protected Codec<? extends ChunkGenerator> codec() {
        return CODEC;
    }

    @Override
    public CompletableFuture<ChunkAccess> fillFromNoise(Executor executor, Blender blender, RandomState rs,
                                                        StructureManager sm, ChunkAccess chunk) {
        PositionalRandomFactory f = rs.getOrCreateRandomFactory(LAYOUT);
        int cx = chunk.getPos().x, cz = chunk.getPos().z;
        if (ComplexLayout.reserved(cx, cz)) {
            fillReserved(chunk);
        } else {
            RoomPlacement room = ComplexLayout.roomAt(f, cx, cz);
            Division div = Division.at(f, cx, cz);
            if (room != null) {
                fillRoomChunk(chunk, room, FLOOR_Y + 1 + div.air);
            } else {
                Fragment frag = null;
                List<Fragment> fragments = FragmentStore.all();
                if (!fragments.isEmpty() && f.at(cx, 8, cz).nextInt(1000) < div.fragmentPermille) {
                    frag = fragments.get(f.at(cx, 9, cz).nextInt(fragments.size()));
                }
                fillProcedural(chunk, f, div, frag);
            }
        }
        Heightmap.primeHeightmaps(chunk, EnumSet.of(Heightmap.Types.OCEAN_FLOOR_WG, Heightmap.Types.WORLD_SURFACE_WG));
        return CompletableFuture.completedFuture(chunk);
    }

    // ---------------------------------------------------------------- Main Chamber

    private void fillReserved(ChunkAccess chunk) {
        if (ComplexLayout.hasCustomMainChamber()) {
            // Main Chamber buatanmu: sisa chunk di luar schematic dibiarkan terbuka (bukan blok padat),
            // supaya bukaan di dinding luar langsung tersambung ke Backrooms di sekelilingnya.
            fillOpenBase(chunk, MAIN_CEIL_Y);
            ComplexLayout.apply(chunk);
            return;
        }
        int top = ComplexLayout.reservedTop();
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        int x0 = chunk.getPos().getMinBlockX(), z0 = chunk.getPos().getMinBlockZ();
        for (int lx = 0; lx < 16; lx++) {
            for (int lz = 0; lz < 16; lz++) {
                int x = x0 + lx, z = z0 + lz;
                for (int y = 0; y < FLOOR_Y; y++) chunk.setBlockState(p.set(x, y, z), bedrock, false);
                for (int y = FLOOR_Y; y <= top; y++) chunk.setBlockState(p.set(x, y, z), wall, false);
                for (int y = top + 1; y <= TOP_Y; y++) chunk.setBlockState(p.set(x, y, z), bedrock, false);
            }
        }
        ComplexLayout.apply(chunk);
    }

    // ---------------------------------------------------------------- ruangan buatan (.schem)

    private void fillRoomChunk(ChunkAccess chunk, RoomPlacement rp, int ceilY) {
        fillOpenBase(chunk, ceilY);
        rp.room().placeInChunk(chunk, rp.minCx() * 16, FLOOR_Y, rp.minCz() * 16);
    }

    /** Lantai karpet, atap tile di ceilY, wallpaper di atasnya (bedrock hanya 2 lapisan paling atas dimensi). */
    private void fillOpenBase(ChunkAccess chunk, int ceilY) {
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        int x0 = chunk.getPos().getMinBlockX(), z0 = chunk.getPos().getMinBlockZ();
        for (int lx = 0; lx < 16; lx++) {
            for (int lz = 0; lz < 16; lz++) {
                int x = x0 + lx, z = z0 + lz;
                for (int y = 0; y < FLOOR_Y; y++) chunk.setBlockState(p.set(x, y, z), bedrock, false);
                chunk.setBlockState(p.set(x, FLOOR_Y, z), carpet, false);
                chunk.setBlockState(p.set(x, ceilY, z), tile, false);
                for (int y = ceilY + 1; y <= TOP_Y; y++) chunk.setBlockState(p.set(x, y, z), y >= TOP_Y - 1 ? bedrock : wall, false);
            }
        }
    }

    // ---------------------------------------------------------------- Backrooms prosedural

    private void fillProcedural(ChunkAccess chunk, PositionalRandomFactory f, Division div, Fragment frag) {
        int cx = chunk.getPos().x, cz = chunk.getPos().z;
        int x0 = chunk.getPos().getMinBlockX(), z0 = chunk.getPos().getMinBlockZ();

        int ceilY = FLOOR_Y + 1 + div.air;     // tinggi atap tetap di seluruh divisi, jadi tidak ada loncatan di tengah aula

        boolean[][] w = new boolean[16][16];   // w[lx][lz] = kolom tembok
        int west = edgeState(f, cx, cz, true);
        int north = edgeState(f, cx, cz, false);
        for (int i = 0; i < 16; i++) {
            boolean door = i >= 6 && i <= 9;
            w[0][i] = west == 0 || (west == 1 && !door);
            w[i][0] = north == 0 || (north == 1 && !door);
        }
        w[0][0] = true;   // pilar sudut: selalu ada

        RandomSource r = f.at(cx, 2, cz);
        switch (div.pickPattern(r.nextInt(100))) {
            case 0 -> {                                 // hutan pilar 2x2
                for (int a : new int[]{4, 11}) for (int c : new int[]{4, 11}) fillBox(w, a, c, 2, 2);
            }
            case 1 -> fillBox(w, 6, 6, 4, 4);           // satu pilar besar 4x4
            case 2 -> {                                 // sekat sepanjang X dengan celah 4
                int o = 2 + r.nextInt(9);
                for (int lx = 1; lx < 16; lx++) if (lx < o || lx >= o + 4) w[lx][8] = true;
            }
            case 3 -> {                                 // sekat sepanjang Z dengan celah 4
                int o = 2 + r.nextInt(9);
                for (int lz = 1; lz < 16; lz++) if (lz < o || lz >= o + 4) w[8][lz] = true;
            }
            case 5 -> {                                 // lorong sempit sepanjang X (lebar 4, cocok dengan pintu)
                for (int lx = 1; lx < 16; lx++) { w[lx][5] = true; w[lx][10] = true; }
                int g1 = 1 + r.nextInt(11), g2 = 1 + r.nextInt(11);
                for (int i = 0; i < 4; i++) { w[g1 + i][5] = false; w[g2 + i][10] = false; }
            }
            case 6 -> {                                 // lorong sempit sepanjang Z
                for (int lz = 1; lz < 16; lz++) { w[5][lz] = true; w[10][lz] = true; }
                int g1 = 1 + r.nextInt(11), g2 = 1 + r.nextInt(11);
                for (int i = 0; i < 4; i++) { w[5][g1 + i] = false; w[10][g2 + i] = false; }
            }
            case 7 -> {                                 // dua deret tiang tipis
                for (int lx : new int[]{2, 5, 8, 11, 14}) { w[lx][4] = true; w[lx][11] = true; }
            }
            case 8 -> {                                 // kamar kecil tertutup dengan satu pintu 2 lebar
                for (int i = 4; i <= 11; i++) { w[i][4] = true; w[i][11] = true; w[4][i] = true; w[11][i] = true; }
                int side = r.nextInt(4), p0 = 5 + r.nextInt(4);
                if (side == 0) { w[p0][4] = false; w[p0 + 1][4] = false; }
                else if (side == 1) { w[p0][11] = false; w[p0 + 1][11] = false; }
                else if (side == 2) { w[4][p0] = false; w[4][p0 + 1] = false; }
                else { w[11][p0] = false; w[11][p0 + 1] = false; }
            }
            case 9 -> {                                 // dinding bentuk L
                for (int lx = 1; lx <= 10; lx++) w[lx][5] = true;
                for (int lz = 5; lz <= 13; lz++) if (lz < 7 || lz > 10) w[10][lz] = true;
            }
            default -> { }                              // 4: aula kosong
        }

        RandomSource lr = f.at(cx, 3, cz);
        boolean dark = lr.nextInt(100) < div.darkChance;  // chunk gelap total (lebih sering di divisi Gelap)
        boolean[][] lit = new boolean[16][16];
        for (int px : new int[]{3, 11}) {
            for (int pz : new int[]{3, 11}) {
                boolean on = lr.nextInt(100) >= div.deadPanel;  // panel mati
                if (on && !dark) { lit[px][pz] = true; lit[px + 1][pz] = true; }
            }
        }

        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (int lx = 0; lx < 16; lx++) {
            for (int lz = 0; lz < 16; lz++) {
                int x = x0 + lx, z = z0 + lz;
                boolean wl = w[lx][lz];
                for (int y = 0; y < FLOOR_Y; y++) chunk.setBlockState(p.set(x, y, z), bedrock, false);
                chunk.setBlockState(p.set(x, FLOOR_Y, z), wl ? wall : carpet, false);
                if (wl) for (int y = FLOOR_Y + 1; y < ceilY; y++) chunk.setBlockState(p.set(x, y, z), wall, false);
                chunk.setBlockState(p.set(x, ceilY, z), lit[lx][lz] ? light : tile, false);
                for (int y = ceilY + 1; y <= TOP_Y; y++) chunk.setBlockState(p.set(x, y, z), y >= TOP_Y - 1 ? bedrock : wall, false);
            }
        }

        if (frag != null) placeFragment(chunk, frag, f.at(cx, 10, cz), ceilY);
    }

    /** Kosongkan bagian tengah chunk, lalu tempel fragmen Overworld (diputar acak dan sedikit "salah"). */
    private void placeFragment(ChunkAccess chunk, Fragment frag, RandomSource r, int ceilY) {
        int rot = r.nextInt(4);
        int sx = FragmentPlacer.sizeX(frag, rot), sz = FragmentPlacer.sizeZ(frag, rot);
        int ox = (16 - sx) / 2, oz = (16 - sz) / 2;
        int x0 = chunk.getPos().getMinBlockX(), z0 = chunk.getPos().getMinBlockZ();
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (int lx = ox; lx < ox + sx; lx++) {
            for (int lz = oz; lz < oz + sz; lz++) {
                chunk.setBlockState(p.set(x0 + lx, FLOOR_Y, z0 + lz), carpet, false);
                for (int y = FLOOR_Y + 1; y < ceilY; y++) chunk.setBlockState(p.set(x0 + lx, y, z0 + lz), air, false);
            }
        }
        FragmentPlacer.transform(frag, rot, r, carpet, wall, (x, y, z, s) -> {
            int wy = FLOOR_Y + y;
            if (wy < ceilY) chunk.setBlockState(new BlockPos(x0 + ox + x, wy, z0 + oz + z), s, false);
        });
    }

    private static void fillBox(boolean[][] w, int x, int z, int sx, int sz) {
        for (int i = x; i < x + sx; i++) for (int j = z; j < z + sz; j++) w[i][j] = true;
    }

    private static int edgeState(PositionalRandomFactory f, int cx, int cz, boolean west) {
        int ncx = west ? cx - 1 : cx;
        int ncz = west ? cz : cz - 1;
        if (ComplexLayout.reserved(ncx, ncz)) {
            // Main Chamber buatanmu: tanpa tembok tambahan, jadi bukaan di dindingmu (di posisi mana pun)
            // langsung tembus ke Backrooms. Placeholder: tertutup.
            return ComplexLayout.hasCustomMainChamber() ? 2 : 0;
        }
        if (ComplexLayout.roomAt(f, ncx, ncz) != null) return 1;         // sebelah ruangan buatan: selalu ada pintu
        int roll = f.at(cx, west ? 0 : 1, cz).nextInt(100);
        int state = roll < 20 ? 2 : roll < 62 ? 1 : 0;
        // batas antar divisi dengan tinggi atap berbeda: tembok atau pintu saja, tidak boleh terbuka penuh
        if (state == 2 && Division.at(f, cx, cz).air != Division.at(f, ncx, ncz).air) state = 1;
        return state;
    }

    // ---------------------------------------------------------------- boilerplate ChunkGenerator

    @Override
    public void applyCarvers(WorldGenRegion region, long seed, RandomState rs, BiomeManager bm,
                             StructureManager sm, ChunkAccess chunk, GenerationStep.Carving step) {}

    @Override
    public void buildSurface(WorldGenRegion region, StructureManager sm, RandomState rs, ChunkAccess chunk) {}

    @Override
    public void spawnOriginalMobs(WorldGenRegion region) {}

    @Override
    public int getGenDepth() {
        return 32;
    }

    @Override
    public int getSeaLevel() {
        return 0;
    }

    @Override
    public int getMinY() {
        return 0;
    }

    @Override
    public int getBaseHeight(int x, int z, Heightmap.Types type, LevelHeightAccessor level, RandomState rs) {
        return FLOOR_Y + 1;
    }

    @Override
    public NoiseColumn getBaseColumn(int x, int z, LevelHeightAccessor level, RandomState rs) {
        return new NoiseColumn(level.getMinBuildHeight(), new BlockState[0]);
    }

    @Override
    public void addDebugScreenInfo(List<String> info, RandomState rs, BlockPos pos) {}
}
