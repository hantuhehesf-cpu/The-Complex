package com.thecomplex.world;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.thecomplex.ModBlocks;
import com.thecomplex.TheComplex;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.WorldGenRegion;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.LevelHeightAccessor;
import net.minecraft.world.level.NoiseColumn;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.biome.BiomeManager;
import net.minecraft.world.level.biome.BiomeSource;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.PositionalRandomFactory;
import net.minecraft.world.level.levelgen.RandomState;
import net.minecraft.world.level.levelgen.blending.Blender;

import java.util.EnumSet;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

import static com.thecomplex.world.ComplexLayout.*;

/**
 * Generator tanpa noise. Setiap chunk = satu sel 16x16.
 * Chunk memiliki sisi barat (x lokal 0) dan utara (z lokal 0) miliknya sendiri,
 * jadi tidak ada ketergantungan antar-chunk (tanpa state, aman untuk multithread).
 *
 * Status sisi: 0 = tembok, 1 = pintu selebar 4 di offset 6..9, 2 = terbuka penuh (aula besar).
 */
public class ComplexChunkGenerator extends ChunkGenerator {
    public static final Codec<ComplexChunkGenerator> CODEC = RecordCodecBuilder.create(i -> i.group(
            BiomeSource.CODEC.fieldOf("biome_source").forGetter(g -> g.biomeSource)
    ).apply(i, i.stable(ComplexChunkGenerator::new)));

    private static final ResourceLocation LAYOUT = new ResourceLocation(TheComplex.MODID, "layout");

    private final BlockState bedrock = Blocks.BEDROCK.defaultBlockState();
    private final BlockState wall = ModBlocks.WALLPAPER.get().defaultBlockState();
    private final BlockState carpet = ModBlocks.CARPET_FLOOR.get().defaultBlockState();
    private final BlockState tile = ModBlocks.CEILING_TILE.get().defaultBlockState();
    private final BlockState light = ModBlocks.FLUORESCENT_PANEL.get().defaultBlockState();

    public ComplexChunkGenerator(BiomeSource source) {
        super(source);
    }

    @Override
    protected Codec<? extends ChunkGenerator> codec() {
        return CODEC;
    }

    @Override
    public CompletableFuture<ChunkAccess> fillFromNoise(Executor executor, Blender blender, RandomState rs,
                                                        StructureManager sm, ChunkAccess chunk) {
        PositionalRandomFactory f = rs.getOrCreateRandomFactory(LAYOUT);
        int cx = chunk.getPos().x, cz = chunk.getPos().z;
        if (ComplexLayout.reserved(cx, cz)) {
            fillReserved(chunk);
        } else {
            RoomPlacement room = ComplexLayout.roomAt(f, cx, cz);
            if (room != null) fillRoomChunk(chunk, room);
            else fillProcedural(chunk, f);
        }
        Heightmap.primeHeightmaps(chunk, EnumSet.of(Heightmap.Types.OCEAN_FLOOR_WG, Heightmap.Types.WORLD_SURFACE_WG));
        return CompletableFuture.completedFuture(chunk);
    }

    // ---------------------------------------------------------------- Main Chamber

    private void fillReserved(ChunkAccess chunk) {
        int top = ComplexLayout.reservedTop();
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        int x0 = chunk.getPos().getMinBlockX(), z0 = chunk.getPos().getMinBlockZ();
        for (int lx = 0; lx < 16; lx++) {
            for (int lz = 0; lz < 16; lz++) {
                int x = x0 + lx, z = z0 + lz;
                for (int y = 0; y < FLOOR_Y; y++) chunk.setBlockState(p.set(x, y, z), bedrock, false);
                for (int y = FLOOR_Y; y <= top; y++) chunk.setBlockState(p.set(x, y, z), wall, false);
                for (int y = top + 1; y <= TOP_Y; y++) chunk.setBlockState(p.set(x, y, z), bedrock, false);
            }
        }
        ComplexLayout.apply(chunk);
    }

    // ---------------------------------------------------------------- ruangan buatan (.schem)

    private void fillRoomChunk(ChunkAccess chunk, RoomPlacement rp) {
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        int x0 = chunk.getPos().getMinBlockX(), z0 = chunk.getPos().getMinBlockZ();
        for (int lx = 0; lx < 16; lx++) {
            for (int lz = 0; lz < 16; lz++) {
                int x = x0 + lx, z = z0 + lz;
                for (int y = 0; y < FLOOR_Y; y++) chunk.setBlockState(p.set(x, y, z), bedrock, false);
                chunk.setBlockState(p.set(x, FLOOR_Y, z), carpet, false);
                chunk.setBlockState(p.set(x, CEIL_Y, z), tile, false);
                for (int y = CEIL_Y + 1; y <= TOP_Y; y++) chunk.setBlockState(p.set(x, y, z), bedrock, false);
            }
        }
        rp.room().placeInChunk(chunk, rp.minCx() * 16, FLOOR_Y, rp.minCz() * 16);
    }

    // ---------------------------------------------------------------- Backrooms prosedural

    private void fillProcedural(ChunkAccess chunk, PositionalRandomFactory f) {
        int cx = chunk.getPos().x, cz = chunk.getPos().z;
        int x0 = chunk.getPos().getMinBlockX(), z0 = chunk.getPos().getMinBlockZ();

        boolean[][] w = new boolean[16][16];   // w[lx][lz] = kolom tembok
        int west = edgeState(f, cx, cz, true);
        int north = edgeState(f, cx, cz, false);
        for (int i = 0; i < 16; i++) {
            boolean door = i >= 6 && i <= 9;
            w[0][i] = west == 0 || (west == 1 && !door);
            w[i][0] = north == 0 || (north == 1 && !door);
        }
        w[0][0] = true;   // pilar sudut: selalu ada

        RandomSource r = f.at(cx, 2, cz);
        int t = r.nextInt(100);
        if (t < 35) {                                   // hutan pilar 2x2
            for (int a : new int[]{4, 11}) for (int c : new int[]{4, 11}) fillBox(w, a, c, 2, 2);
        } else if (t < 55) {                            // satu pilar besar 4x4
            fillBox(w, 6, 6, 4, 4);
        } else if (t < 75) {                            // sekat horizontal dengan celah 4
            int o = 2 + r.nextInt(9);
            for (int lx = 1; lx < 16; lx++) if (lx < o || lx >= o + 4) w[lx][8] = true;
        } else if (t < 90) {                            // sekat vertikal dengan celah 4
            int o = 2 + r.nextInt(9);
            for (int lz = 1; lz < 16; lz++) if (lz < o || lz >= o + 4) w[8][lz] = true;
        }                                               // sisanya: aula kosong

        RandomSource lr = f.at(cx, 3, cz);
        boolean dark = lr.nextInt(100) < 8;             // sesekali satu chunk gelap total
        boolean[][] lit = new boolean[16][16];
        for (int px : new int[]{3, 11}) {
            for (int pz : new int[]{3, 11}) {
                boolean on = lr.nextInt(100) >= 15;     // 15% panel mati
                if (on && !dark) { lit[px][pz] = true; lit[px + 1][pz] = true; }
            }
        }

        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (int lx = 0; lx < 16; lx++) {
            for (int lz = 0; lz < 16; lz++) {
                int x = x0 + lx, z = z0 + lz;
                boolean wl = w[lx][lz];
                for (int y = 0; y < FLOOR_Y; y++) chunk.setBlockState(p.set(x, y, z), bedrock, false);
                chunk.setBlockState(p.set(x, FLOOR_Y, z), wl ? wall : carpet, false);
                if (wl) for (int y = FLOOR_Y + 1; y < CEIL_Y; y++) chunk.setBlockState(p.set(x, y, z), wall, false);
                chunk.setBlockState(p.set(x, CEIL_Y, z), lit[lx][lz] ? light : tile, false);
                for (int y = CEIL_Y + 1; y <= TOP_Y; y++) chunk.setBlockState(p.set(x, y, z), bedrock, false);
            }
        }
    }

    private static void fillBox(boolean[][] w, int x, int z, int sx, int sz) {
        for (int i = x; i < x + sx; i++) for (int j = z; j < z + sz; j++) w[i][j] = true;
    }

    private static int edgeState(PositionalRandomFactory f, int cx, int cz, boolean west) {
        int ncx = west ? cx - 1 : cx;
        int ncz = west ? cz : cz - 1;
        if (ComplexLayout.reserved(ncx, ncz)) return 0;                  // Main Chamber: tertutup
        if (ComplexLayout.roomAt(f, ncx, ncz) != null) return 1;         // sebelah ruangan buatan: selalu ada pintu
        int roll = f.at(cx, west ? 0 : 1, cz).nextInt(100);
        return roll < 20 ? 2 : roll < 62 ? 1 : 0;
    }

    // ---------------------------------------------------------------- boilerplate ChunkGenerator

    @Override
    public void applyCarvers(WorldGenRegion region, long seed, RandomState rs, BiomeManager bm,
                             StructureManager sm, ChunkAccess chunk, GenerationStep.Carving step) {}

    @Override
    public void buildSurface(WorldGenRegion region, StructureManager sm, RandomState rs, ChunkAccess chunk) {}

    @Override
    public void spawnOriginalMobs(WorldGenRegion region) {}

    @Override
    public int getGenDepth() {
        return 32;
    }

    @Override
    public int getSeaLevel() {
        return 0;
    }

    @Override
    public int getMinY() {
        return 0;
    }

    @Override
    public int getBaseHeight(int x, int z, Heightmap.Types type, LevelHeightAccessor level, RandomState rs) {
        return FLOOR_Y + 1;
    }

    @Override
    public NoiseColumn getBaseColumn(int x, int z, LevelHeightAccessor level, RandomState rs) {
        return new NoiseColumn(level.getMinBuildHeight(), new BlockState[0]);
    }

    @Override
    public void addDebugScreenInfo(List<String> info, RandomState rs, BlockPos pos) {}
}
