package com.thecomplex.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

import java.util.EnumMap;
import java.util.Map;

/**
 * Baji / lereng 45 derajat. facing = arah naik (sisi tinggi). Dipasang menghadap arah pandangan pemain,
 * jadi pemain berjalan naik ke depan. Tumbukan berupa 8 anak tangga setinggi 2 piksel (landai, bisa dilewati mulus).
 */
public class WedgeBlock extends Block {
    public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;

    private static final Map<Direction, VoxelShape> SHAPES = new EnumMap<>(Direction.class);

    static {
        SHAPES.put(Direction.NORTH, build(0));
        SHAPES.put(Direction.EAST, build(1));
        SHAPES.put(Direction.SOUTH, build(2));
        SHAPES.put(Direction.WEST, build(3));
    }

    /** turns = jumlah putaran 90 derajat searah jarum jam dari arah utara. */
    private static VoxelShape build(int turns) {
        VoxelShape shape = Shapes.empty();
        for (int i = 0; i < 8; i++) {
            double x1 = 0, x2 = 16, y2 = 2 * (i + 1), z1 = 14 - 2 * i, z2 = 16 - 2 * i;
            for (int t = 0; t < turns; t++) {
                double nx1 = 16 - z2, nx2 = 16 - z1, nz1 = x1, nz2 = x2;
                x1 = nx1;
                x2 = nx2;
                z1 = nz1;
                z2 = nz2;
            }
            shape = Shapes.or(shape, Block.box(x1, 0, z1, x2, y2, z2));
        }
        return shape;
    }

    public WedgeBlock(Properties props) {
        super(props);
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.NORTH));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        return defaultBlockState().setValue(FACING, ctx.getHorizontalDirection());
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return SHAPES.get(state.getValue(FACING));
    }

    @Override
    public boolean useShapeForLightOcclusion(BlockState state) {
        return true;
    }

    @Override
    public BlockState rotate(BlockState state, Rotation rot) {
        return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
    }

    @Override
    public BlockState mirror(BlockState state, Mirror mirror) {
        return state.rotate(mirror.getRotation(state.getValue(FACING)));
    }
}
