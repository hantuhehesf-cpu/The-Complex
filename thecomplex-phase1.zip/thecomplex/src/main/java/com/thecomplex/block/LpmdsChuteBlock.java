package com.thecomplex.block;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.BlockHitResult;

import java.util.Locale;

/**
 * Modul pengarah (emitter chute) LPMDS. Taruh menempel di sisi mesin LPMDS.
 * 16 langkah (22,5 derajat per langkah): klik kanan memutar searah jarum jam, sneak + klik (tangan kosong) berlawanan.
 * Langkah 0 = selatan, 4 = barat, 8 = utara, 12 = timur.
 */
public class LpmdsChuteBlock extends Block {
    public static final IntegerProperty ROTATION = BlockStateProperties.ROTATION_16;
    private static final String[] COMPASS = {"S", "SSB", "SB", "BSB", "B", "BBU", "BU", "UBU", "U", "UTU", "TU", "TTU", "T", "TTS", "TS", "STS"};

    public LpmdsChuteBlock(Properties props) {
        super(props);
        registerDefaultState(stateDefinition.any().setValue(ROTATION, 0));
    }

    public static String compass(int step) {
        return COMPASS[step & 15];
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(ROTATION);
    }

    /** Moncong menghadap ke arah pemain memandang saat memasang. */
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        return defaultBlockState().setValue(ROTATION, Mth.floor(ctx.getRotation() * 16.0F / 360.0F + 0.5D) & 15);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide) return InteractionResult.SUCCESS;
        int step = (state.getValue(ROTATION) + (player.isShiftKeyDown() ? 15 : 1)) & 15;
        level.setBlock(pos, state.setValue(ROTATION, step), 3);
        level.playSound(null, pos, SoundEvents.LEVER_CLICK, SoundSource.BLOCKS, 0.6f, 0.8f + step * 0.03f);
        player.displayClientMessage(Component.literal(String.format(Locale.ROOT,
                "Chute: langkah %d/16 = %.1f° (%s)", step, step * 22.5, compass(step))), true);
        return InteractionResult.CONSUME;
    }
}
