package com.thecomplex.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Lengkung (arch): satu blok dengan bukaan berbentuk lengkung yang menembus searah sumbu AXIS.
 * Dipakai sebagai penutup atas ambang pintu (misalnya lorong 3 blok: lengkung di blok paling atas).
 * Dipasang searah pandangan pemain.
 */
public class ArchBlock extends Block {
    public static final EnumProperty<Direction.Axis> AXIS = BlockStateProperties.HORIZONTAL_AXIS;

    /** Bukaan sepanjang sumbu Z (menghadap utara-selatan). */
    private static final VoxelShape Z_SHAPE = Shapes.or(
            Block.box(0, 0, 0, 2, 16, 16), Block.box(14, 0, 0, 16, 16, 16), Block.box(2, 15, 0, 14, 16, 16),
            Block.box(2, 11, 0, 3, 13, 16), Block.box(13, 11, 0, 14, 13, 16),
            Block.box(2, 13, 0, 5, 15, 16), Block.box(11, 13, 0, 14, 15, 16));
    /** Bukaan sepanjang sumbu X (menghadap timur-barat). */
    private static final VoxelShape X_SHAPE = Shapes.or(
            Block.box(0, 0, 0, 16, 16, 2), Block.box(0, 0, 14, 16, 16, 16), Block.box(0, 15, 2, 16, 16, 14),
            Block.box(0, 11, 2, 16, 13, 3), Block.box(0, 11, 13, 16, 13, 14),
            Block.box(0, 13, 2, 16, 15, 5), Block.box(0, 13, 11, 16, 15, 14));

    public ArchBlock(Properties props) {
        super(props);
        registerDefaultState(stateDefinition.any().setValue(AXIS, Direction.Axis.Z));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(AXIS);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        return defaultBlockState().setValue(AXIS, ctx.getHorizontalDirection().getAxis());
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return state.getValue(AXIS) == Direction.Axis.X ? X_SHAPE : Z_SHAPE;
    }

    @Override
    public boolean useShapeForLightOcclusion(BlockState state) {
        return true;
    }

    @Override
    public BlockState rotate(BlockState state, Rotation rot) {
        if (rot == Rotation.CLOCKWISE_90 || rot == Rotation.COUNTERCLOCKWISE_90) {
            return state.setValue(AXIS, state.getValue(AXIS) == Direction.Axis.X ? Direction.Axis.Z : Direction.Axis.X);
        }
        return state;
    }
}
