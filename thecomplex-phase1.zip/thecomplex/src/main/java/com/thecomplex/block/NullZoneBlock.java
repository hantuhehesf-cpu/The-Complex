package com.thecomplex.block;

import com.thecomplex.ComplexTeleporter;
import com.thecomplex.TheComplex;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Null Zone: tanpa collision. Yang dibuat sistem (di dinding basis pemain) menyimpan blok aslinya
 * dan memulihkannya setelah dipakai atau kedaluwarsa. Yang ditaruh manual (kreatif, .schem) permanen.
 */
public class NullZoneBlock extends Block implements EntityBlock {
    /** Berapa tick pemain harus berada di dalam blok sebelum jatuh tembus. */
    public static final int TRIGGER_TICKS = 8;

    public NullZoneBlock(Properties props) {
        super(props);
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new NullZoneBlockEntity(pos, state);
    }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        if (!(level instanceof ServerLevel sl) || !(entity instanceof ServerPlayer player)) return;
        if (level.dimension() == TheComplex.COMPLEX) return;
        if (ComplexTeleporter.onCooldown(player)) return;
        CompoundTag data = player.getPersistentData();
        long now = level.getGameTime();
        int count = (now - data.getLong("complex_nz_last") <= 3) ? data.getInt("complex_nz_count") + 1 : 1;
        data.putLong("complex_nz_last", now);
        data.putInt("complex_nz_count", count);
        if (count >= TRIGGER_TICKS) {
            data.putInt("complex_nz_count", 0);
            ComplexTeleporter.toBackrooms(player);
            // pulihkan seluruh gugus Null Zone di sekitarnya (dinding 1x2 atau lantai 2x2x2)
            for (int dx = -1; dx <= 1; dx++)
                for (int dy = -1; dy <= 1; dy++)
                    for (int dz = -1; dz <= 1; dz++)
                        restore(sl, pos.offset(dx, dy, dz));
        }
    }

    @Override
    public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        restore(level, pos);
    }

    /** Kembalikan blok asli (kalau ada). Null Zone manual tidak punya blok asli dan tetap di tempat. */
    public static void restore(ServerLevel level, BlockPos pos) {
        if (level.getBlockEntity(pos) instanceof NullZoneBlockEntity be && be.getOriginal() != null) {
            level.setBlock(pos, be.getOriginal(), 3);
        }
    }
}
