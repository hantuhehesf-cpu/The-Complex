package com.thecomplex.block;

import com.thecomplex.ComplexTeleporter;
import com.thecomplex.TheComplex;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

public class NullZoneBlock extends Block {
    /** Berapa tick pemain harus berada di dalam blok sebelum jatuh tembus. */
    public static final int TRIGGER_TICKS = 8;

    public NullZoneBlock(Properties props) {
        super(props);
    }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        if (level.isClientSide || !(entity instanceof ServerPlayer player)) return;
        if (level.dimension() == TheComplex.COMPLEX) return;
        CompoundTag data = player.getPersistentData();
        long now = level.getGameTime();
        int count = (now - data.getLong("complex_nz_last") <= 3) ? data.getInt("complex_nz_count") + 1 : 1;
        data.putLong("complex_nz_last", now);
        data.putInt("complex_nz_count", count);
        if (count >= TRIGGER_TICKS) {
            data.putInt("complex_nz_count", 0);
            ComplexTeleporter.toBackrooms(player);
        }
    }
}
