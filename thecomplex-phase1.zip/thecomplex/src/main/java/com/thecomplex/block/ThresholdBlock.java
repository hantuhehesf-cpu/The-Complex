package com.thecomplex.block;

import com.thecomplex.ComplexTeleporter;
import com.thecomplex.TheComplex;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Null Zone yang stabil. Tanpa collision, dua arah:
 * di dunia luar masuk ke The Complex, di dalam The Complex keluar ke tempat pemain masuk.
 */
public class ThresholdBlock extends Block {
    public ThresholdBlock(Properties props) {
        super(props);
    }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        if (level.isClientSide || !(entity instanceof ServerPlayer player)) return;
        if (ComplexTeleporter.onCooldown(player)) return;
        if (level.dimension() == TheComplex.COMPLEX) ComplexTeleporter.returnFromComplex(player, pos);
        else ComplexTeleporter.toArrival(player);
    }
}
