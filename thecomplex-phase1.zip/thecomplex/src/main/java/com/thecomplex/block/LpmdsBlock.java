package com.thecomplex.block;

import com.thecomplex.ModBlocks;
import com.thecomplex.TheComplex;
import com.thecomplex.net.Net;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.BlockHitResult;

import java.util.ArrayList;
import java.util.List;

/**
 * Low-Proximity Magnetic Distortion System.
 * Klik kanan: gempa 8 detik, lalu Null Zone stabil (Threshold, 2 lebar x 3 tinggi) terbuka
 * dua blok di depan mesin dan tetap terbuka. Klik kanan lagi untuk menutupnya.
 * Mesin tidak memindahkan siapa pun; pemain sendiri yang melangkah masuk.
 */
public class LpmdsBlock extends Block {
    public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;
    public static final BooleanProperty ACTIVE = BooleanProperty.create("active");
    public static final int CHARGE_TICKS = 160;

    public LpmdsBlock(Properties props) {
        super(props);
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.NORTH).setValue(ACTIVE, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING, ACTIVE);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        return defaultBlockState().setValue(FACING, ctx.getHorizontalDirection().getOpposite());
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide) return InteractionResult.SUCCESS;
        if (level.dimension() == TheComplex.COMPLEX) {
            player.displayClientMessage(Component.literal("LPMDS: no signal"), true);
            return InteractionResult.CONSUME;
        }
        ServerLevel sl = (ServerLevel) level;
        if (sl.getBlockTicks().hasScheduledTick(pos, this)) return InteractionResult.CONSUME; // sedang mengisi daya

        if (state.getValue(ACTIVE)) {
            close(sl, pos, state);
            sl.playSound(null, pos, SoundEvents.ENDER_DRAGON_GROWL, SoundSource.BLOCKS, 2.0f, 0.7f);
            Net.sendQuake(sl, pos, 40, 0.5f);
        } else {
            sl.playSound(null, pos, SoundEvents.ENDER_DRAGON_GROWL, SoundSource.BLOCKS, 4.0f, 0.4f);
            Net.sendQuake(sl, pos, CHARGE_TICKS, 1.0f);
            sl.scheduleTick(pos, this, CHARGE_TICKS);
        }
        return InteractionResult.CONSUME;
    }

    @Override
    public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (state.getValue(ACTIVE)) return;
        List<BlockPos> cells = portalCells(pos, state.getValue(FACING));
        for (BlockPos c : cells) {
            BlockState s = level.getBlockState(c);
            if (!s.isAir() && !s.canBeReplaced()) {
                level.players().stream().filter(p -> p.distanceToSqr(pos.getX(), pos.getY(), pos.getZ()) < 256)
                        .forEach(p -> p.displayClientMessage(Component.literal("LPMDS: no clear space"), true));
                return;
            }
        }
        BlockState threshold = ModBlocks.THRESHOLD.get().defaultBlockState();
        for (BlockPos c : cells) level.setBlock(c, threshold, 3);
        level.setBlock(pos, state.setValue(ACTIVE, true), 3);
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moving) {
        if (!level.isClientSide && !state.is(newState.getBlock()) && state.getValue(ACTIVE)) {
            close((ServerLevel) level, pos, state);
        }
        super.onRemove(state, level, pos, newState, moving);
    }

    private void close(ServerLevel level, BlockPos pos, BlockState state) {
        for (BlockPos c : portalCells(pos, state.getValue(FACING))) {
            if (level.getBlockState(c).is(ModBlocks.THRESHOLD.get())) {
                level.setBlock(c, Blocks.AIR.defaultBlockState(), 3);
            }
        }
        if (level.getBlockState(pos).is(this)) level.setBlock(pos, state.setValue(ACTIVE, false), 3);
    }

    /** Dua kolom x tiga tinggi, dua blok di depan mesin. */
    private static List<BlockPos> portalCells(BlockPos pos, Direction facing) {
        BlockPos base = pos.relative(facing, 2);
        BlockPos side = base.relative(facing.getClockWise());
        List<BlockPos> list = new ArrayList<>();
        for (int y = 0; y < 3; y++) {
            list.add(base.above(y));
            list.add(side.above(y));
        }
        return list;
    }
}
