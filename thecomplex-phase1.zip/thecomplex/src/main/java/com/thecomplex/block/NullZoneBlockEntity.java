package com.thecomplex.block;

import com.thecomplex.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.Tag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/** Menyimpan blok asli yang digantikan Null Zone liar, supaya dinding bisa dipulihkan. */
public class NullZoneBlockEntity extends BlockEntity {
    private BlockState original;

    public NullZoneBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.NULL_ZONE.get(), pos, state);
    }

    public BlockState getOriginal() {
        return original;
    }

    public void setOriginal(BlockState state) {
        this.original = state;
        setChanged();
        if (level != null) level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        if (original != null) tag.put("original", NbtUtils.writeBlockState(original));
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        original = tag.contains("original", Tag.TAG_COMPOUND)
                ? NbtUtils.readBlockState(BuiltInRegistries.BLOCK.asLookup(), tag.getCompound("original"))
                : null;
    }

    @Override
    public CompoundTag getUpdateTag() {
        return saveWithoutMetadata();
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
}
