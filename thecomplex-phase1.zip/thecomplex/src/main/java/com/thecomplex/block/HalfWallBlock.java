package com.thecomplex.block;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.WallBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.WallSide;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Setengah dinding: sekat tipis yang menyambung otomatis seperti dinding vanilla, tetapi lebih rendah
 * (tiang 12 piksel, sisi 10 piksel, sisi "tall" 16 piksel kalau ditumpuk). Bisa dilompati.
 * Agar saling menyambung, blok ini ada di tag minecraft:walls.
 */
public class HalfWallBlock extends WallBlock {
    private static final VoxelShape POST = Block.box(4, 0, 4, 12, 12, 12);
    // urutan: utara, timur, selatan, barat
    private static final VoxelShape[] LOW = {
            Block.box(5, 0, 0, 11, 10, 8), Block.box(8, 0, 5, 16, 10, 11),
            Block.box(5, 0, 8, 11, 10, 16), Block.box(0, 0, 5, 8, 10, 11)};
    private static final VoxelShape[] TALL = {
            Block.box(5, 0, 0, 11, 16, 8), Block.box(8, 0, 5, 16, 16, 11),
            Block.box(5, 0, 8, 11, 16, 16), Block.box(0, 0, 5, 8, 16, 11)};

    private final Map<BlockState, VoxelShape> cache = new ConcurrentHashMap<>();

    public HalfWallBlock(Properties props) {
        super(props);
    }

    private static VoxelShape side(VoxelShape base, WallSide side, int i) {
        if (side == WallSide.LOW) return Shapes.or(base, LOW[i]);
        if (side == WallSide.TALL) return Shapes.or(base, TALL[i]);
        return base;
    }

    private static VoxelShape build(BlockState s) {
        VoxelShape shape = s.getValue(UP) ? POST : Shapes.empty();
        shape = side(shape, s.getValue(NORTH_WALL), 0);
        shape = side(shape, s.getValue(EAST_WALL), 1);
        shape = side(shape, s.getValue(SOUTH_WALL), 2);
        shape = side(shape, s.getValue(WEST_WALL), 3);
        return shape.isEmpty() ? POST : shape;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return cache.computeIfAbsent(state, HalfWallBlock::build);
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return getShape(state, level, pos, ctx);
    }
}
