package com.thecomplex;

import com.thecomplex.block.LpmdsBlock;
import com.thecomplex.block.LpmdsChuteBlock;
import com.thecomplex.block.NullZoneBlock;
import com.thecomplex.block.ThresholdBlock;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.function.Supplier;

public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, TheComplex.MODID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, TheComplex.MODID);

    public static final RegistryObject<Block> WALLPAPER = reg("wallpaper",
            () -> new Block(props(MapColor.COLOR_YELLOW, SoundType.STONE).strength(1.5f, 6f)));
    public static final RegistryObject<Block> CARPET_FLOOR = reg("carpet_floor",
            () -> new Block(props(MapColor.COLOR_BROWN, SoundType.WOOL).strength(0.8f)));
    public static final RegistryObject<Block> CEILING_TILE = reg("ceiling_tile",
            () -> new Block(props(MapColor.SAND, SoundType.STONE).strength(0.8f)));
    public static final RegistryObject<Block> FLUORESCENT_PANEL = reg("fluorescent_panel",
            () -> new Block(props(MapColor.QUARTZ, SoundType.GLASS).strength(0.5f).lightLevel(s -> 15)));

    /** Tampak persis seperti wallpaper, tapi tanpa collision: pemain bisa jatuh tembus. */
    public static final RegistryObject<Block> NULL_ZONE = reg("null_zone",
            () -> new NullZoneBlock(props(MapColor.COLOR_YELLOW, SoundType.STONE).strength(1.5f)
                    .noCollission()
                    .isSuffocating((s, l, p) -> false)
                    .isViewBlocking((s, l, p) -> false)));

    /** Null Zone stabil, dibuka oleh LPMDS (dan satu permanen di Main Chamber sebagai jalan pulang). */
    public static final RegistryObject<Block> THRESHOLD = reg("threshold",
            () -> new ThresholdBlock(props(MapColor.COLOR_YELLOW, SoundType.GLASS).strength(-1f, 3600000f)
                    .noCollission().noOcclusion().noLootTable()
                    .lightLevel(s -> 9)
                    .isSuffocating((s, l, p) -> false)
                    .isViewBlocking((s, l, p) -> false)));

    public static final RegistryObject<Block> LPMDS = reg("lpmds",
            () -> new LpmdsBlock(props(MapColor.METAL, SoundType.METAL).strength(4f, 1200f)
                    .lightLevel(s -> s.getValue(LpmdsBlock.ACTIVE) ? 10 : 3)));

    /** Modul pengarah medan LPMDS: menempel di sisi mesin, dapat diputar 16 langkah. */
    public static final RegistryObject<Block> LPMDS_CHUTE = reg("lpmds_chute",
            () -> new LpmdsChuteBlock(props(MapColor.METAL, SoundType.METAL).strength(3f, 600f).noOcclusion()));

    private static BlockBehaviour.Properties props(MapColor color, SoundType sound) {
        return BlockBehaviour.Properties.of().mapColor(color).sound(sound);
    }

    private static RegistryObject<Block> reg(String name, Supplier<Block> sup) {
        RegistryObject<Block> o = BLOCKS.register(name, sup);
        ITEMS.register(name, () -> new BlockItem(o.get(), new Item.Properties()));
        return o;
    }

    private ModBlocks() {}
}
