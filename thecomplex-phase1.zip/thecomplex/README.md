# The Complex (Fase 2a) — Forge 1.20.1

Belum dikompilasi atau diuji di sini, jadi build pertama kemungkinan butuh perbaikan kecil.

## Build
GitHub Actions (workflow ada di percakapan) atau MDK Forge 1.20.1 (47.3.0) dengan menyalin `src/`. Java 17.

## Ruangan buatanmu (WorldEdit)
1. Bangun ruangan. `//pos1` di sudut barat laut lapisan lantai, `//pos2` di sudut seberang atas.
2. Berdiri di `pos1`, `//copy`, lalu `//schem save namaruangan`.
3. Salin file dari `config/worldedit/schematics/` ke:
   - `config/thecomplex/rooms/` untuk ruangan biasa (Pitfalls, dll.)
   - `config/thecomplex/main_chamber.schem` untuk Main Chamber
4. Ruangan: jalankan `/complex reload` (atau restart). Main Chamber: restart, dan hapus folder
   `dimensions/thecomplex/the_complex` di dalam folder save dunia (dunia ditutup) supaya Complex dibuat ulang.

Aturan:
- Titik (0,0,0) schematic = sudut barat laut lantai. Offset di file WorldEdit diabaikan, jadi berdiri di mana pun saat `//copy` tidak masalah.
- Lapisan paling bawah = lantai (y=16). Tinggi Backrooms standar: lantai + 3 udara + atap tile (5 lapis).
- Ukuran ideal kelipatan 16. Pintu lebar 4 di offset 6..9 pada tiap sisi chunk. Slot maksimum 4x4 chunk (64x64) per ruangan.
- Pakai blok saja. Entitas (painting, item frame) dan isi chest tidak ikut.
- Main Chamber ditaruh sejajar chunk di sekitar (0,0): sudut barat laut jatuh di batas chunk terdekat dari tengah.
  Taruh blok `thecomplex:threshold` di dalamnya sebagai pintu ke dunia luar; titik tiba otomatis dihitung dari posisinya.
- Cabang ke Backrooms: buat bukaan lebar 4 di offset 6..9 pada sisi chunk di tepi Main Chamber. Chunk Backrooms di
  sisi timur/selatan sudah otomatis punya pintu ke arah Main Chamber; di sisi barat/utara bukaannya milikmu sendiri.
  Gunakan ukuran kelipatan 16 supaya sejajar.
- Tanpa main_chamber.schem, dipakai placeholder 96x96 yang tertutup, dengan satu Threshold di dinding selatan.

Ruangan muncul di grid prosedural: tiap slot 4x4 chunk punya peluang 30% berisi satu ruangan
(`ComplexLayout.ROOM_CHANCE`, `SLOT`). Chunk prosedural di sebelah ruangan selalu punya pintu ke arahnya.

## Perintah (OP)
`/complex enter`, `/complex backrooms`, `/complex leave`,
`/complex rooms`, `/complex reload`, `/complex room <nama>` (tempel ke dunia di posisimu untuk uji bentuk),
`/complex heat` (heat chunk-mu dan 5 chunk teratas), `/complex spawnnz` (paksa satu Null Zone di dekatmu, harus di dalam bangunan).

## Yang sudah ada
- Dimensi `thecomplex:the_complex`: tinggi 32, atap bedrock, tanpa mob, tanpa kabut
- Backrooms prosedural: aula terbuka, pintu, hutan pilar, sekat, lampu mati, chunk gelap; tinggi 3 blok
- Blok: Wallpaper, Damp Carpet, Ceiling Tile, Fluorescent Panel, Null Zone, Threshold, LPMDS
- LPMDS: gempa 8 detik lalu Threshold stabil 2x3 di depan mesin; klik lagi untuk menutup
- Threshold dua arah: dunia luar masuk ke Main Chamber; di Main Chamber keluar ke tempat pemain terakhir masuk
- Pelacakan aktivitas (Overworld): tiap 5 detik mencatat chunk tempatmu berada. Disimpan per pemain, maksimal 256 chunk,
  menurun pelan (paruh waktu sekitar 5 jam bermain).
- Null Zone liar: dicek tiap 10 detik. Peluang naik dari 1/360 (tempat asing, rata-rata 1 jam) sampai 1/60 (chunk yang
  sangat sering kamu datangi, rata-rata 10 menit). Ditaruh di dinding bagian dalam ruangan (di bawah atap), condong ke
  chunk dengan heat tertinggi di dekatmu. Menyimpan blok aslinya: setelah dipakai atau setelah 10-30 menit, dinding
  kembali normal. Null Zone yang kamu taruh manual atau dari .schem permanen.
  Konstanta: `ActivityTracker.CHANCE_COLD/CHANCE_HOT/HEAT_FULL`, `NullZoneSpawner.LIFETIME_*`, `NullZoneBlock.TRIGGER_TICKS`.
- Catatan: Null Zone liar masih tampak seperti wallpaper. Menyamar jadi blok aslinya adalah langkah berikutnya.

## Bagian yang paling mungkin perlu dicek saat compile
- `RandomState.getOrCreateRandomFactory`, `Heightmap.primeHeightmaps`, `ViewportEvent.RenderFog`
- `BlockStateParser.parseForBlock` dan `NbtIo.readCompressed` di `Schem`
- `NbtUtils.readBlockState` dan `SavedData` di `NullZoneBlockEntity` / `ActivityData`

## Fase berikutnya
Menyamarkan Null Zone liar sebagai blok aslinya, fragmen "ingatan" overworld, lalu entitas (Lifeform, Still Lifes).
