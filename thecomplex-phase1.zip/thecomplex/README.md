# The Complex — Forge 1.20.1

Belum dikompilasi atau diuji di sini, jadi build pertama kemungkinan butuh perbaikan kecil.

## Build
GitHub Actions (build.yml ada di percakapan). Java 17. Jar ada di artifact `thecomplex-jar`.

## Schematic (.schem WorldEdit) ada DI DALAM mod
- Main Chamber bawaan: `src/main/resources/data/thecomplex/schem/main_chamber.schem`
- Ruangan bawaan: `src/main/resources/data/thecomplex/schem/rooms/*.schem`
- Lewat GitHub: upload file `.schem` ke halaman utama repo (sebelahnya ZIP). Workflow otomatis memasukkannya ke mod:
  nama `mainchamber` / `main_chamber` / `Main Chamber` = Main Chamber, nama lain = ruangan.
- Uji cepat tanpa build ulang (opsional): `config/thecomplex/main_chamber.schem` dan `config/thecomplex/rooms/` diutamakan
  daripada yang di dalam mod. Hapus isinya kalau ingin memakai versi bawaan mod.
- Aturan ruangan: titik (0,0,0) schematic = sudut barat laut lantai; lapisan paling bawah = lantai (y=16); ukuran maksimal 64x64
  (4x4 chunk); tinggi udara bebas (3 sampai 6 atau lebih). Pakai blok saja (tanpa entitas/isi chest).
- Main Chamber ditaruh sejajar chunk di sekitar (0,0). Bukaan di dinding luarnya (posisi, lebar, tinggi bebas) tembus ke Backrooms.
  Blok `thecomplex:threshold` di dalamnya = pintu ke dunia luar; titik tiba dihitung dari posisinya.
  Setelah mengganti Main Chamber: hapus folder `dimensions/thecomplex/the_complex` di save dunia.

## Backrooms prosedural: sistem divisi
Dunia dibagi jadi wilayah 8x8 chunk (128x128 blok) yang disebut **divisi**. Satu divisi punya tinggi atap tetap (3 atau 4 blok udara),
pola ruangan khas, tingkat kegelapan, dan peluang fragmen. Atap tidak berubah di tengah aula; perubahan tinggi hanya terjadi di batas divisi,
dan di batas itu sisi chunk dibuat tembok atau pintu (tidak terbuka penuh). Di atas atap diisi wallpaper, bukan bedrock.

| Divisi | Nama | Udara | Ciri |
|---|---|---|---|
| A | Standar | 3 | campuran pola biasa |
| B | Aula | 4 | aula luas, pilar besar |
| C | Labirin | 3 | sekat, lorong sempit, kamar kecil |
| D | Gelap | 3 | banyak lampu mati, chunk gelap sering |
| E | Tinggi | 4 | hutan pilar, deretan tiang |
| F | Kenangan | 4 | aula kosong; tempat fragmen Overworld paling sering muncul |

Pola: hutan pilar, pilar besar, sekat (2 arah), aula kosong, lorong sempit (2 arah), dua deret tiang, kamar kecil, dinding L.
Konstanta ada di `Division.java`.

**Ruangan .schem per divisi:** tambahkan `@` dan huruf divisi di akhir nama file, mis. `pitfalls@C.schem` (hanya di divisi C),
`kantor@BE.schem` (hanya di B dan E). Tanpa `@` = boleh di semua divisi. Tiap slot 4x4 chunk berpeluang 30% memuat satu ruangan
(`ComplexLayout.ROOM_CHANCE`). Bagian chunk di luar ruangan memakai tinggi atap divisinya.

- Dengung panel lampu (`fluorescent_hum.ogg`) terus berputar di The Complex. Volume dasar: `HumSound.VOLUME`.
- Atap: 1 tile = 1 blok (tekstur `ceiling_tile`).

## Aktivitas, Null Zone, fragmen
- Tiap 5 detik di Overworld, chunk tempatmu dicatat (maks 256 chunk per pemain, menurun pelan).
- Null Zone dicek tiap 10 detik; peluang naik dari 1/360 (tempat asing) sampai 1/60 (tempat yang sangat sering kamu datangi).
  Muncul di dinding (1x2) atau lantai (2x2, dua blok dalam) bagian dalam ruangan, condong ke chunk dengan heat tertinggi.
- Null Zone menyamar sebagai blok aslinya (tampilannya meniru blok yang digantikan; blok berwarna biome seperti rumput tidak dipakai),
  dan memulihkannya setelah dipakai atau setelah 10-30 menit. Yang ditaruh manual / dari .schem permanen dan tampak seperti wallpaper.
- Fragmen Overworld (maks 12x9x12, disimpan di data dunia, maks 24): bangunan di tempat Null Zone muncul (peluang 30%), pohon,
  atau potongan struktur vanilla. Ditangkap otomatis sesekali (rata-rata ~5 menit per pemain) atau lewat Dev UI.
- Di Backrooms, fragmen muncul per divisi (0,3% di sebagian besar divisi, 6% di divisi F). Fragmen dipotong oleh atap Backrooms, atap tidak dinaikkan. Setiap fragmen: diputar acak, lantai sebagian jadi karpet, sebagian blok jadi wallpaper,
  dedaunan jadi wallpaper atau tetap ada tanpa luruh, dan ada lubang kecil. Peluangnya ada di `Division.java` (`fragmentPermille`).

## Developer UI (tanpa command)
Item **Complex Dev Tool** (creative tab "Tools & Utilities"): klik kanan. Hanya untuk OP atau mode kreatif.
Tab: Masuk (Main Chamber, Backrooms acak, keluar, ganti kreatif/survival, pulihkan nyawa), Null Zone (acak/lantai/dinding, tambah heat, reset heat),
**Pelacak** (daftar Null Zone yang baru muncul: ketuk baris untuk teleport, teleport ke terdekat, pulihkan semua),
Fragmen (tangkap bangunan/pohon/struktur, tempel acak, hapus semua), Ruangan (pilih, tempel, muat ulang).
Status (dimensi, Main Chamber, jumlah ruangan/fragmen/Null Zone terlacak, posisi, heat) tampil di bagian atas.
Selama Dev Tool dipegang: action bar menampilkan panah dan jarak ke Null Zone terdekat, dan sel udara yang menempel pada Null Zone
dalam radius 40 blok diberi percikan cahaya.
Command lama `/complex ...` masih ada.

## Yang paling mungkin perlu dicek saat compile
- `RandomState.getOrCreateRandomFactory`, `Heightmap.primeHeightmaps`, `ViewportEvent.RenderFog`
- `BlockStateParser.parseForBlock`, `NbtIo.readCompressed`, `NbtUtils.readBlockState`, `SavedData`
- `IModFile.findResource` (SchemStore), `ModelEvent.ModifyBakingResult` dan `BakedModelWrapper` (MimicModel)
- `Screen.rebuildWidgets` (DevScreen), `AbstractTickableSoundInstance` (HumSound)

## Fase berikutnya
Entitas (Lifeform, lalu Still Lifes).
