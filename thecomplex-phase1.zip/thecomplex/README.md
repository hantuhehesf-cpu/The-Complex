# The Complex (Fase 1) — Forge 1.20.1

Backrooms ala Kane Pixels. Belum dikompilasi atau diuji di sini, jadi build pertama kemungkinan butuh perbaikan kecil.

## Cara build
Paling aman: ambil MDK resmi Forge 1.20.1 (47.3.0), lalu salin folder `src/` ke dalamnya
(timpa `mods.toml`, ganti `build.gradle` bila perlu). `build.gradle` di sini adalah versi MDK yang disederhanakan.
Java 17. Jalankan `gradlew build`, jar ada di `build/libs`.

## Yang sudah ada
- Dimensi `thecomplex:the_complex` (tinggi 32, atap bedrock, tanpa mob)
- Main Chamber (96x96, atap 12 blok): pilar 4x4, meja maket kuning di tengah
- Ruang industri + gerbang Threshold di sisi selatan (tempat tiba lewat LPMDS)
- 6 hallway (2 utara, 2 barat, 2 timur), 48 blok, lalu Backrooms prosedural
- Backrooms prosedural: aula terbuka, pintu, hutan pilar, sekat, panel lampu mati, chunk gelap
- Blok: Wallpaper, Damp Carpet, Ceiling Tile, Fluorescent Panel, Null Zone, LPMDS
- Null Zone: tampak seperti wallpaper, tanpa collision; 8 tick di dalamnya = jatuh ke Backrooms
- Null Zone muncul acak di Overworld (lihat `ServerEvents.NULL_ZONE_ONE_IN`)
- LPMDS: klik kanan, gempa 8 detik (camera shake), lalu Null Zone stabil (blok Threshold, 2 lebar x 3 tinggi)
  terbuka dua blok di depan mesin dan tetap terbuka. Klik kanan lagi untuk menutup. Mesin tidak memindahkan siapa pun.
- Threshold dua arah: di dunia luar masuk ke The Complex (tiba di ruang industri), di dalam The Complex keluar
  ke tempat pemain terakhir masuk (diingat per pemain). Ada Threshold permanen di dinding selatan ruang industri.
- Null Zone liar tetap satu arah: jatuh ke Backrooms; jalan pulangnya adalah menemukan Threshold di ruang industri.
- Perintah (OP): `/complex enter`, `/complex backrooms`, `/complex leave`

## Koordinat tetap (di dunia Complex)
- Main Chamber: x,z -48..47, lantai y=16 (karpet), udara y=17..28
- Threshold: dinding beton di z=48..50, bukaan x -3..2
- Titik tiba: 0.5, 17, 74.5 (menghadap utara, ke arah Main Chamber)
- Threshold jalan pulang: x -1..0, y 17..19, z=79 (tepat di belakang titik tiba)
- Standar pintu: lebar 4 di offset 6..9 pada setiap sisi chunk (dipakai juga oleh hallway)

## Bagian yang paling mungkin perlu dicek saat compile
- `RandomState.getOrCreateRandomFactory(ResourceLocation)` di `ComplexChunkGenerator`
- Parameter `Heightmap.primeHeightmaps`
Kalau salah satunya beda, kirim pesan errornya.

## Fase berikutnya
1. Ruangan buatanmu (NBT) disisipkan ke grid prosedural, termasuk opsi mengganti Main Chamber
2. Pelacakan aktivitas + fragmen overworld (basis, pohon, rumah villager, struktur)
3. Entitas: Lifeform, lalu Still Lifes
