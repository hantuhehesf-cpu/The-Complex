# The Complex (Fase 1) — Forge 1.20.1

Backrooms ala Kane Pixels. Belum dikompilasi atau diuji di sini, jadi build pertama kemungkinan butuh perbaikan kecil.

## Cara build
Lewat GitHub Actions (workflow ada di percakapan), atau MDK resmi Forge 1.20.1 (47.3.0) dengan menyalin folder `src/`.
Java 17. Jar ada di `build/libs`.

## Yang sudah ada
- Dimensi `thecomplex:the_complex` (tinggi 32, atap bedrock, tanpa mob, tanpa kabut)
- Main Chamber (96x96, tinggi udara 4 blok): 16 pilar cruciform (placeholder) dan meja maket kuning di tengah
- 6 hallway (2 utara, 2 barat, 2 timur), 48 blok, lalu Backrooms prosedural dengan langit-langit 3 blok
- Backrooms prosedural: aula terbuka, pintu, hutan pilar, sekat, panel lampu mati, chunk gelap
- Blok: Wallpaper, Damp Carpet, Ceiling Tile, Fluorescent Panel, Null Zone, Threshold, LPMDS
- LPMDS: klik kanan, gempa 8 detik (camera shake), lalu Threshold stabil (2 lebar x 3 tinggi) terbuka
  dua blok di depan mesin dan tetap terbuka. Klik kanan lagi untuk menutup. Mesin tidak memindahkan siapa pun.
- Threshold dua arah: di dunia luar langsung masuk ke Main Chamber; di dalam Main Chamber keluar ke tempat
  pemain terakhir masuk (diingat per pemain). Ada Threshold permanen di dinding selatan Main Chamber.
- Null Zone liar: tampak seperti wallpaper tanpa collision; 8 tick di dalamnya = jatuh ke Backrooms
  (satu arah; jalan pulangnya adalah menemukan Threshold di Main Chamber). Muncul acak di Overworld
  (lihat `ServerEvents.NULL_ZONE_ONE_IN`).
- Perintah (OP): `/complex enter`, `/complex backrooms`, `/complex leave`

## Koordinat tetap (di dunia Complex)
- Main Chamber: x,z -48..47, lantai y=16 (karpet), udara y=17..20, langit-langit y=21 (`ComplexLayout.MAIN_CEIL_Y`)
- Titik tiba: 0.5, 17, 42.5 (menghadap utara, lorong tengah)
- Threshold jalan pulang: x -1..0, y 17..19, z=47 (tepat di belakang titik tiba)
- Pilar cruciform: pusat di x,z = +-16 dan +-32; lengan lebar 3, panjang lengan `ComplexLayout.PILLAR_ARM_LEN` (3)
- Standar pintu: lebar 4 di offset 6..9 pada setiap sisi chunk (dipakai juga oleh hallway)
- Tinggi Backrooms: lantai y=16, udara y=17..19, langit-langit y=20 (`ComplexLayout.CEIL_Y`)

## Bagian yang paling mungkin perlu dicek saat compile
- `RandomState.getOrCreateRandomFactory(ResourceLocation)` di `ComplexChunkGenerator`
- `Heightmap.primeHeightmaps` dan `ViewportEvent.RenderFog` di `FogClient`

## Fase berikutnya
1. Ruangan buatanmu (NBT) disisipkan ke grid prosedural, termasuk opsi mengganti Main Chamber
2. Pelacakan aktivitas + fragmen overworld (basis, pohon, rumah villager, struktur)
3. Entitas: Lifeform, lalu Still Lifes
