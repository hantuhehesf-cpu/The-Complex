# The Complex (Fase 1.5) — Forge 1.20.1

Belum dikompilasi atau diuji di sini, jadi build pertama kemungkinan butuh perbaikan kecil.

## Build
GitHub Actions (workflow ada di percakapan) atau MDK Forge 1.20.1 (47.3.0) dengan menyalin `src/`. Java 17.

## Ruangan buatanmu (WorldEdit)
1. Bangun ruangan. `//pos1` di sudut barat laut lapisan lantai, `//pos2` di sudut seberang atas.
2. Berdiri di `pos1`, `//copy`, lalu `//schem save namaruangan`.
3. Salin file dari `config/worldedit/schematics/` ke:
   - `config/thecomplex/rooms/` untuk ruangan biasa (Pitfalls, dll.)
   - `config/thecomplex/main_chamber.schem` untuk Main Chamber
4. Ruangan: jalankan `/complex reload` (atau restart). Main Chamber: restart, dan hapus folder
   `dimensions/thecomplex/the_complex` di dalam folder save dunia (dunia ditutup) supaya Complex dibuat ulang.

Aturan:
- Titik (0,0,0) schematic = sudut barat laut lantai. Offset di file WorldEdit diabaikan, jadi berdiri di mana pun saat `//copy` tidak masalah.
- Lapisan paling bawah = lantai (y=16). Tinggi Backrooms standar: lantai + 3 udara + atap tile (5 lapis).
- Ukuran ideal kelipatan 16. Pintu lebar 4 di offset 6..9 pada tiap sisi chunk. Slot maksimum 4x4 chunk (64x64) per ruangan.
- Pakai blok saja. Entitas (painting, item frame) dan isi chest tidak ikut.
- Main Chamber ditaruh di tengah dunia Complex (0,0). Taruh blok `thecomplex:threshold` di dindingnya sebagai pintu
  keluar; titik tiba otomatis dihitung dari posisinya, menghadap tengah ruangan.
  Tanpa file ini, dipakai placeholder 96x96 dengan satu Threshold di dinding selatan.
- Tidak ada hallway. Threshold satu-satunya pintu Main Chamber.

Ruangan muncul di grid prosedural: tiap slot 4x4 chunk punya peluang 30% berisi satu ruangan
(`ComplexLayout.ROOM_CHANCE`, `SLOT`). Chunk prosedural di sebelah ruangan selalu punya pintu ke arahnya.

## Perintah (OP)
`/complex enter`, `/complex backrooms`, `/complex leave`,
`/complex rooms` (daftar ruangan dimuat), `/complex reload`, `/complex room <nama>` (tempel ke dunia di posisimu untuk uji bentuk).

## Yang sudah ada
- Dimensi `thecomplex:the_complex`: tinggi 32, atap bedrock, tanpa mob, tanpa kabut
- Backrooms prosedural: aula terbuka, pintu, hutan pilar, sekat, lampu mati, chunk gelap; tinggi 3 blok
- Blok: Wallpaper, Damp Carpet, Ceiling Tile, Fluorescent Panel, Null Zone, Threshold, LPMDS
- LPMDS: gempa 8 detik lalu Threshold stabil 2x3 di depan mesin; klik lagi untuk menutup
- Threshold dua arah: dunia luar masuk ke Main Chamber; di Main Chamber keluar ke tempat pemain terakhir masuk
- Null Zone liar: muncul acak di Overworld, satu arah ke Backrooms (`ServerEvents.NULL_ZONE_ONE_IN`, `NullZoneBlock.TRIGGER_TICKS`)
- Catatan: tanpa hallway, pemain yang jatuh lewat Null Zone liar tidak punya jalan kaki kembali ke Main Chamber

## Bagian yang paling mungkin perlu dicek saat compile
- `RandomState.getOrCreateRandomFactory`, `Heightmap.primeHeightmaps`, `ViewportEvent.RenderFog`
- `BlockStateParser.parseForBlock` dan `NbtIo.readCompressed` di `Schem`

## Fase berikutnya
Pelacakan aktivitas + fragmen overworld, lalu entitas (Lifeform, Still Lifes).
