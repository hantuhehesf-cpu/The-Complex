# The Complex — Forge 1.20.1

Belum dikompilasi atau diuji di sini, jadi build pertama kemungkinan butuh perbaikan kecil.

## Build
GitHub Actions (build.yml ada di percakapan). Java 17. Jar ada di artifact `thecomplex-jar`.

## Schematic (.schem WorldEdit) ada DI DALAM mod
- Main Chamber bawaan: `src/main/resources/data/thecomplex/schem/main_chamber.schem`
- Ruangan bawaan: `src/main/resources/data/thecomplex/schem/rooms/*.schem`
- Lewat GitHub: upload file `.schem` ke halaman utama repo (sebelahnya ZIP). Workflow otomatis memasukkannya ke mod:
  nama `mainchamber` / `main_chamber` / `Main Chamber` = Main Chamber, nama lain = ruangan.
- Uji cepat tanpa build ulang (opsional): `config/thecomplex/main_chamber.schem` dan `config/thecomplex/rooms/` diutamakan
  daripada yang di dalam mod. Hapus isinya kalau ingin memakai versi bawaan mod.
- Aturan ruangan: titik (0,0,0) schematic = sudut barat laut lantai; lapisan paling bawah = lantai (y=16); ukuran maksimal 64x64
  (4x4 chunk); tinggi udara bebas (3 sampai 6 atau lebih). Pakai blok saja (tanpa entitas/isi chest).
- Main Chamber ditaruh sejajar chunk di sekitar (0,0). Bukaan di dinding luarnya (posisi, lebar, tinggi bebas) tembus ke Backrooms.
  Blok `thecomplex:threshold` di dalamnya = pintu ke dunia luar; titik tiba dihitung dari posisinya.
  Setelah mengganti Main Chamber: hapus folder `dimensions/thecomplex/the_complex` di save dunia.

## Backrooms prosedural
- Tinggi udara per slot 4x4 chunk: 3 (60%), 4 (20%), 5 (12%), 6 (8%).
- Pola ruangan: hutan pilar, pilar besar, sekat (2 arah), aula kosong, lorong sempit (2 arah), dua deret tiang,
  kamar kecil tertutup, dinding L; sisi bisa tembok, pintu 4 lebar, atau terbuka penuh; panel mati; chunk gelap.
- Ruangan .schem disisipkan: tiap slot 4x4 chunk punya peluang 30% (`ComplexLayout.ROOM_CHANCE`).
- Dengung panel lampu (`fluorescent_hum.ogg`) terus berputar di The Complex. Volume dasar: `HumSound.VOLUME`; ikut slider "Ambient/Environment".
- Atap: 1 tile = 1 blok (tekstur `ceiling_tile`).

## Aktivitas, Null Zone, fragmen
- Tiap 5 detik di Overworld, chunk tempatmu dicatat (maks 256 chunk per pemain, menurun pelan).
- Null Zone dicek tiap 10 detik; peluang naik dari 1/360 (tempat asing) sampai 1/60 (tempat yang sangat sering kamu datangi).
  Muncul di dinding (1x2) atau lantai (2x2, dua blok dalam) bagian dalam ruangan, condong ke chunk dengan heat tertinggi.
- Null Zone menyamar sebagai blok aslinya (tampilannya meniru blok yang digantikan; blok berwarna biome seperti rumput tidak dipakai),
  dan memulihkannya setelah dipakai atau setelah 10-30 menit. Yang ditaruh manual / dari .schem permanen dan tampak seperti wallpaper.
- Fragmen Overworld (maks 12x9x12, disimpan di data dunia, maks 24): bangunan di tempat Null Zone muncul (peluang 30%), pohon,
  atau potongan struktur vanilla. Ditangkap otomatis sesekali (rata-rata ~5 menit per pemain) atau lewat Dev UI.
- Di Backrooms, 5% chunk prosedural memuat satu fragmen: diputar acak, lantai sebagian jadi karpet, sebagian blok jadi wallpaper,
  dedaunan jadi wallpaper atau tetap ada tanpa luruh, dan ada lubang kecil. Konstanta: `ComplexChunkGenerator.FRAGMENT_CHANCE`.

## Developer UI (tanpa command)
Item **Complex Dev Tool** (creative tab "Tools & Utilities"): klik kanan. Hanya untuk OP atau mode kreatif.
Tab: Masuk (Main Chamber, Backrooms acak, keluar), Null Zone (acak/lantai/dinding, tambah heat, reset heat),
Fragmen (tangkap bangunan/pohon/struktur, tempel acak, hapus semua), Ruangan (pilih, tempel, muat ulang).
Status (dimensi, Main Chamber, jumlah ruangan dan fragmen, heat) tampil di bagian atas.
Command lama `/complex ...` masih ada.

## Yang paling mungkin perlu dicek saat compile
- `RandomState.getOrCreateRandomFactory`, `Heightmap.primeHeightmaps`, `ViewportEvent.RenderFog`
- `BlockStateParser.parseForBlock`, `NbtIo.readCompressed`, `NbtUtils.readBlockState`, `SavedData`
- `IModFile.findResource` (SchemStore), `ModelEvent.ModifyBakingResult` dan `BakedModelWrapper` (MimicModel)
- `Screen.rebuildWidgets` (DevScreen), `AbstractTickableSoundInstance` (HumSound)

## Fase berikutnya
Entitas (Lifeform, lalu Still Lifes).
