package com.thecomplex.net;

import com.thecomplex.TheComplex;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.Optional;

public final class Net {
    private static final String PROTOCOL = "4";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(TheComplex.MODID, "main"), () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    public static void register() {
        CHANNEL.registerMessage(0, QuakePacket.class, QuakePacket::encode, QuakePacket::decode, QuakePacket::handle);
        CHANNEL.registerMessage(1, DevActionPacket.class, DevActionPacket::encode, DevActionPacket::decode,
                DevActionPacket::handle, Optional.of(NetworkDirection.PLAY_TO_SERVER));
        CHANNEL.registerMessage(2, OpenDevPacket.class, OpenDevPacket::encode, OpenDevPacket::decode,
                OpenDevPacket::handle, Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(3, BriefcaseSyncPacket.class, BriefcaseSyncPacket::encode, BriefcaseSyncPacket::decode,
                BriefcaseSyncPacket::handle, Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(4, BriefcaseOpPacket.class, BriefcaseOpPacket::encode, BriefcaseOpPacket::decode,
                BriefcaseOpPacket::handle, Optional.of(NetworkDirection.PLAY_TO_SERVER));
        CHANNEL.registerMessage(5, ThrowPacket.class, ThrowPacket::encode, ThrowPacket::decode,
                ThrowPacket::handle, Optional.of(NetworkDirection.PLAY_TO_SERVER));
        CHANNEL.registerMessage(6, SeamlessPacket.class, SeamlessPacket::encode, SeamlessPacket::decode,
                SeamlessPacket::handle, Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(7, PortalViewPacket.class, PortalViewPacket::encode, PortalViewPacket::decode,
                PortalViewPacket::handle, Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(8, PortalFarPacket.class, PortalFarPacket::encode, PortalFarPacket::decode,
                PortalFarPacket::handle, Optional.of(NetworkDirection.PLAY_TO_CLIENT));
    }

    public static void sendQuake(ServerLevel level, BlockPos pos, int ticks, float intensity) {
        CHANNEL.send(PacketDistributor.NEAR.with(() -> new PacketDistributor.TargetPoint(
                pos.getX(), pos.getY(), pos.getZ(), 48, level.dimension())), new QuakePacket(ticks, intensity));
    }

    public static void sendQuakeTo(ServerPlayer player, int ticks, float intensity) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new QuakePacket(ticks, intensity));
    }

    private Net() {}
}
