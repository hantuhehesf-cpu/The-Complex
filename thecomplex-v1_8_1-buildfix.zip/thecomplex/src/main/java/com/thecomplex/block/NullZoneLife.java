package com.thecomplex.block;

import com.thecomplex.ModBlocks;
import com.thecomplex.activity.NullZoneSpawner;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;

/** Umur Null Zone liar: kedaluwarsa, tumbuh, dipicu, dan dipulihkan. */
public final class NullZoneLife {
    /** Jarak antar pertumbuhan otomatis (tick): 90 detik. */
    public static final int GROW_INTERVAL = 1800;
    /** Peluang (persen) Null Zone yang bisa tumbuh benar-benar tumbuh setelah dipakai, bukannya pulih. */
    public static final int GROW_ON_TRIGGER = 50;

    private NullZoneLife() {}

    public static void restore(ServerLevel level, BlockPos pos) {
        if (level.getBlockEntity(pos) instanceof NullZoneBlockEntity be && !be.isStable() && be.getOriginal() != null) {
            level.setBlock(pos, be.getOriginal(), 3);
        }
    }

    /** Tick terjadwal sebuah sel: pulih saat kedaluwarsa, atau (untuk jangkar yang bisa tumbuh) tumbuh dulu. */
    public static void onTick(ServerLevel level, BlockPos pos) {
        if (!(level.getBlockEntity(pos) instanceof NullZoneBlockEntity be)) return;
        if (be.isStable()) return;
        long now = level.getGameTime();
        long expires = be.getExpiresAt();
        if (expires == 0 || now >= expires - 1) {          // 0 = Null Zone versi lama: perilaku lama (langsung pulih)
            restore(level, pos);
            return;
        }
        if (be.isAnchor() && be.getGrowsLeft() > 0) {
            be.setGrowsLeft(be.getGrowsLeft() - 1);
            NullZoneSpawner.expand(level, pos, be);
        }
        long next = be.isAnchor() && be.getGrowsLeft() > 0 ? Math.min(expires - now, GROW_INTERVAL) : expires - now;
        level.scheduleTick(pos, ModBlocks.NULL_ZONE.get(), (int) Math.max(1, next));
    }

    /** Pemain baru saja menembus sel ini. Yang bisa tumbuh kadang tumbuh dan tetap ada; selainnya seluruh gugus pulih. */
    public static void onTriggered(ServerLevel level, BlockPos pos, NullZoneBlockEntity be) {
        if (be.isStable()) return;
        if (!be.hasAnchor()) {
            for (int dx = -1; dx <= 1; dx++)
                for (int dy = -1; dy <= 1; dy++)
                    for (int dz = -1; dz <= 1; dz++)
                        restore(level, pos.offset(dx, dy, dz));
            return;
        }
        BlockPos anchor = be.getAnchor();
        if (level.getBlockEntity(anchor) instanceof NullZoneBlockEntity a && a.isAnchor() && a.getGrowsLeft() > 0
                && level.random.nextInt(100) < GROW_ON_TRIGGER) {
            a.setGrowsLeft(a.getGrowsLeft() - 1);
            NullZoneSpawner.expand(level, anchor, a);
            return;
        }
        restoreCluster(level, anchor);
    }

    /** Pulihkan semua sel yang berjangkar di anchor. */
    public static void restoreCluster(ServerLevel level, BlockPos anchor) {
        int rad = 9;
        for (BlockPos q : BlockPos.betweenClosed(anchor.offset(-rad, -rad, -rad), anchor.offset(rad, rad, rad))) {
            if (!level.getBlockState(q).is(ModBlocks.NULL_ZONE.get())) continue;
            if (level.getBlockEntity(q) instanceof NullZoneBlockEntity b && !b.isStable() && b.hasAnchor() && b.getAnchorLong() == anchor.asLong()) {
                restore(level, q.immutable());
            }
        }
    }
}
