package com.thecomplex.world;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.thecomplex.ModBlocks;
import com.thecomplex.TheComplex;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.WorldGenRegion;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.LevelHeightAccessor;
import net.minecraft.world.level.NoiseColumn;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.biome.BiomeManager;
import net.minecraft.world.level.biome.BiomeSource;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.PositionalRandomFactory;
import net.minecraft.world.level.levelgen.RandomState;
import net.minecraft.world.level.levelgen.blending.Blender;

import java.util.EnumSet;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

import static com.thecomplex.world.ComplexLayout.*;

/**
 * Generator tanpa noise. Setiap chunk = satu sel 16x16.
 * Chunk memiliki sisi barat (x lokal 0) dan utara (z lokal 0) miliknya sendiri,
 * jadi tidak ada ketergantungan antar-chunk (tanpa state, aman untuk multithread).
 *
 * Status sisi: 0 = tembok, 1 = pintu selebar 4 di offset 6..9, 2 = terbuka penuh (aula besar).
 * Tinggi udara 3 sampai 6 blok, sama di seluruh slot SLOT x SLOT chunk.
 */
public class ComplexChunkGenerator extends ChunkGenerator {
    public static final Codec<ComplexChunkGenerator> CODEC = RecordCodecBuilder.create(i -> i.group(
            BiomeSource.CODEC.fieldOf("biome_source").forGetter(g -> g.biomeSource)
    ).apply(i, i.stable(ComplexChunkGenerator::new)));

    private static final ResourceLocation LAYOUT = new ResourceLocation(TheComplex.MODID, "layout");

    private final BlockState bedrock = Blocks.BEDROCK.defaultBlockState();
    private final BlockState air = Blocks.AIR.defaultBlockState();
    private final BlockState wall = ModBlocks.WALLPAPER.get().defaultBlockState();
    private final BlockState carpet = ModBlocks.CARPET_FLOOR.get().defaultBlockState();
    private final BlockState tile = ModBlocks.CEILING_TILE.get().defaultBlockState();
    private final BlockState light = ModBlocks.FLUORESCENT_PANEL.get().defaultBlockState();

    public ComplexChunkGenerator(BiomeSource source) {
        super(source);
    }

    @Override
    protected Codec<? extends ChunkGenerator> codec() {
        return CODEC;
    }

    @Override
    public CompletableFuture<ChunkAccess> fillFromNoise(Executor executor, Blender blender, RandomState rs,
                                                        StructureManager sm, ChunkAccess chunk) {
        PositionalRandomFactory f = rs.getOrCreateRandomFactory(LAYOUT);
        int cx = chunk.getPos().x, cz = chunk.getPos().z;
        if (ComplexLayout.reserved(cx, cz)) {
            fillReserved(chunk, f);
        } else {
            RoomPlacement room = ComplexLayout.roomAt(f, cx, cz);
            Division div = Division.at(f, cx, cz);
            if (room != null) {
                fillRoomChunk(chunk, room, f, div);
            } else {
                fillProcedural(chunk, f, div);
            }
        }
        Heightmap.primeHeightmaps(chunk, EnumSet.of(Heightmap.Types.OCEAN_FLOOR_WG, Heightmap.Types.WORLD_SURFACE_WG));
        return CompletableFuture.completedFuture(chunk);
    }

    // ---------------------------------------------------------------- Main Chamber

    private void fillReserved(ChunkAccess chunk, PositionalRandomFactory f) {
        if (ComplexLayout.hasCustomMainChamber()) {
            // Main Chamber buatanmu: bagian chunk di luar schematic (sisa pembulatan ke chunk) diisi Backrooms prosedural biasa,
            // lengkap dengan dinding dan lampu, lalu schematic ditempel di atasnya.
            fillProcedural(chunk, f, Division.at(f, chunk.getPos().x, chunk.getPos().z));
            ComplexLayout.apply(chunk);
            return;
        }
        int top = ComplexLayout.reservedTop();
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        int x0 = chunk.getPos().getMinBlockX(), z0 = chunk.getPos().getMinBlockZ();
        for (int lx = 0; lx < 16; lx++) {
            for (int lz = 0; lz < 16; lz++) {
                int x = x0 + lx, z = z0 + lz;
                for (int y = 0; y < FLOOR_Y; y++) chunk.setBlockState(p.set(x, y, z), bedrock, false);
                for (int y = FLOOR_Y; y <= top; y++) chunk.setBlockState(p.set(x, y, z), wall, false);
                for (int y = top + 1; y <= TOP_Y; y++) chunk.setBlockState(p.set(x, y, z), bedrock, false);
            }
        }
        ComplexLayout.apply(chunk);
    }

    // ---------------------------------------------------------------- ruangan buatan (.schem)

    private void fillRoomChunk(ChunkAccess chunk, RoomPlacement rp, PositionalRandomFactory f, Division div) {
        // dasar prosedural dulu (supaya sisa chunk di luar ruangan tidak kosong), lalu ruangan ditempel di atasnya
        fillProcedural(chunk, f, div);
        rp.room().placeInChunk(chunk, rp.minCx() * 16, FLOOR_Y, rp.minCz() * 16);
    }

    // ---------------------------------------------------------------- procedural Backrooms

    private BlockState famBlock(byte fam) {
        return fam == BackroomsDesigner.WHITE ? ModBlocks.WHITE_WALL.get().defaultBlockState()
                : fam == BackroomsDesigner.OFFICE ? ModBlocks.OFFICE_WALL.get().defaultBlockState() : wall;
    }

    private static boolean office(byte fam) {
        return fam != BackroomsDesigner.CLASSIC;
    }

    private void fillProcedural(ChunkAccess chunk, PositionalRandomFactory f, Division div) {
        int cx = chunk.getPos().x, cz = chunk.getPos().z;
        int x0 = chunk.getPos().getMinBlockX(), z0 = chunk.getPos().getMinBlockZ();

        // One ceiling height for the whole division, so there is no step in the middle of a hall.
        int ceilY = FLOOR_Y + 1 + div.air;

        BackroomsDesigner.Plan plan = BackroomsDesigner.design(f, cx, cz, div, ComplexLayout.boxesNear(f, cx, cz), x0, z0);

        RandomSource lr = f.at(cx, 3, cz);
        boolean dark = lr.nextInt(100) < div.darkChance || div.noLights;  // fully dark chunk; "No Lighting Tile" division: always
        boolean[][] lit = new boolean[16][16];
        for (int px : new int[]{3, 11}) {
            for (int pz : new int[]{3, 11}) {
                boolean on = lr.nextInt(100) >= div.deadPanel;  // dead panel
                if (on && !dark) { lit[px][pz] = true; lit[px + 1][pz] = true; }
            }
        }

        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        int y1 = FLOOR_Y + 1;
        for (int lx = 0; lx < 16; lx++) {
            for (int lz = 0; lz < 16; lz++) {
                int x = x0 + lx, z = z0 + lz, i = lz * 16 + lx;
                byte kind = plan.kind[i], fam = plan.fam[i];
                int d = plan.dir[i];
                for (int y = 0; y < FLOOR_Y; y++) chunk.setBlockState(p.set(x, y, z), bedrock, false);
                chunk.setBlockState(p.set(x, FLOOR_Y, z), kind == BackroomsDesigner.WALL ? famBlock(fam) : carpet, false);
                switch (kind) {
                    case BackroomsDesigner.WALL -> {
                        for (int y = y1; y < ceilY; y++) chunk.setBlockState(p.set(x, y, z), famBlock(fam), false);
                    }
                    case BackroomsDesigner.PILLAR -> {
                        BlockState s = (office(fam) ? ModBlocks.OFFICE_WALL_PILLAR : ModBlocks.WALLPAPER_PILLAR).get().defaultBlockState();
                        for (int y = y1; y < ceilY; y++) chunk.setBlockState(p.set(x, y, z), s, false);
                    }
                    case BackroomsDesigner.HALF_PILLAR -> {
                        BlockState s = (office(fam) ? ModBlocks.OFFICE_WALL_HALF_PILLAR : ModBlocks.WALLPAPER_HALF_PILLAR).get().defaultBlockState()
                                .setValue(com.thecomplex.block.HalfPillarBlock.FACING, net.minecraft.core.Direction.from2DDataValue(d));
                        for (int y = y1; y < ceilY; y++) chunk.setBlockState(p.set(x, y, z), s, false);
                    }
                    case BackroomsDesigner.VSLAB -> {
                        BlockState s = (office(fam) ? ModBlocks.OFFICE_WALL_VERTICAL_SLAB : ModBlocks.WALLPAPER_VERTICAL_SLAB).get().defaultBlockState()
                                .setValue(com.thecomplex.block.VerticalSlabBlock.FACING, net.minecraft.core.Direction.from2DDataValue(d));
                        for (int y = y1; y < ceilY; y++) chunk.setBlockState(p.set(x, y, z), s, false);
                    }
                    // doorway: the lintel row is the top air layer; the Left/Right arch pair sits over the center two cells
                    case BackroomsDesigner.LINTEL -> chunk.setBlockState(p.set(x, ceilY - 1, z), famBlock(fam), false);
                    case BackroomsDesigner.ARCH_L, BackroomsDesigner.ARCH_R -> chunk.setBlockState(p.set(x, ceilY - 1, z),
                            (kind == BackroomsDesigner.ARCH_L
                                    ? (office(fam) ? ModBlocks.OFFICE_WALL_ARCH_LEFT : ModBlocks.WALLPAPER_ARCH_LEFT)
                                    : (office(fam) ? ModBlocks.OFFICE_WALL_ARCH_RIGHT : ModBlocks.WALLPAPER_ARCH_RIGHT)).get().defaultBlockState()
                                    .setValue(com.thecomplex.block.ArchPieceBlock.FACING, net.minecraft.core.Direction.from2DDataValue(d)), false);
                    default -> { }
                }
                chunk.setBlockState(p.set(x, ceilY, z), lit[lx][lz] ? light : tile, false);
                for (int y = ceilY + 1; y <= TOP_Y; y++) chunk.setBlockState(p.set(x, y, z), y >= TOP_Y - 1 ? bedrock : wall, false);
            }
        }
    }

    // ---------------------------------------------------------------- boilerplate ChunkGenerator

    @Override
    public void applyCarvers(WorldGenRegion region, long seed, RandomState rs, BiomeManager bm,
                             StructureManager sm, ChunkAccess chunk, GenerationStep.Carving step) {}

    @Override
    public void buildSurface(WorldGenRegion region, StructureManager sm, RandomState rs, ChunkAccess chunk) {}

    @Override
    public void spawnOriginalMobs(WorldGenRegion region) {}

    @Override
    public int getGenDepth() {
        return 32;
    }

    @Override
    public int getSeaLevel() {
        return 0;
    }

    @Override
    public int getMinY() {
        return 0;
    }

    @Override
    public int getBaseHeight(int x, int z, Heightmap.Types type, LevelHeightAccessor level, RandomState rs) {
        return FLOOR_Y + 1;
    }

    @Override
    public NoiseColumn getBaseColumn(int x, int z, LevelHeightAccessor level, RandomState rs) {
        return new NoiseColumn(level.getMinBuildHeight(), new BlockState[0]);
    }

    @Override
    public void addDebugScreenInfo(List<String> info, RandomState rs, BlockPos pos) {}
}
