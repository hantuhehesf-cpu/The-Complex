package com.thecomplex.client;

import com.thecomplex.dev.DevActions;
import com.thecomplex.net.DevActionPacket;
import com.thecomplex.net.Net;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.List;

/** Developer UI: semua uji coba lewat tombol, tanpa mengetik command. Dibuka dengan item "Complex Dev Tool" (klik kanan). */
public class DevScreen extends Screen {
    private static int page = 0;
    private static int roomIndex = 0;

    private final String status;
    private final List<String> rooms;
    private final List<String> zones;     // "id|teks"

    public DevScreen(String status, List<String> rooms, List<String> zones) {
        super(Component.literal("The Complex - Dev"));
        this.status = status;
        this.rooms = rooms;
        this.zones = zones;
        if (roomIndex >= rooms.size()) roomIndex = 0;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private void send(int action, String arg) {
        Net.CHANNEL.sendToServer(new DevActionPacket(action, arg));
    }

    private int colWidth() {
        return Math.min(150, (width - 20) / 2);
    }

    private void button(String label, int col, int row, Button.OnPress press) {
        int bw = colWidth();
        int x = width / 2 - bw - 2 + col * (bw + 4);
        int y = 74 + row * 22;
        addRenderableWidget(Button.builder(Component.literal(label), press).bounds(x, y, bw, 20).build());
    }

    private void action(String label, int col, int row, int action) {
        button(label, col, row, b -> send(action, ""));
    }

    @Override
    protected void init() {
        String[] tabs = {"Enter", "Null Zone", "Tracker", "Rooms", "LPMDS", "Case", "Close"};
        int tw = Math.min(80, (width - 10) / tabs.length);
        int tx = (width - tw * tabs.length) / 2;
        for (int i = 0; i < tabs.length; i++) {
            final int idx = i;
            addRenderableWidget(Button.builder(Component.literal(tabs[i]), b -> {
                if (idx == tabs.length - 1) {
                    onClose();
                } else {
                    page = idx;
                    rebuildWidgets();
                }
            }).bounds(tx + i * tw, 50, tw, 18).build());
        }

        switch (page) {
            case 0 -> {
                action("Enter Main Chamber", 0, 0, DevActions.ENTER);
                action("Random Backrooms", 1, 0, DevActions.BACKROOMS);
                action("Leave to Overworld", 0, 1, DevActions.LEAVE);
                action("Refresh status", 1, 1, DevActions.REFRESH);
                action("Toggle creative / survival", 0, 2, DevActions.TOGGLE_MODE);
                action("Restore health & hunger", 1, 2, DevActions.HEAL);
            }
            case 1 -> {
                action("Null Zone (random)", 0, 0, DevActions.NZ_ANY);
                action("Null Zone on floor", 1, 0, DevActions.NZ_FLOOR);
                action("Null Zone on wall", 0, 1, DevActions.NZ_WALL);
                action("Heat this chunk +240", 1, 1, DevActions.HEAT_BOOST);
                action("Clear heat log", 0, 2, DevActions.HEAT_RESET);
                action("Stable Wild Null Zone", 1, 2, DevActions.NZ_STABLE);
                action("Null Zone on grass/dirt", 0, 3, DevActions.NZ_GROUND);
            }
            case 2 -> {
                action("Teleport to nearest", 0, 0, DevActions.ZONE_NEAREST);
                action("Restore all", 1, 0, DevActions.ZONES_CLEAR);
                int bw = colWidth() * 2 + 4;
                int x = width / 2 - bw / 2;
                for (int i = 0; i < Math.min(3, zones.size()); i++) {
                    String entry = zones.get(i);
                    int bar = entry.indexOf('|');
                    String id = bar < 0 ? "" : entry.substring(0, bar);
                    String text = bar < 0 ? entry : entry.substring(bar + 1);
                    addRenderableWidget(Button.builder(Component.literal(text), b -> send(DevActions.ZONE_TP, id))
                            .bounds(x, 74 + (i + 1) * 22, bw, 20).build());
                }
            }
            case 4 -> {
                action("Give LPMDS set", 0, 0, DevActions.LPMDS_GIVE);
                action("Fill power", 1, 0, DevActions.LPMDS_CHARGE);
                action("Mark failed tests done", 0, 1, DevActions.LPMDS_SKIP);
                action("Force-open Threshold", 1, 1, DevActions.LPMDS_OPEN);
                action("Close Threshold", 0, 2, DevActions.LPMDS_CLOSE);
                action("Reset machine", 1, 2, DevActions.LPMDS_RESET);
                action("Nearest machine info", 0, 3, DevActions.LPMDS_INFO);
                action("Natural Null Zones ON/OFF", 1, 3, DevActions.LPMDS_FLAG);
            }
            case 5 -> {
                action("Give Briefcase set", 0, 0, DevActions.BRIEFCASE_GIVE);
                action("Recall Briefcases on the ground", 1, 0, DevActions.BRIEFCASE_RECALL);
            }
            default -> {
                int bw = colWidth();
                int cx = width / 2;
                addRenderableWidget(Button.builder(Component.literal("<"), b -> {
                    if (!rooms.isEmpty()) roomIndex = (roomIndex - 1 + rooms.size()) % rooms.size();
                    rebuildWidgets();
                }).bounds(cx - bw - 2, 74, 30, 20).build());
                addRenderableWidget(Button.builder(Component.literal(">"), b -> {
                    if (!rooms.isEmpty()) roomIndex = (roomIndex + 1) % rooms.size();
                    rebuildWidgets();
                }).bounds(cx + bw + 2 - 30, 74, 30, 20).build());
                button("Paste here", 0, 1, b -> {
                    if (!rooms.isEmpty()) send(DevActions.ROOM_PASTE, rooms.get(roomIndex));
                });
                action("Reload rooms", 1, 1, DevActions.ROOM_RELOAD);
            }
        }
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        int y = 4;
        for (String line : status.split("\n")) {
            g.drawString(font, font.plainSubstrByWidth(line, width - 16), 8, y, 0xFFFFFF);
            y += 9;
        }
        if (page == 2) {
            String hint = zones.isEmpty()
                    ? "No Null Zones recorded yet. Create one from the Null Zone tab."
                    : "Tap a row to teleport. Hold the Dev Tool: compass in the action bar + light sparks.";
            g.drawCenteredString(font, font.plainSubstrByWidth(hint, width - 16), width / 2, 74 + 22 + (zones.isEmpty() ? 6 : 78), 0xAAAAAA);
        }
        if (page == 3) {
            String name = rooms.isEmpty() ? "(no rooms yet)" : (roomIndex + 1) + "/" + rooms.size() + "  " + rooms.get(roomIndex);
            g.drawCenteredString(font, font.plainSubstrByWidth(name, width - 80), width / 2, 80, 0xFFFFAA);
        }
        super.render(g, mouseX, mouseY, partialTick);
    }
}
