package com.thecomplex.portal;

import com.thecomplex.ComplexTeleporter;
import com.thecomplex.ModBlocks;
import com.thecomplex.TheComplex;
import com.thecomplex.activity.NullZoneSpawner;
import com.thecomplex.block.NullZoneBlockEntity;
import com.thecomplex.world.ComplexLayout;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/**
 * Stable Wild Null Zone: pintu dinding yang sangat langka, permanen, dua arah (seperti Threshold yang menyamar).
 * Ujung satunya ada jauh di dalam The Complex, jauh dari Main Chamber. Lewat dari mana pun, keluar di ujung yang lain.
 */
public final class WildPortals {
    public static final int MAX_PAIRS = 6;

    private WildPortals() {}

    private record FarEnd(BlockPos cell, Direction normal) {}

    /**
     * Buat ujung seberang di The Complex untuk Stable Wild Null Zone di (originCell, normal) dan catat pasangannya.
     * Ujung Overworld ditaruh oleh pemanggil. Mengembalikan id pasangan, atau -1 kalau gagal (tidak ada tempat / sudah penuh).
     */
    public static int createPair(ServerLevel origin, BlockPos originCell, Direction normal, RandomSource r) {
        MinecraftServer server = origin.getServer();
        if (server == null) return -1;
        ServerLevel complex = server.getLevel(TheComplex.COMPLEX);
        WildPortalData data = WildPortalData.get(server);
        if (complex == null || data.count() >= MAX_PAIRS) return -1;
        FarEnd far = findFarEnd(complex, r);
        if (far == null) return -1;
        int id = data.reserve();
        BlockPos a = far.cell();
        Direction d = far.normal();
        double plane = NullZoneSpawner.planeOf(d, a.getX() + 0.5, a.getY() + 0.5, a.getZ() + 0.5);
        NullZoneSpawner.placeCell(complex, a, d, plane, a.asLong(), 0, true, id, 1, 0, true);
        NullZoneSpawner.placeCell(complex, a.above(), d, plane, a.asLong(), 0, true, id, 1, 0, false);
        data.put(new WildPortalData.Pair(id,
                new WildPortalData.End(origin.dimension().location().toString(), originCell.asLong(), normal.get3DDataValue()),
                new WildPortalData.End(TheComplex.COMPLEX.location().toString(), a.asLong(), d.get3DDataValue())));
        return id;
    }

    /**
     * Finds a Backrooms wall for the far end of a Stable Wild Null Zone: open floor in front, far from the Main Chamber.
     * The wall must be at least 2 blocks thick (v1.8): the two cells that become the portal (a and the cell above it) need
     * a solid wall layer behind them as well. With a 1-block wall the far side of the portal would open into the next
     * room, and someone standing there could walk into the portal from behind or see a one-block "ghost" wall.
     */
    private static FarEnd findFarEnd(ServerLevel complex, RandomSource r) {
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        int baseCx = (int) Math.floor(ComplexLayout.chamberCenterX() / 16.0);
        int baseCz = (int) Math.floor(ComplexLayout.chamberCenterZ() / 16.0);
        for (int tries = 0; tries < 24; tries++) {
            int cx = baseCx + (14 + r.nextInt(30)) * (r.nextBoolean() ? 1 : -1);
            int cz = baseCz + (14 + r.nextInt(30)) * (r.nextBoolean() ? 1 : -1);
            complex.getChunk(cx, cz);
            // thick walls are less common than thin ones, so look at more cells per chunk (cheap: no chunk loading)
            for (int i = 0; i < 200; i++) {
                int x = cx * 16 + 1 + r.nextInt(14);
                int z = cz * 16 + 1 + r.nextInt(14);
                m.set(x, ComplexLayout.FLOOR_Y + 1, z);
                if (!complex.getBlockState(m).isAir() || !complex.getBlockState(m.above()).isAir()
                        || !complex.getBlockState(m.below()).is(ModBlocks.CARPET_FLOOR.get())) continue;
                BlockPos floor = m.immutable();
                for (Direction d : new Direction[]{Direction.NORTH, Direction.EAST, Direction.SOUTH, Direction.WEST}) {
                    BlockPos a = floor.relative(d);
                    if (isThickWall(complex, a, d)) return new FarEnd(a, d);
                }
            }
        }
        return null;
    }

    /** Cell a and the cell above it are wall, and so are the two cells directly behind them (wall at least 2 thick). */
    private static boolean isThickWall(ServerLevel level, BlockPos a, Direction d) {
        BlockPos back = a.relative(d);
        // all four cells must be in the same loaded area; never force a chunk to load here
        if (!level.hasChunkAt(a) || !level.hasChunkAt(back)) return false;
        return isBackroomsWall(level.getBlockState(a)) && isBackroomsWall(level.getBlockState(a.above()))
                && isBackroomsWall(level.getBlockState(back)) && isBackroomsWall(level.getBlockState(back.above()));
    }

    private static boolean isBackroomsWall(BlockState s) {
        return s.is(ModBlocks.WALLPAPER.get()) || s.is(ModBlocks.OFFICE_WALL.get()) || s.is(ModBlocks.WHITE_WALL.get());
    }

    /** Ujung lain dari pasangan nz: dunia, sel, dan normal-nya. Null kalau pasangan tidak ditemukan. */
    public static WildPortalData.End otherEnd(MinecraftServer server, NullZoneBlockEntity nz) {
        WildPortalData.Pair pair = WildPortalData.get(server).get(nz.getPairId());
        if (pair == null) return null;
        return nz.getEnd() == 0 ? pair.complex() : pair.overworld();
    }

    public static ServerLevel levelOf(MinecraftServer server, WildPortalData.End end) {
        ResourceLocation id = ResourceLocation.tryParse(end.dim());
        return id == null ? null : server.getLevel(ResourceKey.create(Registries.DIMENSION, id));
    }

    /** Pemain menembus bidang sebuah Stable Wild Null Zone. travel = arah gerak (horizontal), vel = kecepatan per tick. */
    public static void cross(ServerPlayer p, NullZoneBlockEntity nz, Vec3 travel, Vec3 vel) {
        MinecraftServer server = p.server;
        WildPortalData.End other = otherEnd(server, nz);
        if (other == null) return;
        ServerLevel dest = levelOf(server, other);
        if (dest == null) return;
        BlockPos oc = BlockPos.of(other.cell());
        Direction on = Direction.from3DDataValue(other.normal());
        dest.getChunk(oc.getX() >> 4, oc.getZ() >> 4);
        // keluar di sisi ruangan dinding tujuan, sedikit di dalam sel (belum melewati bidangnya)
        Vec3 exit = new Vec3(-on.getStepX(), 0, -on.getStepZ());
        double relY = Mth.clamp(p.getY() - nz.getAnchor().getY(), 0.0, 1.0);
        Vec3 np = new Vec3(oc.getX() + 0.5 + exit.x * 0.45, oc.getY() + relY, oc.getZ() + 0.5 + exit.z * 0.45);
        np = ComplexTeleporter.settle(dest, p, np, exit);
        double dyaw = ComplexTeleporter.yawOf(exit) - ComplexTeleporter.yawOf(travel);
        float yaw = Mth.wrapDegrees((float) (p.getYRot() + dyaw));
        if (nz.getEnd() == 0) ComplexTeleporter.rememberReturn(p, null, Direction.NORTH);
        Seamless.send(p, dest, np, yaw, p.getXRot(), ComplexTeleporter.rotateYaw(vel, dyaw), Seamless.STYLE_WILD);
    }
}
