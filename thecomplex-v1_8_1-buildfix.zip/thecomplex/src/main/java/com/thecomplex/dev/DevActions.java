package com.thecomplex.dev;

import com.thecomplex.ComplexTeleporter;
import com.thecomplex.ModBlocks;
import com.thecomplex.activity.ActivityData;
import com.thecomplex.activity.ActivityTracker;
import com.thecomplex.activity.NullZoneSpawner;
import com.thecomplex.activity.NullZoneTracker;
import com.thecomplex.lpmds.LpmdsBlockEntity;
import com.thecomplex.net.Net;
import com.thecomplex.net.OpenDevPacket;
import com.thecomplex.world.Schem;
import com.thecomplex.world.SchemStore;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Semua tombol di Developer UI berujung di sini (dijalankan di server, setelah dicek izinnya). */
public final class DevActions {
    public static final int ENTER = 0, BACKROOMS = 1, LEAVE = 2, REFRESH = 3,
            NZ_ANY = 4, NZ_FLOOR = 5, NZ_WALL = 6, HEAT_BOOST = 7, HEAT_RESET = 8,
            ROOM_PASTE = 14, ROOM_RELOAD = 15,
            ZONE_TP = 16, ZONE_NEAREST = 17, ZONES_CLEAR = 18, TOGGLE_MODE = 19, HEAL = 20,
            LPMDS_CHARGE = 21, LPMDS_SKIP = 22, LPMDS_RESET = 23, LPMDS_OPEN = 24, LPMDS_CLOSE = 25, LPMDS_GIVE = 26, LPMDS_INFO = 27, LPMDS_FLAG = 28,
            BRIEFCASE_GIVE = 29, BRIEFCASE_RECALL = 30,
            NZ_STABLE = 31, NZ_GROUND = 32;

    private DevActions() {}

    public static boolean allowed(ServerPlayer p) {
        return p.hasPermissions(2) || p.isCreative();
    }

    private static void msg(ServerPlayer p, String text) {
        p.sendSystemMessage(Component.literal("[Complex] " + text));
    }

    public static void handle(ServerPlayer p, int action, String arg) {
        if (!allowed(p)) {
            msg(p, "Operators or creative mode only.");
            return;
        }
        ServerLevel ow = p.server.overworld();
        ServerLevel level = p.serverLevel();
        RandomSource r = p.getRandom();
        switch (action) {
            case ENTER -> ComplexTeleporter.toArrival(p);
            case BACKROOMS -> ComplexTeleporter.toBackrooms(p);
            case LEAVE -> ComplexTeleporter.leave(p);
            case NZ_ANY, NZ_FLOOR, NZ_WALL -> {
                int mode = action == NZ_FLOOR ? NullZoneSpawner.MODE_FLOOR
                        : action == NZ_WALL ? NullZoneSpawner.MODE_WALL : NullZoneSpawner.MODE_ANY;
                boolean ok = NullZoneSpawner.spawnFor(p, ActivityData.get(ow), mode);
                msg(p, ok ? "Null Zone created near you." : "No suitable spot. Stand inside a roofed building.");
            }
            case NZ_STABLE -> {
                boolean ok = NullZoneSpawner.spawnFor(p, ActivityData.get(ow), NullZoneSpawner.MODE_STABLE);
                msg(p, ok ? "Stable Wild Null Zone created near you." : "No suitable spot (stand inside a roofed building), or the limit is reached.");
            }
            case NZ_GROUND -> {
                boolean ok = NullZoneSpawner.spawnFor(p, ActivityData.get(ow), NullZoneSpawner.MODE_GROUND);
                msg(p, ok ? "Null Zone created on grass/dirt near you." : "No suitable grass or dirt. Stand outside.");
            }
            case HEAT_BOOST -> {
                ActivityData.get(ow).boost(p.getUUID(), p.chunkPosition(), 240f);
                msg(p, "Heat at this chunk +240.");
            }
            case HEAT_RESET -> {
                ActivityData.get(ow).clear(p.getUUID());
                msg(p, "Your activity log was cleared.");
            }
            case ROOM_PASTE -> {
                Schem s = SchemStore.find(arg);
                if (s == null) {
                    msg(p, "Room not found: " + arg);
                } else {
                    s.placeInLevel(level, p.blockPosition().below());
                    msg(p, "Pasted: " + s.name + " (" + s.width + "x" + s.height + "x" + s.length + ")");
                }
            }
            case ROOM_RELOAD -> msg(p, "Reloaded: " + SchemStore.reloadRooms() + " rooms.");
            case ZONE_TP, ZONE_NEAREST -> {
                NullZoneTracker.Entry en = null;
                if (action == ZONE_NEAREST) {
                    en = NullZoneTracker.nearest(p);
                } else {
                    try {
                        en = NullZoneTracker.find(Long.parseLong(arg));
                    } catch (NumberFormatException ignored) {
                        // id tidak valid
                    }
                }
                if (en == null) {
                    msg(p, "Null Zone not found (it may have already recovered).");
                } else {
                    ServerLevel target = p.server.getLevel(en.dim());
                    if (target == null) {
                        msg(p, "That dimension is not available.");
                    } else {
                        BlockPos spot = ComplexTeleporter.safeSpotNear(target, en.pos(), 2);
                        float yaw = ComplexTeleporter.yawToward(spot, en.pos().getX() + 0.5, en.pos().getZ() + 0.5);
                        p.teleportTo(target, spot.getX() + 0.5, spot.getY(), spot.getZ() + 0.5, yaw, 0f);
                        msg(p, "Teleported near Null Zone " + en.kind() + " at " + en.pos().toShortString());
                    }
                }
            }
            case ZONES_CLEAR -> msg(p, NullZoneTracker.clearAll(p.server) + " wild Null Zones restored.");
            case TOGGLE_MODE -> {
                boolean toCreative = !p.isCreative();
                p.setGameMode(toCreative ? GameType.CREATIVE : GameType.SURVIVAL);
                msg(p, toCreative ? "Creative mode." : "Survival mode.");
            }
            case HEAL -> {
                p.setHealth(p.getMaxHealth());
                p.getFoodData().setFoodLevel(20);
                p.getFoodData().setSaturation(20f);
                msg(p, "Health and hunger restored.");
            }
            case BRIEFCASE_GIVE -> {
                p.getInventory().add(new ItemStack(com.thecomplex.ModItems.BRIEFCASE.get()));
                p.getInventory().add(com.thecomplex.item.FlashlightItem.charged());
                p.getInventory().add(new ItemStack(com.thecomplex.ModItems.FLASHLIGHT_BATTERY.get(), 4));
                p.getInventory().add(new ItemStack(com.thecomplex.ModItems.DUCT_TAPE.get()));
                p.getInventory().add(new ItemStack(com.thecomplex.ModItems.DUCT_TAPE.get()));
                p.getInventory().add(new ItemStack(ModBlocks.DUCT_ANCHOR.get(), 2));
                p.getInventory().add(new ItemStack(com.thecomplex.ModItems.ROPE.get()));
                msg(p, "Given: Briefcase, Flashlight (full), 4 batteries, 2 Duct Tape, 2 Duct Anchor, Rope.");
            }
            case BRIEFCASE_RECALL -> {
                int n = 0;
                for (com.thecomplex.briefcase.BriefcaseEntity be : level.getEntitiesOfClass(com.thecomplex.briefcase.BriefcaseEntity.class,
                        p.getBoundingBox().inflate(48))) {
                    if (!p.getInventory().add(be.getStack().copy())) break;
                    be.discard();
                    n++;
                }
                msg(p, n + " Briefcase(s) on the ground (radius 48) returned to your inventory.");
            }
            case LPMDS_GIVE -> {
                p.getInventory().add(new ItemStack(ModBlocks.LPMDS.get()));
                p.getInventory().add(new ItemStack(ModBlocks.LPMDS_CHUTE.get()));
                p.getInventory().add(new ItemStack(com.thecomplex.ModItems.LPMDS_MARKER.get()));
                msg(p, "Given: LPMDS, Emitter Chute, Magnetic Marker.");
            }
            case LPMDS_CHARGE, LPMDS_SKIP, LPMDS_RESET, LPMDS_OPEN, LPMDS_CLOSE, LPMDS_INFO -> {
                LpmdsBlockEntity be = LpmdsBlockEntity.findNear(level, p.blockPosition(), 10);
                if (be == null) {
                    msg(p, "No LPMDS within 10 blocks.");
                } else if (action == LPMDS_CHARGE) {
                    be.devCharge();
                    msg(p, "Nearest LPMDS power filled.");
                } else if (action == LPMDS_SKIP) {
                    be.devSkipTests();
                    msg(p, "Failed tests marked done: the next test is the final test.");
                } else if (action == LPMDS_RESET) {
                    be.devReset(level);
                    msg(p, "Nearest LPMDS reset (test 0, power 0, marking cleared).");
                } else if (action == LPMDS_OPEN) {
                    be.devForceOpen(level);
                    msg(p, "Force-opening the Threshold.");
                } else if (action == LPMDS_CLOSE) {
                    be.closeFrame(level, true);
                    msg(p, "Threshold closed.");
                } else {
                    msg(p, be.statusLine(level));
                }
            }
            case LPMDS_FLAG -> {
                ActivityData d = ActivityData.get(ow);
                d.setActivated(!d.isActivated());
                msg(p, "Natural Null Zones: " + (d.isActivated() ? "ON (treated as if the LPMDS was activated)." : "OFF (waiting for the LPMDS to be activated)."));
            }
            default -> { }
        }
        sendOpen(p);
    }

    public static String status(ServerPlayer p) {
        ActivityData d = ActivityData.get(p.server.overworld());
        float heat = d.heatAt(p.getUUID(), p.chunkPosition());
        long oneIn = Math.round(1.0 / ActivityTracker.chance(heat));
        return "Dimension: " + p.level().dimension().location() + "\n"
                + SchemStore.mainChamberStatus() + "\n"
                + "Rooms: " + SchemStore.rooms().size()
                + " | Tracked Null Zones: " + NullZoneTracker.forPlayer(p).size() + "\n"
                + "Position: " + p.blockPosition().toShortString() + " | Natural Null Zones: " + (d.isActivated() ? "on" : "off (LPMDS not active yet)") + "\n"
                + String.format(Locale.ROOT, "Heat at this chunk: %.1f (Null Zone about 1/%d per 10 seconds)", heat, oneIn);
    }

    public static void sendOpen(ServerPlayer p) {
        List<String> names = new ArrayList<>();
        for (Schem s : SchemStore.rooms()) names.add(s.name);
        List<String> zones = new ArrayList<>();
        for (NullZoneTracker.Entry e : NullZoneTracker.forPlayer(p)) {
            if (zones.size() >= 6) break;
            zones.add(e.id() + "|" + NullZoneTracker.describe(p, e));
        }
        Net.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), new OpenDevPacket(status(p), names, zones));
    }
}
