package com.thecomplex.tape;

import com.thecomplex.ModBlocks;
import com.thecomplex.ModItems;
import com.thecomplex.TheComplex;
import com.thecomplex.block.DuctAnchorBlock;
import com.thecomplex.block.DuctTapeBlock;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Alur Duct Tape (sekarang berupa BLOK di lantai, seperti Redstone):
 *  1. Pegang Duct Tape, klik kanan anchor awal: sesi dimulai.
 *  2. Jalan LURUS (satu sumbu). Blok tape terpasang di lantai tepat di tempat kamu berjalan, 1 roll = 8 blok.
 *  3. Pasang anchor kedua tepat sejajar, klik kanan: sisa celah ditutup dan tape selesai.
 * Setiap blok tape bisa dihancurkan sendiri-sendiri.
 */
@Mod.EventBusSubscriber(modid = TheComplex.MODID)
public final class TapeEvents {
    public static final int MAX_LEN = 64;

    public static final class Session {
        public final BlockPos a;
        public int axis = -1;   // 0 = sumbu X, 1 = sumbu Z
        public int dir;         // +1 / -1
        public int next = 1;    // petak berikutnya yang perlu diisi (0 = anchor awal)

        Session(BlockPos a) {
            this.a = a;
        }

        public BlockPos cell(int k, int y) {
            return axis == 0 ? new BlockPos(a.getX() + k * dir, y, a.getZ()) : new BlockPos(a.getX(), y, a.getZ() + k * dir);
        }
    }

    private static final Map<UUID, Session> SESSIONS = new HashMap<>();
    private static final Map<UUID, Long> WARNED = new HashMap<>();

    private TapeEvents() {}

    public static void msg(ServerPlayer p, String text) {
        p.displayClientMessage(Component.literal("[Tape] " + text), true);
    }

    private static void warn(ServerPlayer p, String text) {
        long now = p.level().getGameTime();
        if (now - WARNED.getOrDefault(p.getUUID(), -100L) > 60) {
            WARNED.put(p.getUUID(), now);
            msg(p, text);
        }
    }

    public static Session sessionOf(ServerPlayer p) {
        return SESSIONS.get(p.getUUID());
    }

    public static void begin(ServerPlayer p, BlockPos anchor) {
        SESSIONS.put(p.getUUID(), new Session(anchor));
    }

    public static void end(ServerPlayer p) {
        SESSIONS.remove(p.getUUID());
    }

    /** Pakai 1 blok dari roll mana pun yang dibawa (tangan dulu). false = tidak ada roll. */
    public static boolean consumeUnit(ServerPlayer p) {
        ItemStack main = p.getMainHandItem(), off = p.getOffhandItem();
        if (main.is(ModItems.DUCT_TAPE.get())) return use(p, main);
        if (off.is(ModItems.DUCT_TAPE.get())) return use(p, off);
        for (int i = 0; i < p.getInventory().items.size(); i++) {
            ItemStack s = p.getInventory().items.get(i);
            if (s.is(ModItems.DUCT_TAPE.get())) return use(p, s);
        }
        return false;
    }

    private static boolean use(ServerPlayer p, ItemStack roll) {
        roll.hurtAndBreak(1, p, x -> {});
        return true;
    }

    /** Cari tinggi lantai untuk satu petak: sel kosong dengan permukaan padat di bawahnya. */
    private static int findY(ServerLevel level, int x, int z, double yRef) {
        int ref = (int) Math.floor(yRef + 0.01);
        for (int dy : new int[]{0, 1, -1, -2}) {
            BlockPos pos = new BlockPos(x, ref + dy, z);
            BlockState st = level.getBlockState(pos);
            if ((st.isAir() || st.canBeReplaced()) && !st.is(ModBlocks.DUCT_TAPE_STRIP.get())
                    && level.getBlockState(pos.below()).isFaceSturdy(level, pos.below(), Direction.UP)) {
                return ref + dy;
            }
        }
        return Integer.MIN_VALUE;
    }

    /**
     * Isi petak dari s.next sampai `last` (termasuk) dengan blok tape.
     * Petak yang terhalang dilewati. Berhenti kalau roll habis. Mengembalikan false kalau berhenti karena roll habis.
     */
    public static boolean fill(ServerLevel level, ServerPlayer p, Session s, int last, double yRef) {
        while (s.next <= last) {
            BlockPos flat = s.cell(s.next, 0);
            int y = findY(level, flat.getX(), flat.getZ(), yRef);
            if (y != Integer.MIN_VALUE) {
                BlockPos pos = new BlockPos(flat.getX(), y, flat.getZ());
                if (!consumeUnit(p)) return false;
                BlockState st = ModBlocks.DUCT_TAPE_STRIP.get().defaultBlockState()
                        .setValue(DuctTapeBlock.AXIS, s.axis == 0 ? Direction.Axis.X : Direction.Axis.Z);
                level.setBlock(pos, st, Block.UPDATE_ALL);
                SoundType snd = SoundType.WOOL;
                level.playSound(null, pos, snd.getPlaceSound(), SoundSource.BLOCKS, 0.5f, 1.3f);
            }
            s.next++;
        }
        return true;
    }

    /** Sneak + tangan kosong di anchor: hapus tape yang menempel (4 arah, mengikuti perubahan tinggi). */
    public static int reel(ServerLevel level, BlockPos anchor) {
        int removed = 0;
        for (Direction d : Direction.Plane.HORIZONTAL) {
            Direction.Axis axis = d.getAxis();
            int y = anchor.getY();
            for (int k = 1; k <= MAX_LEN; k++) {
                boolean found = false;
                for (int dy : new int[]{0, 1, -1}) {
                    BlockPos pos = new BlockPos(anchor.getX() + d.getStepX() * k, y + dy, anchor.getZ() + d.getStepZ() * k);
                    BlockState st = level.getBlockState(pos);
                    if (st.is(ModBlocks.DUCT_TAPE_STRIP.get()) && st.getValue(DuctTapeBlock.AXIS) == axis) {
                        level.removeBlock(pos, false);
                        y = pos.getY();
                        removed++;
                        found = true;
                        break;
                    }
                }
                if (!found) break;
            }
        }
        return removed;
    }

    @SubscribeEvent
    public static void onTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p)) return;
        Session s = SESSIONS.get(p.getUUID());
        if (s == null) return;
        ServerLevel level = p.serverLevel();
        if (!(level.getBlockState(s.a).getBlock() instanceof DuctAnchorBlock)) {
            SESSIONS.remove(p.getUUID());
            msg(p, "Anchor awal hilang. Sesi tape dibatalkan.");
            return;
        }

        double dx = p.getX() - (s.a.getX() + 0.5), dz = p.getZ() - (s.a.getZ() + 0.5);
        if (s.axis < 0) {
            if (Math.max(Math.abs(dx), Math.abs(dz)) < 1.3) return;
            if (Math.abs(dx) >= Math.abs(dz)) {
                s.axis = 0;
                s.dir = dx > 0 ? 1 : -1;
            } else {
                s.axis = 1;
                s.dir = dz > 0 ? 1 : -1;
            }
        }
        double along = (s.axis == 0 ? dx : dz) * s.dir;
        double lat = s.axis == 0 ? dz : dx;
        if (Math.abs(lat) > 1.0) {
            warn(p, "Keluar jalur: tape berhenti. Kembali ke garis lurus dari anchor awal.");
            return;
        }
        if (!p.onGround()) return;
        int last = Math.min(MAX_LEN, (int) Math.floor(along + 0.3));
        if (last >= s.next && !fill(level, p, s, last, p.getY())) {
            warn(p, "Roll habis. Pegang atau bawa Duct Tape lain, atau pasang anchor kedua.");
        }
    }

    @SubscribeEvent
    public static void onDimension(PlayerEvent.PlayerChangedDimensionEvent e) {
        SESSIONS.remove(e.getEntity().getUUID());
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        SESSIONS.remove(e.getEntity().getUUID());
        WARNED.remove(e.getEntity().getUUID());
    }
}
