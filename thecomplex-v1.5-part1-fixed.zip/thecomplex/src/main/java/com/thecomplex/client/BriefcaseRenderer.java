package com.thecomplex.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.thecomplex.ModItems;
import com.thecomplex.TheComplex;
import com.thecomplex.briefcase.BriefcaseEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.world.inventory.InventoryMenu;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/** Menggambar Briefcase di tanah (model item, rebah) dan tali yang menggantung darinya. */
public class BriefcaseRenderer extends EntityRenderer<BriefcaseEntity> {
    private static final ResourceLocation ROPE_TEX = new ResourceLocation(TheComplex.MODID, "textures/entity/rope.png");
    private static ItemStack STACK;
    private final ItemRenderer items;

    public BriefcaseRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.items = ctx.getItemRenderer();
        this.shadowRadius = 0.25f;
    }

    @Override
    public ResourceLocation getTextureLocation(BriefcaseEntity e) {
        return InventoryMenu.BLOCK_ATLAS;
    }

    @Override
    public void render(BriefcaseEntity e, float yaw, float partial, PoseStack ps, MultiBufferSource buf, int light) {
        if (STACK == null) STACK = new ItemStack(ModItems.BRIEFCASE.get());
        float ang = Mth.lerp(partial, e.yRotO, e.getYRot());
        ps.pushPose();
        ps.translate(0, 0.12, 0);
        ps.mulPose(Axis.YP.rotationDegrees(-ang));
        ps.mulPose(Axis.XP.rotationDegrees(-90f));
        if (e.tumble > 0f) {
            // berputar saat di udara
            ps.translate(0, 0, 0.0);
            ps.mulPose(Axis.XP.rotationDegrees(e.tumble + 26f * partial));
        }
        ps.scale(0.9f, 0.9f, 0.9f);
        items.renderStatic(STACK, ItemDisplayContext.FIXED, light, OverlayTexture.NO_OVERLAY, ps, buf, e.level(), e.getId());
        ps.popPose();

        float len = e.getRopeLen();
        if (len > 0.4f) {
            double ex = Mth.lerp(partial, e.xo, e.getX()), ey = Mth.lerp(partial, e.yo, e.getY()), ez = Mth.lerp(partial, e.zo, e.getZ());
            float hx = (float) (e.getRopeX() - ex), hz = (float) (e.getRopeZ() - ez);
            float topY = (float) (e.getRopeTop() + 0.1 - ey);
            VertexConsumer vc = buf.getBuffer(RenderType.entityCutoutNoCull(ROPE_TEX));
            // simpul ke tepi, lalu tali jatuh ke bawah
            ribbon(ps, vc, 0, 0.12f, 0, hx, topY, hz, 0.05f, light, 0f);
            int segs = (int) Math.ceil(len);
            for (int i = 0; i < segs; i++) {
                float y0 = topY - i, y1 = Math.max(topY - len, topY - i - 1);
                ribbon(ps, vc, hx, y0, hz, hx, y1, hz, 0.05f, light, 0f);
            }
        }
        super.render(e, yaw, partial, ps, buf, light);
    }

    /** Pita tipis dari p0 ke p1: dua bidang saling tegak lurus, bertekstur tali. */
    private static void ribbon(PoseStack ps, VertexConsumer vc, float x0, float y0, float z0, float x1, float y1, float z1, float w, int light, float v0) {
        Vector3f dir = new Vector3f(x1 - x0, y1 - y0, z1 - z0);
        float length = dir.length();
        if (length < 1e-4f) return;
        dir.div(length);
        Vector3f ref = Math.abs(dir.y) > 0.95f ? new Vector3f(1, 0, 0) : new Vector3f(0, 1, 0);
        Vector3f s1 = new Vector3f(dir).cross(ref).normalize().mul(w);
        Vector3f s2 = new Vector3f(dir).cross(s1).normalize().mul(w);
        PoseStack.Pose pose = ps.last();
        Matrix4f m = pose.pose();
        Matrix3f n = pose.normal();
        float vEnd = Math.min(1f, length);
        quad(vc, m, n, x0 - s1.x, y0 - s1.y, z0 - s1.z, x0 + s1.x, y0 + s1.y, z0 + s1.z,
                x1 + s1.x, y1 + s1.y, z1 + s1.z, x1 - s1.x, y1 - s1.y, z1 - s1.z, vEnd, light);
        quad(vc, m, n, x0 - s2.x, y0 - s2.y, z0 - s2.z, x0 + s2.x, y0 + s2.y, z0 + s2.z,
                x1 + s2.x, y1 + s2.y, z1 + s2.z, x1 - s2.x, y1 - s2.y, z1 - s2.z, vEnd, light);
    }

    private static void quad(VertexConsumer vc, Matrix4f m, Matrix3f n,
                             float ax, float ay, float az, float bx, float by, float bz,
                             float cx, float cy, float cz, float dx, float dy, float dz, float vEnd, int light) {
        v(vc, m, n, ax, ay, az, 0f, 0f, light);
        v(vc, m, n, bx, by, bz, 1f, 0f, light);
        v(vc, m, n, cx, cy, cz, 1f, vEnd, light);
        v(vc, m, n, dx, dy, dz, 0f, vEnd, light);
        // sisi belakang
        v(vc, m, n, dx, dy, dz, 0f, vEnd, light);
        v(vc, m, n, cx, cy, cz, 1f, vEnd, light);
        v(vc, m, n, bx, by, bz, 1f, 0f, light);
        v(vc, m, n, ax, ay, az, 0f, 0f, light);
    }

    private static void v(VertexConsumer vc, Matrix4f m, Matrix3f n, float x, float y, float z, float u, float vv, int light) {
        vc.vertex(m, x, y, z).color(255, 255, 255, 255).uv(u, vv)
                .overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(n, 0f, 1f, 0f).endVertex();
    }
}
