package com.thecomplex.client;

import com.thecomplex.TheComplex;
import com.thecomplex.briefcase.RopeHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.Input;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.LogicalSide;

/**
 * Memanjat tali di klien (gerak pemain lokal ditentukan klien).
 * Lompat = naik, sneak = turun, tanpa tombol = menggantung. Tanpa arah gerak, pemain ditarik ke titik gantung sedikit di luar tali (tali tidak menembus tubuh).
 * Menekan arah (WASD) melepas pegangan ke samping. Di ujung atas, berjalanlah keluar ke tepian.
 */
@Mod.EventBusSubscriber(modid = TheComplex.MODID, value = Dist.CLIENT)
public final class RopeClient {
    private RopeClient() {}

    @SubscribeEvent
    public static void onTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.side != LogicalSide.CLIENT) return;
        Minecraft mc = Minecraft.getInstance();
        if (!(e.player instanceof LocalPlayer p) || p != mc.player) return;
        if (p.getAbilities().flying || p.isPassenger() || p.isSpectator() || p.isDeadOrDying()) return;

        RopeHelper.Hit h = RopeHelper.find(p);
        if (h == null) return;
        p.fallDistance = 0f;

        Input in = p.input;
        boolean free = mc.screen == null;
        double y = p.getY();
        double vy = 0;
        if (free && in.jumping) vy = 0.2;
        else if (free && in.shiftKeyDown) vy = -0.2;

        if (vy > 0) {
            // jangan naik melewati permukaan tepian
            double room = h.top() + 0.02 - y;
            vy = room <= 0 ? 0 : Math.min(vy, room);
        }
        if (vy < 0 && y <= h.bottom() + 0.01) vy = 0;

        Vec3 d = p.getDeltaMovement();
        double vx = d.x, vz = d.z;
        boolean steering = free && (Math.abs(in.forwardImpulse) > 0.05f || Math.abs(in.leftImpulse) > 0.05f);
        boolean atTop = y >= h.top() - 0.01;
        if (!steering && !atTop) {
            vx = clamp((h.tx() - p.getX()) * 0.4, 0.08);
            vz = clamp((h.tz() - p.getZ()) * 0.4, 0.08);
        }
        p.setDeltaMovement(vx, vy, vz);
    }

    private static double clamp(double v, double m) {
        return Math.max(-m, Math.min(m, v));
    }
}
