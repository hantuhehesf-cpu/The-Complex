package com.thecomplex.client;

import com.thecomplex.TheComplex;
import com.thecomplex.briefcase.BriefcaseItem;
import com.thecomplex.net.Net;
import com.thecomplex.net.ThrowPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Posisi lempar Briefcase (hanya klien).
 *  - Klik kiri (Briefcase di tangan utama): masuk posisi lempar. Di dalam posisi lempar, klik kiri lagi menaikkan nilai (5 kembali ke 1).
 *  - Roda mouse: naik/turun nilai 1..5 (tidak mengganti hotbar selama posisi lempar).
 *  - Klik kanan: lempar (HANYA saat posisi lempar).
 *  - ESC, buka layar, atau ganti slot hotbar: batal.
 */
@Mod.EventBusSubscriber(modid = TheComplex.MODID, value = Dist.CLIENT)
public final class ThrowClient {
    public static boolean active;
    public static int power = 3;
    private static int slot;
    private static float zoom;

    private ThrowClient() {}

    public static void cancel() {
        active = false;
    }

    @SubscribeEvent
    public static void onInteract(InputEvent.InteractionKeyMappingTriggered e) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.screen != null) return;
        boolean briefcase = p.getMainHandItem().getItem() instanceof BriefcaseItem;
        if (!briefcase) {
            active = false;
            return;
        }
        if (e.isAttack()) {
            e.setCanceled(true);
            e.setSwingHand(false);
            if (!active) {
                active = true;
                slot = p.getInventory().selected;
            } else {
                power = power % BriefcaseItem.MAX_POWER + 1;
            }
        } else if (e.isUseItem() && active) {
            e.setCanceled(true);
            e.setSwingHand(false);
            if (e.getHand() == InteractionHand.MAIN_HAND) {
                Net.CHANNEL.sendToServer(new ThrowPacket(power));
                active = false;
            }
        }
    }

    @SubscribeEvent
    public static void onScroll(InputEvent.MouseScrollingEvent e) {
        if (!active) return;
        double d = e.getScrollDelta();
        if (d == 0) return;
        power = Math.max(1, Math.min(BriefcaseItem.MAX_POWER, power + (d > 0 ? 1 : -1)));
        e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (active && (p == null || mc.screen != null
                || p.getInventory().selected != slot
                || !(p.getMainHandItem().getItem() instanceof BriefcaseItem))) {
            active = false;
        }
        // zoom kamera saat layar Briefcase terbuka
        boolean open = mc.screen instanceof BriefcaseScreen;
        zoom = open ? Math.min(1f, zoom + 0.14f) : Math.max(0f, zoom - 0.14f);
    }

    @SubscribeEvent
    public static void onFov(ViewportEvent.ComputeFov e) {
        if (zoom <= 0f) return;
        float eased = 1f - (1f - zoom) * (1f - zoom);
        e.setFOV(e.getFOV() * (1.0 - 0.28 * eased));
    }
}
