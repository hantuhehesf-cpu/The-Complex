package com.thecomplex.briefcase;

import com.thecomplex.ModItems;
import com.thecomplex.block.WedgeBlock;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Half;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;

import java.util.UUID;

/**
 * Briefcase yang dilempar. Fisika: jatuh, memantul, meluncur turun di tangga dan baji.
 * Kalau tahu-tahu diam dan ada Rope di slotnya, tali menggantung dari tepi terdekat (maks. ropeMaxLength blok)
 * dan bisa dipanjat / dituruni (lihat RopeHelper dan RopeClient).
 * Klik kanan: buka inventori. Sneak + klik kanan: ambil.
 */
public class BriefcaseEntity extends Entity {
    private static final EntityDataAccessor<Float> ROPE_LEN = SynchedEntityData.defineId(BriefcaseEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> ROPE_X = SynchedEntityData.defineId(BriefcaseEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> ROPE_Z = SynchedEntityData.defineId(BriefcaseEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> ROPE_TOP = SynchedEntityData.defineId(BriefcaseEntity.class, EntityDataSerializers.FLOAT);

    private ItemStack stack = ItemStack.EMPTY;
    private UUID owner;
    private int rest;
    private float spin;

    public BriefcaseEntity(EntityType<? extends BriefcaseEntity> type, Level level) {
        super(type, level);
    }

    public void setStack(ItemStack s) {
        this.stack = s;
    }

    public ItemStack getStack() {
        return stack;
    }

    public void setOwner(UUID id) {
        this.owner = id;
    }

    public void setSpin(float s) {
        this.spin = s;
    }

    public float getRopeLen() {
        return entityData.get(ROPE_LEN);
    }

    public float getRopeX() {
        return entityData.get(ROPE_X);
    }

    public float getRopeZ() {
        return entityData.get(ROPE_Z);
    }

    public float getRopeTop() {
        return entityData.get(ROPE_TOP);
    }

    private void setRope(float len, double x, double z, double top) {
        entityData.set(ROPE_LEN, len);
        entityData.set(ROPE_X, (float) x);
        entityData.set(ROPE_Z, (float) z);
        entityData.set(ROPE_TOP, (float) top);
    }

    @Override
    protected void defineSynchedData() {
        entityData.define(ROPE_LEN, 0f);
        entityData.define(ROPE_X, 0f);
        entityData.define(ROPE_Z, 0f);
        entityData.define(ROPE_TOP, 0f);
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        stack = ItemStack.of(tag.getCompound("Stack"));
        if (tag.hasUUID("Owner")) owner = tag.getUUID("Owner");
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.put("Stack", stack.save(new CompoundTag()));
        if (owner != null) tag.putUUID("Owner", owner);
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }

    @Override
    public boolean isPickable() {
        return !isRemoved();
    }

    @Override
    public boolean isAttackable() {
        return false;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        return false;
    }

    @Override
    public ItemStack getPickResult() {
        return new ItemStack(ModItems.BRIEFCASE.get());
    }

    @Override
    public boolean isPushedByFluid() {
        return false;
    }

    private Direction slopeDown() {
        BlockPos p = BlockPos.containing(getX(), getY() - 0.05, getZ());
        BlockState s = level().getBlockState(p);
        if (s.getBlock() instanceof StairBlock && s.getValue(StairBlock.HALF) == Half.BOTTOM) return s.getValue(StairBlock.FACING);
        if (s.getBlock() instanceof WedgeBlock) return s.getValue(WedgeBlock.FACING).getOpposite();
        return null;
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        if (stack.isEmpty()) {
            discard();
            return;
        }

        if (getY() < level().getMinBuildHeight() - 32) {
            returnToOwner();
            return;
        }

        Vec3 v = getDeltaMovement().add(0, -0.04, 0);
        move(MoverType.SELF, v);
        Vec3 a = getDeltaMovement();
        double nx = a.x, ny = a.y, nz = a.z;
        if (horizontalCollision) {
            if (Math.abs(a.x) < 1e-5 && Math.abs(v.x) > 0.02) nx = -v.x * 0.4;
            if (Math.abs(a.z) < 1e-5 && Math.abs(v.z) > 0.02) nz = -v.z * 0.4;
            spin *= 0.6f;
        }

        boolean ground = this.onGround();
        Direction down = ground ? slopeDown() : null;
        if (ground) {
            if (v.y < -0.2) {
                ny = -v.y * 0.3;
                level().playSound(null, blockPosition(), SoundEvents.WOOL_FALL, SoundSource.NEUTRAL, 0.8f, 0.7f);
            } else {
                ny = 0;
            }
            if (down != null) {
                // tangga / baji: meluncur ke arah turun
                nx = nx * 0.93 + down.getStepX() * 0.045;
                nz = nz * 0.93 + down.getStepZ() * 0.045;
            } else {
                nx *= 0.55;
                nz *= 0.55;
            }
            spin *= 0.75f;
        } else {
            nx *= 0.99;
            nz *= 0.99;
            ny *= 0.98;
        }
        setDeltaMovement(nx, ny, nz);
        setYRot(getYRot() + spin);
        if (Math.abs(spin) < 0.5f) spin = 0;

        boolean still = ground && down == null && nx * nx + nz * nz < 1.0e-5 && Math.abs(ny) < 0.01;
        if (still) {
            rest++;
            if (rest == 6) computeRope();
        } else {
            if (rest != 0 && getRopeLen() > 0) setRope(0f, 0, 0, 0);
            rest = 0;
        }
    }

    private boolean free(BlockPos p) {
        return level().getBlockState(p).getCollisionShape(level(), p).isEmpty();
    }

    private void computeRope() {
        if (BriefcaseData.getRope(stack).isEmpty()) {
            setRope(0f, 0, 0, 0);
            return;
        }
        int max = BriefcaseConfig.ROPE_MAX.get();
        BlockPos base = BlockPos.containing(getX(), getY() + 0.05, getZ());
        int bestDepth = 0;
        BlockPos best = null;
        for (Direction d : Direction.Plane.HORIZONTAL) {
            BlockPos n = base.relative(d);
            if (!free(n)) continue;
            int depth = 0;
            while (depth < max && free(n.below(depth + 1))) depth++;
            if (depth > bestDepth) {
                bestDepth = depth;
                best = n;
            }
        }
        if (best == null) {
            setRope(0f, 0, 0, 0);
            return;
        }
        // ujung atas tali = tinggi permukaan tempat Briefcase bertumpu
        setRope(bestDepth, best.getX() + 0.5, best.getZ() + 0.5, base.getY());
    }

    @Override
    public InteractionResult interact(Player player, InteractionHand hand) {
        if (level().isClientSide) return InteractionResult.SUCCESS;
        if (player instanceof ServerPlayer sp) {
            if (sp.isShiftKeyDown()) pickup(sp);
            else BriefcaseSessions.openEntity(sp, this);
        }
        return InteractionResult.CONSUME;
    }

    private void pickup(ServerPlayer sp) {
        ItemStack s = stack;
        stack = ItemStack.EMPTY;
        if (!sp.getInventory().add(s)) sp.drop(s, false);
        level().playSound(null, blockPosition(), SoundEvents.ARMOR_EQUIP_LEATHER, SoundSource.PLAYERS, 0.8f, 1.0f);
        discard();
    }

    /** Jatuh ke void: kembalikan ke pemilik kalau masih online. */
    private void returnToOwner() {
        if (!level().isClientSide && owner != null && level().getServer() != null) {
            ServerPlayer o = level().getServer().getPlayerList().getPlayer(owner);
            if (o != null && !stack.isEmpty()) {
                if (!o.getInventory().add(stack)) o.drop(stack, false);
                stack = ItemStack.EMPTY;
            }
        }
        discard();
    }
}
