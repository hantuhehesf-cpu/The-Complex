package com.thecomplex.briefcase;

import com.thecomplex.ModItems;
import com.thecomplex.block.WedgeBlock;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Half;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;

import java.util.UUID;

/**
 * Briefcase yang dilempar. Fisika: jatuh, memantul, meluncur turun di tangga dan baji.
 * Kalau tahu-tahu diam dan ada Rope di slotnya, tali menggantung dari tepi terdekat (maks. ropeMaxLength blok)
 * dan bisa dipanjat / dituruni (lihat RopeHelper dan RopeClient).
 * Klik kanan: buka inventori. Sneak + klik kanan: ambil.
 */
public class BriefcaseEntity extends Entity {
    private static final EntityDataAccessor<Float> ROPE_LEN = SynchedEntityData.defineId(BriefcaseEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> ROPE_X = SynchedEntityData.defineId(BriefcaseEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> ROPE_Z = SynchedEntityData.defineId(BriefcaseEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> ROPE_TOP = SynchedEntityData.defineId(BriefcaseEntity.class, EntityDataSerializers.FLOAT);

    private static final EntityDataAccessor<Integer> ROPE_DIR = SynchedEntityData.defineId(BriefcaseEntity.class, EntityDataSerializers.INT);

    private static final double GRAVITY = 0.04;
    private static final double WALL_BOUNCE = 0.12;
    private static final double GROUND_BOUNCE = 0.10;
    private static final double LAND_KEEP = 0.70;      // sisa kecepatan datar saat mendarat
    private static final double MAX_SLIDE = 0.30;

    private ItemStack stack = ItemStack.EMPTY;
    private UUID owner;
    private int rest;
    private boolean sleeping;
    private boolean wasGround;
    /** hanya klien, untuk animasi berputar saat di udara */
    public float tumble;

    public BriefcaseEntity(EntityType<? extends BriefcaseEntity> type, Level level) {
        super(type, level);
    }

    public void setStack(ItemStack s) {
        this.stack = s;
    }

    public ItemStack getStack() {
        return stack;
    }

    public void setOwner(UUID id) {
        this.owner = id;
    }

    public float getRopeLen() {
        return entityData.get(ROPE_LEN);
    }

    public float getRopeX() {
        return entityData.get(ROPE_X);
    }

    public float getRopeZ() {
        return entityData.get(ROPE_Z);
    }

    public float getRopeTop() {
        return entityData.get(ROPE_TOP);
    }

    /** Arah tepi (dari Briefcase menuju kolom tali); pemain menggantung sedikit di sisi ini. */
    public Direction getRopeDir() {
        return Direction.from2DDataValue(entityData.get(ROPE_DIR));
    }

    private void setRope(float len, double x, double z, double top, Direction dir) {
        entityData.set(ROPE_LEN, len);
        entityData.set(ROPE_X, (float) x);
        entityData.set(ROPE_Z, (float) z);
        entityData.set(ROPE_TOP, (float) top);
        entityData.set(ROPE_DIR, dir.get2DDataValue());
    }

    /**
     * Kotak untuk culling kamera mencakup seluruh tali. Tanpa ini tali ikut hilang begitu
     * Briefcase (yang kecil) keluar dari layar, padahal talinya masih terlihat.
     */
    @Override
    public AABB getBoundingBoxForCulling() {
        AABB box = getBoundingBox().inflate(0.4);
        float len = getRopeLen();
        if (len > 0.4f) {
            double rx = getRopeX(), rz = getRopeZ(), top = getRopeTop();
            box = box.minmax(new AABB(rx - 0.4, top - len - 0.2, rz - 0.4, rx + 0.4, top + 0.4, rz + 0.4));
        }
        return box;
    }

    @Override
    public boolean shouldRenderAtSqrDistance(double distSqr) {
        return distSqr < 80.0 * 80.0;
    }

    @Override
    protected void defineSynchedData() {
        entityData.define(ROPE_LEN, 0f);
        entityData.define(ROPE_X, 0f);
        entityData.define(ROPE_Z, 0f);
        entityData.define(ROPE_TOP, 0f);
        entityData.define(ROPE_DIR, 0);
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        stack = ItemStack.of(tag.getCompound("Stack"));
        if (tag.hasUUID("Owner")) owner = tag.getUUID("Owner");
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.put("Stack", stack.save(new CompoundTag()));
        if (owner != null) tag.putUUID("Owner", owner);
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }

    @Override
    public boolean isPickable() {
        return !isRemoved();
    }

    @Override
    public boolean isAttackable() {
        return false;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        return false;
    }

    @Override
    public ItemStack getPickResult() {
        return new ItemStack(ModItems.BRIEFCASE.get());
    }

    @Override
    public boolean isPushedByFluid() {
        return false;
    }

    private Direction slopeDown() {
        BlockPos p = BlockPos.containing(getX(), getY() - 0.05, getZ());
        BlockState s = level().getBlockState(p);
        if (s.getBlock() instanceof StairBlock && s.getValue(StairBlock.HALF) == Half.BOTTOM) return s.getValue(StairBlock.FACING);
        if (s.getBlock() instanceof WedgeBlock) return s.getValue(WedgeBlock.FACING).getOpposite();
        return null;
    }

    /**
     * Fisika berjalan di KLIEN dan SERVER dengan kode yang sama (seperti item/proyektil vanilla):
     * klien memprediksi gerakan sendiri sehingga mulus, server hanya mengoreksi posisi.
     * Benda yang sudah diam "tidur": tidak disimulasikan tiap tick, hanya dicek lantainya tiap 10 tick.
     */
    @Override
    public void tick() {
        super.tick();
        boolean client = level().isClientSide;
        if (!client) {
            if (stack.isEmpty()) {
                discard();
                return;
            }
            if (getY() < level().getMinBuildHeight() - 32) {
                returnToOwner();
                return;
            }
        }

        if (sleeping) {
            if ((tickCount + getId()) % 10 != 0) return;
            // cek lantai: masih ada? (move kecil ke bawah)
            move(MoverType.SELF, new Vec3(0, -GRAVITY, 0));
            if (this.onGround()) {
                setDeltaMovement(Vec3.ZERO);
                return;
            }
            sleeping = false;
            rest = 0;
            if (!client && getRopeLen() > 0) setRope(0f, 0, 0, 0, Direction.NORTH);
        }

        Vec3 v = getDeltaMovement().add(0, -GRAVITY, 0);
        move(MoverType.SELF, v);
        Vec3 a = getDeltaMovement();
        double nx = a.x, ny = a.y, nz = a.z;

        if (horizontalCollision) {
            // dinding: pantulan kecil saja
            if (Math.abs(a.x) < 1e-5 && Math.abs(v.x) > 0.02) nx = -v.x * WALL_BOUNCE;
            if (Math.abs(a.z) < 1e-5 && Math.abs(v.z) > 0.02) nz = -v.z * WALL_BOUNCE;
        }

        boolean ground = this.onGround();
        Direction down = null;
        if (ground) {
            if (!wasGround) {
                // baru mendarat: kehilangan momentum
                if (v.y < -0.12 && !client) {
                    level().playSound(null, blockPosition(), SoundEvents.WOOL_FALL, SoundSource.NEUTRAL, 0.7f, 0.7f);
                }
                nx *= LAND_KEEP;
                nz *= LAND_KEEP;
                ny = v.y < -0.35 ? -v.y * GROUND_BOUNCE : 0;
            } else {
                ny = 0;
            }
            down = slopeDown();
            if (down != null) {
                // tangga / baji: meluncur turun, kecepatan dibatasi
                nx = nx * 0.93 + down.getStepX() * 0.045;
                nz = nz * 0.93 + down.getStepZ() * 0.045;
                double h2 = nx * nx + nz * nz;
                if (h2 > MAX_SLIDE * MAX_SLIDE) {
                    double k = MAX_SLIDE / Math.sqrt(h2);
                    nx *= k;
                    nz *= k;
                }
            } else {
                BlockPos under = BlockPos.containing(getX(), getY() - 0.5, getZ());
                float f = level().getBlockState(under).getFriction(level(), under, this) * 0.8f;
                nx *= f;
                nz *= f;
            }
        } else {
            nx *= 0.99;
            nz *= 0.99;
            ny *= 0.98;
        }
        wasGround = ground;
        setDeltaMovement(nx, ny, nz);

        if (client) {
            tumble = ground ? 0f : tumble + 26f;
        }

        boolean still = ground && down == null && nx * nx + nz * nz < 4.0e-4 && Math.abs(ny) < 0.01;
        if (still) {
            setDeltaMovement(Vec3.ZERO);
            rest++;
            if (!client && rest == 6) computeRope();
            if (rest >= 8) sleeping = true;
        } else {
            if (rest != 0 && !client && getRopeLen() > 0) setRope(0f, 0, 0, 0, Direction.NORTH);
            rest = 0;
        }
    }

    private boolean free(BlockPos p) {
        return level().getBlockState(p).getCollisionShape(level(), p).isEmpty();
    }

    private void computeRope() {
        if (BriefcaseData.getRope(stack).isEmpty()) {
            setRope(0f, 0, 0, 0, Direction.NORTH);
            return;
        }
        int max = BriefcaseConfig.ROPE_MAX.get();
        BlockPos base = BlockPos.containing(getX(), getY() + 0.05, getZ());
        int bestDepth = 0;
        BlockPos best = null;
        Direction bestDir = Direction.NORTH;
        for (Direction d : Direction.Plane.HORIZONTAL) {
            BlockPos n = base.relative(d);
            if (!free(n)) continue;
            int depth = 0;
            while (depth < max && free(n.below(depth + 1))) depth++;
            if (depth > bestDepth) {
                bestDepth = depth;
                best = n;
                bestDir = d;
            }
        }
        if (best == null) {
            setRope(0f, 0, 0, 0, Direction.NORTH);
            return;
        }
        // ujung atas tali = tinggi permukaan tempat Briefcase bertumpu
        setRope(bestDepth, best.getX() + 0.5, best.getZ() + 0.5, base.getY(), bestDir);
    }

    @Override
    public InteractionResult interact(Player player, InteractionHand hand) {
        if (level().isClientSide) return InteractionResult.SUCCESS;
        if (player instanceof ServerPlayer sp) {
            if (sp.isShiftKeyDown()) pickup(sp);
            else BriefcaseSessions.openEntity(sp, this);
        }
        return InteractionResult.CONSUME;
    }

    private void pickup(ServerPlayer sp) {
        ItemStack s = stack;
        stack = ItemStack.EMPTY;
        if (!sp.getInventory().add(s)) sp.drop(s, false);
        level().playSound(null, blockPosition(), SoundEvents.ARMOR_EQUIP_LEATHER, SoundSource.PLAYERS, 0.8f, 1.0f);
        discard();
    }

    /** Jatuh ke void: kembalikan ke pemilik kalau masih online. */
    private void returnToOwner() {
        if (!level().isClientSide && owner != null && level().getServer() != null) {
            ServerPlayer o = level().getServer().getPlayerList().getPlayer(owner);
            if (o != null && !stack.isEmpty()) {
                if (!o.getInventory().add(stack)) o.drop(stack, false);
                stack = ItemStack.EMPTY;
            }
        }
        discard();
    }
}
