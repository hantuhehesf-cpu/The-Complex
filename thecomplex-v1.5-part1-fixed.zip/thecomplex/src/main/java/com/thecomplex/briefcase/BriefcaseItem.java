package com.thecomplex.briefcase;

import com.thecomplex.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * Exploration Briefcase.
 * Klik kanan (di luar posisi lempar): buka inventori. Klik kiri: masuk posisi lempar (klien, lihat ThrowClient).
 */
public class BriefcaseItem extends Item {
    public BriefcaseItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide && player instanceof ServerPlayer sp) {
            int slot = hand == InteractionHand.MAIN_HAND ? sp.getInventory().selected : 40;
            BriefcaseSessions.openHand(sp, slot);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    /** Klik kiri tidak boleh merusak blok (dipakai untuk posisi lempar). */
    @Override
    public boolean canAttackBlock(BlockState state, Level level, BlockPos pos, Player player) {
        return false;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tips, TooltipFlag flag) {
        tips.add(Component.literal("Klik kanan: buka. Klik kiri: posisi lempar."));
        int n = BriefcaseData.read(stack).size();
        tips.add(Component.literal("Isi: " + n + " item" + (BriefcaseData.getRope(stack).isEmpty() ? "" : " + tali")));
    }

    /** Jumlah bar kekuatan lempar. Kekuatan 5 = sekitar 8 blok. */
    public static final int MAX_POWER = 5;

    /**
     * Dipanggil server saat klien mengirim lemparan. Lemparan selalu mendatar (tidak terbang):
     * hanya sedikit lengkung, arah vertikal pandangan berpengaruh kecil. Kekuatan 1..5 = sekitar 1,6 sampai 8 blok.
     */
    public static void throwFrom(ServerPlayer p, int power) {
        ItemStack held = p.getMainHandItem();
        if (!(held.getItem() instanceof BriefcaseItem)) return;
        power = Mth.clamp(power, 1, MAX_POWER);
        BriefcaseEntity e = new BriefcaseEntity(ModEntities.BRIEFCASE.get(), p.level());
        e.setStack(held.copy());
        e.setOwner(p.getUUID());

        Vec3 look = p.getLookAngle();
        Vec3 flat = new Vec3(look.x, 0, look.z);
        if (flat.lengthSqr() < 1.0e-4) flat = Vec3.directionFromRotation(0f, p.getYRot());
        flat = flat.normalize();
        double speed = 0.15 * power;
        double vy = 0.04 + Mth.clamp(look.y, -0.5, 0.4) * 0.10;

        e.moveTo(p.getX() + flat.x * 0.35, p.getEyeY() - 0.3, p.getZ() + flat.z * 0.35, p.getYRot(), 0f);
        if (!p.level().noCollision(e)) e.moveTo(p.getX(), p.getEyeY() - 0.3, p.getZ(), p.getYRot(), 0f);
        e.setDeltaMovement(flat.x * speed, vy, flat.z * speed);
        p.level().addFreshEntity(e);
        p.setItemInHand(InteractionHand.MAIN_HAND, ItemStack.EMPTY);
        p.level().playSound(null, p.blockPosition(), SoundEvents.SNOWBALL_THROW, SoundSource.PLAYERS, 0.7f, 0.7f);
        p.swing(InteractionHand.MAIN_HAND, true);
    }
}
