package com.thecomplex.briefcase;

import net.minecraft.core.Direction;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

import java.util.List;

/** Menentukan apakah pemain sedang berada di tali yang menggantung dari sebuah Briefcase. Dipakai klien dan server. */
public final class RopeHelper {
    /** x,z = garis tali; tx,tz = tempat pemain menggantung (sedikit di luar tali, supaya tali tidak menembus tubuh). */
    public record Hit(BriefcaseEntity entity, double top, double bottom, double x, double z, double tx, double tz) {}

    public static final double HANG_OFFSET = 0.45;

    private RopeHelper() {}

    public static Hit find(Player p) {
        Level level = p.level();
        List<BriefcaseEntity> list = level.getEntitiesOfClass(BriefcaseEntity.class, p.getBoundingBox().inflate(1.0, 14.0, 1.0));
        for (BriefcaseEntity e : list) {
            float len = e.getRopeLen();
            if (len < 0.5f) continue;
            double top = e.getRopeTop();
            double bottom = top - len;
            double dx = p.getX() - e.getRopeX(), dz = p.getZ() - e.getRopeZ();
            if (dx * dx + dz * dz > 0.95 * 0.95) continue;
            double y = p.getY();
            if (y < bottom - 0.3 || y > top + 0.9) continue;
            Direction d = e.getRopeDir();
            return new Hit(e, top, bottom, e.getRopeX(), e.getRopeZ(),
                    e.getRopeX() + d.getStepX() * HANG_OFFSET, e.getRopeZ() + d.getStepZ() * HANG_OFFSET);
        }
        return null;
    }
}
