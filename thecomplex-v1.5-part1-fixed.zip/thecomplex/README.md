# The Complex — Forge 1.20.1

Belum dikompilasi atau diuji di sini, jadi build pertama kemungkinan butuh perbaikan kecil.

## Build
GitHub Actions (build.yml ada di percakapan). Java 17. Jar ada di artifact `thecomplex-jar`.

## Schematic (.schem WorldEdit) ada DI DALAM mod
- Main Chamber bawaan: `src/main/resources/data/thecomplex/schem/main_chamber.schem`
- Ruangan bawaan: `src/main/resources/data/thecomplex/schem/rooms/*.schem`
- Lewat GitHub: upload file `.schem` ke halaman utama repo (sebelahnya ZIP). Workflow otomatis memasukkannya ke mod:
  nama `mainchamber` / `main_chamber` / `Main Chamber` = Main Chamber, nama lain = ruangan.
- Uji cepat tanpa build ulang (opsional): `config/thecomplex/main_chamber.schem` dan `config/thecomplex/rooms/` diutamakan
  daripada yang di dalam mod. Hapus isinya kalau ingin memakai versi bawaan mod.
- Aturan ruangan: titik (0,0,0) schematic = sudut barat laut lantai; lapisan paling bawah = lantai (y=16); ukuran maksimal 64x64
  (4x4 chunk); tinggi udara bebas (3 sampai 6 atau lebih). Pakai blok saja (tanpa entitas/isi chest).
- Main Chamber ditaruh sejajar chunk di sekitar (0,0). Bukaan di dinding luarnya (posisi, lebar, tinggi bebas) tembus ke Backrooms.
  Blok `thecomplex:threshold` di dalamnya = pintu ke dunia luar; titik tiba dihitung dari posisinya.
  Setelah mengganti Main Chamber: hapus folder `dimensions/thecomplex/the_complex` di save dunia.

## Backrooms prosedural: sistem divisi
Dunia dibagi jadi wilayah 8x8 chunk (128x128 blok) yang disebut **divisi**. Ada tiga:

| Divisi | Nama | Udara | Peluang wilayah | Ciri |
|---|---|---|---|---|
| A | Standar | 3 | 60% | campuran pola Labirin + Standar, lampu normal |
| D | Tanpa Lampu (No Lighting Tile) | 3 | 20% | tidak ada panel lampu sama sekali |
| F | Fragmen | 4 | 20% | aula lapang; fragmen Overworld paling sering muncul (6% chunk) |

Tinggi atap tetap di seluruh divisi (tidak berubah di tengah aula). Di batas divisi yang tingginya beda, sisi chunk dibuat tembok
atau pintu, tidak terbuka penuh. Di atas atap diisi wallpaper, bukan bedrock. Pengaturan ada di `Division.java`.

**Ruangan .schem:** nama file bisa memuat dua kode di akhir:
- `@` + huruf divisi: `pitfalls@A.schem` (hanya divisi A), `kantor@AD.schem` (A dan D). Tanpa `@` = semua divisi.
- `#` + angka kelangkaan: `#1` biasa (default), `#2` setengah sebanyak #1, `#3` seperempat, `#4` sangat jarang,
  **`#5` = hanya satu di seluruh dimensi**. Ruangan #5 ditaruh di satu slot yang ditentukan seed dunia, dalam jarak 8 slot
  (sekitar 512 blok) dari titik awal, di divisi yang diizinkan namanya.
- Contoh: `jalan_desa@A#2.schem`, `pintu_aneh@F#5.schem`.
Tiap slot 4x4 chunk berpeluang 30% memuat satu ruangan (`ComplexLayout.ROOM_CHANCE`).
Sisa chunk di luar ruangan (kalau ukurannya bukan kelipatan 16) diisi Backrooms prosedural lengkap dengan dinding dan lampu,
dan tembok/pilar prosedural dalam jarak 2 blok dari tepi ruangan dibersihkan supaya semua pintu ruangan tembus ke luar.

- Dengung panel lampu (`fluorescent_hum.ogg`) terus berputar di The Complex. Volume dasar: `HumSound.VOLUME`.
- Atap: 1 tile = 1 blok (tekstur `ceiling_tile`).

## Aktivitas, Null Zone, fragmen
- Tiap 5 detik di Overworld, chunk tempatmu dicatat (maks 256 chunk per pemain, menurun pelan).
- Null Zone alami **hanya muncul setelah sebuah LPMDS berhasil dibuka** di dunia ini (disimpan di data dunia; bisa diganti lewat Dev UI tab LPMDS,
  tombol "Null Zone alami ON/OFF"). Tombol uji di Dev UI tetap bisa membuatnya kapan saja.
- Null Zone dicek tiap 10 detik; peluang naik dari 1/360 (tempat asing) sampai 1/60 (tempat yang sangat sering kamu datangi).
  Muncul di dinding (1x2) atau lantai (2x2, dua blok dalam) bagian dalam ruangan, condong ke chunk dengan heat tertinggi.
- Null Zone menyamar sebagai blok aslinya (tampilannya meniru blok yang digantikan; blok berwarna biome seperti rumput tidak dipakai),
  dan memulihkannya setelah dipakai atau setelah 10-30 menit. Yang ditaruh manual / dari .schem permanen dan tampak seperti wallpaper.
- Fragmen Overworld (maks 12x9x12, disimpan di data dunia, maks 24): bangunan di tempat Null Zone muncul (peluang 30%), pohon,
  atau potongan struktur vanilla. Ditangkap otomatis sesekali (rata-rata ~5 menit per pemain) atau lewat Dev UI.
- Di Backrooms, fragmen muncul per divisi (0,3% di sebagian besar divisi, 6% di divisi F). Fragmen dipotong oleh atap Backrooms, atap tidak dinaikkan. Setiap fragmen: diputar acak, lantai sebagian jadi karpet, sebagian blok jadi wallpaper,
  dedaunan jadi wallpaper atau tetap ada tanpa luruh, dan ada lubang kecil. Peluangnya ada di `Division.java` (`fragmentPermille`).

## Developer UI (tanpa command)
Item **Complex Dev Tool** (creative tab "Tools & Utilities"): klik kanan. Hanya untuk OP atau mode kreatif.
Tab: Masuk (Main Chamber, Backrooms acak, keluar, ganti kreatif/survival, pulihkan nyawa), Null Zone (acak/lantai/dinding, tambah heat, reset heat),
**Pelacak** (daftar Null Zone yang baru muncul: ketuk baris untuk teleport, teleport ke terdekat, pulihkan semua),
Fragmen (tangkap bangunan/pohon/struktur, tempel acak, hapus semua), Ruangan (pilih, tempel, muat ulang).
Status (dimensi, Main Chamber, jumlah ruangan/fragmen/Null Zone terlacak, posisi, heat) tampil di bagian atas.
Selama Dev Tool dipegang: action bar menampilkan panah dan jarak ke Null Zone terdekat, dan sel udara yang menempel pada Null Zone
dalam radius 40 blok diberi percikan cahaya.
Command lama `/complex ...` masih ada.

## Mengganti Main Chamber lewat GitHub
Upload file `.schem` bernama `mainchamber` / `main_chamber` / `Main Chamber` ke halaman utama repo (sebelah ZIP). Workflow menyalinnya ke dalam mod
sebelum compile dan menggantikan Main Chamber bawaan. Setelah memasang mod baru: hapus folder `dimensions/thecomplex/the_complex` di save dunia,
dan hapus `config/thecomplex/main_chamber.schem` kalau ada (file di config selalu diutamakan).

## LPMDS + Threshold (butuh daya)
Cara pakai, berurutan:
1. Taruh **LPMDS**. Sambungkan sumber daya **Forge Energy (FE)** ke sisi mana pun: konverter FE dari Create: Power Grid,
   atau mod lain yang mengeluarkan FE (mis. alternator Create Crafts & Additions). Daya tersimpan di mesin (default 200.000 FE).
2. Pasang **LPMDS Emitter Chute** menempel di sisi mesin. Klik kanan memutar searah jarum jam (16 langkah, 22,5 derajat),
   sneak + klik (tangan kosong) berlawanan. Langkah 0 = selatan, 4 = barat, 8 = utara, 12 = timur.
3. Pakai **Magnetic Marker**: klik kanan LPMDS, lalu klik dua sel sudut berlawanan dari bingkai 2 lebar x 3 tinggi x 1 tebal
   (sel kosong di depan sisi blok yang diklik, seperti memasang blok). Garis kuning = bingkai, garis biru = tautan ke mesin.
   Sneak + klik menghapus penandaan.
4. Klik kanan LPMDS (tangan kosong) untuk memulai tes. Kalau ada masalah (daya, jarak, area terhalang), mesin menjelaskannya
   dan tes tidak dihitung.
5. **Tes 1, 2, 3 pasti gagal** (efek berbeda tiap tes: medan runtuh, lonjakan fasa, kunci gagal; ada camera shake, suara, partikel,
   dan log di chat). Setelah pendinginan 8 detik, ulangi. Jumlah tes gagal dan pendinginan bisa diubah di config.
6. **Tes akhir** berhasil kalau daya cukup (90.000 FE), area target kosong, dan chute menghadap bingkai (langkah terdekat ke arah bingkai).
   Sinar medan menunjukkan arah chute yang sebenarnya, jadi meleset terlihat jelas. Saat berhasil: layar "THRESHOLD STABIL",
   kilatan, guncangan panjang, dan 6 blok Threshold terbentuk. Threshold tetap terbuka sampai ditutup (sneak + klik, tangan kosong)
   atau mesin dihancurkan.
- Tanpa bingkai ditandai: medan mengikuti arah chute (atau arah depan mesin, kalau tanpa chute) dan membuka Threshold 3 blok di depannya.
- Konfigurasi: `config/thecomplex-common.toml` (requirePower, capacity, maxReceivePerTick, failedTestCost, finalTestCost,
  scriptedFailures, cooldownTicks, range). `requirePower=false` menjalankan mesin tanpa daya.
- Dev UI tab **LPMDS**: beri set (mesin + chute + marker), isi daya, anggap tes gagal selesai, buka/tutup paksa, reset, info mesin.
- Integrasi daya memakai antarmuka Forge Energy (tanpa dependensi kompilasi ke Create atau Power Grid). Create 1.20.1 saat ini
  versi 6.0.x, Power Grid 0.6.x untuk Forge 1.20.1 meminta Create 6.0.7+. Dependensi `create` dan `powergrid` dicatat opsional di mods.toml.

## Blok bangunan (yellow palette)
Setiap permukaan kuning punya dua varian: **Classic Wallpaper** (`wallpaper`, motif strip) dan **Plain Office Wall** (`office_wall`, kuning lebih terang, polos).
Ada juga **White Office Wall** (`white_wall`). Semuanya ada di creative tab Building Blocks.

| Bagian | Classic Wallpaper | Plain Office Wall |
|---|---|---|
| Blok penuh | `wallpaper` | `office_wall` (+ `white_wall`) |
| Slab horizontal | `wallpaper_slab` | `office_wall_slab` |
| Slab vertikal | `wallpaper_vertical_slab` | `office_wall_vertical_slab` |
| Lengkung (arch) | `wallpaper_arch` | `office_wall_arch` |
| Baji / lereng | `wallpaper_wedge` | `office_wall_wedge` |
| Tiang 12x12 | `wallpaper_pillar` | `office_wall_pillar` |
| Setengah tiang (menempel dinding) | `wallpaper_half_pillar` | `office_wall_half_pillar` |
| Setengah dinding (menyambung) | `wallpaper_half_wall` | `office_wall_half_wall` |

Tambahan: `carpet_wedge` (baji dengan tekstur karpet).
- Slab vertikal: klik sisi samping blok untuk menempel ke blok itu; klik sisi dalamnya dengan slab yang sama untuk menyatu jadi blok penuh.
- Lengkung: dipasang searah pandangan; cocok sebagai penutup atas ambang pintu (lorong 3 blok: lengkung di blok paling atas).
- Baji: naik ke arah pandangan saat dipasang; tumbukannya 8 anak tangga 2 piksel, jadi landai.
- Setengah dinding: sekat tipis setinggi 12 piksel yang menyambung otomatis (tag `minecraft:walls`), bisa dilompati.

## V1.5 Bagian I: Exploration Briefcase

Item baru (creative tab "Tools & Utilities", atau Dev UI tab **Tas** > "Beri set Briefcase"): `briefcase`, `flashlight`, `flashlight_battery`,
`duct_tape`, `duct_anchor` (blok, placeholder model Grindstone), `rope`. Pengaturan: `config/thecomplex-briefcase.toml`.

**Memakai Briefcase**
- Klik kanan (Briefcase di tangan): buka inventori. Kamera mendekat (FOV mengecil) dan Briefcase terbuka dari tengah.
- Klik kiri: masuk **posisi lempar**. Bar **5 segmen** muncul di bawah crosshair. Atur nilai dengan roda mouse (hotbar tidak berganti selama posisi lempar)
  atau klik kiri berulang (5 kembali ke 1; ini cara paling mudah di layar sentuh). **Klik kanan = lempar**, hanya saat bar tampil.
  Ganti slot hotbar, ESC, atau buka layar apa pun = batal. Lemparan selalu mendatar (tidak terbang): nilai 5 = sekitar 8 blok, nilai 1 = sekitar 1,6 blok.
- Fisika berjalan di klien dan server (mulus, tanpa menunggu server). Pantulan kecil, momentum hilang saat mendarat, dan benda yang sudah diam "tidur" (tidak membebani server). Di tanah **meluncur turun di tangga dan baji**. Klik kanan: buka inventori, sneak + klik kanan: ambil.
- Dev UI tab Tas > "Ambil Briefcase di tanah" mengembalikan semua Briefcase dalam radius 48 blok (kalau nyangkut).

**Inventori gaya Tetris (usulan 1)**: grid 8 lebar x 4 tinggi (`rows` di config, boleh 3). Cara pakai: klik benda di inventorimu (kotak emas), lalu klik petak
di grid. Bayangan hijau = muat, merah = tidak. Klik benda di grid lalu petak lain = pindahkan; klik slot inventorimu = ambil keluar.
Shift + klik = masuk ke tempat kosong pertama. Slot **Tali** di kanan khusus Rope (tiap Briefcase punya satu).
Ukuran tiap item (lebar x tinggi): Flashlight 1x2, Battery 1x1, Duct Tape 1x1, Duct Anchor 2x1, Rope 2x1, item lain 1x1.
Item mod lain (kamera, flare, radio) diatur di config `extraSizes`, format `"modid:item=2x2"` (contoh bawaan: `exposure:camera=2x2`).
Blok tidak bisa masuk (kecuali Duct Anchor). Memutar benda belum ada.

**Tali**: taruh Rope di slot Tali, lempar Briefcase. Kalau berhenti di tepian (sisi sebelahnya kosong ke bawah), tali menggantung dari tepi itu,
maksimal 12 blok (`ropeMaxLength`). Dekati tali: **lompat = naik, sneak = turun**, tanpa tombol = menggantung. Pemain menggantung sedikit di luar tali (tali tidak menembus tubuh). Tali tetap terlihat walau Briefcase-nya sudah keluar dari layar. Tekan arah jalan untuk melepas ke samping.
Di ujung atas, berjalanlah keluar ke tepian. Tali juga menahan jatuh. Tali yang menyentuh lantai dasar (selisih 0 blok) tidak dibuat.

**Senter**: klik kanan = nyala/mati. 2 slot baterai, 1 slot = 7 menit (`slotMinutes`). Isi ulang: pegang Flashlight Battery di tangan lain lalu klik kanan.
Cahaya dibuat dari blok cahaya tak terlihat di titik yang disorot, hanya saat senter dipegang. Blok itu menghapus dirinya sendiri kalau game mati mendadak.

**Duct Tape** (sekarang berupa **blok** di lantai, seperti Redstone: tidak menembus lantai, bisa dihancurkan satu per satu, tidak menjatuhkan item):
1. Pasang Duct Anchor, pegang Duct Tape, klik kanan anchor.
2. Jalan LURUS menjauh (arah terkunci ke sumbu X atau Z). Blok tape terpasang di lantai tempat kamu berjalan, 1 roll = 8 blok (roll cadangan di inventori dipakai otomatis). Keluar jalur >1 blok: tape berhenti sampai kembali.
3. Pasang anchor kedua tepat sejajar (satu garis dengan yang pertama), klik kanan: celah terakhir ditutup dan tape selesai.
Sneak + tangan kosong di anchor = gulung semua tape yang menempel padanya. Petak yang tidak punya lantai padat (misalnya di atas baji) dilewati.

**Yang belum ada / perlu diketahui**
- Belum ada resep crafting dan loot: semua lewat creative atau Dev UI.
- Memindahkan item di grid sudah ada tapi belum diuji (kamu bilang opsional): kalau ada masalah, cukup ambil keluar lalu masukkan lagi.
- Tali: server dedicated dengan `allow-flight=false` bisa menendang pemain yang menggantung >4 detik. Singleplayer aman.
- Model Briefcase, senter, dan tekstur masih placeholder buatan kode (16x16).
- Entity Culling: kalau tali masih hilang, pastikan `thecomplex:briefcase` ada di daftar skip/whitelist mod itu.

## Yang paling mungkin perlu dicek saat compile
- `RandomState.getOrCreateRandomFactory`, `Heightmap.primeHeightmaps`, `ViewportEvent.RenderFog`
- `BlockStateParser.parseForBlock`, `NbtIo.readCompressed`, `NbtUtils.readBlockState`, `SavedData`
- `IModFile.findResource` (SchemStore), `ModelEvent.ModifyBakingResult` dan `BakedModelWrapper` (MimicModel)
- `Screen.rebuildWidgets` (DevScreen), `AbstractTickableSoundInstance` (HumSound)
- Briefcase: `Entity.onGround` (field), `ItemRenderer.renderStatic` + `ItemDisplayContext`, `RenderLevelStageEvent`, `InputEvent.InteractionKeyMappingTriggered`/`MouseScrollingEvent`,
  `RegisterGuiOverlaysEvent`, `NetworkHooks.getEntitySpawningPacket`, `BlockBehaviour.Properties.replaceable()`, `ItemProperties.register`
- LPMDS: `ForgeCapabilities.ENERGY` + `LazyOptional`, `ForgeConfigSpec`, paket judul layar (`ClientboundSetTitleTextPacket`), `SoundEvents.WARDEN_SONIC_CHARGE`

## Fase berikutnya
V1.5 Bagian II, lalu entitas (Lifeform, lalu Still Lifes).
