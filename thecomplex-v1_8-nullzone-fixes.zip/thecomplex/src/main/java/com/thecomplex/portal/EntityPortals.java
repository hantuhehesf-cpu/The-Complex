package com.thecomplex.portal;

import com.thecomplex.ComplexTeleporter;
import com.thecomplex.TheComplex;
import com.thecomplex.block.NullZoneBlockEntity;
import com.thecomplex.block.NullZoneLife;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.portal.PortalInfo;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.util.ITeleporter;

import java.util.function.Function;

/**
 * Non-player entities walking, falling or dropping into a Null Zone (v1.8).
 *
 * Called from {@code NullZoneBlock.entityInside}. Uses the same portal plane as players, but with the middle of the
 * entity's bounding box instead of the eyes (mobs and items have very different eye heights).
 *  - Unstable Null Zone (Overworld only): the entity arrives in a random Backrooms spot. A floor Null Zone drops it in through
 *    the ceiling, exactly like a player. The Null Zone is used up, like it is for a player.
 *  - Stable Wild Null Zone: the entity goes to the other end (both directions work).
 *
 * Which entities: living entities (mobs, animals, villagers) and dropped items. Players are handled by PortalSystem.
 * Never moved: passengers and vehicles, leashed mobs, bosses and anything that refuses to change dimension.
 * If the destination has no room for the entity (for example a ghast), nothing happens and the entity stays where it is.
 */
public final class EntityPortals {
    /** Persistent-data key: game time until which this entity ignores Null Zones (also survives the dimension change). */
    private static final String COOLDOWN = "complex_ent_cd";
    private static final String LEGACY_LAST = "complex_ent_nz_last";
    private static final String LEGACY_COUNT = "complex_ent_nz_count";
    private static final int COOLDOWN_TICKS = 60;
    /** Hand-placed Null Zones (no portal plane): the entity must stay inside this many ticks, like players (8). */
    private static final int LEGACY_TRIGGER_TICKS = 8;

    private EntityPortals() {}

    /** Can this entity use Null Zones at all? */
    public static boolean canUse(Entity e) {
        if (e instanceof Player || e.isRemoved() || e.isPassenger() || e.isVehicle()) return false;
        if (!(e instanceof LivingEntity) && !(e instanceof ItemEntity)) return false;
        if (e instanceof Mob m && m.isLeashed()) return false;
        return e.canChangeDimensions();
    }

    public static void onInside(ServerLevel level, BlockPos pos, Entity e) {
        if (!canUse(e)) return;
        long now = level.getGameTime();
        CompoundTag data = e.getPersistentData();
        if (now < data.getLong(COOLDOWN)) return;
        if (!(level.getBlockEntity(pos) instanceof NullZoneBlockEntity nz)) return;
        boolean inComplex = level.dimension() == TheComplex.COMPLEX;
        Direction dir = nz.getNormal();

        if (dir == null) {
            // Null Zone without portal data (creative, .schem, old version): only works in the Overworld, after a few ticks inside.
            if (inComplex) return;
            int count = (now - data.getLong(LEGACY_LAST) <= 3) ? data.getInt(LEGACY_COUNT) + 1 : 1;
            data.putLong(LEGACY_LAST, now);
            data.putInt(LEGACY_COUNT, count);
            if (count >= LEGACY_TRIGGER_TICKS) {
                data.putInt(LEGACY_COUNT, 0);
                if (enterBackrooms(e, level, null)) {
                    for (int dx = -1; dx <= 1; dx++)
                        for (int dy = -1; dy <= 1; dy++)
                            for (int dz = -1; dz <= 1; dz++)
                                NullZoneLife.restore(level, pos.offset(dx, dy, dz));
                }
            }
            return;
        }
        if (!nz.isStable() && inComplex) return;

        Vec3 nv = new Vec3(dir.getStepX(), dir.getStepY(), dir.getStepZ());
        double mid = e.getBbHeight() * 0.5;
        Vec3 cur = new Vec3(e.getX(), e.getY() + mid, e.getZ());
        Vec3 prev = new Vec3(e.xo, e.yo + mid, e.zo);
        double sp = prev.dot(nv) - nz.getPlane(), sc = cur.dot(nv) - nz.getPlane();
        boolean crossed = (sp < 0 && sc >= 0) || (sp > 0 && sc <= 0);
        if (!crossed) return;
        Vec3 hit = prev.add(cur.subtract(prev).scale(sp / (sp - sc)));
        double mg = 0.3;
        if (dir.getAxis() != Direction.Axis.X && (hit.x < pos.getX() - mg || hit.x > pos.getX() + 1 + mg)) return;
        if (dir.getAxis() != Direction.Axis.Y && (hit.y < pos.getY() - mg || hit.y > pos.getY() + 1 + mg)) return;
        if (dir.getAxis() != Direction.Axis.Z && (hit.z < pos.getZ() - mg || hit.z > pos.getZ() + 1 + mg)) return;

        boolean ok;
        if (nz.isStable()) {
            ok = crossStable(e, nz, nv.scale(sc > sp ? 1 : -1));
        } else {
            ok = enterBackrooms(e, level, dir);
            if (ok) NullZoneLife.onTriggered(level, pos, nz);
        }
        if (!ok) data.putLong(COOLDOWN, now + COOLDOWN_TICKS);   // no room over there: do not retry every tick
    }

    // ---------------------------------------------------------------- destinations

    /** Unstable Null Zone: random Backrooms spot, far from the Main Chamber. normal DOWN (floor) = drop in through the ceiling. */
    private static boolean enterBackrooms(Entity e, ServerLevel from, Direction normal) {
        MinecraftServer server = from.getServer();
        if (server == null) return false;
        ServerLevel complex = server.getLevel(TheComplex.COMPLEX);
        if (complex == null) return false;
        RandomSource r = e.getRandom();
        BlockPos spot = ComplexTeleporter.findBackroomsSpot(complex, r, 8);
        if (spot == null) return false;

        float yaw = r.nextFloat() * 360f;
        Vec3 vel = ComplexTeleporter.rotateYaw(e.getDeltaMovement(), yaw - e.getYRot());
        boolean floor = normal == Direction.DOWN;
        if (floor || ComplexTeleporter.CEILING_DROP_FOR_WALLS) {
            ComplexTeleporter.Drop drop = ComplexTeleporter.prepareCeilingDrop(complex, spot, e.getBbHeight());
            if (drop != null) {
                if (move(e, complex, drop.pos(), yaw, ComplexTeleporter.dropVelocity(vel), drop.fallDistance())) return true;
                // no room for this entity in the hole: close it again right away
                ComplexTeleporter.closeDrop(complex, drop);
                return false;
            }
        }
        Vec3 pos = new Vec3(spot.getX() + 0.5, spot.getY() + (floor ? 1.0 : 0.0), spot.getZ() + 0.5);
        return move(e, complex, pos, yaw, vel, 0f);
    }

    /** Stable Wild Null Zone: to the other end, out on the room side of that wall. */
    private static boolean crossStable(Entity e, NullZoneBlockEntity nz, Vec3 travel) {
        MinecraftServer server = e.getServer();
        if (server == null) return false;
        WildPortalData.End other = WildPortals.otherEnd(server, nz);
        if (other == null) return false;
        ServerLevel dest = WildPortals.levelOf(server, other);
        if (dest == null) return false;
        BlockPos oc = BlockPos.of(other.cell());
        Direction on = Direction.from3DDataValue(other.normal());
        dest.getChunk(oc.getX() >> 4, oc.getZ() >> 4);
        Vec3 exit = new Vec3(-on.getStepX(), 0, -on.getStepZ());
        double relY = Mth.clamp(e.getY() - nz.getAnchor().getY(), 0.0, 1.0);
        Vec3 np = new Vec3(oc.getX() + 0.5 + exit.x * 0.45, oc.getY() + relY, oc.getZ() + 0.5 + exit.z * 0.45);
        double dyaw = ComplexTeleporter.yawOf(exit) - ComplexTeleporter.yawOf(travel);
        float yaw = Mth.wrapDegrees((float) (e.getYRot() + dyaw));
        return move(e, dest, np, yaw, ComplexTeleporter.rotateYaw(e.getDeltaMovement(), dyaw), 0f);
    }

    // ---------------------------------------------------------------- the actual move

    /**
     * Moves the entity to another dimension. Returns false (and does nothing) when the destination box is not free.
     * Vanilla's default dimension entry point returns null for dimensions that are not the Nether or the End, so the
     * teleporter supplies the exact destination itself.
     */
    private static boolean move(Entity e, ServerLevel dest, Vec3 pos, float yaw, Vec3 vel, float fallDistance) {
        dest.getChunk(Mth.floor(pos.x) >> 4, Mth.floor(pos.z) >> 4);
        if (!dest.noCollision((Entity) null, e.getDimensions(e.getPose()).makeBoundingBox(pos))) return false;
        long now = e.level().getGameTime();
        e.getPersistentData().putLong(COOLDOWN, now + COOLDOWN_TICKS);   // copied to the new entity by the dimension change
        final float pitch = e.getXRot();
        Entity moved = e.changeDimension(dest, new ITeleporter() {
            @Override
            public PortalInfo getPortalInfo(Entity entity, ServerLevel destWorld, Function<ServerLevel, PortalInfo> defaultPortalInfo) {
                return new PortalInfo(pos, vel, yaw, pitch);
            }
        });
        if (moved == null) return false;
        moved.fallDistance = fallDistance;
        return true;
    }
}
